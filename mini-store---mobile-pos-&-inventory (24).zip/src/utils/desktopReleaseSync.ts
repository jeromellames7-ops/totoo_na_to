import { db } from '../lib/firebase';
import { doc, setDoc, onSnapshot } from 'firebase/firestore';
import { getEffectiveAccountId, getProducts, getSales, getUtangRecords, notifyDataChanged } from './storage';
import { pushCloudSync, pullCloudSync, getDeviceId } from './syncEngine';
import { getAllPdsImagesFromIndexedDB } from './pdsImageStorage';
import { getLocalPrintProjects } from './printStudioStorage';
import { getLocalElectricBills, getLocalWaterBills, getLocalGasRecords, getLocalMenstruationRecords, getLocalPillPlan } from './homeMonitoringStorage';
import { playSuccessChime } from './sound';
import { showSystemNotification } from './notificationHelper';

export const DESKTOP_DATA_RECEIVED_EVENT = 'tindahan_desktop_data_received_signal';
export const MOBILE_DATA_RECEIVED_EVENT = 'tindahan_mobile_data_received_signal';
export const CROSS_DEVICE_DATA_RECEIVED_EVENT = 'tindahan_cross_device_data_received_signal';
export const DESKTOP_RELEASE_SENT_EVENT = 'tindahan_desktop_release_sent_signal';

export interface ReleaseSummary {
  productsCount: number;
  salesCount: number;
  utangCount: number;
  printProjectsCount: number;
  billsCount: number;
  extractedDocsCount: number;
  activeTableRowsCount: number;
  pdsImagesCount: number;
  releasedAt: string;
  sourceDevice: string;
  targetDevice?: 'desktop' | 'mobile';
}

export interface DesktopReleaseSignal {
  accountId: string;
  targetDevice?: 'desktop' | 'mobile';
  deviceId: string;
  deviceName: string;
  timestamp: string;
  summary: ReleaseSummary;
}

// Detect device model or type
export function getDeviceTypeDescription(): string {
  if (typeof window === 'undefined') return 'Mobile Device';
  const ua = navigator.userAgent;
  if (/iPad|iPhone|iPod/.test(ua)) return 'iOS iPhone/iPad';
  if (/android/i.test(ua)) return 'Android Smartphone';
  if (/mobile/i.test(ua)) return 'Mobile Smartphone';
  if (/Macintosh|Mac OS X/.test(ua)) return 'Apple Mac Computer';
  if (/Windows/.test(ua)) return 'Windows Desktop PC / Laptop';
  if (/Linux/.test(ua)) return 'Linux Computer';
  return 'Desktop Computer / Laptop';
}

export function isCurrentDeviceMobile(): boolean {
  if (typeof window === 'undefined') return false;
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|mobile/i.test(navigator.userAgent) || window.innerWidth <= 768;
}

/**
 * Universal Data Releaser: Can send from Mobile -> Desktop OR from Desktop -> Mobile
 */
export async function triggerReleaseData(
  target: 'desktop' | 'mobile',
  targetAccountId?: string
): Promise<{ success: boolean; summary: ReleaseSummary; error?: string }> {
  const accountId = targetAccountId || getEffectiveAccountId();
  const deviceId = getDeviceId();
  const deviceName = getDeviceTypeDescription();

  try {
    // 1. Gather all POS data
    const products = getProducts(accountId);
    const sales = getSales(accountId);
    const utang = getUtangRecords(accountId);

    // 2. Gather Print Studio data
    const printProjects = getLocalPrintProjects();

    // 3. Gather Home Monitoring data
    const electricBills = getLocalElectricBills();
    const waterBills = getLocalWaterBills();
    const gasRecords = getLocalGasRecords();
    const menstruationRecords = getLocalMenstruationRecords();
    const pillPlan = getLocalPillPlan();
    const totalBills = electricBills.length + waterBills.length + gasRecords.length + menstruationRecords.length + (pillPlan ? 1 : 0);

    // 4. Gather Doc Extractor data
    let activeTable: any = null;
    try {
      const activeRaw =
        localStorage.getItem(`tindahan_doc_extracted_active_table_acc_${accountId}`) ||
        localStorage.getItem('tindahan_doc_extracted_active_table');
      if (activeRaw) activeTable = JSON.parse(activeRaw);
    } catch (e) {}

    let documents: any[] = [];
    try {
      const histRaw =
        localStorage.getItem(`tindahan_doc_extracted_history_acc_${accountId}`) ||
        localStorage.getItem('tindahan_doc_extracted_history');
      if (histRaw) documents = JSON.parse(histRaw);
    } catch (e) {}

    let pdsPictures: any[] = [];
    try {
      pdsPictures = await getAllPdsImagesFromIndexedDB(accountId);
    } catch (e) {}

    const summary: ReleaseSummary = {
      productsCount: products.length,
      salesCount: sales.length,
      utangCount: utang.length,
      printProjectsCount: printProjects.length,
      billsCount: totalBills,
      extractedDocsCount: documents.length,
      activeTableRowsCount: activeTable?.tables?.[0]?.rows?.length || 0,
      pdsImagesCount: pdsPictures.length,
      releasedAt: new Date().toISOString(),
      sourceDevice: deviceName,
      targetDevice: target,
    };

    // 5. Push POS and basic collections to Firebase
    try {
      await pushCloudSync(accountId);
    } catch (e) {
      console.warn('[Release Sync] POS sync warning:', e);
    }

    // 6. Push to Server endpoint with complete Data Bundle
    const endpoint = target === 'mobile' ? '/api/sync/release-to-mobile' : '/api/sync/release-to-desktop';
    try {
      await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accountId,
          targetDevice: target,
          deviceId,
          deviceName,
          summary,
          dataBundle: {
            docExtractor: {
              activeTable,
              documents,
              pdsPictures: pdsPictures.slice(0, 15),
            },
          },
        }),
      });
    } catch (e) {
      console.warn('[Release Sync] Server release endpoint warning:', e);
    }

    // 7. Write Signal Doc to Firestore for Realtime multi-client listener
    try {
      const signalKey = target === 'mobile' ? `mobile_sync_${accountId}` : `desktop_sync_${accountId}`;
      const signalRef = doc(db, 'system_signals', signalKey);
      await setDoc(
        signalRef,
        {
          accountId,
          targetDevice: target,
          deviceId,
          deviceName,
          timestamp: new Date().toISOString(),
          summary,
        },
        { merge: true }
      );
    } catch (e) {
      console.warn('[Release Sync] Firestore signal write warning:', e);
    }

    // Dispatch local notification event
    window.dispatchEvent(
      new CustomEvent(DESKTOP_RELEASE_SENT_EVENT, {
        detail: { accountId, target, summary },
      })
    );

    return { success: true, summary };
  } catch (err: any) {
    console.error(`[Release Sync] Error releasing data to ${target}:`, err);
    return {
      success: false,
      summary: {
        productsCount: 0,
        salesCount: 0,
        utangCount: 0,
        printProjectsCount: 0,
        billsCount: 0,
        extractedDocsCount: 0,
        activeTableRowsCount: 0,
        pdsImagesCount: 0,
        releasedAt: new Date().toISOString(),
        sourceDevice: deviceName,
        targetDevice: target,
      },
      error: err?.message || 'Error executing release',
    };
  }
}

/**
 * Triggered on MOBILE DEVICE: Releases all active data to the desktop computer
 */
export async function triggerReleaseDataToDesktop(targetAccountId?: string) {
  return triggerReleaseData('desktop', targetAccountId);
}

/**
 * Triggered on COMPUTER / DESKTOP: Releases all active data to the mobile device
 */
export async function triggerReleaseDataToMobile(targetAccountId?: string) {
  return triggerReleaseData('mobile', targetAccountId);
}

/**
 * Automatically listens for Cross-Device Release Signals (Mobile -> PC or PC -> Mobile)
 */
let lastReceivedTimestamp = '';
export function initDesktopReleaseListener(onSignalReceived?: (signal: DesktopReleaseSignal) => void) {
  const accountId = getEffectiveAccountId();
  const myDeviceId = getDeviceId();

  // 1. Listen to Firestore desktop & mobile signal docs
  const handleSnap = async (snap: any, expectedTarget: 'desktop' | 'mobile') => {
    if (!snap.exists()) return;
    const data = snap.data() as DesktopReleaseSignal;
    if (!data || !data.timestamp) return;

    // Prevent self-triggering loop if this device just sent it
    if (data.deviceId === myDeviceId) return;
    if (data.timestamp === lastReceivedTimestamp) return;

    // Check if signal is recent (within last 30 minutes)
    const signalAge = Date.now() - new Date(data.timestamp).getTime();
    if (signalAge > 30 * 60 * 1000) return;

    lastReceivedTimestamp = data.timestamp;

    // Trigger full automatic background sync across modules
    await handleIncomingDeviceData(data, expectedTarget);
    if (onSignalReceived) {
      onSignalReceived(data);
    }
  };

  try {
    const desktopSignalRef = doc(db, 'system_signals', `desktop_sync_${accountId}`);
    onSnapshot(desktopSignalRef, (snap) => handleSnap(snap, 'desktop'), (err) => console.warn(err));

    const mobileSignalRef = doc(db, 'system_signals', `mobile_sync_${accountId}`);
    onSnapshot(mobileSignalRef, (snap) => handleSnap(snap, 'mobile'), (err) => console.warn(err));
  } catch (e) {}

  // 2. Listen to Server SSE stream
  try {
    const eventSource = new EventSource('/api/doc-extractor/stream');
    eventSource.onmessage = async (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (
          (payload.type === 'DESKTOP_RELEASE_SIGNAL' || payload.type === 'MOBILE_RELEASE_SIGNAL') &&
          payload.accountId === accountId
        ) {
          const signal = payload.signal as DesktopReleaseSignal;
          const target = payload.targetDevice || (payload.type === 'MOBILE_RELEASE_SIGNAL' ? 'mobile' : 'desktop');
          if (signal && signal.deviceId !== myDeviceId && signal.timestamp !== lastReceivedTimestamp) {
            lastReceivedTimestamp = signal.timestamp;
            await handleIncomingDeviceData(signal, target);
            if (onSignalReceived) {
              onSignalReceived(signal);
            }
          }
        }
      } catch (e) {}
    };
  } catch (e) {}
}

async function handleIncomingDeviceData(signal: DesktopReleaseSignal, target: 'desktop' | 'mobile') {
  const accountId = signal.accountId || getEffectiveAccountId();

  // 1. Pull POS & Store Collections
  try {
    await pullCloudSync(accountId);
  } catch (e) {}

  // 2. Pull Doc Extractor state from server
  try {
    const res = await fetch(`/api/doc-extractor/pull?accountId=${encodeURIComponent(accountId)}`);
    const json = await res.json();
    if (json.success && json.data) {
      if (json.data.activeTable) {
        localStorage.setItem(`tindahan_doc_extracted_active_table_acc_${accountId}`, JSON.stringify(json.data.activeTable));
        localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(json.data.activeTable));
      }
      if (Array.isArray(json.data.documents) && json.data.documents.length > 0) {
        localStorage.setItem(`tindahan_doc_extracted_history_acc_${accountId}`, JSON.stringify(json.data.documents));
        localStorage.setItem('tindahan_doc_extracted_history', JSON.stringify(json.data.documents));
      }
    }
  } catch (e) {}

  // Notify UI
  notifyDataChanged();
  playSuccessChime();

  const isMobileTarget = target === 'mobile' || signal.targetDevice === 'mobile';
  const notifTitle = isMobileTarget
    ? '📱 Natanggap ang Data mula sa Desktop Computer!'
    : '🖥️ Natanggap ang Data mula sa Mobile Device!';
  const notifBody = isMobileTarget
    ? `Awtomatikong na-load sa iyong mobile device ang data mula sa ${signal.deviceName || 'Desktop Computer'}. Updated ang POS, Print Studio, Doc Extractor at Home Monitoring.`
    : `Awtomatikong na-load sa desktop computer ang data mula sa ${signal.deviceName || 'Mobile Phone'}. Updated ang POS, Print Studio, Doc Extractor at Home Monitoring.`;

  showSystemNotification(notifTitle, {
    body: notifBody,
    playSound: 'none',
  });

  const eventName = isMobileTarget ? MOBILE_DATA_RECEIVED_EVENT : DESKTOP_DATA_RECEIVED_EVENT;
  window.dispatchEvent(
    new CustomEvent(eventName, {
      detail: signal,
    })
  );
  window.dispatchEvent(
    new CustomEvent(CROSS_DEVICE_DATA_RECEIVED_EVENT, {
      detail: signal,
    })
  );
}
