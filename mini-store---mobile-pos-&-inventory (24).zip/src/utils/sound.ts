// Audio feedback using Web Audio API for fast offline sound synthesis

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

// Automatically resume audio context on first user touch/click for iOS Safari
if (typeof window !== 'undefined') {
  const unlockAudio = () => {
    try {
      const ctx = getAudioContext();
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const buffer = ctx.createBuffer(1, 1, 22050);
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(ctx.destination);
      source.start(0);
    } catch (e) {
      // ignore
    }
    window.removeEventListener('touchstart', unlockAudio);
    window.removeEventListener('click', unlockAudio);
  };
  window.addEventListener('touchstart', unlockAudio, { once: true });
  window.addEventListener('click', unlockAudio, { once: true });
}

/**
 * Play a high-pitched barcode scanner 'BEEP'
 */
export function playScanBeep() {
  try {
    const ctx = getAudioContext();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(1800, ctx.currentTime); // High barcode scanner tone
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.15);
  } catch (e) {
    console.warn('Audio context playback prevented:', e);
  }
}

/**
 * Play a success chime for completed checkout
 */
export function playSuccessChime() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    
    // Note 1 (C5)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.frequency.setValueAtTime(523.25, now);
    gain1.gain.setValueAtTime(0.12, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(now);
    osc1.stop(now + 0.15);

    // Note 2 (G5)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.frequency.setValueAtTime(783.99, now + 0.1);
    gain2.gain.setValueAtTime(0.15, now + 0.1);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(now + 0.1);
    osc2.stop(now + 0.35);
  } catch (e) {
    console.warn('Audio playback error:', e);
  }
}

/**
 * Play a warning alert sound for low stock
 */
export function playWarningBeep() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(400, now);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.25);
  } catch (e) {
    console.warn('Audio error:', e);
  }
}

/**
 * Play a triple-tone ascending chime for HP Smart Tank 580 connection
 */
export function playPrinterConnectedChime() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    const notes = [
      { freq: 659.25, time: 0, dur: 0.12 }, // E5
      { freq: 830.61, time: 0.1, dur: 0.12 }, // G#5
      { freq: 1046.5, time: 0.2, dur: 0.3 }, // C6
    ];

    notes.forEach((n) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(n.freq, now + n.time);
      gain.gain.setValueAtTime(0.18, now + n.time);
      gain.gain.exponentialRampToValueAtTime(0.001, now + n.time + n.dur);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + n.time);
      osc.stop(now + n.time + n.dur);
    });
  } catch (e) {
    console.warn('Printer sound error:', e);
  }
}

/**
 * Play an urgent multi-tone alert sound for LPG/Gasul 1-month due
 */
export function playLpgDueAlarm() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    // Triple alert pulse
    const tones = [
      { freq: 880, time: 0, dur: 0.15 },
      { freq: 700, time: 0.18, dur: 0.15 },
      { freq: 880, time: 0.36, dur: 0.15 },
      { freq: 700, time: 0.54, dur: 0.15 },
      { freq: 1040, time: 0.72, dur: 0.35 },
    ];

    tones.forEach((t) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(t.freq, now + t.time);
      gain.gain.setValueAtTime(0.25, now + t.time);
      gain.gain.exponentialRampToValueAtTime(0.001, now + t.time + t.dur);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + t.time);
      osc.stop(now + t.time + t.dur);
    });
  } catch (e) {
    console.warn('LPG alarm audio error:', e);
  }
}

/**
 * Play a soothing, melodious daily reminder chime for 7:00 PM Pill intake
 */
export function playPillReminderAlarm() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;

    // Gentle 4-tone marimba chime (F5, A5, C6, E6)
    const melody = [
      { freq: 698.46, time: 0, dur: 0.25 }, // F5
      { freq: 880.0, time: 0.18, dur: 0.25 }, // A5
      { freq: 1046.5, time: 0.36, dur: 0.3 }, // C6
      { freq: 1318.51, time: 0.54, dur: 0.5 }, // E6
      { freq: 1046.5, time: 0.9, dur: 0.6 }, // C6 resolve
    ];

    melody.forEach((m) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(m.freq, now + m.time);
      gain.gain.setValueAtTime(0.22, now + m.time);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + m.time + m.dur);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + m.time);
      osc.stop(now + m.time + m.dur);
    });
  } catch (e) {
    console.warn('Pill reminder audio error:', e);
  }
}

/**
 * Play haptic tick sound for two-finger pinch gesture
 */
export function playTickSound() {
  try {
    const ctx = getAudioContext();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1200, now);
    gain.gain.setValueAtTime(0.04, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.03);
  } catch (e) {
    // ignore
  }
}



