export type Language = 'tl' | 'en';

const LANG_STORAGE_KEY = 'tindahan_app_language_v1';
export const LANG_CHANGE_EVENT = 'tindahan_lang_changed';

export function getLanguage(): Language {
  try {
    const saved = localStorage.getItem(LANG_STORAGE_KEY);
    if (saved === 'en' || saved === 'tl') return saved;
  } catch (e) {
    // fallback
  }
  return 'en'; // Default to English
}

export function setLanguage(lang: Language) {
  localStorage.setItem(LANG_STORAGE_KEY, lang);
  window.dispatchEvent(new Event(LANG_CHANGE_EVENT));
}

export const translations = {
  tl: {
    appTitle: 'MINI STORE',
    appSubtitle: 'Smart Inventory & Real-time POS Manager',
    offlineMode: 'Offline Mode',

    // Tabs
    tabPos: 'POS Scanner',
    tabInventory: 'Inventory',
    tabDashboard: 'Dashboard',
    tabHistory: 'Kasaysayan',
    tabAccounts: 'Accounts',

    // Scanner
    liveScanner: 'Live Camera QR & Barcode Scanner',
    fastScanHint: 'Itutok ang camera sa QR o Barcode para sa mabilis na pag-detect at may tunog (beep)',
    startCamera: 'Start Camera Scanner',
    stopCamera: 'Stop Camera',
    cameraOff: 'Naka-off ang Camera Scanner',
    cameraOffSub: 'I-tap ang button para buksan ang camera ng phone/laptop.',
    lastScanned: 'Huling Na-scan:',
    manualSearch: 'Manual Barcode Entry / Search',
    manualSearchPlaceholder: 'I-type ang barcode o QR code...',
    quickTestBarcodes: 'Quick Test Barcodes (1-Tap Test Scan)',
    tapToSimulate: 'I-tap para ma-test ang scan sound & popup',

    // Inventory & Products
    inventoryTitle: 'Listahan ng Mga Paninda',
    inventorySubtitle: 'I-manage ang stock, presyo, at barcode ng mga produkto',
    addProduct: 'Magdagdag ng Bagong Produkto',
    editProduct: 'I-edit ang Produkto',
    deleteProduct: 'I-delete',
    searchProduct: 'Maghanap ng paninda...',
    allCategories: 'Lahat ng Kategorya',
    printQrSheet: 'Bondpaper QR Sheet (20 per Page)',
    outOfStock: 'Out of Stock (0 pcs)',
    lowStock: 'Mababa ang Stock',
    inStock: 'In Stock',
    stockQty: 'Stock:',
    price: 'Presyo:',
    costPrice: 'Puhunan:',
    profit: 'Tubo:',
    qrCode: 'QR Code',
    compactQrNotice: 'Compact QR code para sa madaling pag-scan',

    // Product Form Modal
    formAddTitle: 'Mag-dagdag ng Bagong Produkto',
    formEditTitle: 'I-edit ang Detalye ng Produkto',
    formSub: 'I-save sa local inventory database para automatic na ma-scan!',
    barcodeLabel: 'Barcode / Product Code *',
    autoGenCode: 'Auto-generate Code',
    productNameLabel: 'Pangalan ng Produkto *',
    categoryLabel: 'Kategorya (Category)',
    priceLabel: 'Presyo ng Benta (₱) *',
    costLabel: 'Puhunan / Cost (₱)',
    stockLabel: 'Dami ng Stock (Quantity) *',
    lowStockLimitLabel: 'Low Stock Warning Limit',
    imageLabel: 'Picture ng Produkto',
    detailsLabel: 'Detalye ng Item (Description)',
    cancel: 'Kanselahin',
    saveProductBtn: 'I-save sa Inventory',
    autoQrNotice: 'Awtomatikong mag-ge-generate ng QR Code na kasya 20 piraso sa 1 bondpaper!',

    // Quick Checkout Popup Modal
    scannedItemFound: 'Barcode Found! Scanned Item Confirmation',
    lowStockNalala: 'nalang natira',
    quantityLabel: 'Kuantidad (Quantity)',
    addToCartBtn: 'Idagdag sa Cart',
    quickCheckoutBtn: 'Quick Checkout',

    // Printable QR Bondpaper Sheet
    qrSheetTitle: '20 QR Code Printable Sheet (Bondpaper Layout)',
    qrSheetSub: 'Naka-layout na ang 20 QR codes sa 1 Short/Long Bondpaper. I-print o i-save bilang PDF!',
    printNow: 'I-print ang Bondpaper Sheet',
    close: 'Isara',
    pageInfo: 'Pahina 1 of 1 (20 Grid Items)',

    // Dashboard & Reports
    dashboardTitle: 'Real-time Sales Dashboard & Reports',
    dashboardSub: 'Live analytics ng kita at mga benta sa tindahan',
    rangeToday: 'Ngayon',
    rangeWeek: 'Linggo',
    rangeMonth: 'Buwan',
    rangeAll: 'Lahat',
    totalGrossSales: 'Kabuuan ng Benta',
    totalNetProfit: 'Malinis na Tubo',
    totalTransactions: 'Dami ng Benta',
    totalItemsSold: 'Items Naibenta',
    salesTrendChart: 'Sales Trend Chart',
    topProductsTitle: 'Pinaka-mabentang Produkto (Top Selling)',
    paymentBreakdownTitle: 'Paraan ng Bayad (Cash vs GCash vs Maya)',

    // Unregistered Barcode Modal
    unregisteredBadge: 'Unregistered Barcode',
    unregisteredTitle: 'Hindi Pa Naka-rehistro!',
    unregisteredSub: 'Wala pa sa inventory database ang barcode code na:',
    unregisteredPrompt: 'Gusto mo bang irehistro ang produktong ito para ma-save sa database para sa susunod na scan?',
    registerNowBtn: 'I-register Ngayon',

    // Accounts & Account Data Isolation
    accountsTitle: 'User Accounts & Data Isolation',
    accountsSub: 'Mayroong 3 accounts. Protektado ng Security PIN ang Admin account para sa may-ari ng tindahan.',
    adminNotice: '⭐ Naka-log in bilang Admin: May kakayahang buksan, suriin, at baguhin ang buong detalye ng paninda at benta ng IBANG account.',
    adminCrossControl: 'Buksan & Baguhin ang Database ng IBANG Account',
    activeAccountLabel: 'Pumili ng Active Account',
    activeAccount: 'Active Account',
    activeStatus: 'Active',
    switchAccount: 'Lumipat dito',
    viewingStoreOf: 'Sinisuri ang Database ni:',
    changeStoreDatabase: 'Baguhin ang Sisiring Database:',
    pinProtected: 'PIN Protected',
    pinSettings: 'Admin Protection PIN Settings',
    currentPin: 'Kasalukuyang PIN:',
    changePinBtn: 'Baguhin ang PIN',
    newPinLabel: 'Bagong 4-Digit PIN:',
    confirmPinLabel: 'I-confirm Bagong PIN:',
    savePinBtn: 'I-save Bagong Admin PIN',
    resetDataBtn: 'Reset All Data to Default',

    // Cart & Receipt
    cartTitle: 'POS Order Cart',
    itemsInCart: 'iba\'t ibang item sa cart',
    emptyCart: 'Walang laman ang cart',
    emptyCartSub: 'Mag-scan ng barcode/QR o mag-click ng item sa inventory para idagdag dito.',
    paymentMethod: 'Paraan ng Pagbabayad:',
    cashReceived: 'Bayad ng Customer (₱):',
    changeAmount: 'Sukli (Change):',
    refNo: 'Reference No.:',
    discount: 'Bawas / Discount (₱):',
    subtotal: 'Subtotal:',
    total: 'Kabuuan (Total):',
    completeSale: 'Kompletuhin ang Benta',
    processingSale: 'Kino-kompleto ang Benta...',
    receiptTitle: 'Salamat sa Pagbili! (Sales Receipt)',
    printReceipt: 'Print Resibo',
    done: 'Tapos na',
    viewCartBtn: 'Tingnan ang Cart',

    // Alerts & Notifications
    lowStockAlertsTitle: 'Low Stock Reminders',
    lowStockBanner: 'Low Stock Warning: May mga panindang kailangang i-restock!',
    viewAlerts: 'Tingnan &rarr;',
    restockNow: 'Restock Ngayon',
    soundFeedback: 'Scan Sound: ON',
  },
  en: {
    appTitle: 'MINI STORE',
    appSubtitle: 'Smart Inventory & Real-time POS Manager',
    offlineMode: 'Offline Mode',

    // Tabs
    tabPos: 'POS Scanner',
    tabInventory: 'Inventory',
    tabDashboard: 'Dashboard',
    tabHistory: 'History',
    tabAccounts: 'Accounts',

    // Scanner
    liveScanner: 'Live Camera QR & Barcode Scanner',
    fastScanHint: 'Point camera at QR or Barcode for fast instant scan with audio beep',
    startCamera: 'Start Camera Scanner',
    stopCamera: 'Stop Camera',
    cameraOff: 'Camera Scanner is Off',
    cameraOffSub: 'Tap the button to start the device camera.',
    lastScanned: 'Last Scanned:',
    manualSearch: 'Manual Barcode Entry / Search',
    manualSearchPlaceholder: 'Type barcode or QR code...',
    quickTestBarcodes: 'Quick Test Barcodes (1-Tap Test Scan)',
    tapToSimulate: 'Tap to test scan audio & popup',

    // Inventory & Products
    inventoryTitle: 'Products Inventory List',
    inventorySubtitle: 'Manage stock, prices, and product barcodes',
    addProduct: 'Add New Product',
    editProduct: 'Edit Product',
    deleteProduct: 'Delete',
    searchProduct: 'Search inventory...',
    allCategories: 'All Categories',
    printQrSheet: 'Bondpaper QR Sheet (20 per Page)',
    outOfStock: 'Out of Stock (0 pcs)',
    lowStock: 'Low Stock',
    inStock: 'In Stock',
    stockQty: 'Stock:',
    price: 'Price:',
    costPrice: 'Cost:',
    profit: 'Profit:',
    qrCode: 'QR Code',
    compactQrNotice: 'Compact QR code for quick scanning',

    // Product Form Modal
    formAddTitle: 'Add New Product',
    formEditTitle: 'Edit Product Details',
    formSub: 'Save to local inventory database for instant scanning!',
    barcodeLabel: 'Barcode / Product Code *',
    autoGenCode: 'Auto-generate Code',
    productNameLabel: 'Product Name *',
    categoryLabel: 'Category',
    priceLabel: 'Selling Price (₱) *',
    costLabel: 'Cost Price (₱)',
    stockLabel: 'Stock Quantity *',
    lowStockLimitLabel: 'Low Stock Warning Limit',
    imageLabel: 'Product Image',
    detailsLabel: 'Product Description / Details',
    cancel: 'Cancel',
    saveProductBtn: 'Save to Inventory',
    autoQrNotice: 'Automatically generates QR Code formatted 20 per printable bond paper!',

    // Quick Checkout Popup Modal
    scannedItemFound: 'Barcode Found! Scanned Item Confirmation',
    lowStockNalala: 'items remaining',
    quantityLabel: 'Quantity',
    addToCartBtn: 'Add to Cart',
    quickCheckoutBtn: 'Quick Checkout',

    // Printable QR Bondpaper Sheet
    qrSheetTitle: '20 QR Code Printable Sheet (Bondpaper Layout)',
    qrSheetSub: '20 QR codes formatted on 1 standard Bond Paper sheet. Print or save as PDF!',
    printNow: 'Print Bondpaper Sheet',
    close: 'Close',
    pageInfo: 'Page 1 of 1 (20 Grid Items)',

    // Dashboard & Reports
    dashboardTitle: 'Real-time Sales Dashboard & Reports',
    dashboardSub: 'Live store sales and profit analytics',
    rangeToday: 'Today',
    rangeWeek: 'This Week',
    rangeMonth: 'This Month',
    rangeAll: 'All Time',
    totalGrossSales: 'Total Gross Sales',
    totalNetProfit: 'Total Net Profit',
    totalTransactions: 'Transactions',
    totalItemsSold: 'Items Sold',
    salesTrendChart: 'Sales Trend Chart',
    topProductsTitle: 'Top Selling Products',
    paymentBreakdownTitle: 'Payment Methods (Cash vs GCash vs Maya)',

    // Unregistered Barcode Modal
    unregisteredBadge: 'Unregistered Barcode',
    unregisteredTitle: 'Not Yet Registered!',
    unregisteredSub: 'The following barcode is not yet in the inventory database:',
    unregisteredPrompt: 'Would you like to register this product so it can be automatically scanned next time?',
    registerNowBtn: 'Register Now',

    // Accounts & Account Data Isolation
    accountsTitle: 'User Accounts & Data Isolation',
    accountsSub: '3 accounts available. Admin account is security PIN protected for store owners.',
    adminNotice: '⭐ Logged in as Admin: You have full access to view and edit the complete inventory & sales database of ANY account.',
    adminCrossControl: 'Open & Edit Database of OTHER Accounts',
    activeAccountLabel: 'Select Active Account',
    activeAccount: 'Active Account',
    activeStatus: 'Active',
    switchAccount: 'Switch here',
    viewingStoreOf: 'Viewing Database Of:',
    changeStoreDatabase: 'Change Target Database:',
    pinProtected: 'PIN Protected',
    pinSettings: 'Admin Protection PIN Settings',
    currentPin: 'Current PIN:',
    changePinBtn: 'Change PIN',
    newPinLabel: 'New 4-Digit PIN:',
    confirmPinLabel: 'Confirm New PIN:',
    savePinBtn: 'Save New Admin PIN',
    resetDataBtn: 'Reset All Data to Default',

    // Cart & Receipt
    cartTitle: 'POS Order Cart',
    itemsInCart: 'different items in cart',
    emptyCart: 'Cart is empty',
    emptyCartSub: 'Scan a barcode/QR code or click an item in inventory to add here.',
    paymentMethod: 'Payment Method:',
    cashReceived: 'Customer Cash (₱):',
    changeAmount: 'Change Amount:',
    refNo: 'Reference No.:',
    discount: 'Discount (₱):',
    subtotal: 'Subtotal:',
    total: 'Total Amount:',
    completeSale: 'Complete Sale',
    processingSale: 'Completing Sale...',
    receiptTitle: 'Thank you for buying! (Sales Receipt)',
    printReceipt: 'Print Receipt',
    done: 'Done',
    viewCartBtn: 'View Cart',

    // Alerts & Notifications
    lowStockAlertsTitle: 'Low Stock Reminders',
    lowStockBanner: 'Low Stock Warning: Items require restocking!',
    viewAlerts: 'View &rarr;',
    restockNow: 'Restock Now',
    soundFeedback: 'Scan Sound: ON',
  },
};

export function t(key: keyof typeof translations['tl'], overrideLang?: Language): string {
  const lang = overrideLang || getLanguage();
  return translations[lang][key] || translations['tl'][key] || key;
}
