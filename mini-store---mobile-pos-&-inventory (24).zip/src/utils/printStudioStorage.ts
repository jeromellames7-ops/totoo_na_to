import { PrintDocumentProject, BondPaperPreset, CanvasElement, PrintDocumentPage } from '../types';
import { saveToFirestore, deleteFromFirestore, isFirestoreQuotaExhausted } from './firebaseSync';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { getEffectiveAccountId } from './storage';

function getPrintProjectsKey(): string {
  return `tindahan_print_studio_projects_acc_${getEffectiveAccountId()}`;
}

export const PAPER_DIMENSIONS_MM: Record<BondPaperPreset, { width: number; height: number; name: string; desc: string }> = {
  short: { width: 215.9, height: 279.4, name: 'Short Bond Paper (Letter)', desc: '8.5" × 11" (215.9 × 279.4 mm)' },
  long: { width: 215.9, height: 330.2, name: 'Long Bond Paper (Folio)', desc: '8.5" × 13" (215.9 × 330.2 mm)' },
  a4: { width: 210, height: 297, name: 'A4 Standard Bond Paper', desc: '8.27" × 11.69" (210 × 297 mm)' },
  legal: { width: 215.9, height: 355.6, name: 'US Legal Size', desc: '8.5" × 14" (215.9 × 355.6 mm)' },
  a5: { width: 148, height: 210, name: 'A5 Booklet', desc: '5.83" × 8.27" (148 × 210 mm)' },
  a3: { width: 297, height: 420, name: 'A3 Poster Paper', desc: '11.69" × 16.54" (297 × 420 mm)' },
  '4r': { width: 101.6, height: 152.4, name: '4R Photo Paper', desc: '4" × 6" (101.6 × 152.4 mm)' },
  '3r': { width: 88.9, height: 127, name: '3R Photo Paper', desc: '3.5" × 5" (88.9 × 127 mm)' },
  '5r': { width: 127, height: 177.8, name: '5R Photo Paper', desc: '5" × 7" (127 × 177.8 mm)' },
  custom: { width: 215.9, height: 279.4, name: 'Custom Paper Size', desc: 'User-defined Dimensions' },
};

export const PHOTO_PRESETS_MM = {
  '1x1': { width: 25.4, height: 25.4, label: '1x1 in (ID)', desc: '1" × 1" (25.4mm)' },
  '2x2': { width: 50.8, height: 50.8, label: '2x2 in (Passport/Visa)', desc: '2" × 2" (50.8mm)' },
  passport: { width: 35, height: 45, label: 'Philippine Passport', desc: '35mm × 45mm' },
  '2r': { width: 63.5, height: 88.9, label: '2R (Wallet Size)', desc: '2.5" × 3.5"' },
  '3r': { width: 88.9, height: 127, label: '3R Photo', desc: '3.5" × 5"' },
  '4r': { width: 101.6, height: 152.4, label: '4R Photo', desc: '4" × 6"' },
  '5r': { width: 127, height: 177.8, label: '5R Photo', desc: '5" × 7"' },
  half_page: { width: 100, height: 130, label: 'Half Page', desc: 'Fit half page' },
  full_page: { width: 195, height: 260, label: 'Full Page Fit', desc: 'Fit bondpaper' },
};

export const FONT_COLLECTIONS = [
  // Classic Document & Academic Fonts (Requested: Times New Roman, Calibri, Cambria)
  { name: 'Times New Roman (Academic/Official)', font: '"Times New Roman", Times, "Liberation Serif", serif' },
  { name: 'Calibri (Standard Document)', font: 'Calibri, Carlito, "Segoe UI", Arial, sans-serif' },
  { name: 'Cambria (Formal Serif)', font: 'Cambria, Caladea, Georgia, serif' },
  { name: 'Arial (Clean Standard)', font: 'Arial, "Helvetica Neue", Helvetica, sans-serif' },
  { name: 'Georgia (Elegant Book Serif)', font: 'Georgia, "Times New Roman", serif' },
  { name: 'Garamond (Classic Literature)', font: 'Garamond, "EB Garamond", Georgia, serif' },
  { name: 'Verdana (High Readability)', font: 'Verdana, Geneva, sans-serif' },
  { name: 'Trebuchet MS (Modern Clean)', font: '"Trebuchet MS", "Lucida Sans Unicode", sans-serif' },
  { name: 'Courier New (Monospace Typewriter)', font: '"Courier New", Courier, monospace' },

  // Sans-Serif & Modern Google Fonts
  { name: 'Inter (Clean Modern)', font: "'Inter', sans-serif" },
  { name: 'Roboto (Standard)', font: "'Roboto', sans-serif" },
  { name: 'Poppins (Geometric)', font: "'Poppins', sans-serif" },
  { name: 'Montserrat (Bold Clean)', font: "'Montserrat', sans-serif" },
  { name: 'Oswald (Tall Headline)', font: "'Oswald', sans-serif" },
  { name: 'Anton (Heavy Impact)', font: "'Anton', sans-serif" },
  { name: 'Bebas Neue (Display Caps)', font: "'Bebas Neue', sans-serif" },

  // Serif & Luxury
  { name: 'Playfair Display (Luxury Serif)', font: "'Playfair Display', serif" },
  { name: 'Merriweather (Classic Book)', font: "'Merriweather', serif" },
  { name: 'Cinzel (Roman Elegance)', font: "'Cinzel', serif" },
  { name: 'Abril Fatface (Bold Classic)', font: "'Abril Fatface', serif" },

  // Handwritten & Cursive
  { name: 'Dancing Script (Flowing Cursive)', font: "'Dancing Script', cursive" },
  { name: 'Pacifico (Retro Brush)', font: "'Pacifico', cursive" },
  { name: 'Caveat (Natural Handwriting)', font: "'Caveat', cursive" },
  { name: 'Great Vibes (Calligraphy Script)', font: "'Great Vibes', cursive" },
  { name: 'Sacramento (Delicate Script)', font: "'Sacramento', cursive" },
  { name: 'Satisfy (Smooth Casual)', font: "'Satisfy', cursive" },
  { name: 'Kalam (Friendly Marker)', font: "'Kalam', cursive" },

  // Creative & Display
  { name: 'Bangers (Comic Pop)', font: "'Bangers', cursive" },
  { name: 'Comic Neue (Friendly Comic)', font: "'Comic Neue', cursive" },
  { name: 'Lobster (Bold Script)', font: "'Lobster', cursive" },
  { name: 'Righteous (Retro Sci-Fi)', font: "'Righteous', cursive" },
  { name: 'Courier Prime (Typewriter Mono)', font: "'Courier Prime', monospace" },
];

export function getLocalPrintProjects(): PrintDocumentProject[] {
  try {
    const raw = localStorage.getItem(getPrintProjectsKey());
    if (!raw) return [];
    const parsed: PrintDocumentProject[] = JSON.parse(raw);
    return parsed.map((p) => {
      // Ensure pages array exists
      if (!p.pages || p.pages.length === 0) {
        return {
          ...p,
          pages: [
            {
              id: `${p.id}_p1`,
              pageNumber: 1,
              elements: p.elements || [],
            },
          ],
        };
      }
      return p;
    });
  } catch (e) {
    return [];
  }
}

export function saveLocalPrintProjects(projects: PrintDocumentProject[]) {
  try {
    localStorage.setItem(getPrintProjectsKey(), JSON.stringify(projects));
  } catch (e) {
    console.error('Error saving print projects to localStorage:', e);
  }
}

export async function savePrintProjectToDatabase(project: PrintDocumentProject): Promise<void> {
  const effectiveAccId = getEffectiveAccountId();
  const pages = project.pages && project.pages.length > 0
    ? project.pages
    : [{ id: `${project.id}_p1`, pageNumber: 1, elements: project.elements || [] }];

  const projectWithAcc: PrintDocumentProject = {
    ...project,
    accountId: project.accountId || effectiveAccId,
    pages,
    elements: project.elements || [],
  };
  const all = getLocalPrintProjects();
  const existingIndex = all.findIndex((p) => p.id === projectWithAcc.id);
  let updated: PrintDocumentProject[];
  if (existingIndex >= 0) {
    updated = [...all];
    updated[existingIndex] = projectWithAcc;
  } else {
    updated = [projectWithAcc, ...all];
  }
  saveLocalPrintProjects(updated);

  // Firestore sync
  try {
    await saveToFirestore('print_documents', projectWithAcc.id, {
      ...projectWithAcc,
      accountId: effectiveAccId,
      elements: JSON.stringify(projectWithAcc.elements),
      pages: JSON.stringify(projectWithAcc.pages),
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.warn('[Firebase] Firestore print project save fallback:', err);
  }
}

export async function deletePrintProjectFromDatabase(id: string): Promise<void> {
  const all = getLocalPrintProjects().filter((p) => p.id !== id);
  saveLocalPrintProjects(all);

  try {
    await deleteFromFirestore('print_documents', id);
  } catch (err) {
    console.warn('[Firebase] Firestore delete print project fallback:', err);
  }
}

export async function loadPrintProjectsFromFirestore(): Promise<PrintDocumentProject[]> {
  if (isFirestoreQuotaExhausted()) {
    return getLocalPrintProjects();
  }
  try {
    const effectiveAccId = getEffectiveAccountId();
    const snapshot = await getDocs(collection(db, 'print_documents'));
    const items: PrintDocumentProject[] = [];
    snapshot.docs.forEach((docSnap) => {
      const data = docSnap.data();
      if (data.accountId && data.accountId !== effectiveAccId) {
        return; // Skip documents belonging to other accounts
      }
      let elements: CanvasElement[] = [];
      if (typeof data.elements === 'string') {
        try {
          elements = JSON.parse(data.elements);
        } catch {
          elements = [];
        }
      } else if (Array.isArray(data.elements)) {
        elements = data.elements;
      }

      let pages: PrintDocumentPage[] = [];
      if (typeof data.pages === 'string') {
        try {
          pages = JSON.parse(data.pages);
        } catch {
          pages = [];
        }
      } else if (Array.isArray(data.pages)) {
        pages = data.pages;
      }

      if (pages.length === 0) {
        pages = [{ id: `${docSnap.id}_p1`, pageNumber: 1, elements }];
      }

      items.push({
        id: docSnap.id,
        accountId: data.accountId || effectiveAccId,
        title: data.title || 'Untitled Document',
        paperPreset: data.paperPreset || 'short',
        customWidthMm: data.customWidthMm || 215.9,
        customHeightMm: data.customHeightMm || 279.4,
        orientation: data.orientation || 'portrait',
        elements,
        pages,
        updatedAt: data.updatedAt || new Date().toISOString(),
      });
    });

    if (items.length > 0) {
      saveLocalPrintProjects(items);
      return items;
    }
  } catch (e) {
    console.warn('[Firebase] Loading print projects fallback:', e);
  }
  return getLocalPrintProjects();
}

export function createDefaultPrintDocument(): PrintDocumentProject {
  const docId = `doc_${Date.now()}`;
  return {
    id: docId,
    title: 'Untitled Bondpaper Print',
    paperPreset: 'short',
    customWidthMm: 215.9,
    customHeightMm: 279.4,
    orientation: 'portrait',
    elements: [],
    pages: [
      {
        id: `page_${Date.now()}_1`,
        pageNumber: 1,
        elements: [],
      },
    ],
    updatedAt: new Date().toISOString(),
  };
}

