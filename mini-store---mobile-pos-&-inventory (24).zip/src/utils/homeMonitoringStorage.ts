import {
  ElectricBillRecord,
  WaterBillRecord,
  GasStoveLpgRecord,
  MenstruationCycleRecord,
  PillMonitoringPlan,
  PillTakeLog,
} from '../types';
import { saveToFirestore, deleteFromFirestore, isFirestoreQuotaExhausted } from './firebaseSync';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { calculateOneMonthDueDate } from './notificationHelper';
import { getEffectiveAccountId } from './storage';

function getElectricKey(): string {
  return `tindahan_electric_bills_acc_${getEffectiveAccountId()}`;
}

function getWaterKey(): string {
  return `tindahan_water_bills_acc_${getEffectiveAccountId()}`;
}

function getGasKey(): string {
  return `tindahan_gas_lpg_acc_${getEffectiveAccountId()}`;
}

function getMenstruationKey(): string {
  return `tindahan_menstruation_acc_${getEffectiveAccountId()}`;
}

function getPillPlanKey(): string {
  return `tindahan_pill_plan_acc_${getEffectiveAccountId()}`;
}

// ==========================================
// ELECTRIC BILLS (0 Default Example Data)
// ==========================================
export function getLocalElectricBills(): ElectricBillRecord[] {
  try {
    const raw = localStorage.getItem(getElectricKey());
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

export function saveLocalElectricBills(records: ElectricBillRecord[]) {
  try {
    localStorage.setItem(getElectricKey(), JSON.stringify(records));
  } catch (e) {
    console.error('Error saving electric bills:', e);
  }
}

export async function saveElectricBillToDb(record: ElectricBillRecord): Promise<void> {
  const all = getLocalElectricBills();
  const index = all.findIndex((r) => r.id === record.id);
  const updated = index >= 0 ? [...all] : [record, ...all];
  if (index >= 0) updated[index] = record;
  saveLocalElectricBills(updated);

  const accId = getEffectiveAccountId();
  try {
    await saveToFirestore('home_monitoring', `electric_${record.id}_${accId}`, {
      category: 'electric',
      accountId: accId,
      data: JSON.stringify(record),
      updatedAt: new Date().toISOString(),
    });
  } catch (e) {
    console.warn('[Firebase] Save electric bill fallback:', e);
  }
}

export async function deleteElectricBillFromDb(id: string): Promise<void> {
  const updated = getLocalElectricBills().filter((r) => r.id !== id);
  saveLocalElectricBills(updated);
  const accId = getEffectiveAccountId();
  try {
    await deleteFromFirestore('home_monitoring', `electric_${id}_${accId}`);
    await deleteFromFirestore('home_monitoring', `electric_${id}`);
  } catch (e) {
    console.warn('[Firebase] Delete electric bill fallback:', e);
  }
}

// ==========================================
// WATER BILLS (0 Default Example Data)
// ==========================================
export function getLocalWaterBills(): WaterBillRecord[] {
  try {
    const raw = localStorage.getItem(getWaterKey());
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

export function saveLocalWaterBills(records: WaterBillRecord[]) {
  try {
    localStorage.setItem(getWaterKey(), JSON.stringify(records));
  } catch (e) {
    console.error('Error saving water bills:', e);
  }
}

export async function saveWaterBillToDb(record: WaterBillRecord): Promise<void> {
  const all = getLocalWaterBills();
  const index = all.findIndex((r) => r.id === record.id);
  const updated = index >= 0 ? [...all] : [record, ...all];
  if (index >= 0) updated[index] = record;
  saveLocalWaterBills(updated);

  const accId = getEffectiveAccountId();
  try {
    await saveToFirestore('home_monitoring', `water_${record.id}_${accId}`, {
      category: 'water',
      accountId: accId,
      data: JSON.stringify(record),
      updatedAt: new Date().toISOString(),
    });
  } catch (e) {
    console.warn('[Firebase] Save water bill fallback:', e);
  }
}

export async function deleteWaterBillFromDb(id: string): Promise<void> {
  const updated = getLocalWaterBills().filter((r) => r.id !== id);
  saveLocalWaterBills(updated);
  const accId = getEffectiveAccountId();
  try {
    await deleteFromFirestore('home_monitoring', `water_${id}_${accId}`);
    await deleteFromFirestore('home_monitoring', `water_${id}`);
  } catch (e) {
    console.warn('[Firebase] Delete water bill fallback:', e);
  }
}

// ==========================================
// GAS STOVE / LPG TANKS (0 Default Example Data)
// ==========================================
export function getLocalGasRecords(): GasStoveLpgRecord[] {
  try {
    const raw = localStorage.getItem(getGasKey());
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

export function saveLocalGasRecords(records: GasStoveLpgRecord[]) {
  try {
    localStorage.setItem(getGasKey(), JSON.stringify(records));
  } catch (e) {
    console.error('Error saving gas records:', e);
  }
}

export async function saveGasRecordToDb(record: GasStoveLpgRecord): Promise<void> {
  // Ensure automatic 1-month due date calculation if not explicitly set
  if (!record.dueDate && record.purchaseDate) {
    record.dueDate = calculateOneMonthDueDate(record.purchaseDate);
  }

  const all = getLocalGasRecords();
  const index = all.findIndex((r) => r.id === record.id);
  const updated = index >= 0 ? [...all] : [record, ...all];
  if (index >= 0) updated[index] = record;
  saveLocalGasRecords(updated);

  const accId = getEffectiveAccountId();
  try {
    await saveToFirestore('home_monitoring', `gas_${record.id}_${accId}`, {
      category: 'gas',
      accountId: accId,
      data: JSON.stringify(record),
      updatedAt: new Date().toISOString(),
    });
  } catch (e) {
    console.warn('[Firebase] Save gas record fallback:', e);
  }
}

export async function deleteGasRecordFromDb(id: string): Promise<void> {
  const updated = getLocalGasRecords().filter((r) => r.id !== id);
  saveLocalGasRecords(updated);
  const accId = getEffectiveAccountId();
  try {
    await deleteFromFirestore('home_monitoring', `gas_${id}_${accId}`);
    await deleteFromFirestore('home_monitoring', `gas_${id}`);
  } catch (e) {
    console.warn('[Firebase] Delete gas record fallback:', e);
  }
}

// ==========================================
// WOMEN'S MENSTRUATION / PERIOD TRACKER (0 Default Example Data)
// ==========================================
export function getLocalMenstruationRecords(): MenstruationCycleRecord[] {
  try {
    const raw = localStorage.getItem(getMenstruationKey());
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

export function saveLocalMenstruationRecords(records: MenstruationCycleRecord[]) {
  try {
    localStorage.setItem(getMenstruationKey(), JSON.stringify(records));
  } catch (e) {
    console.error('Error saving menstruation records:', e);
  }
}

export async function saveMenstruationRecordToDb(record: MenstruationCycleRecord): Promise<void> {
  const all = getLocalMenstruationRecords();
  const index = all.findIndex((r) => r.id === record.id);
  const updated = index >= 0 ? [...all] : [record, ...all];
  if (index >= 0) updated[index] = record;
  saveLocalMenstruationRecords(updated);

  const accId = getEffectiveAccountId();
  try {
    await saveToFirestore('home_monitoring', `menstruation_${record.id}_${accId}`, {
      category: 'menstruation',
      accountId: accId,
      data: JSON.stringify(record),
      updatedAt: new Date().toISOString(),
    });
  } catch (e) {
    console.warn('[Firebase] Save menstruation record fallback:', e);
  }
}

export async function deleteMenstruationRecordFromDb(id: string): Promise<void> {
  const updated = getLocalMenstruationRecords().filter((r) => r.id !== id);
  saveLocalMenstruationRecords(updated);
  const accId = getEffectiveAccountId();
  try {
    await deleteFromFirestore('home_monitoring', `menstruation_${id}_${accId}`);
    await deleteFromFirestore('home_monitoring', `menstruation_${id}`);
  } catch (e) {
    console.warn('[Firebase] Delete menstruation record fallback:', e);
  }
}

// ==========================================
// PILLS MONITORING TRACKER (0 Default Example Data)
// ==========================================
export function getLocalPillPlan(): PillMonitoringPlan | null {
  try {
    const raw = localStorage.getItem(getPillPlanKey());
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}

export function saveLocalPillPlan(plan: PillMonitoringPlan | null) {
  try {
    if (plan) {
      localStorage.setItem(getPillPlanKey(), JSON.stringify(plan));
    } else {
      localStorage.removeItem(getPillPlanKey());
    }
  } catch (e) {
    console.error('Error saving pill plan:', e);
  }
}

export async function savePillPlanToDb(plan: PillMonitoringPlan): Promise<void> {
  saveLocalPillPlan(plan);
  const accId = getEffectiveAccountId();
  try {
    await saveToFirestore('home_monitoring', `pill_plan_${plan.id}_${accId}`, {
      category: 'pill_plan',
      accountId: accId,
      data: JSON.stringify(plan),
      updatedAt: new Date().toISOString(),
    });
  } catch (e) {
    console.warn('[Firebase] Save pill plan fallback:', e);
  }
}

export async function deletePillPlanFromDb(id: string): Promise<void> {
  saveLocalPillPlan(null);
  const accId = getEffectiveAccountId();
  try {
    await deleteFromFirestore('home_monitoring', `pill_plan_${id}_${accId}`);
    await deleteFromFirestore('home_monitoring', `pill_plan_${id}`);
  } catch (e) {
    console.warn('[Firebase] Delete pill plan fallback:', e);
  }
}

/**
 * Helper to record pill taken (manual click or automatic 7:00 PM alarm acknowledgement)
 * STRICT RULE: Only 1 check per day (isa lamang kada araw).
 */
export function recordPillTaken(plan: PillMonitoringPlan, autoCounted: boolean = false, notes?: string): PillMonitoringPlan {
  const todayStr = new Date().toISOString().split('T')[0];
  const nowTime = new Date().toTimeString().slice(0, 5); // "19:00"

  const existingLogIndex = plan.logs.findIndex((l) => l.date === todayStr);

  // If already logged today, do not increment or check again (strictly 1 check per day)
  if (existingLogIndex >= 0) {
    return plan;
  }

  const pillNum = plan.currentPillIndex;

  const newLog: PillTakeLog = {
    id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
    pillNumber: pillNum,
    date: todayStr,
    time: nowTime,
    taken: true,
    autoCounted,
    notes,
  };

  const updatedLogs = [...plan.logs, newLog];

  // Calculate next pill index (loops within pack, e.g., 1 to 28)
  const nextPillIndex = pillNum >= plan.totalPillsInPack ? 1 : pillNum + 1;
  const totalTaken = updatedLogs.filter((l) => l.taken).length;

  const updatedPlan: PillMonitoringPlan = {
    ...plan,
    currentPillIndex: nextPillIndex,
    totalPillsTaken: totalTaken,
    streakDays: (plan.streakDays || 0) + 1,
    lastReminderDate: todayStr,
    logs: updatedLogs,
    updatedAt: new Date().toISOString(),
  };

  saveLocalPillPlan(updatedPlan);
  savePillPlanToDb(updatedPlan);
  return updatedPlan;
}

/**
 * Delete / Undo a checked pill log
 */
export function deletePillLog(plan: PillMonitoringPlan, logId: string): PillMonitoringPlan {
  const updatedLogs = plan.logs.filter((l) => l.id !== logId);
  const totalTaken = updatedLogs.filter((l) => l.taken).length;
  // Recalculate currentPillIndex based on total pills taken (1 to totalPillsInPack)
  const nextPillIndex = (totalTaken % plan.totalPillsInPack) + 1;

  const updatedPlan: PillMonitoringPlan = {
    ...plan,
    currentPillIndex: nextPillIndex,
    totalPillsTaken: totalTaken,
    streakDays: Math.max(0, updatedLogs.length),
    logs: updatedLogs,
    updatedAt: new Date().toISOString(),
  };

  saveLocalPillPlan(updatedPlan);
  savePillPlanToDb(updatedPlan);
  return updatedPlan;
}

// Load all from Firestore (Account Isolated)
export async function syncAllHomeMonitoringFromFirestore(): Promise<void> {
  if (isFirestoreQuotaExhausted()) return;
  try {
    const effectiveAccId = getEffectiveAccountId();
    const snapshot = await getDocs(collection(db, 'home_monitoring'));
    const elecs: ElectricBillRecord[] = [];
    const waters: WaterBillRecord[] = [];
    const gases: GasStoveLpgRecord[] = [];
    const mens: MenstruationCycleRecord[] = [];
    let pillPlan: PillMonitoringPlan | null = null;

    snapshot.docs.forEach((docSnap) => {
      const data = docSnap.data();
      if (!data || !data.data) return;
      
      // Strict Account Isolation: only load records belonging to this account
      const recordAccId = data.accountId || 'user-admin';
      if (recordAccId !== effectiveAccId) return;

      try {
        const parsed = JSON.parse(data.data);
        if (data.category === 'electric') elecs.push(parsed);
        else if (data.category === 'water') waters.push(parsed);
        else if (data.category === 'gas') gases.push(parsed);
        else if (data.category === 'menstruation') mens.push(parsed);
        else if (data.category === 'pill_plan') pillPlan = parsed;
      } catch (err) {
        // parse error
      }
    });

    if (elecs.length > 0) saveLocalElectricBills(elecs);
    if (waters.length > 0) saveLocalWaterBills(waters);
    if (gases.length > 0) saveLocalGasRecords(gases);
    if (mens.length > 0) saveLocalMenstruationRecords(mens);
    if (pillPlan) saveLocalPillPlan(pillPlan);
  } catch (e) {
    console.warn('[Firebase] syncAllHomeMonitoringFromFirestore fallback:', e);
  }
}
