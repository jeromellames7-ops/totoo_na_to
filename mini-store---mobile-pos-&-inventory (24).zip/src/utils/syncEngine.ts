import {
  getProducts,
  getSales,
  getUtangRecords,
  getShiftReports,
  getEffectiveAccountId,
  notifyDataChanged,
  getAccounts,
} from './storage';
import { collection, onSnapshot, getDocs, writeBatch, doc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { saveToFirestore, isFirestoreQuotaExhausted, handleFirestoreError } from './firebaseSync';

export type SyncState = 'synced' | 'syncing' | 'offline_queued' | 'error';

export interface SyncStatus {
  isOnline: boolean;
  syncState: SyncState;
  pendingCount: number;
  lastSyncedTime: string | null;
  deviceId: string;
  queueSummary: string[];
}

export interface QueuedMutation {
  id: string;
  type: 'SAVE_PRODUCT' | 'DELETE_PRODUCT' | 'RECORD_SALE' | 'SAVE_UTANG' | 'RECORD_UTANG_PAYMENT' | 'SAVE_SHIFT';
  accountId: string;
  payload: any;
  timestamp: string;
  description: string;
}

const STORAGE_KEYS = {
  OFFLINE_QUEUE: 'tindahan_offline_queue_v1',
  DEVICE_ID: 'tindahan_device_id_v1',
  LAST_SYNC_TIME: 'tindahan_last_sync_time_v1',
};

export const SYNC_STATUS_EVENT = 'tindahan_sync_status_changed';

// Get or create unique Device ID for this browser/device
export function getDeviceId(): string {
  let id = localStorage.getItem(STORAGE_KEYS.DEVICE_ID);
  if (!id) {
    id = `POS-Dev-${Math.floor(1000 + Math.random() * 9000)}`;
    localStorage.setItem(STORAGE_KEYS.DEVICE_ID, id);
  }
  return id;
}

// Queue management
export function getOfflineQueue(): QueuedMutation[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.OFFLINE_QUEUE);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

function saveOfflineQueue(queue: QueuedMutation[]) {
  localStorage.setItem(STORAGE_KEYS.OFFLINE_QUEUE, JSON.stringify(queue));
  broadcastSyncStatus();
}

export function queueOfflineMutation(mutation: Omit<QueuedMutation, 'id' | 'timestamp'>) {
  const queue = getOfflineQueue();
  const fullMutation: QueuedMutation = {
    ...mutation,
    id: `mut-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: new Date().toISOString(),
  };
  queue.push(fullMutation);
  saveOfflineQueue(queue);
}

export function clearOfflineQueue() {
  localStorage.removeItem(STORAGE_KEYS.OFFLINE_QUEUE);
  broadcastSyncStatus();
}

export function removeQueuedMutationForId(targetId: string) {
  const queue = getOfflineQueue();
  const filtered = queue.filter((item) => {
    if (item.payload && (item.payload.id === targetId || item.payload.productId === targetId)) {
      return false;
    }
    return true;
  });
  saveOfflineQueue(filtered);
}

// Internal State
let currentIsOnline = true;
let currentSyncState: SyncState = 'synced';
let lastSyncedTime = localStorage.getItem(STORAGE_KEYS.LAST_SYNC_TIME);
let broadcastChannel: BroadcastChannel | null = null;
let isInternalSnapshotUpdate = false;

try {
  broadcastChannel = new BroadcastChannel('tindahan_sync_channel');
  broadcastChannel.onmessage = (event) => {
    if (event.data && event.data.type === 'LOCAL_TAB_MUTATED') {
      notifyDataChanged();
      broadcastSyncStatus();
    }
  };
} catch (e) {
  // Fallback
}

export function getSyncStatus(): SyncStatus {
  const queue = getOfflineQueue();
  return {
    isOnline: currentIsOnline,
    syncState: queue.length > 0 && !currentIsOnline ? 'offline_queued' : currentSyncState,
    pendingCount: queue.length,
    lastSyncedTime,
    deviceId: getDeviceId(),
    queueSummary: queue.map((q) => q.description),
  };
}

export function broadcastSyncStatus() {
  window.dispatchEvent(new CustomEvent(SYNC_STATUS_EVENT, { detail: getSyncStatus() }));
}

function withTimeout<T>(promise: Promise<T>, ms = 4000): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(() => reject(new Error('Firestore request timed out')), ms)
    ),
  ]);
}

// Push local full state & queued items to Firebase Firestore safely using batching
export async function pushCloudSync(targetAccountId?: string): Promise<boolean> {
  if (isFirestoreQuotaExhausted()) {
    currentSyncState = 'synced';
    broadcastSyncStatus();
    return false;
  }

  const accountId = targetAccountId || getEffectiveAccountId();
  const queue = getOfflineQueue();

  currentSyncState = 'syncing';
  broadcastSyncStatus();

  try {
    const products = getProducts(accountId);
    const sales = getSales(accountId);
    const utang = getUtangRecords(accountId);
    const shifts = getShiftReports(accountId);
    const accounts = getAccounts();

    const batch = writeBatch(db);
    let operationCount = 0;

    for (const p of products) {
      if (p.id) {
        batch.set(doc(db, 'products', p.id), { ...p, accountId }, { merge: true });
        operationCount++;
      }
    }

    for (const s of sales) {
      if (s.id) {
        batch.set(doc(db, 'sales', s.id), { ...s, accountId }, { merge: true });
        operationCount++;
      }
    }

    for (const u of utang) {
      if (u.id) {
        batch.set(doc(db, 'utang', u.id), { ...u, accountId }, { merge: true });
        operationCount++;
      }
    }

    for (const sf of shifts) {
      if (sf.id) {
        batch.set(doc(db, 'shifts', sf.id), { ...sf, accountId }, { merge: true });
        operationCount++;
      }
    }

    for (const acc of accounts) {
      if (acc.id) {
        batch.set(doc(db, 'accounts', acc.id), acc, { merge: true });
        operationCount++;
      }
    }

    if (operationCount > 0) {
      await withTimeout(batch.commit(), 5000);
    }

    localStorage.removeItem(STORAGE_KEYS.OFFLINE_QUEUE);

    const nowIso = new Date().toISOString();
    lastSyncedTime = nowIso;
    localStorage.setItem(STORAGE_KEYS.LAST_SYNC_TIME, nowIso);

    currentIsOnline = true;
    currentSyncState = 'synced';
    broadcastSyncStatus();

    if (broadcastChannel) {
      broadcastChannel.postMessage({ type: 'LOCAL_TAB_MUTATED' });
    }

    return true;
  } catch (err) {
    handleFirestoreError(err, 'pushCloudSync');
  }

  currentSyncState = queue.length > 0 ? 'offline_queued' : 'synced';
  broadcastSyncStatus();
  return false;
}

// Pull latest data from Firebase Firestore and update local storage
export async function pullCloudSync(targetAccountId?: string): Promise<boolean> {
  if (isFirestoreQuotaExhausted()) {
    currentSyncState = 'synced';
    broadcastSyncStatus();
    return false;
  }

  const accountId = targetAccountId || getEffectiveAccountId();

  try {
    // 1. Fetch products
    const prodSnap = await withTimeout(getDocs(collection(db, 'products')), 4000);
    const prodList: any[] = [];
    prodSnap.forEach((doc) => {
      const data = doc.data();
      if (!data.accountId || data.accountId === accountId) {
        prodList.push(data);
      }
    });

    // 2. Fetch sales
    const salesSnap = await withTimeout(getDocs(collection(db, 'sales')), 4000);
    const salesList: any[] = [];
    salesSnap.forEach((doc) => {
      const data = doc.data();
      if (!data.accountId || data.accountId === accountId) {
        salesList.push(data);
      }
    });

    // 3. Fetch utang
    const utangSnap = await withTimeout(getDocs(collection(db, 'utang')), 4000);
    const utangList: any[] = [];
    utangSnap.forEach((doc) => {
      const data = doc.data();
      if (!data.accountId || data.accountId === accountId) {
        utangList.push(data);
      }
    });

    // 4. Fetch shifts
    const shiftSnap = await withTimeout(getDocs(collection(db, 'shifts')), 4000);
    const shiftList: any[] = [];
    shiftSnap.forEach((doc) => {
      const data = doc.data();
      if (!data.accountId || data.accountId === accountId) {
        shiftList.push(data);
      }
    });

    // 5. Fetch accounts
    const accSnap = await withTimeout(getDocs(collection(db, 'accounts')), 4000);
    const accList: any[] = [];
    accSnap.forEach((doc) => {
      accList.push(doc.data());
    });

    isInternalSnapshotUpdate = true;
    updateLocalStorageAccountData(accountId, {
      products: prodList,
      sales: salesList,
      utang: utangList,
      shifts: shiftList,
    });

    if (accList.length > 0) {
      localStorage.setItem('tindahan_accounts_v1', JSON.stringify(accList));
    }
    isInternalSnapshotUpdate = false;

    const nowIso = new Date().toISOString();
    lastSyncedTime = nowIso;
    localStorage.setItem(STORAGE_KEYS.LAST_SYNC_TIME, nowIso);

    currentIsOnline = true;
    currentSyncState = 'synced';
    notifyDataChanged();
    broadcastSyncStatus();
    return true;
  } catch (err) {
    handleFirestoreError(err, 'pullCloudSync');
  }
  return false;
}

// Helper to write cloud data into local storage keys safely without losing local offline data
function updateLocalStorageAccountData(accountId: string, data: any) {
  let needsCloudPush = false;

  if (data.products && Array.isArray(data.products)) {
    if (data.products.length > 0) {
      localStorage.setItem(`tindahan_products_acc_${accountId}`, JSON.stringify(data.products));
    } else {
      const existing = localStorage.getItem(`tindahan_products_acc_${accountId}`);
      if (existing) {
        try {
          const parsed = JSON.parse(existing);
          if (Array.isArray(parsed) && parsed.length > 0) {
            needsCloudPush = true;
          }
        } catch (e) {}
      }
    }
  }

  if (data.sales && Array.isArray(data.sales)) {
    if (data.sales.length > 0) {
      localStorage.setItem(`tindahan_sales_acc_${accountId}`, JSON.stringify(data.sales));
    } else {
      const existing = localStorage.getItem(`tindahan_sales_acc_${accountId}`);
      if (existing) {
        try {
          const parsed = JSON.parse(existing);
          if (Array.isArray(parsed) && parsed.length > 0) {
            needsCloudPush = true;
          }
        } catch (e) {}
      }
    }
  }

  if (data.utang && Array.isArray(data.utang)) {
    if (data.utang.length > 0) {
      localStorage.setItem(`tindahan_utang_acc_${accountId}`, JSON.stringify(data.utang));
    } else {
      const existing = localStorage.getItem(`tindahan_utang_acc_${accountId}`);
      if (existing) {
        try {
          const parsed = JSON.parse(existing);
          if (Array.isArray(parsed) && parsed.length > 0) {
            needsCloudPush = true;
          }
        } catch (e) {}
      }
    }
  }

  if (data.shifts && Array.isArray(data.shifts)) {
    if (data.shifts.length > 0) {
      localStorage.setItem(`tindahan_shifts_acc_${accountId}`, JSON.stringify(data.shifts));
    }
  }

  // If cloud database is empty for this account but local storage has data, push local data to Firestore if quota not exceeded
  if (needsCloudPush && !isFirestoreQuotaExhausted()) {
    setTimeout(() => {
      pushCloudSync(accountId).catch(() => {});
    }, 500);
  }
}

// Initialize real-time auto-sync engine using Firebase Firestore onSnapshot listeners
export function initSyncEngine() {
  window.addEventListener('online', async () => {
    currentIsOnline = true;
    broadcastSyncStatus();
    if (!isFirestoreQuotaExhausted()) {
      await pushCloudSync();
    }
  });

  window.addEventListener('offline', () => {
    currentIsOnline = false;
    currentSyncState = 'offline_queued';
    broadcastSyncStatus();
  });

  // Set up real-time Firebase Firestore listeners for collections with graceful error handlers
  if (!isFirestoreQuotaExhausted()) {
    try {
      const accountId = getEffectiveAccountId();

      // 1. Products listener
      onSnapshot(
        collection(db, 'products'),
        (snapshot) => {
          if (snapshot.metadata.hasPendingWrites) return;
          const items: any[] = [];
          snapshot.forEach((d) => {
            const item = d.data();
            if (!item.accountId || item.accountId === accountId) {
              items.push(item);
            }
          });
          localStorage.setItem(`tindahan_products_acc_${accountId}`, JSON.stringify(items));
          notifyDataChanged();
          currentIsOnline = true;
          currentSyncState = 'synced';
          broadcastSyncStatus();
        },
        (err) => {
          handleFirestoreError(err, 'products onSnapshot');
        }
      );

      // 2. Sales listener
      onSnapshot(
        collection(db, 'sales'),
        (snapshot) => {
          if (snapshot.metadata.hasPendingWrites) return;
          const items: any[] = [];
          snapshot.forEach((d) => {
            const item = d.data();
            if (!item.accountId || item.accountId === accountId) {
              items.push(item);
            }
          });
          localStorage.setItem(`tindahan_sales_acc_${accountId}`, JSON.stringify(items));
          notifyDataChanged();
        },
        (err) => {
          handleFirestoreError(err, 'sales onSnapshot');
        }
      );

      // 3. Utang listener
      onSnapshot(
        collection(db, 'utang'),
        (snapshot) => {
          if (snapshot.metadata.hasPendingWrites) return;
          const items: any[] = [];
          snapshot.forEach((d) => {
            const item = d.data();
            if (!item.accountId || item.accountId === accountId) {
              items.push(item);
            }
          });
          localStorage.setItem(`tindahan_utang_acc_${accountId}`, JSON.stringify(items));
          notifyDataChanged();
        },
        (err) => {
          handleFirestoreError(err, 'utang onSnapshot');
        }
      );

      // 4. Accounts listener
      onSnapshot(
        collection(db, 'accounts'),
        (snapshot) => {
          if (snapshot.metadata.hasPendingWrites) return;
          const accs: any[] = [];
          snapshot.forEach((d) => accs.push(d.data()));
          if (accs.length > 0) {
            localStorage.setItem('tindahan_accounts_v1', JSON.stringify(accs));
            notifyDataChanged();
          }
        },
        (err) => {
          handleFirestoreError(err, 'accounts onSnapshot');
        }
      );
    } catch (e) {
      console.warn('Firebase listeners setup failed, working offline/localStorage fallback mode:', e);
    }
  }

  // Initial pull/push on launch
  setTimeout(() => {
    if (!isFirestoreQuotaExhausted()) {
      pullCloudSync().catch(() => {});
    }
  }, 1000);
}

