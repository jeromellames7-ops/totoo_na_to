import { saveToFirestore, isFirestoreQuotaExhausted } from './firebaseSync';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { getEffectiveAccountId } from './storage';

export interface PrintSaleTransaction {
  id: string;
  accountId: string;
  timestamp: string; // ISO string
  copies: number;
  pages: number;
  paperSize: string;
  colorMode: 'colored' | 'bw';
  pricePerPage: number;
  costPerPage: number;
  totalAmount: number; // Benta
  costAmount: number; // Puhunan
  profitAmount: number; // Tubo (Benta - Puhunan)
  customerPaid: number;
  customerChange: number;
}

function getSalesKey(): string {
  return `tindahan_print_sales_acc_${getEffectiveAccountId()}`;
}

function getClearedFlagKey(): string {
  return `tindahan_print_sales_cleared_${getEffectiveAccountId()}`;
}

function getClearedTimestampKey(): string {
  return `tindahan_print_sales_cleared_ts_${getEffectiveAccountId()}`;
}

function isCleared(timestamp: string): boolean {
  try {
    const clearedTs = localStorage.getItem(getClearedTimestampKey());
    if (!clearedTs) return false;
    return new Date(timestamp).getTime() <= parseInt(clearedTs, 10);
  } catch {
    return false;
  }
}

export function getLocalPrintSales(): PrintSaleTransaction[] {
  try {
    if (localStorage.getItem(getClearedFlagKey()) === 'true') {
      return [];
    }
    const raw = localStorage.getItem(getSalesKey());
    if (!raw) return [];
    const items: PrintSaleTransaction[] = JSON.parse(raw);
    // Auto purge items older than 3 months (90 days) or cleared before timestamp
    const threeMonthsAgo = Date.now() - 90 * 24 * 60 * 60 * 1000;
    const validItems = items.filter((item) => {
      if (isCleared(item.timestamp)) return false;
      if (new Date(item.timestamp).getTime() <= threeMonthsAgo) return false;
      return true;
    });
    return validItems;
  } catch {
    return [];
  }
}

export function saveLocalPrintSales(items: PrintSaleTransaction[]) {
  try {
    if (items.length === 0) {
      localStorage.setItem(getClearedTimestampKey(), Date.now().toString());
      localStorage.setItem(getClearedFlagKey(), 'true');
    }
    localStorage.setItem(getSalesKey(), JSON.stringify(items));
  } catch (e) {
    console.error('Error saving print sales:', e);
  }
}

export async function savePrintSaleTransaction(
  sale: Omit<PrintSaleTransaction, 'id' | 'accountId' | 'timestamp'>
): Promise<PrintSaleTransaction> {
  const effectiveAccId = getEffectiveAccountId();
  localStorage.removeItem(getClearedFlagKey());
  const fullSale: PrintSaleTransaction = {
    ...sale,
    id: `sale_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
    accountId: effectiveAccId,
    timestamp: new Date().toISOString(),
  };

  const local = getLocalPrintSales();
  const updated = [fullSale, ...local];
  saveLocalPrintSales(updated);

  try {
    await saveToFirestore('print_sales_transactions', fullSale.id, fullSale);
  } catch (err) {
    console.warn('[Firebase] Firestore print sale save fallback:', err);
  }

  return fullSale;
}

export async function loadPrintSalesFromFirestore(): Promise<PrintSaleTransaction[]> {
  if (isFirestoreQuotaExhausted()) {
    return getLocalPrintSales();
  }
  try {
    const effectiveAccId = getEffectiveAccountId();
    if (localStorage.getItem(getClearedFlagKey()) === 'true') {
      return [];
    }
    const snapshot = await getDocs(collection(db, 'print_sales_transactions'));
    const items: PrintSaleTransaction[] = [];
    const threeMonthsAgo = Date.now() - 90 * 24 * 60 * 60 * 1000;
    snapshot.docs.forEach((docSnap) => {
      const data = docSnap.data() as PrintSaleTransaction;
      if (data.accountId && data.accountId !== effectiveAccId) return;
      if (isCleared(data.timestamp)) return;
      if (new Date(data.timestamp).getTime() <= threeMonthsAgo) return; // skip items older than 3 months
      items.push({
        ...data,
        id: docSnap.id,
      });
    });

    if (items.length > 0) {
      items.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      saveLocalPrintSales(items);
      return items;
    }
  } catch (e) {
    console.warn('[Firebase] Fallback loading print sales:', e);
  }
  return getLocalPrintSales();
}
