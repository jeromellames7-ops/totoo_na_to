import { playLpgDueAlarm, playPillReminderAlarm } from './sound';
import { GasStoveLpgRecord, PillMonitoringPlan } from '../types';

/**
 * Request native Notification permission from browser/device
 */
export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    console.warn('This browser does not support desktop/mobile system notifications.');
    return 'denied';
  }

  if (Notification.permission === 'granted') {
    return 'granted';
  }

  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch (e) {
    console.error('Error requesting notification permission:', e);
    return 'denied';
  }
}

export function isNotificationSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window;
}

export function getNotificationPermissionStatus(): NotificationPermission {
  if (typeof window === 'undefined' || !('Notification' in window)) return 'denied';
  return Notification.permission;
}

/**
 * Trigger a high-priority system notification outside the app
 */
export async function showSystemNotification(
  title: string,
  options: {
    body: string;
    icon?: string;
    badge?: string;
    tag?: string;
    requireInteraction?: boolean;
    playSound?: 'lpg' | 'pill' | 'none';
    vibrate?: number[];
  }
) {
  // Play sound if requested
  if (options.playSound === 'lpg') {
    playLpgDueAlarm();
  } else if (options.playSound === 'pill') {
    playPillReminderAlarm();
  }

  // Mobile vibration if supported
  if (typeof navigator !== 'undefined' && navigator.vibrate) {
    navigator.vibrate(options.vibrate || [200, 100, 200, 100, 400]);
  }

  if (!isNotificationSupported()) {
    return;
  }

  if (Notification.permission !== 'granted') {
    const perm = await requestNotificationPermission();
    if (perm !== 'granted') return;
  }

  try {
    // If Service Worker is available, use showNotification for persistent lockscreen / background delivery
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      const reg = await navigator.serviceWorker.ready;
      reg.showNotification(title, {
        body: options.body,
        icon: options.icon || '/icon-192x192.png',
        badge: options.badge || '/icon-192x192.png',
        tag: options.tag || 'tindahan-home-alert',
        requireInteraction: options.requireInteraction ?? true,
        data: { url: window.location.href },
      } as any);
      return;
    }

    // Standard Notification fallback
    const notif = new Notification(title, {
      body: options.body,
      icon: options.icon || '/icon-192x192.png',
      badge: options.badge || '/icon-192x192.png',
      tag: options.tag || 'tindahan-home-alert',
      requireInteraction: options.requireInteraction ?? true,
    });

    notif.onclick = () => {
      window.focus();
      notif.close();
    };
  } catch (err) {
    console.warn('Could not display system notification:', err);
  }
}

/**
 * Calculate 1-Month due date from purchase date (adds exactly 1 month or 30 days)
 */
export function calculateOneMonthDueDate(purchaseDateStr: string): string {
  try {
    const d = new Date(purchaseDateStr);
    if (isNaN(d.getTime())) {
      const today = new Date();
      today.setMonth(today.getMonth() + 1);
      return today.toISOString().split('T')[0];
    }
    const due = new Date(d);
    due.setMonth(due.getMonth() + 1);
    return due.toISOString().split('T')[0];
  } catch {
    const today = new Date();
    today.setMonth(today.getMonth() + 1);
    return today.toISOString().split('T')[0];
  }
}

/**
 * Calculate days remaining until 1-Month LPG Due Date
 */
export function getLpgDaysRemaining(purchaseDateStr: string, dueDateStr?: string): {
  daysRemaining: number;
  totalDays: number;
  progressPercent: number;
  isDue: boolean;
  dueDate: string;
} {
  const purchase = new Date(purchaseDateStr);
  const due = dueDateStr ? new Date(dueDateStr) : new Date(calculateOneMonthDueDate(purchaseDateStr));
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const totalTime = Math.max(1, due.getTime() - purchase.getTime());
  const totalDays = Math.max(1, Math.round(totalTime / (1000 * 60 * 60 * 24)));

  const diffTime = due.getTime() - today.getTime();
  const daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  const elapsedDays = totalDays - daysRemaining;
  const progressPercent = Math.min(100, Math.max(0, (elapsedDays / totalDays) * 100));

  return {
    daysRemaining,
    totalDays,
    progressPercent,
    isDue: daysRemaining <= 0,
    dueDate: due.toISOString().split('T')[0],
  };
}
