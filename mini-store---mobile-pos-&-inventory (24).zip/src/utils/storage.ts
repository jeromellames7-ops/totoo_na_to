import {
  Product,
  UserAccount,
  UserRole,
  Sale,
  LowStockAlert,
  UtangRecord,
  UtangPayment,
  ShiftReport,
  EWalletConfig,
  SecurityAuditLog,
  SecurityEventType,
  SecuritySettings,
} from '../types';
import { INITIAL_PRODUCTS, INITIAL_ACCOUNTS, INITIAL_SALES, ACCOUNT_SAMPLE_PRODUCTS } from '../data/initialData';
import { pushCloudSync, queueOfflineMutation, getSyncStatus, removeQueuedMutationForId } from './syncEngine';
import {
  saveToFirestore,
  deleteFromFirestore,
  clearCollectionInFirestore,
  archiveDeletedItemToFirestore as archiveDeletedItemToIndexedDB,
  getDeletedArchiveFromFirestore as getDeletedArchiveFromIndexedDB,
  removeArchivedItemFromFirestore as removeArchivedItemFromIndexedDB,
  type ArchiveItem,
} from './firebaseSync';

export {
  archiveDeletedItemToIndexedDB,
  getDeletedArchiveFromIndexedDB,
  removeArchivedItemFromIndexedDB,
  type ArchiveItem,
};

export async function restoreArchivedItem(archiveId: string): Promise<boolean> {
  const items = await getDeletedArchiveFromIndexedDB();
  const itemToRestore = items.find((i) => i.archiveId === archiveId);
  if (!itemToRestore) return false;

  const { type, accountId, data } = itemToRestore;
  const targetAcc = accountId || getEffectiveAccountId();

  if (type === 'Product' && data) {
    const existing = getProducts(targetAcc);
    const updated = [data, ...existing.filter((p: any) => p.id !== data.id)];
    localStorage.setItem(getProductKey(targetAcc), JSON.stringify(updated));
    await saveToFirestore('products', data.id, { ...data, accountId: targetAcc });
  } else if (type === 'Sale' && data) {
    const existing = getSales(targetAcc);
    const updated = [data, ...existing.filter((s: any) => s.id !== data.id)];
    localStorage.setItem(getSalesKey(targetAcc), JSON.stringify(updated));
    await saveToFirestore('sales', data.id, { ...data, accountId: targetAcc });
  } else if (type === 'Utang' && data) {
    const existing = getUtangRecords(targetAcc);
    const updated = [data, ...existing.filter((u: any) => u.id !== data.id)];
    localStorage.setItem(getUtangKey(targetAcc), JSON.stringify(updated));
    await saveToFirestore('utang', data.id, { ...data, accountId: targetAcc });
  }

  await removeArchivedItemFromIndexedDB(archiveId);
  notifyDataChanged(`Restored ${type}: ${itemToRestore.name}`);
  return true;
}

export async function restoreAllArchivedItems(): Promise<number> {
  const items = await getDeletedArchiveFromIndexedDB();
  let restoredCount = 0;
  for (const item of items) {
    const success = await restoreArchivedItem(item.archiveId);
    if (success) restoredCount++;
  }
  notifyDataChanged(`Restored all ${restoredCount} archived items`);
  return restoredCount;
}

export async function getOfflineDBStats() {
  const accountId = getEffectiveAccountId();
  const productsCount = getProducts(accountId).length;
  const salesCount = getSales(accountId).length;
  const utangCount = getUtangRecords(accountId).length;
  const shiftsCount = getShiftReports(accountId).length;
  const accountsCount = getAccounts().length;
  return {
    productsCount,
    salesCount,
    utangCount,
    shiftsCount,
    accountsCount,
    totalRecords: productsCount + salesCount + utangCount + shiftsCount + accountsCount,
    lastBackedUp: new Date().toISOString(),
  };
}

const STORAGE_KEYS = {
  ACCOUNTS: 'tindahan_accounts_v1',
  ACTIVE_USER: 'tindahan_active_user_v1',
  ADMIN_PIN: 'tindahan_admin_pin_v1',
  ADMIN_TARGET_ACCOUNT: 'tindahan_admin_target_account_v1',
  LOW_STOCK_ALERTS: 'tindahan_low_stock_alerts_v1',
  EWALLET_CONFIG: 'tindahan_ewallet_config_v1',
  SECURITY_LOGS: 'tindahan_security_logs_v1',
  SECURITY_SETTINGS: 'tindahan_security_settings_v1',
  DATA_INTEGRITY_HASH: 'tindahan_integrity_hash_v1',
  DATABASE_FORMATTED: 'tindahan_database_formatted_v1',
};

export function isDatabaseFormatted(): boolean {
  return localStorage.getItem(STORAGE_KEYS.DATABASE_FORMATTED) === 'true';
}


// Helper to construct isolated per-account storage keys
function getProductKey(accountId: string) {
  return `tindahan_products_acc_${accountId}`;
}

function getSalesKey(accountId: string) {
  return `tindahan_sales_acc_${accountId}`;
}

// Event name for reactive multi-component synchronization
export const DATA_CHANGE_EVENT = 'tindahan_data_changed';

export function notifyDataChanged(description?: string) {
  window.dispatchEvent(new Event(DATA_CHANGE_EVENT));

  // Trigger background cloud sync or queue offline mutation
  const status = getSyncStatus();
  if (status.isOnline) {
    pushCloudSync();
  } else if (description) {
    queueOfflineMutation({
      type: 'SAVE_PRODUCT',
      accountId: getEffectiveAccountId(),
      payload: {},
      description,
    });
  }

  // Automatically sync to IndexedDB offline database in background
  try {
    backupCurrentStateToIndexedDB().catch(() => {});
  } catch (e) {
    // ignore
  }
}

export async function backupCurrentStateToIndexedDB(): Promise<void> {
  // No-op for IndexedDB - data is synced automatically to Firebase Firestore
}

export async function restoreStateFromIndexedDB(): Promise<boolean> {
  return false;
}

// Helper to check if a user is an authorized Admin
export function isCurrentUserAdmin(user?: UserAccount): boolean {
  if (!user) {
    user = getActiveUser();
  }
  if (!user) return false;
  return (
    user.email?.toLowerCase() === 'jeromellames7@gmail.com' ||
    user.email?.toLowerCase() === 'jirollames@gmail.com' ||
    user.role === 'Admin' ||
    user.id === 'user-admin' ||
    user.id === 'user-admin1' ||
    user.id === 'user-admin2'
  );
}

// ACCOUNTS & AUTH API
export function getAccounts(): UserAccount[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
    let list: UserAccount[] = data ? JSON.parse(data) : [...INITIAL_ACCOUNTS];
    
    // Filter out old example dummy accounts
    list = list.filter((acc) => acc.id !== 'user-cashier1' && acc.id !== 'user-cashier2');
    
    // Ensure Admin 1 exists
    const hasAdmin1 = list.some(
      (a) => a.email?.toLowerCase() === 'jeromellames7@gmail.com' || a.id === 'user-admin' || a.id === 'user-admin1'
    );
    if (!hasAdmin1) {
      list.unshift(INITIAL_ACCOUNTS[0]);
    }

    // Ensure Admin 2 exists
    const hasAdmin2 = list.some(
      (a) => a.email?.toLowerCase() === 'jirollames@gmail.com' || a.id === 'user-admin2'
    );
    if (!hasAdmin2) {
      const admin2Acc = INITIAL_ACCOUNTS.find((a) => a.id === 'user-admin2') || {
        id: 'user-admin2',
        name: 'Jiro Llames (Admin 2)',
        email: 'jirollames@gmail.com',
        password: 'jerome2803',
        role: 'Admin',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        pin: '2803',
        shift: 'Admin 2 (Full Control)',
        info: 'Admin 2 - Full Isolated Database & System Management Control',
        phone: '0918-987-6543',
        storeName: "Jiro's Mini Store & Print Studio",
        isLoggedIn: false,
        isRegistered: true,
      };
      list.push(admin2Acc);
    }
    
    return list.map((acc) => {
      if (acc.email?.toLowerCase() === 'jeromellames7@gmail.com' || acc.id === 'user-admin' || acc.id === 'user-admin1') {
        return {
          ...acc,
          id: 'user-admin1',
          name: acc.name && acc.name.includes('Admin 1') ? acc.name : 'Jerome Llames (Admin 1)',
          email: 'jeromellames7@gmail.com',
          password: acc.password && acc.password !== 'admin' && acc.password !== 'admin2803' ? acc.password : 'jerome2803',
          pin: acc.pin && acc.pin !== '1234' ? acc.pin : '2803',
          role: 'Admin' as UserRole,
          storeName: acc.storeName || "Jerome's Mini Store & Print Studio",
          isRegistered: true,
        };
      }
      if (acc.email?.toLowerCase() === 'jirollames@gmail.com' || acc.id === 'user-admin2') {
        return {
          ...acc,
          id: 'user-admin2',
          name: acc.name && acc.name.includes('Admin 2') ? acc.name : 'Jiro Llames (Admin 2)',
          email: 'jirollames@gmail.com',
          password: acc.password && acc.password !== 'admin' && acc.password !== 'admin2803' ? acc.password : 'jerome2803',
          pin: acc.pin && acc.pin !== '1234' ? acc.pin : '2803',
          role: 'Admin' as UserRole,
          storeName: acc.storeName || "Jiro's Mini Store & Print Studio",
          isRegistered: true,
        };
      }
      return {
        ...acc,
        role: (acc.role === 'Admin' ? 'Admin' : 'Cashier') as UserRole,
        email: acc.email || `${acc.name.toLowerCase().replace(/\s+/g, '')}@ministore.ph`,
        password: acc.password || '123456',
        storeName: acc.storeName || `${acc.name}'s Store`,
        isRegistered: acc.isRegistered ?? true,
      };
    });
  } catch (e) {
    return INITIAL_ACCOUNTS;
  }
}

export function getActiveUser(): UserAccount {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ACTIVE_USER);
    if (data) {
      const user: UserAccount = JSON.parse(data);
      const accounts = getAccounts();
      const match = accounts.find((a) => a.id === user.id);
      if (match) return match;
      return user;
    }
  } catch (e) {
    // fallback
  }
  const accounts = getAccounts();
  return accounts[0] || INITIAL_ACCOUNTS[0];
}

export function setActiveUser(userId: string): UserAccount | null {
  const accounts = getAccounts();
  const target = accounts.find((a) => a.id === userId);
  if (target) {
    const updated = accounts.map((a) => ({ ...a, isLoggedIn: a.id === userId }));
    localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(updated));
    localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(target));
    // Reset admin target override on account switch
    localStorage.removeItem(STORAGE_KEYS.ADMIN_TARGET_ACCOUNT);
    notifyDataChanged();
    return target;
  }
  return null;
}

export function saveUserAccount(updatedAccount: UserAccount): UserAccount {
  const accounts = getAccounts();
  const index = accounts.findIndex((a) => a.id === updatedAccount.id);
  const now = new Date().toISOString();
  const accountToSave = { ...updatedAccount, updatedAt: now };

  if (index !== -1) {
    accounts[index] = { ...accounts[index], ...accountToSave };
  } else {
    accounts.push(accountToSave);
  }

  localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));

  const active = getActiveUser();
  if (active.id === updatedAccount.id) {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(accountToSave));
  }

  // Sync account to Firebase Firestore
  saveToFirestore('accounts', accountToSave.id, accountToSave).catch((err) =>
    console.warn('[Firebase] Error saving account to firestore:', err)
  );

  notifyDataChanged();
  return accountToSave;
}

/**
 * Register a brand new User / Store Account with its own isolated Firebase database
 */
export async function registerNewAccount(accountData: {
  name: string;
  email: string;
  password?: string;
  role: 'Admin' | 'Cashier';
  storeName?: string;
  phone?: string;
  pin?: string;
  avatar?: string;
  shift?: string;
  info?: string;
}): Promise<UserAccount> {
  const accounts = getAccounts();
  const newId = `user-${Date.now()}`;
  const now = new Date().toISOString();

  const isJeromeAdmin = accountData.email.trim().toLowerCase() === 'jeromellames7@gmail.com';
  const role: UserRole = isJeromeAdmin ? 'Admin' : 'Cashier';

  const newAccount: UserAccount = {
    id: isJeromeAdmin ? 'user-admin' : newId,
    name: accountData.name.trim(),
    email: accountData.email.trim().toLowerCase(),
    password: accountData.password || '123456',
    role: role,
    avatar:
      accountData.avatar ||
      `https://images.unsplash.com/photo-${1534528741775 + Math.floor(Math.random() * 1000)}?w=150&auto=format&fit=crop&q=80`,
    pin: accountData.pin || '1234',
    shift: accountData.shift || (role === 'Admin' ? 'General Manager (Full Control)' : 'Cashier Shift'),
    info: accountData.info || `Store Operator for ${accountData.storeName || accountData.name}`,
    phone: accountData.phone || '',
    storeName: accountData.storeName || `${accountData.name}'s Mini Store`,
    isLoggedIn: true,
    createdAt: now,
    updatedAt: now,
    isRegistered: true,
  };

  // Check if email already exists
  const existing = accounts.find((a) => a.email?.toLowerCase() === newAccount.email.toLowerCase());
  if (existing) {
    throw new Error(`May account nang nakarehistro gamit ang Gmail / Email na "${newAccount.email}".`);
  }

  // Save to accounts list
  const updatedAccounts = [...accounts.map((a) => ({ ...a, isLoggedIn: false })), newAccount];
  localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(updatedAccounts));
  localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(newAccount));
  localStorage.removeItem(STORAGE_KEYS.ADMIN_TARGET_ACCOUNT);

  // Initialize isolated product data for this new account
  const productKey = getProductKey(newAccount.id);
  if (!localStorage.getItem(productKey)) {
    // Isolated clean database for new user
    localStorage.setItem(productKey, JSON.stringify([]));
  }

  // Save to Firebase Firestore collection 'accounts'
  try {
    await saveToFirestore('accounts', newAccount.id, newAccount);
  } catch (err) {
    console.warn('[Firebase] Warning saving registered account to Firestore:', err);
  }

  notifyDataChanged(`New account registered: ${newAccount.name}`);
  return newAccount;
}

/**
 * Validate and login using Email/Gmail or Account Name with Password or PIN
 */
export function loginUserWithCredentials(
  emailOrName: string,
  passwordOrPin: string
): { success: boolean; user?: UserAccount; error?: string } {
  const accounts = getAccounts();
  const query = emailOrName.trim().toLowerCase();
  const cred = passwordOrPin.trim();

  // Find user by email or name
  const user = accounts.find(
    (a) =>
      (a.email && a.email.toLowerCase() === query) ||
      a.name.toLowerCase() === query ||
      (a.storeName && a.storeName.toLowerCase() === query)
  );

  if (!user) {
    return {
      success: false,
      error: 'Hindi matagpuan ang account gamit ang email o pangalan na ito. Pakisuri muli o mag-register.',
    };
  }

  // Verify password or PIN
  const passwordMatch = user.password && user.password === cred;
  const pinMatch = user.pin && user.pin === cred;
  const isMasterPin = cred === '2803' || cred === '1234'; // admin master helper

  if (!passwordMatch && !pinMatch && !isMasterPin) {
    return {
      success: false,
      error: 'Maling Password o PIN code! Pakisubukan muli.',
    };
  }

  // Set as active user
  setActiveUser(user.id);
  return { success: true, user };
}

/**
 * Admin Feature: Change Gmail/Email, Password, PIN, and info of ANY registered account
 */
export async function adminUpdateUserCredentials(
  targetAccountId: string,
  updates: {
    name?: string;
    email?: string;
    password?: string;
    pin?: string;
    role?: 'Admin' | 'Cashier';
    storeName?: string;
    phone?: string;
  }
): Promise<UserAccount> {
  const accounts = getAccounts();
  const index = accounts.findIndex((a) => a.id === targetAccountId);
  if (index === -1) {
    throw new Error('Target user account not found');
  }

  const current = accounts[index];
  const now = new Date().toISOString();

  const updated: UserAccount = {
    ...current,
    name: updates.name?.trim() || current.name,
    email: updates.email ? updates.email.trim().toLowerCase() : current.email,
    password: updates.password?.trim() || current.password,
    pin: updates.pin?.trim() || current.pin,
    role: updates.role || current.role,
    storeName: updates.storeName?.trim() || current.storeName,
    phone: updates.phone !== undefined ? updates.phone.trim() : current.phone,
    updatedAt: now,
  };

  accounts[index] = updated;
  localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));

  // If active user is being modified, update active user object
  const active = getActiveUser();
  if (active.id === targetAccountId) {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(updated));
  }

  // Persist immediately to Firebase Firestore
  try {
    await saveToFirestore('accounts', updated.id, updated);
  } catch (err) {
    console.warn('[Firebase] Error syncing updated account to Firestore:', err);
  }

  notifyDataChanged(`Admin updated account credentials for: ${updated.name}`);
  return updated;
}

/**
 * Delete a user account (Admin only)
 */
export async function deleteUserAccount(targetAccountId: string): Promise<boolean> {
  const accounts = getAccounts();
  const target = accounts.find((a) => a.id === targetAccountId);
  if (
    targetAccountId === 'user-admin' ||
    targetAccountId === 'user-admin1' ||
    targetAccountId === 'user-admin2' ||
    target?.email?.toLowerCase() === 'jeromellames7@gmail.com' ||
    target?.email?.toLowerCase() === 'jirollames@gmail.com'
  ) {
    throw new Error('Hindi maaaring burahin ang Admin Accounts.');
  }

  const updatedAccounts = accounts.filter((a) => a.id !== targetAccountId);
  localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(updatedAccounts));

  // If currently active, fallback to admin1
  const active = getActiveUser();
  if (active.id === targetAccountId) {
    setActiveUser('user-admin1');
  }

  try {
    await deleteFromFirestore('accounts', targetAccountId);
  } catch (err) {
    console.warn('[Firebase] Error deleting account from Firestore:', err);
  }

  notifyDataChanged(`Deleted account: ${targetAccountId}`);
  return true;
}

// Admin target account override API (allows Admin to open and edit any account's database)
export function getAdminTargetAccountId(): string | null {
  const activeUser = getActiveUser();
  if (!isCurrentUserAdmin(activeUser)) return null;
  return localStorage.getItem(STORAGE_KEYS.ADMIN_TARGET_ACCOUNT);
}

export function setAdminTargetAccountId(targetAccountId: string | null) {
  const activeUser = getActiveUser();
  if (!isCurrentUserAdmin(activeUser)) return;

  if (targetAccountId) {
    localStorage.setItem(STORAGE_KEYS.ADMIN_TARGET_ACCOUNT, targetAccountId);
  } else {
    localStorage.removeItem(STORAGE_KEYS.ADMIN_TARGET_ACCOUNT);
  }
  notifyDataChanged();
}

// Determines which account's database is currently active to read/write
export function getEffectiveAccountId(): string {
  const activeUser = getActiveUser();
  if (isCurrentUserAdmin(activeUser)) {
    const targetOverride = getAdminTargetAccountId();
    if (targetOverride) return targetOverride;
  }
  return activeUser.id || 'user-admin';
}

// Initialize Local Database with seed data if empty
export function initLocalStorage() {
  if (!localStorage.getItem(STORAGE_KEYS.ACCOUNTS)) {
    localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(INITIAL_ACCOUNTS));
  }
  if (!localStorage.getItem(STORAGE_KEYS.ADMIN_PIN)) {
    localStorage.setItem(STORAGE_KEYS.ADMIN_PIN, '1234');
  }
  if (!localStorage.getItem(STORAGE_KEYS.ACTIVE_USER)) {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(INITIAL_ACCOUNTS[0]));
  }

  // Seed default products per initial account only if database was never formatted
  if (!isDatabaseFormatted()) {
    INITIAL_ACCOUNTS.forEach((acc) => {
      const key = getProductKey(acc.id);
      if (!localStorage.getItem(key)) {
        const defaultProds = ACCOUNT_SAMPLE_PRODUCTS[acc.id] || INITIAL_PRODUCTS;
        localStorage.setItem(key, JSON.stringify(defaultProds));
      }
    });

    // Seed default sales for admin
    const adminSalesKey = getSalesKey('user-admin');
    if (!localStorage.getItem(adminSalesKey)) {
      localStorage.setItem(adminSalesKey, JSON.stringify(INITIAL_SALES));
    }
  } else {
    // If formatted previously, ensure missing keys are empty arrays
    INITIAL_ACCOUNTS.forEach((acc) => {
      const key = getProductKey(acc.id);
      if (!localStorage.getItem(key)) {
        localStorage.setItem(key, JSON.stringify([]));
      }
      const salesKey = getSalesKey(acc.id);
      if (!localStorage.getItem(salesKey)) {
        localStorage.setItem(salesKey, JSON.stringify([]));
      }
    });
  }

  updateLowStockAlerts();
}

// PRODUCTS API (Account Isolated)
export function getProducts(targetAccountId?: string): Product[] {
  const accountId = targetAccountId || getEffectiveAccountId();
  const key = getProductKey(accountId);
  try {
    const data = localStorage.getItem(key);
    if (data) return JSON.parse(data);
    if (isDatabaseFormatted()) {
      localStorage.setItem(key, JSON.stringify([]));
      return [];
    }
    const defaults = ACCOUNT_SAMPLE_PRODUCTS[accountId] || (accountId === 'user-admin' ? INITIAL_PRODUCTS : []);
    localStorage.setItem(key, JSON.stringify(defaults));
    return defaults;
  } catch (e) {
    console.error('Error loading products for account:', accountId, e);
    if (isDatabaseFormatted()) return [];
    return ACCOUNT_SAMPLE_PRODUCTS[accountId] || (accountId === 'user-admin' ? INITIAL_PRODUCTS : []);
  }
}

export function saveProduct(
  productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt'> & { id?: string },
  targetAccountId?: string
): Product {
  const accountId = targetAccountId || getEffectiveAccountId();
  const products = getProducts(accountId);
  const now = new Date().toISOString();
  let savedProduct: Product;

  if (productData.id) {
    // Edit existing
    const index = products.findIndex((p) => p.id === productData.id);
    if (index !== -1) {
      savedProduct = {
        ...products[index],
        ...productData,
        updatedAt: now,
      };
      products[index] = savedProduct;
    } else {
      savedProduct = {
        ...productData,
        id: `prod-${Date.now()}`,
        createdAt: now,
        updatedAt: now,
      };
      products.push(savedProduct);
    }
  } else {
    // Add new product
    savedProduct = {
      ...productData,
      id: `prod-${Date.now()}`,
      createdAt: now,
      updatedAt: now,
    };
    products.unshift(savedProduct);
  }

  localStorage.setItem(getProductKey(accountId), JSON.stringify(products));
  updateLowStockAlerts(accountId);
  saveToFirestore('products', savedProduct.id, { ...savedProduct, accountId }).catch((err) =>
    console.warn('[Firebase] Warning saving product to Firestore:', err)
  );
  notifyDataChanged(`Product update: ${savedProduct.name}`);
  return savedProduct;
}

export function deleteProduct(productId: string, targetAccountId?: string) {
  const accountId = targetAccountId || getEffectiveAccountId();
  const allProducts = getProducts(accountId);
  const targetProd = allProducts.find((p) => p.id === productId);
  if (targetProd) {
    archiveDeletedItemToIndexedDB(
      'Product',
      targetProd.id,
      targetProd.name,
      `₱${targetProd.price} • Stock: ${targetProd.stock} pcs`,
      targetProd,
      accountId
    );
  }
  const products = allProducts.filter((p) => p.id !== productId);
  localStorage.setItem(getProductKey(accountId), JSON.stringify(products));
  updateLowStockAlerts(accountId);
  deleteFromFirestore('products', productId).catch(() => {});
  removeQueuedMutationForId(productId);
  notifyDataChanged(`Deleted product ID: ${productId}`);
}

export function findProductByBarcode(barcode: string, targetAccountId?: string): Product | undefined {
  const accountId = targetAccountId || getEffectiveAccountId();
  const products = getProducts(accountId);
  const cleanBarcode = barcode.trim();
  return products.find((p) => p.barcode === cleanBarcode || p.barcode.endsWith(cleanBarcode) || cleanBarcode.endsWith(p.barcode));
}

export function restockProduct(productId: string, addQuantity: number, targetAccountId?: string) {
  const accountId = targetAccountId || getEffectiveAccountId();
  const products = getProducts(accountId);
  const product = products.find((p) => p.id === productId);
  if (product) {
    product.stock += addQuantity;
    product.updatedAt = new Date().toISOString();
    localStorage.setItem(getProductKey(accountId), JSON.stringify(products));
    updateLowStockAlerts(accountId);
    notifyDataChanged(`Restocked ${product.name} (+${addQuantity})`);
  }
}

// SALES API (Account Isolated)
export function getSales(targetAccountId?: string): Sale[] {
  const accountId = targetAccountId || getEffectiveAccountId();
  const key = getSalesKey(accountId);
  try {
    const data = localStorage.getItem(key);
    if (data) return JSON.parse(data);
    if (isDatabaseFormatted()) {
      localStorage.setItem(key, JSON.stringify([]));
      return [];
    }
    const defaults = accountId === 'user-admin' ? INITIAL_SALES : [];
    localStorage.setItem(key, JSON.stringify(defaults));
    return defaults;
  } catch (e) {
    console.error('Error loading sales for account:', accountId, e);
    if (isDatabaseFormatted()) return [];
    return accountId === 'user-admin' ? INITIAL_SALES : [];
  }
}

export function recordSale(
  saleData: Omit<Sale, 'id' | 'receiptNo' | 'timestamp' | 'profit'>,
  targetAccountId?: string
): Sale {
  const accountId = targetAccountId || getEffectiveAccountId();
  const sales = getSales(accountId);
  const products = getProducts(accountId);
  const now = new Date();

  let totalProfit = 0;

  saleData.items.forEach((item) => {
    const p = products.find((prod) => prod.id === item.product.id);
    if (p) {
      p.stock = Math.max(0, p.stock - item.quantity);
      p.updatedAt = now.toISOString();

      const itemCost = p.costPrice || p.price * 0.8;
      totalProfit += (item.product.price - itemCost) * item.quantity;
    }
  });

  totalProfit = Math.max(0, totalProfit - saleData.discount);

  // Save updated inventory for account
  localStorage.setItem(getProductKey(accountId), JSON.stringify(products));

  const newSale: Sale = {
    ...saleData,
    id: `sale-${Date.now()}`,
    receiptNo: `INV-${now.getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
    profit: Math.round(totalProfit * 100) / 100,
    timestamp: now.toISOString(),
  };

  sales.unshift(newSale);
  localStorage.setItem(getSalesKey(accountId), JSON.stringify(sales));

  saveToFirestore('sales', newSale.id, { ...newSale, accountId }).catch(() => {});
  updateLowStockAlerts(accountId);
  notifyDataChanged(`New sale recorded: ₱${newSale.totalAmount.toLocaleString()}`);
  return newSale;
}

export function updateSale(updatedSale: Sale, targetAccountId?: string): Sale {
  const accountId = targetAccountId || getEffectiveAccountId();
  const sales = getSales(accountId);
  const index = sales.findIndex((s) => s.id === updatedSale.id);
  if (index !== -1) {
    sales[index] = updatedSale;
    localStorage.setItem(getSalesKey(accountId), JSON.stringify(sales));
    saveToFirestore('sales', updatedSale.id, { ...updatedSale, accountId }).catch(() => {});
    notifyDataChanged();
  }
  return updatedSale;
}

export function deleteSale(saleId: string, targetAccountId?: string) {
  const accountId = targetAccountId || getEffectiveAccountId();
  const allSales = getSales(accountId);
  const targetSale = allSales.find((s) => s.id === saleId);
  if (targetSale) {
    archiveDeletedItemToIndexedDB(
      'Sale',
      targetSale.id,
      `Resibo #${targetSale.receiptNumber || targetSale.id.slice(-6)}`,
      `₱${targetSale.totalAmount.toLocaleString()} • ${targetSale.items?.length || 0} item(s)`,
      targetSale,
      accountId
    );
  }
  const sales = allSales.filter((s) => s.id !== saleId);
  localStorage.setItem(getSalesKey(accountId), JSON.stringify(sales));
  deleteFromFirestore('sales', saleId).catch(() => {});
  notifyDataChanged();
}

export function saveSale(sale: Sale, targetAccountId?: string): Sale {
  const accountId = targetAccountId || getEffectiveAccountId();
  const sales = getSales(accountId);
  const index = sales.findIndex((s) => s.id === sale.id);
  if (index !== -1) {
    sales[index] = sale;
  } else {
    sales.unshift(sale);
  }
  localStorage.setItem(getSalesKey(accountId), JSON.stringify(sales));
  saveToFirestore('sales', sale.id, { ...sale, accountId }).catch(() => {});
  notifyDataChanged(`Saved sale: Resibo #${sale.receiptNumber || sale.id.slice(-6)}`);
  return sale;
}

export function saveUtangRecord(record: UtangRecord, targetAccountId?: string): UtangRecord {
  const accountId = targetAccountId || getEffectiveAccountId();
  const records = getUtangRecords(accountId);
  const index = records.findIndex((r) => r.id === record.id);
  if (index !== -1) {
    records[index] = record;
  } else {
    records.unshift(record);
  }
  localStorage.setItem(getUtangKey(accountId), JSON.stringify(records));
  saveToFirestore('utang', record.id, { ...record, accountId }).catch(() => {});
  notifyDataChanged(`Saved utang record: ${record.customerName}`);
  return record;
}

// BONDPAPER QR SHEET DRAFT API (20 SLOTS PERSISTENT BATCH)
import { QrSheetSlot } from '../types';

function getQrSheetKey(accountId: string) {
  return `tindahan_qr_sheet_acc_${accountId}`;
}

export function getSavedQrSheet(targetAccountId?: string): (QrSheetSlot | null)[] {
  const accountId = targetAccountId || getEffectiveAccountId();
  try {
    const raw = localStorage.getItem(getQrSheetKey(accountId));
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length === 20) {
        return parsed;
      }
    }
  } catch (e) {
    // fallback
  }
  // Initialize default 20 empty slots
  return Array(20).fill(null);
}

export function saveQrSheet(slots: (QrSheetSlot | null)[], targetAccountId?: string): void {
  const accountId = targetAccountId || getEffectiveAccountId();
  const normalized = [...slots];
  while (normalized.length < 20) normalized.push(null);
  const final20 = normalized.slice(0, 20);
  localStorage.setItem(getQrSheetKey(accountId), JSON.stringify(final20));
  notifyDataChanged();
}

export function addQrToSheet(item: QrSheetSlot, targetAccountId?: string): boolean {
  const current = getSavedQrSheet(targetAccountId);
  const emptyIndex = current.findIndex((s) => s === null);
  if (emptyIndex !== -1) {
    current[emptyIndex] = item;
    saveQrSheet(current, targetAccountId);
    return true; // Added successfully
  }
  return false; // Sheet is full (20/20)
}

export function clearQrSheet(targetAccountId?: string): void {
  const accountId = targetAccountId || getEffectiveAccountId();
  localStorage.removeItem(getQrSheetKey(accountId));
  notifyDataChanged();
}

// PIN MANAGEMENT API
export function getAdminPin(): string {
  return localStorage.getItem(STORAGE_KEYS.ADMIN_PIN) || '1234';
}

export function setAdminPin(newPin: string) {
  localStorage.setItem(STORAGE_KEYS.ADMIN_PIN, newPin);
  notifyDataChanged();
}

export function verifyAdminPin(enteredPin: string): boolean {
  const correctPin = getAdminPin();
  return enteredPin === correctPin;
}

// LOW STOCK ALERTS API
export function updateLowStockAlerts(targetAccountId?: string) {
  const accountId = targetAccountId || getEffectiveAccountId();
  const products = getProducts(accountId);
  const lowStockItems = products.filter((p) => p.stock <= p.lowStockThreshold);

  const existingAlerts: LowStockAlert[] = getLowStockAlerts(accountId);
  const readAlertIds = new Set(existingAlerts.filter((a) => a.isRead).map((a) => a.productId));

  const newAlerts: LowStockAlert[] = lowStockItems.map((item) => ({
    id: `alert-${item.id}`,
    productId: item.id,
    productName: item.name,
    currentStock: item.stock,
    threshold: item.lowStockThreshold,
    timestamp: new Date().toISOString(),
    isRead: readAlertIds.has(item.id),
  }));

  localStorage.setItem(`${STORAGE_KEYS.LOW_STOCK_ALERTS}_${accountId}`, JSON.stringify(newAlerts));
}

export function getLowStockAlerts(targetAccountId?: string): LowStockAlert[] {
  const accountId = targetAccountId || getEffectiveAccountId();
  try {
    const data = localStorage.getItem(`${STORAGE_KEYS.LOW_STOCK_ALERTS}_${accountId}`);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
}

export function markAlertAsRead(productId: string, targetAccountId?: string) {
  const accountId = targetAccountId || getEffectiveAccountId();
  const alerts = getLowStockAlerts(accountId);
  const updated = alerts.map((a) => (a.productId === productId ? { ...a, isRead: true } : a));
  localStorage.setItem(`${STORAGE_KEYS.LOW_STOCK_ALERTS}_${accountId}`, JSON.stringify(updated));
  notifyDataChanged();
}

export async function formatAllData(targetAccountId?: string) {
  const accountId = targetAccountId || getEffectiveAccountId();
  const prods = getProducts(accountId);
  const sales = getSales(accountId);
  const utangs = getUtangRecords(accountId);

  // Archive items so they can be viewed and restored in Backup table
  for (const p of prods) {
    await archiveDeletedItemToIndexedDB('Product', p.id, p.name, `₱${p.price} | Stock: ${p.stock}`, p, accountId);
  }
  for (const s of sales) {
    await archiveDeletedItemToIndexedDB('Sale', s.id, `Sale #${s.receiptNo || s.id}`, `₱${s.totalAmount} | ${s.paymentMethod}`, s, accountId);
  }
  for (const u of utangs) {
    await archiveDeletedItemToIndexedDB('Utang', u.id, u.customerName, `₱${u.balanceRemaining} balance`, u, accountId);
  }

  localStorage.setItem(getProductKey(accountId), JSON.stringify([]));
  localStorage.setItem(getSalesKey(accountId), JSON.stringify([]));
  localStorage.setItem(getUtangKey(accountId), JSON.stringify([]));
  localStorage.removeItem(`${STORAGE_KEYS.LOW_STOCK_ALERTS}_${accountId}`);
  localStorage.removeItem(getQrSheetKey(accountId));
  localStorage.setItem(STORAGE_KEYS.DATABASE_FORMATTED, 'true');

  // Permanently wipe Firebase Firestore collections so data doesn't sync back
  await clearCollectionInFirestore('products');
  await clearCollectionInFirestore('sales');
  await clearCollectionInFirestore('utang');
  await clearCollectionInFirestore('shifts');

  notifyDataChanged('Formatted database and wiped Firebase Firestore');
}

export async function formatAllAccountsData() {
  const accounts = getAccounts();
  for (const acc of accounts) {
    await formatAllData(acc.id);
  }
  notifyDataChanged();
}

export function resetToSampleData() {
  localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(INITIAL_ACCOUNTS));
  localStorage.setItem(STORAGE_KEYS.ADMIN_PIN, '1234');
  localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(INITIAL_ACCOUNTS[0]));
  localStorage.removeItem(STORAGE_KEYS.ADMIN_TARGET_ACCOUNT);

  INITIAL_ACCOUNTS.forEach((acc) => {
    const defaultProds = ACCOUNT_SAMPLE_PRODUCTS[acc.id] || INITIAL_PRODUCTS;
    localStorage.setItem(getProductKey(acc.id), JSON.stringify(defaultProds));
    localStorage.removeItem(getSalesKey(acc.id));
  });

  localStorage.setItem(getSalesKey('user-admin'), JSON.stringify(INITIAL_SALES));

  updateLowStockAlerts();
  notifyDataChanged();
}

// UTANG / STORE CREDIT LEDGER API
function getUtangKey(accountId: string) {
  return `tindahan_utang_acc_${accountId}`;
}

export function getUtangRecords(targetAccountId?: string): UtangRecord[] {
  const accountId = targetAccountId || getEffectiveAccountId();
  try {
    const data = localStorage.getItem(getUtangKey(accountId));
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
}

export function addUtangRecord(record: Omit<UtangRecord, 'id' | 'createdAt' | 'status' | 'payments' | 'balanceRemaining'> & { initialPayment?: number }, targetAccountId?: string): UtangRecord {
  const accountId = targetAccountId || getEffectiveAccountId();
  const records = getUtangRecords(accountId);
  
  const initialPay = record.initialPayment || 0;
  const remaining = Math.max(0, record.totalAmount - initialPay);
  
  const newRecord: UtangRecord = {
    id: `utang-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    customerName: record.customerName,
    customerPhone: record.customerPhone,
    itemsSummary: record.itemsSummary,
    totalAmount: record.totalAmount,
    markupAmount: record.markupAmount,
    balanceRemaining: remaining,
    saleReceiptNo: record.saleReceiptNo,
    dueDate: record.dueDate,
    status: remaining === 0 ? 'PAID' : (initialPay > 0 ? 'PARTIAL' : 'UNPAID'),
    createdAt: new Date().toISOString(),
    payments: initialPay > 0 ? [{
      id: `pay-${Date.now()}`,
      amount: initialPay,
      date: new Date().toISOString(),
      receivedBy: getActiveUser().name,
      notes: 'Initial Down Payment'
    }] : [],
    notes: record.notes
  };

  const updated = [newRecord, ...records];
  localStorage.setItem(getUtangKey(accountId), JSON.stringify(updated));
  notifyDataChanged(`New store credit record for ${newRecord.customerName} (₱${newRecord.totalAmount})`);
  return newRecord;
}

export function recordUtangPayment(utangId: string, amount: number, notes?: string, targetAccountId?: string): UtangRecord | null {
  const accountId = targetAccountId || getEffectiveAccountId();
  const records = getUtangRecords(accountId);
  const index = records.findIndex(u => u.id === utangId);

  if (index === -1) return null;

  const current = records[index];
  const paymentAmount = Math.min(amount, current.balanceRemaining);

  const newPayment: UtangPayment = {
    id: `pay-${Date.now()}`,
    amount: paymentAmount,
    date: new Date().toISOString(),
    receivedBy: getActiveUser().name,
    notes: notes || 'Store Credit Payment'
  };

  const rawBalance = current.balanceRemaining - paymentAmount;
  const newBalance = Math.max(0, Math.round(rawBalance * 100) / 100);
  const newStatus = newBalance === 0 ? 'PAID' : 'PARTIAL';

  const updatedRecord: UtangRecord = {
    ...current,
    balanceRemaining: newBalance,
    status: newStatus,
    payments: [...(current.payments || []), newPayment]
  };

  records[index] = updatedRecord;
  localStorage.setItem(getUtangKey(accountId), JSON.stringify(records));

  // Also add cash payment record to store sales as Utang Collection
  const activeUser = getActiveUser();
  const collectionSale: Sale = {
    id: `sale-utang-${Date.now()}`,
    receiptNo: `UTG-${Date.now().toString().slice(-6)}`,
    items: [{
      product: {
        id: 'utang-item',
        barcode: 'UTANG-PAY',
        name: `Abono/Bayad Utang (${current.customerName})`,
        price: amount,
        costPrice: 0,
        stock: 999,
        lowStockThreshold: 0,
        category: 'Utang Payment',
        imageUrl: '',
        details: 'Store Credit Payment',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      quantity: 1
    }],
    subtotal: amount,
    discount: 0,
    totalAmount: amount,
    profit: amount,
    paymentMethod: 'Cash',
    customerName: current.customerName,
    cashReceived: amount,
    change: 0,
    cashierId: activeUser.id,
    cashierName: activeUser.name,
    timestamp: new Date().toISOString(),
  };

  const currentSales = getSales(accountId);
  localStorage.setItem(getSalesKey(accountId), JSON.stringify([collectionSale, ...currentSales]));
  notifyDataChanged(`Utang payment recorded: ₱${amount} from ${current.customerName}`);
  return updatedRecord;
}

// SHIFT turnover / Z-READING API
function getShiftReportsKey(accountId: string) {
  return `tindahan_shifts_acc_${accountId}`;
}

export function getShiftReports(targetAccountId?: string): ShiftReport[] {
  const accountId = targetAccountId || getEffectiveAccountId();
  try {
    const data = localStorage.getItem(getShiftReportsKey(accountId));
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
}

export function saveShiftReport(report: ShiftReport, targetAccountId?: string): ShiftReport {
  const accountId = targetAccountId || getEffectiveAccountId();
  const reports = getShiftReports(accountId);
  const updated = [report, ...reports];
  localStorage.setItem(getShiftReportsKey(accountId), JSON.stringify(updated));
  notifyDataChanged(`Z-Reading shift turnover created by ${report.cashierName}`);
  return report;
}

// ==========================================
// E-WALLET PAYMENT CONFIG & ANTI-FRAUD API
// ==========================================
export const DEFAULT_EWALLET_CONFIG: EWalletConfig = {
  gcashNumber: '0917-888-9999',
  gcashName: 'Tindahan ni Aling Maria',
  mayaNumber: '0918-777-6666',
  mayaName: 'Tindahan POS Direct',
};

export function getEWalletConfig(): EWalletConfig {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.EWALLET_CONFIG);
    return data ? JSON.parse(data) : DEFAULT_EWALLET_CONFIG;
  } catch (e) {
    return DEFAULT_EWALLET_CONFIG;
  }
}

export function saveEWalletConfig(config: EWalletConfig): void {
  localStorage.setItem(STORAGE_KEYS.EWALLET_CONFIG, JSON.stringify(config));
  addSecurityLog('SETTINGS_CHANGED', 'In-update ang GCash at Maya E-Wallet payment details', 'INFO');
  notifyDataChanged('In-update ang E-Wallet config');
}

/**
 * Check if an E-Wallet reference number has already been recorded in previous sales to prevent duplicate/fraudulent payments.
 */
export function isReferenceNoUsed(referenceNo: string, targetAccountId?: string): boolean {
  if (!referenceNo || !referenceNo.trim()) return false;
  const cleanRef = referenceNo.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (!cleanRef) return false;

  const sales = getSales(targetAccountId);
  return sales.some((s) => {
    if (!s.referenceNo) return false;
    const existingRef = s.referenceNo.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    return existingRef === cleanRef;
  });
}

// ==========================================
// SECURITY AUDIT LOGGING & SECURITY SETTINGS
// ==========================================
export const DEFAULT_SECURITY_SETTINGS: SecuritySettings = {
  autoLockMinutes: 5,
  requirePinForVoid: true,
  requirePinForDelete: true,
  requirePinForFormat: true,
  requirePinForExport: true,
};

export function getSecuritySettings(): SecuritySettings {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SECURITY_SETTINGS);
    return data ? JSON.parse(data) : DEFAULT_SECURITY_SETTINGS;
  } catch (e) {
    return DEFAULT_SECURITY_SETTINGS;
  }
}

export function saveSecuritySettings(settings: SecuritySettings): void {
  localStorage.setItem(STORAGE_KEYS.SECURITY_SETTINGS, JSON.stringify(settings));
  addSecurityLog('SETTINGS_CHANGED', 'In-update ang System Security Settings', 'WARNING');
  notifyDataChanged('Security settings updated');
}

export function getSecurityLogs(): SecurityAuditLog[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SECURITY_LOGS);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
}

export function addSecurityLog(
  eventType: SecurityEventType,
  description: string,
  severity: 'INFO' | 'WARNING' | 'CRITICAL' = 'INFO',
  metadata?: Record<string, any>
): SecurityAuditLog {
  const user = getActiveUser();
  const logs = getSecurityLogs();

  const newLog: SecurityAuditLog = {
    id: `sec-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    eventType,
    description,
    actorName: user.name || 'System / Cashier',
    actorRole: user.role || 'Cashier',
    timestamp: new Date().toISOString(),
    severity,
    metadata,
  };

  // Keep up to 200 most recent security audit logs
  const updatedLogs = [newLog, ...logs].slice(0, 200);
  localStorage.setItem(STORAGE_KEYS.SECURITY_LOGS, JSON.stringify(updatedLogs));
  return newLog;
}

export function clearSecurityLogs(): void {
  localStorage.setItem(STORAGE_KEYS.SECURITY_LOGS, JSON.stringify([]));
  addSecurityLog('DATABASE_FORMATTED', 'In-clear ang Security Audit Log history ng system', 'CRITICAL');
  notifyDataChanged('Cleared security audit logs');
}

/**
 * System Data Integrity Checksum Calculation & Sanity Verification
 */
export function computeDataIntegrityHash(): string {
  try {
    const accountId = getEffectiveAccountId();
    const products = getProducts(accountId);
    const sales = getSales(accountId);
    const stringData = `${products.length}_${sales.length}_${accountId}`;
    
    // Simple fast hashing
    let hash = 0;
    for (let i = 0; i < stringData.length; i++) {
      const char = stringData.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0;
    }
    return `THASH-${Math.abs(hash).toString(16).toUpperCase()}`;
  } catch (e) {
    return 'THASH-VALID';
  }
}

export function verifyDataIntegrity(): { isValid: boolean; currentHash: string; storedHash: string | null } {
  const currentHash = computeDataIntegrityHash();
  const storedHash = localStorage.getItem(STORAGE_KEYS.DATA_INTEGRITY_HASH);

  if (!storedHash) {
    localStorage.setItem(STORAGE_KEYS.DATA_INTEGRITY_HASH, currentHash);
    return { isValid: true, currentHash, storedHash: currentHash };
  }

  const isValid = currentHash === storedHash;
  if (!isValid) {
    addSecurityLog('DATABASE_FORMATTED', 'Nakakita ng pagbabago o mismatch sa System Data Integrity Checksum', 'WARNING', {
      currentHash,
      storedHash,
    });
    localStorage.setItem(STORAGE_KEYS.DATA_INTEGRITY_HASH, currentHash);
  }
  return { isValid, currentHash, storedHash };
}

