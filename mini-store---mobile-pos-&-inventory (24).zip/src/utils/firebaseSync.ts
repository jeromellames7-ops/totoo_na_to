import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  writeBatch,
  disableNetwork,
  enableNetwork,
} from 'firebase/firestore';
import { db } from '../lib/firebase';

const QUOTA_STORAGE_KEY = 'tindahan_firestore_quota_exhausted_date_v1';

function checkInitialQuotaStatus(): boolean {
  try {
    const storedDate = localStorage.getItem(QUOTA_STORAGE_KEY);
    if (storedDate) {
      const storedTime = parseInt(storedDate, 10);
      // Quota reset: auto-expire after 5 minutes so network is never permanently locked out
      if (!isNaN(storedTime) && Date.now() - storedTime < 5 * 60 * 1000) {
        return true;
      } else {
        localStorage.removeItem(QUOTA_STORAGE_KEY);
      }
    }
  } catch (e) {}
  return false;
}

let isQuotaExhausted = false; // Always start enabled on fresh session/reload to guarantee connection

// Proactively disable Firestore network on startup ONLY IF daily quota is confirmed exhausted
if (isQuotaExhausted) {
  try {
    disableNetwork(db).catch(() => {});
  } catch (e) {}
}

export function isFirestoreQuotaExhausted(): boolean {
  return isQuotaExhausted;
}

export function resetQuotaExhausted(): void {
  isQuotaExhausted = false;
  try {
    localStorage.removeItem(QUOTA_STORAGE_KEY);
  } catch (e) {}
  try {
    enableNetwork(db).catch(() => {});
  } catch (e) {}
}

export function handleFirestoreError(err: any, actionName: string): boolean {
  const errMsg = err?.message || String(err || '');
  const code = err?.code || '';
  
  // Document size limit errors should NOT lock out the database network!
  if (errMsg.includes('exceeds the maximum allowed size') || errMsg.includes('maximum allowed size')) {
    console.warn(`[Firebase] Document size limit warning in ${actionName}: Payload too large for single doc.`);
    return false;
  }

  // Strict check for real Cloud Firestore daily quota exhaustion ONLY
  if (
    code === 'resource-exhausted' ||
    code === 9 ||
    errMsg.includes('Quota limit exceeded') ||
    errMsg.includes('resource-exhausted') ||
    errMsg.includes('RESOURCE_EXHAUSTED') ||
    errMsg.includes('free tier database') ||
    errMsg.includes('Free daily write units per project') ||
    errMsg.includes('Free daily read units per project')
  ) {
    if (!isQuotaExhausted) {
      isQuotaExhausted = true;
      try {
        localStorage.setItem(QUOTA_STORAGE_KEY, Date.now().toString());
      } catch (e) {}
      console.warn(
        `[Firebase] Firestore daily free quota reached on GCP (${actionName}). Operating in offline-first mode with LocalStorage & IndexedDB persistence.`
      );
    }
    return true;
  }
  if (
    code === 'unavailable' ||
    errMsg.includes('Could not reach Cloud Firestore backend') ||
    errMsg.includes('unavailable') ||
    errMsg.includes('Failed to get document')
  ) {
    console.warn(`[Firebase] Firestore backend currently unavailable/offline (${actionName}). Operating seamlessly in offline mode.`);
    return true;
  }
  console.warn(`[Firebase] Warning during ${actionName}:`, err);
  return false;
}

export async function saveToFirestore(collectionName: string, id: string, data: any) {
  if (isQuotaExhausted) return;
  try {
    const docRef = doc(db, collectionName, id);
    await setDoc(docRef, { ...data, id }, { merge: true });
  } catch (err) {
    handleFirestoreError(err, `saveToFirestore (${collectionName})`);
  }
}

export async function deleteFromFirestore(collectionName: string, id: string) {
  try {
    const docRef = doc(db, collectionName, id);
    await deleteDoc(docRef);
  } catch (err) {
    handleFirestoreError(err, `deleteFromFirestore (${collectionName})`);
  }
}

export async function clearCollectionInFirestore(collectionName: string) {
  try {
    const snapshot = await getDocs(collection(db, collectionName));
    if (snapshot && !snapshot.empty) {
      const batch = writeBatch(db);
      snapshot.docs.forEach((d) => batch.delete(d.ref));
      await batch.commit();
    }
  } catch (err) {
    handleFirestoreError(err, `clearCollectionInFirestore (${collectionName})`);
  }
}

export interface ArchiveItem {
  archiveId: string;
  type: 'Product' | 'Sale' | 'Utang';
  originalId: string;
  name: string;
  details: string;
  deletedAt: string;
  accountId?: string;
  data: any;
}

const LOCAL_ARCHIVE_KEY = 'tindahan_deleted_archive_v1';

export function getLocalArchiveItems(): ArchiveItem[] {
  try {
    const data = localStorage.getItem(LOCAL_ARCHIVE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
}

export function saveLocalArchiveItems(items: ArchiveItem[]): void {
  localStorage.setItem(LOCAL_ARCHIVE_KEY, JSON.stringify(items));
}

export async function archiveDeletedItemToFirestore(
  type: 'Product' | 'Sale' | 'Utang',
  originalId: string,
  name: string,
  details: string,
  data: any,
  accountId?: string
): Promise<void> {
  const archiveId = `${type}_${originalId}_${Date.now()}`;
  const archiveItem: ArchiveItem = {
    archiveId,
    type,
    originalId,
    name,
    details,
    deletedAt: new Date().toISOString(),
    accountId,
    data,
  };

  // Save to local archive
  const localItems = getLocalArchiveItems();
  const updatedLocal = [archiveItem, ...localItems.filter((i) => i.archiveId !== archiveId)];
  saveLocalArchiveItems(updatedLocal);

  // Save to Firestore
  await saveToFirestore('deletedArchive', archiveId, archiveItem);
}

export async function getDeletedArchiveFromFirestore(): Promise<ArchiveItem[]> {
  if (isQuotaExhausted) {
    return getLocalArchiveItems();
  }
  try {
    const snapshot = await getDocs(collection(db, 'deletedArchive'));
    const items = snapshot.docs.map((d) => d.data() as ArchiveItem);
    if (items.length > 0) {
      const sorted = items.sort((a, b) => new Date(b.deletedAt).getTime() - new Date(a.deletedAt).getTime());
      saveLocalArchiveItems(sorted);
      return sorted;
    }
  } catch (e) {
    console.warn('[Firebase] Error loading archive from Firestore, using local fallback:', e);
  }
  return getLocalArchiveItems();
}

export async function removeArchivedItemFromFirestore(archiveId: string): Promise<void> {
  const localItems = getLocalArchiveItems().filter((i) => i.archiveId !== archiveId);
  saveLocalArchiveItems(localItems);
  await deleteFromFirestore('deletedArchive', archiveId);
}

export async function clearAllArchivedItemsFromFirestore(): Promise<void> {
  saveLocalArchiveItems([]);
  await clearCollectionInFirestore('deletedArchive');
}
