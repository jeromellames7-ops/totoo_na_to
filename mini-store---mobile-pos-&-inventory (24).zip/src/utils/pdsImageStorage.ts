import { collection, doc, setDoc, deleteDoc, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { handleFirestoreError, isFirestoreQuotaExhausted } from './firebaseSync';
import { getEffectiveAccountId } from './storage';

export interface PdsStoredImage {
  id: string;
  src: string; // High quality base64 image data
  accountId?: string;
  applicantName?: string;
  pageTitle?: string;
  pageNumber?: number;
  searchKey?: string;
  createdAt?: string;
  uploadedAt?: string;
  docId?: string;
  order?: number;
}

const DB_NAME = 'TindahanPdsPicturesDB_v1';
const DB_VERSION = 1;
const STORE_NAME = 'pds_pictures';

function openPdsDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const dbInstance = request.result;
      if (!dbInstance.objectStoreNames.contains(STORE_NAME)) {
        dbInstance.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Optimize / compress image for Firestore cloud storage (< 400KB per image)
 */
export async function compressImageForCloud(
  base64Str: string,
  maxDimension = 1200,
  quality = 0.72
): Promise<string> {
  if (!base64Str || typeof base64Str !== 'string') return '';
  // If already very lightweight (< 120KB), keep as is
  if (base64Str.length < 120000 && !base64Str.startsWith('data:image/png')) {
    return base64Str;
  }

  return new Promise((resolve) => {
    try {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        let width = img.width || 1000;
        let height = img.height || 1400;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = Math.max(width, 1);
        canvas.height = Math.max(height, 1);
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(base64Str);
          return;
        }

        // Fill white background in case of transparent png
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        let compressed = canvas.toDataURL('image/jpeg', quality);

        // Safety pass: If still over 500KB, re-compress with smaller dimensions
        if (compressed.length > 500000) {
          const smallCanvas = document.createElement('canvas');
          smallCanvas.width = Math.max(Math.round(width * 0.75), 1);
          smallCanvas.height = Math.max(Math.round(height * 0.75), 1);
          const sCtx = smallCanvas.getContext('2d');
          if (sCtx) {
            sCtx.fillStyle = '#ffffff';
            sCtx.fillRect(0, 0, smallCanvas.width, smallCanvas.height);
            sCtx.drawImage(canvas, 0, 0, smallCanvas.width, smallCanvas.height);
            compressed = smallCanvas.toDataURL('image/jpeg', 0.58);
          }
        }

        resolve(compressed);
      };
      img.onerror = () => resolve(base64Str);
      img.src = base64Str;
    } catch {
      resolve(base64Str);
    }
  });
}

/**
 * Save or update an array of PDS images in IndexedDB (fast local caching)
 */
export async function savePdsImagesToIndexedDB(images: PdsStoredImage[], targetAccountId?: string): Promise<void> {
  if (!images || images.length === 0) return;
  const accId = targetAccountId || getEffectiveAccountId();
  try {
    const localDb = await openPdsDb();
    const tx = localDb.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    for (const img of images) {
      if (img.id && img.src) {
        store.put({
          ...img,
          accountId: img.accountId || accId,
        });
      }
    }
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('[IndexedDB] Error saving PDS images:', err);
  }
}

/**
 * Get all stored PDS images from IndexedDB (Scoped to current account)
 */
export async function getAllPdsImagesFromIndexedDB(targetAccountId?: string): Promise<PdsStoredImage[]> {
  const effectiveAccId = targetAccountId || getEffectiveAccountId();
  try {
    const localDb = await openPdsDb();
    const tx = localDb.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const request = store.getAll();
    return new Promise((resolve, reject) => {
      request.onsuccess = () => {
        const rawResults: PdsStoredImage[] = request.result || [];
        const results = rawResults.filter((img) => {
          if (!img.accountId) {
            return effectiveAccId === 'user-admin1' || effectiveAccId === 'user-admin';
          }
          return img.accountId === effectiveAccId;
        });
        results.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
        resolve(results);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (err) {
    console.warn('[IndexedDB] Error reading PDS images:', err);
    return [];
  }
}

/**
 * Delete a specific PDS image by ID or src from IndexedDB
 */
export async function deletePdsImageFromIndexedDB(idOrSrc: string): Promise<void> {
  try {
    const localDb = await openPdsDb();
    const tx = localDb.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);

    // Check if key matches direct ID
    store.delete(idOrSrc);

    // Also scan for any records matching src
    const allReq = store.getAll();
    allReq.onsuccess = () => {
      const all: PdsStoredImage[] = allReq.result || [];
      all.forEach((item) => {
        if (item.src === idOrSrc) {
          store.delete(item.id);
        }
      });
    };

    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('[IndexedDB] Error deleting PDS image:', err);
  }
}

/**
 * Clear all stored PDS images from IndexedDB for the current account
 */
export async function clearAllPdsImagesFromIndexedDB(targetAccountId?: string): Promise<void> {
  const effectiveAccId = targetAccountId || getEffectiveAccountId();
  try {
    const localDb = await openPdsDb();
    const tx = localDb.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const allReq = store.getAll();
    allReq.onsuccess = () => {
      const all: PdsStoredImage[] = allReq.result || [];
      all.forEach((item) => {
        const imgAcc = item.accountId || 'user-admin1';
        if (imgAcc === effectiveAccId || (effectiveAccId === 'user-admin1' && imgAcc === 'user-admin')) {
          store.delete(item.id);
        }
      });
    };
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('[IndexedDB] Error clearing PDS images database:', err);
  }
}

/**
 * SAVE or UPDATE PDS Images to Firebase Firestore (Online Sync across devices) + Local IndexedDB
 */
export async function savePdsImagesToFirebaseAndIndexedDB(
  images: PdsStoredImage[],
  accountId?: string
): Promise<void> {
  if (!images || images.length === 0) return;
  const effectiveAccId = accountId || getEffectiveAccountId();

  // 1. Save to local IndexedDB immediately
  await savePdsImagesToIndexedDB(images, effectiveAccId);

  try {
    localStorage.removeItem('tindahan_doc_extractor_cleared_at');
  } catch (e) {}

  // 2. Save to Firestore online cloud database
  try {
    for (const img of images) {
      if (!img.src) continue;
      const validId = img.id || `pds_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
      const sanitizedId = validId.replace(/[^a-zA-Z0-9_-]/g, '_');
      const cloudOptimizedSrc = await compressImageForCloud(img.src);

      const payload: Record<string, any> = {
        id: sanitizedId,
        accountId: effectiveAccId,
        src: cloudOptimizedSrc || img.src,
        applicantName: img.applicantName || 'Aplikante PDS',
        pageTitle: img.pageTitle || 'PDS Pahina',
        pageNumber: img.pageNumber || 1,
        searchKey: (img.searchKey || img.applicantName || '').toLowerCase(),
        createdAt: img.createdAt || new Date().toISOString(),
        uploadedAt: img.uploadedAt || new Date().toISOString(),
        docId: img.docId || '',
        order: img.order ?? 0,
        updatedAt: new Date().toISOString(),
      };

      const docRef = doc(db, 'pds_pictures', `${sanitizedId}_${effectiveAccId}`);
      await setDoc(docRef, payload, { merge: true });
    }
  } catch (err) {
    handleFirestoreError(err, 'savePdsImagesToFirebase');
  }
}

/**
 * Update PDS Image metadata (e.g. renamed name) in Firebase and IndexedDB
 */
export async function updatePdsImageMetadataInFirebaseAndIndexedDB(
  id: string,
  updates: Partial<PdsStoredImage>,
  accountId?: string
): Promise<void> {
  const effectiveAccId = accountId || getEffectiveAccountId();
  try {
    // 1. Update in local IndexedDB
    const all = await getAllPdsImagesFromIndexedDB(effectiveAccId);
    const updated = all.map((img) => (img.id === id ? { ...img, ...updates, accountId: effectiveAccId } : img));
    await savePdsImagesToIndexedDB(updated, effectiveAccId);

    // 2. Update in Firestore
    if (!isFirestoreQuotaExhausted()) {
      const sanitizedId = id.replace(/[^a-zA-Z0-9_-]/g, '_');
      const docRef = doc(db, 'pds_pictures', `${sanitizedId}_${effectiveAccId}`);
      await setDoc(docRef, { ...updates, accountId: effectiveAccId, updatedAt: new Date().toISOString() }, { merge: true });
    }
  } catch (err) {
    handleFirestoreError(err, 'updatePdsImageMetadata');
  }
}

/**
 * DELETE a single PDS Image from Firebase Firestore and IndexedDB
 */
export async function deletePdsImageFromFirebaseAndIndexedDB(idOrSrc: string, accountId?: string): Promise<void> {
  const effectiveAccId = accountId || getEffectiveAccountId();
  // 1. Local delete
  await deletePdsImageFromIndexedDB(idOrSrc);

  // 2. Cloud Firestore delete
  try {
    const sanitizedId = idOrSrc.replace(/[^a-zA-Z0-9_-]/g, '_');
    await deleteDoc(doc(db, 'pds_pictures', `${sanitizedId}_${effectiveAccId}`)).catch(() => {});
    await deleteDoc(doc(db, 'pds_pictures', sanitizedId)).catch(() => {});

    // In case id was different from key, search & delete matching src docs for this account
    if (idOrSrc.startsWith('data:') || idOrSrc.length > 50) {
      const snap = await getDocs(collection(db, 'pds_pictures'));
      const deletes = snap.docs
        .filter((d) => {
          const data = d.data();
          const docAcc = data?.accountId || 'user-admin1';
          return (docAcc === effectiveAccId || (effectiveAccId === 'user-admin1' && docAcc === 'user-admin')) &&
            (data?.src === idOrSrc || d.id === sanitizedId || d.id === `${sanitizedId}_${effectiveAccId}`);
        })
        .map((d) => deleteDoc(doc(db, 'pds_pictures', d.id)));
      await Promise.allSettled(deletes);
    }
  } catch (err) {
    handleFirestoreError(err, 'deletePdsImageFromFirebase');
  }
}

/**
 * DELETE PDS Images by Applicant Name from Firebase Firestore and IndexedDB
 */
export async function deletePdsImagesByApplicantNameFromFirebaseAndIndexedDB(applicantName: string, accountId?: string): Promise<void> {
  if (!applicantName || applicantName.trim() === '') return;
  const cleanSearch = applicantName.trim().toLowerCase();
  const effectiveAccId = accountId || getEffectiveAccountId();
  
  // 1. Delete from IndexedDB
  try {
    const all = await getAllPdsImagesFromIndexedDB(effectiveAccId);
    const remaining = all.filter((img) => {
      const itemApp = (img.applicantName || '').trim().toLowerCase();
      const itemKey = (img.searchKey || '').trim().toLowerCase();
      return !itemApp.includes(cleanSearch) && !cleanSearch.includes(itemApp) && !itemKey.includes(cleanSearch);
    });
    const localDb = await openPdsDb();
    const tx = localDb.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    // Delete only matching items for this account
    all.forEach((img) => {
      const itemApp = (img.applicantName || '').trim().toLowerCase();
      const itemKey = (img.searchKey || '').trim().toLowerCase();
      if (itemApp.includes(cleanSearch) || cleanSearch.includes(itemApp) || itemKey.includes(cleanSearch)) {
        store.delete(img.id);
      }
    });
    for (const img of remaining) {
      store.put(img);
    }
  } catch (e) {
    console.warn('[IndexedDB] Error deleting photos by name:', e);
  }

  // 2. Delete from Firestore
  try {
    const snap = await getDocs(collection(db, 'pds_pictures'));
    const deletes = snap.docs
      .filter((d) => {
        const data = d.data();
        const docAcc = data?.accountId || 'user-admin1';
        if (docAcc !== effectiveAccId && !(effectiveAccId === 'user-admin1' && docAcc === 'user-admin')) {
          return false;
        }
        const itemApp = (data?.applicantName || '').trim().toLowerCase();
        const itemKey = (data?.searchKey || '').trim().toLowerCase();
        return itemApp.includes(cleanSearch) || cleanSearch.includes(itemApp) || itemKey.includes(cleanSearch);
      })
      .map((d) => deleteDoc(doc(db, 'pds_pictures', d.id)));
    await Promise.allSettled(deletes);
  } catch (err) {
    handleFirestoreError(err, 'deletePdsImagesByApplicantNameFromFirebase');
  }
}

/**
 * CLEAR ALL PDS Images from Firebase Firestore and IndexedDB for the current account
 */
export async function clearAllPdsImagesFromFirebaseAndIndexedDB(accountId?: string): Promise<void> {
  const effectiveAccId = accountId || getEffectiveAccountId();
  // 1. Clear local
  await clearAllPdsImagesFromIndexedDB(effectiveAccId);

  // 2. Clear cloud Firestore
  try {
    const snap = await getDocs(collection(db, 'pds_pictures'));
    const deletePromises = snap.docs
      .filter((d) => {
        const docAcc = d.data()?.accountId || 'user-admin1';
        return docAcc === effectiveAccId || (effectiveAccId === 'user-admin1' && docAcc === 'user-admin');
      })
      .map((d) => deleteDoc(doc(db, 'pds_pictures', d.id)));
    await Promise.allSettled(deletePromises);
  } catch (err) {
    handleFirestoreError(err, 'clearAllPdsImagesFromFirebase');
  }
}
