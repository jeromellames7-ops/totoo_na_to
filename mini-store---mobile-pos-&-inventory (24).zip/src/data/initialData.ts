import { Product, UserAccount, Sale } from '../types';

export const INITIAL_ACCOUNTS: UserAccount[] = [
  {
    id: 'user-admin1',
    name: 'Jerome Llames (Admin 1)',
    email: 'jeromellames7@gmail.com',
    password: 'jerome2803',
    role: 'Admin',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    pin: '2803',
    shift: 'Primary Admin 1 (Full Control)',
    info: 'Admin 1 - Full Isolated Database & System Management Control',
    phone: '0917-123-4567',
    storeName: "Jerome's Mini Store & Print Studio",
    isLoggedIn: true,
    isRegistered: true,
  },
  {
    id: 'user-admin2',
    name: 'Jiro Llames (Admin 2)',
    email: 'jirollames@gmail.com',
    password: 'jerome2803',
    role: 'Admin',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    pin: '2803',
    shift: 'Admin 2 (Full Control)',
    info: 'Admin 2 - Full Isolated Database & System Management Control',
    phone: '0918-987-6543',
    storeName: "Jiro's Mini Store & Print Studio",
    isLoggedIn: false,
    isRegistered: true,
  },
];

export const INITIAL_PRODUCTS: Product[] = [];

const now = new Date();
const todayISO = now.toISOString();

export const INITIAL_SALES: Sale[] = [];

export const ACCOUNT_SAMPLE_PRODUCTS: Record<string, Product[]> = {
  'user-admin': [],
  'user-cashier1': [],
  'user-cashier2': [],
};
