import React, { useState, useEffect, useRef } from 'react';
import { Product, CartItem, Sale, TabType, UserAccount, LowStockAlert } from './types';
import {
  initLocalStorage,
  getProducts,
  getSales,
  getActiveUser,
  getLowStockAlerts,
  getEffectiveAccountId,
  getAdminTargetAccountId,
  recordSale,
  addUtangRecord,
  DATA_CHANGE_EVENT,
} from './utils/storage';
import { playSuccessChime, playLpgDueAlarm, playPillReminderAlarm } from './utils/sound';
import { showSystemNotification, getLpgDaysRemaining } from './utils/notificationHelper';
import { getLocalGasRecords, getLocalPillPlan, recordPillTaken } from './utils/homeMonitoringStorage';
import { getLanguage, t, LANG_CHANGE_EVENT } from './utils/language';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { BarcodeScanner } from './components/BarcodeScanner';
import { QuickCheckoutModal } from './components/QuickCheckoutModal';
import { ProductFormModal } from './components/ProductFormModal';
import { PrintableQrSheetModal } from './components/PrintableQrSheetModal';
import { CartDrawer } from './components/CartDrawer';
import { ReceiptModal } from './components/ReceiptModal';
import { InventoryList } from './components/InventoryList';
import { SalesDashboard } from './components/SalesDashboard';
import { SalesHistory } from './components/SalesHistory';
import { AccountsManager } from './components/AccountsManager';
import { AccountSettingsModal } from './components/AccountSettingsModal';
import { PinModal } from './components/PinModal';
import { LowStockAlertDrawer } from './components/LowStockAlertDrawer';
import { UnregisteredBarcodeModal } from './components/UnregisteredBarcodeModal';
import { InstallApkModal } from './components/InstallApkModal';
import { UtangLedgerModal } from './components/UtangLedgerModal';
import { AiBusinessAssistantModal } from './components/AiBusinessAssistantModal';
import { ZReadingModal } from './components/ZReadingModal';
import { CsvImportExportModal } from './components/CsvImportExportModal';
import { DataSyncStatusModal } from './components/DataSyncStatusModal';
import { SecurityAuditModal } from './components/SecurityAuditModal';
import { TerminalLockOverlay } from './components/TerminalLockOverlay';
import { PortalFrontPage } from './components/PortalFrontPage';
import { PrintStudio } from './components/PrintStudio';
import { HomeMonitoring } from './components/HomeMonitoring';
import { DocExtractor } from './components/DocExtractor';
import { AppModule } from './types';
import { getSecuritySettings, addSecurityLog } from './utils/storage';
import { ShoppingBag, AlertTriangle, Layers } from 'lucide-react';

export default function App() {
  const [activeModule, setActiveModule] = useState<AppModule>(() => {
    try {
      const saved = localStorage.getItem('tindahan_active_module');
      if (saved && ['portal', 'printstudio', 'homemonitoring', 'docscanner', 'pos'].includes(saved)) {
        return saved as AppModule;
      }
    } catch {}
    return 'portal';
  });
  const [activeTab, setActiveTab] = useState<TabType>('pos');
  const [isMobileFrame, setIsMobileFrame] = useState<boolean>(false);

  // Core App State
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [activeUser, setActiveUserState] = useState<UserAccount>(getActiveUser());
  const [lowStockAlerts, setLowStockAlerts] = useState<LowStockAlert[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [, setLangState] = useState(getLanguage());

  // Modals
  const [scannedProduct, setScannedProduct] = useState<Product | null>(null);
  const [unregisteredBarcode, setUnregisteredBarcode] = useState<string | null>(null);
  const [isProductFormOpen, setIsProductFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [initialBarcodeForForm, setInitialBarcodeForForm] = useState('');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedReceiptSale, setSelectedReceiptSale] = useState<Sale | null>(null);
  const [isLowStockDrawerOpen, setIsLowStockDrawerOpen] = useState(false);
  const [isInstallApkModalOpen, setIsInstallApkModalOpen] = useState(false);

  // Advanced Feature Modals State
  const [isUtangModalOpen, setIsUtangModalOpen] = useState(false);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [isZReadingModalOpen, setIsZReadingModalOpen] = useState(false);
  const [isCsvModalOpen, setIsCsvModalOpen] = useState(false);
  const [isDataSyncModalOpen, setIsDataSyncModalOpen] = useState(false);
  const [isSecurityModalOpen, setIsSecurityModalOpen] = useState(false);
  const [isAccountSettingsModalOpen, setIsAccountSettingsModalOpen] = useState(false);
  const [isTerminalLocked, setIsTerminalLocked] = useState(false);

  // Inactivity Auto-Lock Timer
  useEffect(() => {
    let timer: any = null;

    const resetInactivityTimer = () => {
      if (timer) clearTimeout(timer);
      const settings = getSecuritySettings();
      if (settings.autoLockMinutes > 0 && !isTerminalLocked) {
        timer = setTimeout(() => {
          setIsTerminalLocked(true);
          addSecurityLog('LOCK_TERMINAL', 'Awtomatikong na-lock ang terminal dahil sa inactivity', 'INFO');
        }, settings.autoLockMinutes * 60 * 1000);
      }
    };

    const events = ['mousemove', 'keydown', 'click', 'touchstart'];
    events.forEach((evt) => window.addEventListener(evt, resetInactivityTimer));
    resetInactivityTimer();

    return () => {
      if (timer) clearTimeout(timer);
      events.forEach((evt) => window.removeEventListener(evt, resetInactivityTimer));
    };
  }, [isTerminalLocked]);


  // 20-QR Bondpaper Printable Sheet state
  const [isPrintQrSheetOpen, setIsPrintQrSheetOpen] = useState(false);
  const [highlightedQrBarcode, setHighlightedQrBarcode] = useState<string | undefined>(undefined);

  // Admin Security PIN Modal state
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [pinSuccessCallback, setPinSuccessCallback] = useState<(() => void) | null>(null);
  const [pinModalTitle, setPinModalTitle] = useState('Admin Security PIN Required');

  // Load and subscribe to local database
  const loadData = () => {
    const effectiveAccId = getEffectiveAccountId();
    setProducts(getProducts(effectiveAccId));
    setSales(getSales(effectiveAccId));
    setActiveUserState(getActiveUser());
    setLowStockAlerts(getLowStockAlerts(effectiveAccId));
  };

  useEffect(() => {
    initLocalStorage();
    loadData();

    const handleDataChange = () => {
      loadData();
    };

    const handleLangChange = () => setLangState(getLanguage());

    window.addEventListener(DATA_CHANGE_EVENT, handleDataChange);
    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    return () => {
      window.removeEventListener(DATA_CHANGE_EVENT, handleDataChange);
      window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
    };
  }, []);

  // =========================================================================
  // GLOBAL BACKGROUND ALARM & NOTIFICATION ENGINE
  // (Checks LPG 1-Month Due & Daily 7:00 PM Pill Reminder across entire app)
  // =========================================================================
  useEffect(() => {
    let lastCheckedMinute = '';
    const checkInterval = setInterval(() => {
      const now = new Date();
      const currentHHMM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      const todayStr = now.toISOString().split('T')[0];
      const minuteKey = `${todayStr}_${currentHHMM}`;

      if (lastCheckedMinute === minuteKey) return;
      lastCheckedMinute = minuteKey;

      // 1. Check LPG 1-Month Expiry
      const currentGas = getLocalGasRecords();
      currentGas.forEach((gas) => {
        const stats = getLpgDaysRemaining(gas.purchaseDate, gas.dueDate);
        if (stats.isDue) {
          const lastAlertKey = `lpg_alert_date_${gas.id}`;
          const lastAlertDate = localStorage.getItem(lastAlertKey);
          if (lastAlertDate !== todayStr) {
            localStorage.setItem(lastAlertKey, todayStr);
            playLpgDueAlarm();
            showSystemNotification('🔥 Gasul 1-Month Due Reminder!', {
              body: `Ang iyong ${gas.brand} na binili noong ${gas.purchaseDate} ay naka-1 buwan na (Due Date: ${stats.dueDate})! Oras na para mag-refill.`,
              playSound: 'lpg',
              tag: `lpg-due-${gas.id}`,
            });
          }
        }
      });

      // 2. Check Pills 7:00 PM Reminder (or configured reminder time)
      const currentPlan = getLocalPillPlan();
      if (currentPlan && currentPlan.isActive) {
        const reminderTime = currentPlan.reminderTime || '19:00'; // Default 7:00 PM
        const isReminderTimeNow = currentHHMM === reminderTime;
        const alreadyLoggedToday = currentPlan.logs.some((l) => l.date === todayStr && l.taken);

        if (isReminderTimeNow && !alreadyLoggedToday) {
          playPillReminderAlarm();
          showSystemNotification('💊 7:00 PM Pill Reminder!', {
            body: `Oras na uminom ng iyong ${currentPlan.pillBrand} (Pill #${currentPlan.currentPillIndex} of ${currentPlan.totalPillsInPack})! Awtomatikong binilang na ang araw na ito.`,
            playSound: 'pill',
            tag: `pill-daily-${todayStr}`,
          });
          recordPillTaken(currentPlan, true, 'Auto-counted at 7:00 PM Alarm');
        }
      }
    }, 15000); // Check every 15 seconds

    return () => clearInterval(checkInterval);
  }, []);

  // Request Admin PIN before performing sensitive action
  const requestAdminPin = (onSuccess: () => void, title = 'Admin Protection PIN Required') => {
    if (activeUser.role === 'Admin') {
      setPinModalTitle(title);
      setPinSuccessCallback(() => onSuccess);
      setIsPinModalOpen(true);
    } else {
      setPinModalTitle('Kailangan ng Admin PIN para sa action na ito');
      setPinSuccessCallback(() => onSuccess);
      setIsPinModalOpen(true);
    }
  };

  // Cart operations
  const handleAddToCart = (product: Product, quantity = 1) => {
    setCart((prevCart) => {
      const existing = prevCart.find((item) => item.product.id === product.id);
      if (existing) {
        return prevCart.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: Math.min(product.stock, item.quantity + quantity) }
            : item
        );
      }
      return [...prevCart, { product, quantity: Math.min(product.stock, quantity) }];
    });
  };

  const handleUpdateCartQuantity = (productId: string, delta: number) => {
    setCart((prevCart) =>
      prevCart
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 && newQty <= item.product.stock ? { ...item, quantity: newQty } : item;
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.product.id !== productId));
  };

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const unreadLowStockCount = lowStockAlerts.filter((a) => !a.isRead).length;

  const adminTargetId = activeUser.role === 'Admin' ? getAdminTargetAccountId() : null;

  const handleSelectModule = (mod: AppModule) => {
    setActiveModule(mod);
    try {
      localStorage.setItem('tindahan_active_module', mod);
    } catch {}
  };

  const handleNavigateToPortal = () => {
    setActiveModule('portal');
    try {
      localStorage.setItem('tindahan_active_module', 'portal');
    } catch {}
  };

  // ROUTE 1: 3D ANIMATED FRONT PAGE PORTAL
  if (activeModule === 'portal') {
    return (
      <PortalFrontPage
        activeUser={activeUser}
        onSelectModule={handleSelectModule}
        productCount={products.length}
        onUserChanged={(newUser) => {
          setActiveUserState(newUser);
          loadData();
        }}
      />
    );
  }

  // ROUTE 2: FULL-SCREEN BONDPAPER PRINT STUDIO
  if (activeModule === 'printstudio') {
    return (
      <PrintStudio
        activeUser={activeUser}
        onBackToPortal={handleNavigateToPortal}
      />
    );
  }

  // ROUTE 3: HOME MONITORING (ELECTRIC, WATER, GAS, MENSTRUATION)
  if (activeModule === 'homemonitoring') {
    return (
      <HomeMonitoring
        activeUser={activeUser}
        onBackToPortal={handleNavigateToPortal}
      />
    );
  }

  // ROUTE 4: AI FORM & DOCUMENT TABLE EXTRACTOR
  if (activeModule === 'docscanner') {
    return (
      <DocExtractor
        activeUser={activeUser}
        onBackToPortal={handleNavigateToPortal}
      />
    );
  }

  // ROUTE 5: MINI STORE MOBILE POS & INVENTORY
  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans antialiased selection:bg-indigo-600 selection:text-white max-w-full overflow-x-hidden">
      {/* Container wrapper - switchable mobile phone mockup preview vs full responsive */}
      <div
        className={`w-full max-w-full flex-1 flex flex-col mx-auto transition-all overflow-x-hidden ${
          isMobileFrame
            ? 'max-w-md my-0 sm:my-6 rounded-none sm:rounded-[40px] border-0 sm:border-[12px] border-slate-900 shadow-[0_0_50px_rgba(0,0,0,0.12)] overflow-x-hidden min-h-screen sm:min-h-[820px] bg-slate-100 relative'
            : 'max-w-7xl'
        }`}
      >
        {/* Global Header */}
        <Header
          activeUser={activeUser}
          onOpenAccountsModal={() => setActiveTab('accounts')}
          onOpenAccountSettingsModal={() => setIsAccountSettingsModalOpen(true)}
          lowStockAlerts={lowStockAlerts}
          onOpenLowStockDrawer={() => setIsLowStockDrawerOpen(true)}
          isMobileFrame={isMobileFrame}
          onToggleMobileFrame={() => setIsMobileFrame(!isMobileFrame)}
          onNavigateToPortal={() => handleSelectModule('portal')}
          onNavigateToPrintStudio={() => handleSelectModule('printstudio')}
          onNavigateToHomeMonitoring={() => handleSelectModule('homemonitoring')}
          onOpenInstallApkModal={() => setIsInstallApkModalOpen(true)}
          onOpenUtangModal={() => setIsUtangModalOpen(true)}
          onOpenAiModal={() => setIsAiModalOpen(true)}
          onOpenZReadingModal={() => setIsZReadingModalOpen(true)}
          onOpenDataSyncModal={() => setIsDataSyncModalOpen(true)}
          onOpenSecurityModal={() => setIsSecurityModalOpen(true)}
          onLockTerminalNow={() => setIsTerminalLocked(true)}
        />

        {/* Admin Target Store Notification Bar */}
        {adminTargetId && (
          <div className="bg-amber-100 border-b border-amber-200 px-4 py-2 flex items-center justify-between text-xs text-amber-900 font-medium">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-600" />
              <span>
                <strong>Admin Mode:</strong> You are currently viewing & managing account database <strong>#{adminTargetId}</strong>.
              </span>
            </div>
            <button
              onClick={() => setActiveTab('accounts')}
              className="text-amber-800 underline font-bold hover:text-amber-950"
            >
              Switch DB
            </button>
          </div>
        )}

        {/* Low Stock Warning Banner if active */}
        {unreadLowStockCount > 0 && (
          <div
            onClick={() => setIsLowStockDrawerOpen(true)}
            className="bg-orange-50 border-b border-orange-100 px-4 py-2 cursor-pointer hover:bg-orange-100/70 transition-colors flex items-center justify-between text-xs shadow-xs"
          >
            <div className="flex items-center gap-2 text-orange-900 font-bold">
              <AlertTriangle className="w-4 h-4 text-orange-600 animate-bounce" />
              <span>
                Low Stock Warning: {unreadLowStockCount} items need restocking!
              </span>
            </div>
            <span className="text-[10px] underline text-indigo-600 font-bold">View &rarr;</span>
          </div>
        )}

        {/* Main Workspace Body */}
        <main className="flex-1 p-3 sm:p-5 pb-16">
          {activeTab === 'pos' && (
            <div className="space-y-4">
              {/* Floating Quick Cart Toggle Button */}
              {cart.length > 0 && (
                <div className="sticky top-14 z-20 flex justify-end">
                  <button
                    onClick={() => setIsCartOpen(true)}
                    className="py-2.5 px-4 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-200 flex items-center gap-2 border border-indigo-500 animate-pulse"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>{t('viewCartBtn')} ({totalCartCount} items)</span>
                  </button>
                </div>
              )}

              <BarcodeScanner
                onProductScanned={(prod) => setScannedProduct(prod)}
                onUnregisteredBarcodeScanned={(code) => setUnregisteredBarcode(code)}
                onOpenAddProduct={() => {
                  setEditingProduct(null);
                  setInitialBarcodeForForm('');
                  setIsProductFormOpen(true);
                }}
              />
            </div>
          )}

          {activeTab === 'inventory' && (
            <InventoryList
              products={products}
              activeUser={activeUser}
              onOpenAddProduct={() => {
                setEditingProduct(null);
                setInitialBarcodeForForm('');
                setIsProductFormOpen(true);
              }}
              onEditProduct={(prod) => {
                setEditingProduct(prod);
                setIsProductFormOpen(true);
              }}
              onRequestAdminPin={requestAdminPin}
              onSelectProductForCheckout={(prod) => setScannedProduct(prod)}
              onOpenPrintQrSheet={() => {
                setHighlightedQrBarcode(undefined);
                setIsPrintQrSheetOpen(true);
              }}
              onOpenCsvModal={() => setIsCsvModalOpen(true)}
              targetAccountId={getEffectiveAccountId()}
            />
          )}

          {activeTab === 'dashboard' && (
            <SalesDashboard sales={sales} onRequestAdminPin={requestAdminPin} />
          )}

          {activeTab === 'history' && (
            <SalesHistory sales={sales} onSelectSale={(sale) => setSelectedReceiptSale(sale)} />
          )}

          {activeTab === 'accounts' && (
            <AccountsManager
              activeUser={activeUser}
              onRequestAdminPin={requestAdminPin}
              onUserChanged={(newUser) => {
                setActiveUserState(newUser);
                loadData();
              }}
            />
          )}
        </main>

        {/* Bottom Navigation for Mobile Touch */}
        <BottomNav
          activeTab={activeTab}
          onChangeTab={(t) => setActiveTab(t)}
          cartItemCount={totalCartCount}
          lowStockCount={unreadLowStockCount}
        />
      </div>

      {/* --- MODALS & DRAWERS --- */}

      {/* Quick Scanned Product Confirmation & Checkout Popup */}
      <QuickCheckoutModal
        product={scannedProduct}
        isOpen={!!scannedProduct}
        onClose={() => setScannedProduct(null)}
        onAddToCart={(prod, qty) => {
          handleAddToCart(prod, qty);
          setIsCartOpen(true);
        }}
        onQuickCheckoutNow={(prod, qty, paymentMethod, customerInfo) => {
          if (paymentMethod === 'Utang' && customerInfo?.name) {
            const subtotal = prod.price * qty;
            const cost = (prod.costPrice || prod.price * 0.8) * qty;
            const defaultProfit = Math.max(0, subtotal - cost);

            const sale = recordSale({
              items: [{ product: prod, quantity: qty }],
              subtotal,
              discount: 0,
              totalAmount: subtotal,
              paymentMethod: 'Utang',
              referenceNo: `UTANG-${customerInfo.name.trim()}`,
              cashierId: activeUser.id,
              cashierName: activeUser.name,
            });

            addUtangRecord({
              customerName: customerInfo.name.trim(),
              customerPhone: customerInfo.phone?.trim() || undefined,
              itemsSummary: `${qty}x ${prod.name}`,
              totalAmount: subtotal,
              markupAmount: customerInfo.markup !== undefined ? customerInfo.markup : defaultProfit,
              saleReceiptNo: sale.receiptNo,
            });

            playSuccessChime();
            setSelectedReceiptSale(sale);
            setScannedProduct(null);
          } else {
            handleAddToCart(prod, qty);
            setIsCartOpen(true);
          }
        }}
      />

      {/* Unregistered Barcode Popup */}
      <UnregisteredBarcodeModal
        barcode={unregisteredBarcode}
        isOpen={!!unregisteredBarcode}
        onClose={() => setUnregisteredBarcode(null)}
        onRegisterProduct={(code) => {
          setEditingProduct(null);
          setInitialBarcodeForForm(code);
          setIsProductFormOpen(true);
        }}
      />

      {/* Add / Edit Product Form */}
      <ProductFormModal
        isOpen={isProductFormOpen}
        onClose={() => setIsProductFormOpen(false)}
        productToEdit={editingProduct}
        initialBarcode={initialBarcodeForForm}
        targetAccountId={getEffectiveAccountId()}
        onSaved={() => {
          // Product saved to local inventory database
        }}
      />

      {/* 20-QR Bondpaper Printable Sheet Modal */}
      <PrintableQrSheetModal
        isOpen={isPrintQrSheetOpen}
        onClose={() => setIsPrintQrSheetOpen(false)}
        products={products}
        highlightedBarcode={highlightedQrBarcode}
        storeName={activeUser.name.toUpperCase()}
      />

      {/* Cart & Checkout Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={() => setCart([])}
        activeUser={activeUser}
        onSaleCompleted={(sale) => setSelectedReceiptSale(sale)}
      />

      {/* Print / View Receipt Modal */}
      <ReceiptModal
        sale={selectedReceiptSale}
        isOpen={!!selectedReceiptSale}
        onClose={() => setSelectedReceiptSale(null)}
      />

      {/* Admin Security PIN Protection Modal */}
      <PinModal
        isOpen={isPinModalOpen}
        onClose={() => {
          setIsPinModalOpen(false);
          setPinSuccessCallback(null);
        }}
        onSuccess={() => {
          setIsPinModalOpen(false);
          if (pinSuccessCallback) {
            pinSuccessCallback();
            setPinSuccessCallback(null);
          }
        }}
        title={pinModalTitle}
      />

      {/* Low Stock Drawer */}
      <LowStockAlertDrawer
        isOpen={isLowStockDrawerOpen}
        onClose={() => setIsLowStockDrawerOpen(false)}
        alerts={lowStockAlerts}
        products={products}
        onRestockProduct={(prod) => {
          setEditingProduct(prod);
          setIsProductFormOpen(true);
        }}
      />

      {/* APK / PWA App Installation Guide Modal */}
      <InstallApkModal
        isOpen={isInstallApkModalOpen}
        onClose={() => setIsInstallApkModalOpen(false)}
      />

      {/* Utang / Store Credit Ledger Modal */}
      <UtangLedgerModal
        isOpen={isUtangModalOpen}
        onClose={() => setIsUtangModalOpen(false)}
      />

      {/* AI Store Advisor & Restock Intelligence Modal */}
      <AiBusinessAssistantModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
      />

      {/* Z-Reading Shift Turnover Audit Modal */}
      <ZReadingModal
        isOpen={isZReadingModalOpen}
        onClose={() => setIsZReadingModalOpen(false)}
      />

      {/* Bulk Excel & CSV Import/Export Modal */}
      <CsvImportExportModal
        isOpen={isCsvModalOpen}
        onClose={() => setIsCsvModalOpen(false)}
      />

      {/* Automatic Cloud & Multi-Device Sync Modal */}
      <DataSyncStatusModal
        isOpen={isDataSyncModalOpen}
        onClose={() => setIsDataSyncModalOpen(false)}
      />

      {/* System Security Center & Audit Trail Modal */}
      <SecurityAuditModal
        isOpen={isSecurityModalOpen}
        onClose={() => setIsSecurityModalOpen(false)}
        activeUser={activeUser}
        onLockTerminalNow={() => {
          setIsSecurityModalOpen(false);
          setIsTerminalLocked(true);
        }}
      />

      {/* Terminal Lock Security Screen Overlay */}
      <TerminalLockOverlay
        isLocked={isTerminalLocked}
        onUnlock={() => setIsTerminalLocked(false)}
        activeUserName={activeUser.name}
      />

      {/* Account Settings Modal */}
      <AccountSettingsModal
        isOpen={isAccountSettingsModalOpen}
        onClose={() => setIsAccountSettingsModalOpen(false)}
        activeUser={activeUser}
        onUserChanged={(updatedUser) => {
          setActiveUserState(updatedUser);
        }}
      />
    </div>
  );
}
