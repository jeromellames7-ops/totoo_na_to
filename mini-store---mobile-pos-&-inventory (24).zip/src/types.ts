export type UserRole = 'Admin' | 'Cashier';

export interface UserAccount {
  id: string;
  name: string;
  email?: string;
  password?: string;
  role: UserRole;
  avatar: string;
  pin?: string; // Encrypted or 4-digit string for Admin / Quick Lock
  shift?: string;
  info?: string;
  phone?: string;
  storeName?: string;
  isLoggedIn?: boolean;
  createdAt?: string;
  updatedAt?: string;
  isRegistered?: boolean;
}

export interface Product {
  id: string;
  barcode: string;
  name: string;
  price: number;
  costPrice: number; // for profit calculation
  stock: number;
  lowStockThreshold: number;
  category: string;
  imageUrl: string;
  details: string;
  createdAt: string;
  updatedAt: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type PaymentMethod = 'Cash' | 'GCash' | 'Maya' | 'Utang';

export interface UtangPayment {
  id: string;
  amount: number;
  date: string;
  receivedBy: string;
  notes?: string;
}

export interface UtangRecord {
  id: string;
  customerName: string;
  customerPhone?: string;
  itemsSummary: string;
  totalAmount: number;
  markupAmount?: number; // Profit / Tubo amount
  balanceRemaining: number;
  saleReceiptNo?: string;
  dueDate?: string;
  status: 'UNPAID' | 'PARTIAL' | 'PAID';
  createdAt: string;
  payments: UtangPayment[];
  notes?: string;
}

export interface ShiftReport {
  id: string;
  shiftDate: string;
  cashierName: string;
  openingCash: number;
  totalCashSales: number;
  totalDigitalSales: number;
  totalUtangAdded: number;
  totalUtangCollected: number;
  expectedCash: number;
  actualCashCount: number;
  variance: number;
  notes?: string;
  timestamp: string;
}

export interface Sale {
  id: string;
  receiptNo: string;
  receiptNumber?: string; // fallback matching some database schemas
  items: CartItem[];
  subtotal: number;
  discount: number;
  totalAmount: number;
  profit: number;
  paymentMethod: PaymentMethod;
  customerName?: string;
  cashReceived?: number;
  change?: number;
  referenceNo?: string;
  cashierId: string;
  cashierName: string;
  timestamp: string; // ISO date string
}

export interface LowStockAlert {
  id: string;
  productId: string;
  productName: string;
  currentStock: number;
  threshold: number;
  timestamp: string;
  isRead: boolean;
}

export type TabType = 'pos' | 'inventory' | 'dashboard' | 'history' | 'accounts';

export interface QrSheetSlot {
  id: string;
  name: string;
  price: number;
  barcode: string;
  category?: string;
  isCustom?: boolean;
}

export interface EWalletConfig {
  gcashNumber: string;
  gcashName: string;
  gcashQrUrl?: string;
  mayaNumber: string;
  mayaName: string;
  mayaQrUrl?: string;
  qrPhUrl?: string;
}

export type SecurityEventType =
  | 'LOGIN'
  | 'LOGOUT'
  | 'LOCK_TERMINAL'
  | 'UNLOCK_TERMINAL'
  | 'PIN_VERIFIED'
  | 'PIN_FAILED'
  | 'SALE_RECORDED'
  | 'SALE_VOIDED'
  | 'PRODUCT_ADDED'
  | 'PRODUCT_EDITED'
  | 'PRODUCT_DELETED'
  | 'DATABASE_RESTORED'
  | 'DATABASE_FORMATTED'
  | 'SETTINGS_CHANGED'
  | 'EWALLET_PAYMENT_VERIFIED';

export interface SecurityAuditLog {
  id: string;
  eventType: SecurityEventType;
  description: string;
  actorName: string;
  actorRole: UserRole;
  timestamp: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  metadata?: Record<string, any>;
}

export interface SecuritySettings {
  autoLockMinutes: number; // 0 for disabled, 3, 5, 10
  requirePinForVoid: boolean;
  requirePinForDelete: boolean;
  requirePinForFormat: boolean;
  requirePinForExport: boolean;
}

// Global App Module / Navigation
export type AppModule = 'portal' | 'ministore' | 'printstudio' | 'homemonitoring' | 'docscanner';

// ==========================================
// AI DOCUMENT & FORM EXTRACTOR TYPES
// ==========================================
export interface ExtractedTableCell {
  fieldLabel: string;
  value: string;
  isHandwritten: boolean;
  isCheckbox?: boolean;
  checkboxStatus?: 'naka-check' | 'hindi naka-check';
  confidence?: 'high' | 'medium' | 'low' | 'hindi matukoy';
}

export interface ExtractedTableSection {
  sectionTitle: string; // e.g. "Personal Information", "Civil Service Eligibility", "Work Experience", "Educational Background"
  headers: string[];
  rows: Record<string, string>[];
  checkboxes?: { label: string; status: 'naka-check' | 'hindi naka-check'; notes?: string }[];
  notes?: string;
}

export interface ExtractedDocumentResult {
  id: string;
  title: string;
  detectedPersonName?: string; // Pangalan ng tao / may-ari na nakasulat sa loob ng form
  documentType: string; // e.g., "Personal Data Sheet (PDS)", "Civil Service Form", "Generic Handwritten Application Form"
  totalPages: number;
  detectedPageNumbers: string[]; // e.g., ["Page 1 of 4", "Page 2 of 4"]
  sections: ExtractedTableSection[];
  consolidatedMarkdownTable: string;
  signaturesAndDates: { signatureFound: boolean; signerName?: string; dateSigned?: string; notes?: string }[];
  unreadableSummary?: string;
  privacyNoticeAcknowledged: boolean;
  scannedAt: string;
  imagesBase64?: string[];
}

export interface GalleryBoxItem {
  id: string;
  boxNumber: number; // 1, 2, 3, 4, 5, 6, 7, 8... up to 200 (50 sets)
  imageSrc: string | null;
  status: 'empty' | 'queued' | 'scanning' | 'completed' | 'error';
  capturedAt?: string;
  enqueuedAt?: number;
  extractedData?: Record<string, string>;
  personName?: string;
  errorMessage?: string;
}

// ==========================================
// PRINT STUDIO & BONDPAPER EDITOR TYPES
// ==========================================
export type BondPaperPreset = 'short' | 'long' | 'a4' | 'legal' | 'a5' | 'a3' | '4r' | '3r' | '5r' | 'custom';

export type PhotoPresetSize =
  | '1x1'
  | '2x2'
  | 'passport'
  | '2r'
  | '3r'
  | '4r'
  | '5r'
  | 'half_page'
  | 'full_page';

export interface CanvasElement {
  id: string;
  type: 'image' | 'text';
  x: number; // in mm or percentage
  y: number;
  width: number;
  height: number;
  rotation: number;
  zIndex: number;
  // Image properties
  src?: string;
  name?: string;
  opacity?: number;
  filter?: string; // 'none' | 'grayscale(100%)' | 'contrast(150%)' | 'sepia(80%)' | 'brightness(1.2)' | 'vintage'
  borderRadius?: number;
  borderWidth?: number;
  borderColor?: string;
  // Text properties
  text?: string;
  fontFamily?: string;
  fontSize?: number;
  color?: string;
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  align?: 'left' | 'center' | 'right' | 'justify';
  lineHeight?: number;
  letterSpacing?: number;
  backgroundColor?: string;
  shadow?: boolean;
}

export interface PrintDocumentPage {
  id: string;
  pageNumber: number;
  elements: CanvasElement[];
  paperPreset?: BondPaperPreset;
  orientation?: 'portrait' | 'landscape';
}

export interface PrintDocumentProject {
  id: string;
  accountId?: string;
  title: string;
  paperPreset: BondPaperPreset;
  customWidthMm: number;
  customHeightMm: number;
  orientation: 'portrait' | 'landscape';
  elements: CanvasElement[];
  pages?: PrintDocumentPage[];
  updatedAt: string;
}

export type PrinterStatus = 'idle' | 'searching' | 'connecting' | 'connected' | 'printing' | 'error';

// ==========================================
// HOME & FAMILY MONITORING TYPES
// ==========================================
export interface ElectricBillRecord {
  id: string;
  accountId?: string;
  billingMonth: string; // e.g. "August 2026"
  prevReadingKwh: number;
  currentReadingKwh: number;
  totalKwhUsed: number;
  ratePerKwh: number;
  totalBillAmount: number;
  dueDate: string;
  isPaid: boolean;
  paidDate?: string;
  referenceNo?: string;
  notes?: string;
  createdAt: string;
}

export interface WaterBillRecord {
  id: string;
  accountId?: string;
  billingMonth: string;
  prevReadingCuM: number;
  currentReadingCuM: number;
  totalCuMUsed: number;
  ratePerCuM: number;
  totalBillAmount: number;
  dueDate: string;
  isPaid: boolean;
  paidDate?: string;
  referenceNo?: string;
  notes?: string;
  createdAt: string;
}

export interface GasStoveLpgRecord {
  id: string;
  accountId?: string;
  brand: string; // e.g. "Petron Gasul", "Solane", "Prycegas", "Phoenix"
  purchaseDate: string; // YYYY-MM-DD - Kailan binili ang gasul
  tankCapacityKg: number; // 11, 2.7, 22, 50
  tareWeightKg: number;
  currentLevelPercent: number; // 0 - 100
  installedDate: string;
  dueDate: string; // YYYY-MM-DD - Automatic 1 month (30 days) from purchase
  cost: number;
  dailyHoursUsed: number;
  estimatedDaysRemaining: number;
  isSafetyChecked: boolean;
  lastSafetyCheckDate: string;
  isNotifiedDue?: boolean;
  supplierContact?: string;
  notes?: string;
  updatedAt: string;
}

export interface PillTakeLog {
  id: string;
  pillNumber: number; // e.g. 1 to 28
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  taken: boolean;
  autoCounted?: boolean;
  notes?: string;
}

export interface PillMonitoringPlan {
  id: string;
  accountId?: string;
  isActive: boolean;
  pillBrand: string; // e.g. "Trust Pill", "Diane-35", "Althea", "Lady Pill", "Daily Pill"
  packType: '28_day' | '21_day' | 'continuous';
  startDate: string; // YYYY-MM-DD
  reminderTime: string; // "19:00" (7:00 PM)
  totalPillsInPack: number; // 28 or 21
  currentPillIndex: number; // 1 to 28
  totalPillsTaken: number;
  streakDays: number;
  lastReminderDate?: string;
  logs: PillTakeLog[];
  createdAt: string;
  updatedAt: string;
}

export interface MenstruationCycleRecord {
  id: string;
  accountId?: string;
  startDate: string; // YYYY-MM-DD
  endDate?: string; // YYYY-MM-DD
  cycleLengthDays: number; // default 28
  periodDurationDays: number; // default 5
  flow: 'Light' | 'Medium' | 'Heavy' | 'Spotting';
  cramps: 'None' | 'Mild' | 'Moderate' | 'Severe';
  mood: 'Normal' | 'Happy' | 'Tired' | 'Irritable' | 'Emotional' | 'Anxious' | 'Energetic';
  symptoms: string[]; // e.g. ["Headache", "Bloating", "Acne", "Backache", "Cravings"]
  notes?: string;
  createdAt: string;
}


