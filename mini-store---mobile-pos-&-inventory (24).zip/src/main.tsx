import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initSyncEngine } from './utils/syncEngine';
import { ErrorBoundary } from './components/ErrorBoundary';

// Initialize multi-device real-time sync engine
try {
  initSyncEngine();
} catch (e) {
  console.warn('Sync engine initialization fallback:', e);
}

// Global safety handler for iframe/browser background warnings
if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', (event) => {
    // Gracefully handle Firestore/Audio/SW background promise rejections without crashing UI
    if (
      event.reason?.message?.includes('Firestore') ||
      event.reason?.message?.includes('audio') ||
      event.reason?.message?.includes('ServiceWorker') ||
      event.reason?.message?.includes('ResizeObserver')
    ) {
      event.preventDefault();
    }
  });
}

// Register Service Worker for PWA / Mobile App Installability safely
if (typeof window !== 'undefined' && 'serviceWorker' in navigator && window.location.protocol.startsWith('http')) {
  window.addEventListener('load', () => {
    try {
      navigator.serviceWorker
        .register('/sw.js')
        .then((reg) => {
          console.log('PWA ServiceWorker ready:', reg.scope);
        })
        .catch(() => {
          // Graceful fallback for sandboxed iframe environments
        });
    } catch {
      // Ignore
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);


