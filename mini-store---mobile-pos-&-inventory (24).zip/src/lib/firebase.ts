import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore, setLogLevel, enableNetwork } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Silence verbose connection retry warnings in console/logs
try {
  setLogLevel('silent');
} catch (e) {}

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Pass custom database ID if provided in config
export const db = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Always ensure network is enabled for 100% real-time cloud sync across mobile & desktop devices
try {
  enableNetwork(db).catch(() => {});
} catch (e) {}

export default app;
