import { GoogleGenAI } from '@google/genai';
import { compressImageForAi } from './imageCompressor';

export const getClientGeminiApiKey = (): string => {
  return (
    process.env.GEMINI_API_KEY ||
    (import.meta as any).env?.VITE_GEMINI_API_KEY ||
    (import.meta as any).env?.GEMINI_API_KEY ||
    localStorage.getItem('custom_gemini_api_key') ||
    ''
  );
};

export const setClientGeminiApiKey = (key: string) => {
  if (key && key.trim()) {
    localStorage.setItem('custom_gemini_api_key', key.trim());
  } else {
    localStorage.removeItem('custom_gemini_api_key');
  }
};

export async function extractDocumentClientSide(
  images: string[],
  titleHint?: string,
  customApiKey?: string,
  customHeaders?: string[]
) {
  const activeKey = customApiKey || getClientGeminiApiKey();

  // Optimize images while preserving 100% natural colors and handwriting clarity (compact & fast)
  const compressedImages = await Promise.all(
    images.map((img) => compressImageForAi(img, 1280, 0.80))
  );

  // 1. Try server-side proxy FIRST (handles process.env.GEMINI_API_KEY safely without browser permission issues)
  try {
    const serverResponse = await fetch('/api/extract-document', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        images: compressedImages,
        titleHint: titleHint || 'Form / Document',
        customApiKey: activeKey || undefined,
        customHeaders: customHeaders || undefined,
      }),
    });

    if (serverResponse.ok) {
      const serverResult = await serverResponse.json();
      if (serverResult && serverResult.success && serverResult.data) {
        return serverResult;
      }
    }
  } catch (serverErr) {
    console.warn('[Gemini Extractor] Server route fallback:', serverErr);
  }

  // 2. Client-side fallback if server route not reachable
  if (!activeKey || !activeKey.trim()) {
    throw new Error('NO_API_KEY');
  }

  try {
    const ai = new GoogleGenAI({
      apiKey: activeKey.trim(),
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

  const parts: any[] = [];
  compressedImages.forEach((imgStr: string) => {
    let mimeType = 'image/jpeg';
    let base64Data = imgStr;

    if (imgStr.startsWith('data:')) {
      const matches = imgStr.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
      if (matches) {
        mimeType = matches[1];
        base64Data = matches[2];
      } else {
        base64Data = imgStr.split(',')[1] || imgStr;
      }
    }

    parts.push({
      inlineData: {
        mimeType,
        data: base64Data,
      },
    });
  });

  const defaultHeaders = [
    'NAME (SURNAME, FIRST NAME, MIDDLE NAME)',
    'SUFFIX',
    'DATE OF BIRTH (MM, DD, YYYY)',
    'SEX',
    'CIVIL STATUS',
    'ADDRESS (PUROK, BRGY, MUNICIPALITY, PROVINCE)',
    'HEIGHT (Kg)',
    'WEIGHT (Kg)',
    'BLOOD TYPE',
    'RELIGION',
    'PHILHEALTH NO.',
    'SSS NO.',
    'PAG IBIG NO.',
    'TIN NO.',
    'PhilSys Number (PSN)',
    "Voter's Identification Number :",
    'CP NO.',
    'EMAIL ADDRESS',
    'EMPLOYMENT STATUS',
    'HOW LONG HAVE YOU BEEN LOOKING FOR WORK (MONTHS)',
    'PREFERRED OCCUPATION',
    'EDUCATIONAL BACKROUND (SCHOOL, COURSE, YEAR GRAD.)',
    'CERTIFICATION/VOCATIONAL TRAINING',
    'ELIGIBILITY/LICENSE (DATE TAKEN, VALID UNTIL)',
    'WORK EXPERIENCE (EMPLOYER NAME, ADDRESS, POSITION HELD, INCLUSIVE DATES, STATUS)',
    'OTHER SKILLS',
  ];

  const activeHeaders: string[] =
    Array.isArray(customHeaders) && customHeaders.length > 0
      ? customHeaders.map((h: any) => String(h || '').trim()).filter((h: string) => h.length > 0)
      : defaultHeaders;

  const headersListText = activeHeaders.map((h, idx) => `${idx + 1}. ${h}`).join('\n');

  const sampleRowObj: Record<string, string> = {};
  activeHeaders.forEach((h) => {
    sampleRowObj[h] = '';
  });

  const extractionInstruction = `
Ikaw ay isang ultra-fast OCR & Document Data Extractor para sa mga form (PDS, NSRP, Resume, Bio-data).
BUMASA NG HANDWRITTEN (sulat-kamay) at COMPUTER-PRINTED text.

MAHIGPIT NA PATAKARAN SA ZERO HALLUCINATION:
- HINDI KA PWEDENG MAGSINUNGALING: Kung hindi mo TOTOONG NAKITA o NABASA nang malinaw sa larawan ang isang datos para sa header, IWANANG BLANKO O EMPTY STRING ("") ITO!
- BAWAL maglagay ng placeholder ("N/A", "Unknown", "Juan Dela Cruz", atbp.). Tanging TOTOONG nakasulat lamang.
- Awtomatikong unawain ang papel kahit baligtad (180 deg) o nakatagilid.

${titleHint ? `TALA MULA SA GUMAGAMIT: ${titleHint}\n` : ''}
KUNIN ANG MGA DATOS PARA SA SUMUSUNOD NA MGA HEADERS:
${headersListText}

Format your output STRICTLY as valid JSON:
{
  "detectedPersonName": "BUONG PANGALAN NG APLIKANTE",
  "rows": [
    {
      "NAME (SURNAME, FIRST NAME, MIDDLE NAME)": "",
      "DATE OF BIRTH (MM, DD, YYYY)": "",
      "SEX": "",
      "CIVIL STATUS": "",
      "ADDRESS (PUROK, BRGY, MUNICIPALITY, PROVINCE)": "",
      "TIN NO.": "",
      "CP NO.": ""
    }
  ]
}
Kung walang nakitang datos sa isang header, ibalik ang "".
Return ONLY valid JSON.
`;

  parts.push({ text: extractionInstruction });

  const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
  const modelsToTry = [
    'gemini-3.1-flash-lite',
    'gemini-flash-latest',
    'gemini-3.7-flash',
  ];
  let response: any = null;
  let lastError: any = null;

  for (let i = 0; i < modelsToTry.length; i++) {
    const m = modelsToTry[i];
    try {
      response = await ai.models.generateContent({
        model: m,
        contents: { parts },
        config: {
          temperature: 0.1,
          responseMimeType: 'application/json',
          thinkingConfig: {
            thinkingBudget: 0,
          },
        },
      });
      const responseText =
        response?.text ||
        response?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join('') ||
        '';
      if (response && responseText) {
        break;
      }
    } catch (modelErr: any) {
      lastError = modelErr;
      const msg = String(modelErr?.message || modelErr);
      const isRateOrQuota =
        msg.includes('429') ||
        msg.includes('RESOURCE_EXHAUSTED') ||
        msg.includes('quota') ||
        msg.includes('rate');

      const waitTime = isRateOrQuota ? 400 + i * 200 : 150;
      await delay(waitTime);
      continue;
    }
  }

  const rawText =
    response?.text ||
    response?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join('') ||
    '';

  if (!rawText) {
    const lastMsg = String(lastError?.message || lastError || '');
    if (
      lastMsg.includes('429') ||
      lastMsg.includes('RESOURCE_EXHAUSTED') ||
      lastMsg.includes('Quota limit exceeded') ||
      lastMsg.includes('quota')
    ) {
      throw new Error(
        'Pansamantalang naabot ang rate limit sa Gemini API. Maghintay ng ilang segundo o maglagay ng sariling API Key sa Settings.'
      );
    }
    throw lastError || new Error('Mataas ang demand sa AI model ngayon (503). Pakisubukan muli.');
  }

  let parsedJson: any = null;

  try {
    parsedJson = JSON.parse(rawText);
  } catch {
    const jsonMatch = rawText.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
    if (jsonMatch) {
      parsedJson = JSON.parse(jsonMatch[1]);
    } else {
      throw new Error('Hindi ma-parse ang JSON output ng AI sa Netlify.');
    }
  }

  // Normalize rows
  let extractedRows: any[] = [];
  if (parsedJson?.rows && Array.isArray(parsedJson.rows) && parsedJson.rows.length > 0) {
    extractedRows = parsedJson.rows;
  } else if (parsedJson?.sections && Array.isArray(parsedJson.sections)) {
    parsedJson.sections.forEach((sec: any) => {
      if (sec.rows && Array.isArray(sec.rows)) {
        extractedRows.push(...sec.rows);
      }
    });
  }

  if (extractedRows.length === 0) {
    extractedRows = [sampleRowObj];
  }

  const normalizedRows = extractedRows.map((r: any) => {
    const rowObj: Record<string, string> = {};
    activeHeaders.forEach((hdr) => {
      if (r[hdr] !== undefined) {
        rowObj[hdr] = String(r[hdr] || '');
      } else {
        const cleanHdr = hdr.toLowerCase().replace(/[^a-z0-9]/g, '');
        const foundKey = Object.keys(r).find((k) => {
          const cleanK = k.toLowerCase().replace(/[^a-z0-9]/g, '');
          return cleanHdr.includes(cleanK) || cleanK.includes(cleanHdr);
        });
        rowObj[hdr] = foundKey ? String(r[foundKey] || '') : (r[hdr] || '');
      }
    });
    return rowObj;
  });

  const detectedDocName =
    parsedJson?.detectedPersonName ||
    normalizedRows[0]?.[activeHeaders[0]] ||
    normalizedRows[0]?.['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
    'Aplikante PDS';

  const mdHeaders = activeHeaders.join(' | ');
  const mdDividers = activeHeaders.map(() => '---').join(' | ');
  const mdRows = normalizedRows
    .map((row) => activeHeaders.map((h) => row[h] || '-').join(' | '))
    .join('\n');

  const formattedData = {
    detectedPersonName: detectedDocName,
    documentType: titleHint || 'PDS / Document Form',
    totalPages: images.length,
    detectedPageNumbers: [`Page 1 of ${images.length}`],
    sections: [
      {
        sectionTitle: 'RECORD NG DOKUMENTO / TABLE',
        headers: activeHeaders,
        rows: normalizedRows,
        checkboxes: [],
        notes: 'Target headers extracted',
      },
    ],
    signaturesAndDates: [],
    consolidatedMarkdownTable: `| ${mdHeaders} |\n| ${mdDividers} |\n${mdRows}`,
    unreadableSummary: '',
  };

  return {
    success: true,
    data: formattedData,
    scannedAt: new Date().toISOString(),
  };
  } catch (clientErr: any) {
    console.warn('[Gemini Extractor] Client fallback error:', clientErr?.message || clientErr);
    throw clientErr;
  }
}

// Create lightweight compressed and scaled down image specifically for fast OCR analysis (<70KB vs 8MB)
export async function createOptimizedPdsThumbnailForOcr(
  imageSource: File | string,
  maxDimension = 1800,
  quality = 0.88
): Promise<string> {
  return new Promise((resolve) => {
    try {
      const img = new Image();
      img.onload = () => {
        try {
          let { width, height } = img;
          if (width > maxDimension || height > maxDimension) {
            if (width > height) {
              height = Math.round((height * maxDimension) / width);
              width = maxDimension;
            } else {
              width = Math.round((width * maxDimension) / height);
              height = maxDimension;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(typeof imageSource === 'string' ? imageSource : '');
            return;
          }

          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.drawImage(img, 0, 0, width, height);

          const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
          resolve(compressedDataUrl);
        } catch (canvasErr) {
          console.warn('[Image Optimize] Canvas draw error:', canvasErr);
          resolve(typeof imageSource === 'string' ? imageSource : '');
        }
      };

      img.onerror = () => {
        resolve(typeof imageSource === 'string' ? imageSource : '');
      };

      if (typeof imageSource === 'string') {
        img.src = imageSource;
      } else {
        img.src = URL.createObjectURL(imageSource);
      }
    } catch (err) {
      console.warn('[Image Optimize] Optimization exception:', err);
      resolve(typeof imageSource === 'string' ? imageSource : '');
    }
  });
}

// Fast targeted extraction of applicant name directly from PDS document picture with candidate matching
export async function extractPdsApplicantName(
  base64Image: string,
  candidateNames?: string[],
  customApiKey?: string
): Promise<{ applicantName: string; matchedCandidate: string | null }> {
  const activeKey = customApiKey || getClientGeminiApiKey();

  // 1. Try server-side endpoint first
  try {
    const res = await fetch('/api/extract-pds-name', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        image: base64Image,
        candidateNames: Array.isArray(candidateNames) ? candidateNames.slice(0, 500) : undefined,
        customApiKey: activeKey || undefined,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data?.success) {
        return {
          applicantName: String(data.applicantName || '').trim(),
          matchedCandidate: data.matchedCandidate ? String(data.matchedCandidate).trim() : null,
        };
      }
    }
  } catch (serverErr) {
    console.warn('[Gemini Extractor] /api/extract-pds-name server fallback:', serverErr);
  }

  // 2. Client-side fallback if server route unavailable
  if (activeKey && activeKey.trim()) {
    try {
      const ai = new GoogleGenAI({
        apiKey: activeKey.trim(),
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
      });

      let mimeType = 'image/jpeg';
      let base64Data = base64Image;

      if (base64Image.startsWith('data:')) {
        const matches = base64Image.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
        if (matches) {
          mimeType = matches[1];
          base64Data = matches[2];
        } else {
          base64Data = base64Image.split(',')[1] || base64Image;
        }
      }

      const candidateListStr = Array.isArray(candidateNames) && candidateNames.length > 0
        ? candidateNames.slice(0, 500).map((n, idx) => `${idx + 1}. ${n}`).join('\n')
        : '';

      const prompt = `IKAW AY ISANG DALUBHASANG OCR AI EXPERT PARA SA CIVIL SERVICE PERSONAL DATA SHEET (CS FORM NO. 212 REVISED 2017 / 2025, BIO-DATA, RESUME, O APPLICATION FORM).
TIGNAN NG MABUTI AT BASAHIN NANG EKSAKTO KUNG ANO ANG NAKASULAT SA MISMONG LARAWAN NG PDS.

MAHALAGANG TAGUBILIN:
Basahin ang Block I. PERSONAL INFORMATION sa mga kahon:
1. SURNAME (Apelyido)
2. FIRST NAME (Pangalan)
3. MIDDLE NAME (Gitnang Pangalan)
4. NAME EXTENSION (JR., SR., III, IV - kung N/A o blangko, iwanang blangko)

PAALALA:
- Basahin nang mabuti kung ano ang nakasulat sa loob ng mga kahon ng PDS picture (maaaring computerized all-caps o sulat-kamay).
- Halimbawa kung ang nakasulat sa larawan ay:
  SURNAME: PERMANES
  FIRST NAME: MARCELINA
  MIDDLE NAME: QUINEZ
  NAME EXTENSION: N/A
  Ang buong pangalan ay: "PERMANES, MARCELINA QUINEZ"
- KUNG ANO ANG NAKASULAT SA LARAWAN, IYON LAMANG ANG KUNIN. HUWAG MANGHULA NG IBANG TAO O APELYIDO.
${candidateListStr ? `
Mga kilalang pangalan sa database:
${candidateListStr}
Kung ang nabasa sa larawan ay may eksaktong katugma sa listahan (parehong apelyido at unang pangalan), ilagay ito sa "matchedCandidate". Kung hindi tugma, ilagay ang null.` : ''}

Magbalik LAMANG ng valid JSON object:
{
  "surname": "APELYIDO MULA SA LARAWAN",
  "firstName": "UNANG PANGALAN MULA SA LARAWAN",
  "middleName": "GITNANG PANGALAN KUNG MAYROON",
  "nameExtension": "EXTENSION KUNG MAYROON O BLANGKO",
  "applicantName": "SURNAME, FIRST NAME MIDDLE NAME",
  "matchedCandidate": null
}`;

      const modelsToTry = ['gemini-3.1-flash-lite', 'gemini-flash-latest', 'gemini-3.7-flash'];
      let response: any = null;
      for (const m of modelsToTry) {
        try {
          response = await ai.models.generateContent({
            model: m,
            contents: [
              {
                role: 'user',
                parts: [
                  { inlineData: { mimeType, data: base64Data } },
                  { text: prompt },
                ],
              },
            ],
            config: {
              responseMimeType: 'application/json',
              maxOutputTokens: 400,
              temperature: 0.1,
            },
          });
          if (response && (response.text || response.candidates)) break;
        } catch (e) {
          continue;
        }
      }

      const rawText =
        response?.text ||
        response?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join('') ||
        '';
      let applicantName = '';
      let matchedCandidate: string | null = null;
      try {
        const parsed = JSON.parse(rawText);
        const sName = String(parsed.surname || '').trim().replace(/^N\/A$/i, '');
        const fName = String(parsed.firstName || '').trim().replace(/^N\/A$/i, '');
        const mName = String(parsed.middleName || '').trim().replace(/^N\/A$/i, '');
        const ext = String(parsed.nameExtension || '').trim().replace(/^(N\/A|NONE)$/i, '');

        if (sName && fName) {
          applicantName = `${sName}, ${fName}${mName ? ' ' + mName : ''}${ext ? ' ' + ext : ''}`.toUpperCase();
        } else {
          applicantName = String(parsed.applicantName || '').trim().toUpperCase();
        }

        if (parsed.matchedCandidate && typeof parsed.matchedCandidate === 'string' && parsed.matchedCandidate.trim().length > 0 && parsed.matchedCandidate.toLowerCase() !== 'null') {
          matchedCandidate = parsed.matchedCandidate.trim();
        }
      } catch (e) {
        const jsonMatch = rawText.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
        if (jsonMatch) {
          try {
            const parsed = JSON.parse(jsonMatch[1]);
            const sName = String(parsed.surname || '').trim().replace(/^N\/A$/i, '');
            const fName = String(parsed.firstName || '').trim().replace(/^N\/A$/i, '');
            const mName = String(parsed.middleName || '').trim().replace(/^N\/A$/i, '');
            const ext = String(parsed.nameExtension || '').trim().replace(/^(N\/A|NONE)$/i, '');

            if (sName && fName) {
              applicantName = `${sName}, ${fName}${mName ? ' ' + mName : ''}${ext ? ' ' + ext : ''}`.toUpperCase();
            } else {
              applicantName = String(parsed.applicantName || '').trim().toUpperCase();
            }

            if (parsed.matchedCandidate && typeof parsed.matchedCandidate === 'string' && parsed.matchedCandidate.trim().length > 0 && parsed.matchedCandidate.toLowerCase() !== 'null') {
              matchedCandidate = parsed.matchedCandidate.trim();
            }
          } catch (_) {}
        }

        if (!applicantName) {
          const match = rawText.match(/"applicantName"\s*:\s*"([^"]+)"/);
          if (match) applicantName = match[1].trim().toUpperCase();
        }
        if (!matchedCandidate) {
          const matchCand = rawText.match(/"matchedCandidate"\s*:\s*"([^"]+)"/);
          if (matchCand && matchCand[1].toLowerCase() !== 'null') matchedCandidate = matchCand[1].trim();
        }
      }

      return { applicantName, matchedCandidate };
    } catch (clientErr) {
      console.warn('[Gemini Extractor] Client direct extract error:', clientErr);
    }
  }

  return { applicantName: '', matchedCandidate: null };
}

