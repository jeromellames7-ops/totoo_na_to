import { pgTable, text, serial, timestamp, integer, jsonb } from 'drizzle-orm/pg-core';

// Define the 'users' table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Firebase Auth UID
  email: text('email').notNull(),
  displayName: text('display_name'),
  role: text('role').default('user'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Define the 'doc_extractor_state' table (for 100% unified online persistent state)
export const docExtractorState = pgTable('doc_extractor_state', {
  id: text('id').primaryKey(), // e.g. 'global_master'
  activeTable: jsonb('active_table'),
  pdsPictures: jsonb('pds_pictures'),
  documents: jsonb('documents'),
  customHeaders: jsonb('custom_headers'),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Define the 'extracted_documents' table
export const extractedDocuments = pgTable('extracted_documents', {
  id: text('id').primaryKey(),
  title: text('title'),
  detectedPersonName: text('detected_person_name'),
  documentType: text('document_type'),
  totalPages: integer('total_pages').default(1),
  detectedPageNumbers: jsonb('detected_page_numbers'),
  sections: jsonb('sections'),
  signaturesAndDates: jsonb('signatures_and_dates'),
  unreadableSummary: text('unreadable_summary'),
  scannedAt: text('scanned_at'),
  imagesBase64: jsonb('images_base64'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Define the 'pds_pictures' table
export const pdsPictures = pgTable('pds_pictures', {
  id: text('id').primaryKey(),
  src: text('src').notNull(),
  applicantName: text('applicant_name').notNull(),
  pageTitle: text('page_title'),
  pageNumber: integer('page_number').default(1),
  searchKey: text('search_key'),
  docId: text('doc_id'),
  orderNum: integer('order_num').default(0),
  uploadedAt: text('uploaded_at'),
  createdAt: timestamp('created_at').defaultNow(),
});
