import React, { useState, useEffect } from 'react';
import {
  getDeletedArchiveFromIndexedDB,
  removeArchivedItemFromIndexedDB,
  restoreArchivedItem,
  restoreAllArchivedItems,
  type ArchiveItem,
} from '../utils/storage';
import {
  clearAllArchivedItemsFromFirestore,
} from '../utils/firebaseSync';
import {
  Database,
  X,
  RotateCcw,
  Search,
  Trash2,
  CheckCircle2,
  Package,
  Receipt,
  CreditCard,
  RefreshCw,
  Sparkles,
} from 'lucide-react';

interface BackupRestoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataRestored?: () => void;
}

export const BackupRestoreModal: React.FC<BackupRestoreModalProps> = ({
  isOpen,
  onClose,
  onDataRestored,
}) => {
  const [archiveItems, setArchiveItems] = useState<ArchiveItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'Product' | 'Sale' | 'Utang'>('ALL');
  const [actionMsg, setActionMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const loadArchive = async () => {
    setIsLoading(true);
    try {
      const items = await getDeletedArchiveFromIndexedDB();
      setArchiveItems(items);
    } catch (e) {
      console.error('Failed to load archive:', e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadArchive();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleRestoreSingle = async (archiveId: string, itemName: string) => {
    setIsLoading(true);
    try {
      const success = await restoreArchivedItem(archiveId);
      if (success) {
        setActionMsg({
          type: 'success',
          text: `✓ matagumpay na naibalik ang "${itemName}" sa system at Firebase database!`,
        });
        await loadArchive();
        if (onDataRestored) onDataRestored();
      } else {
        setActionMsg({ type: 'error', text: 'Hindi ma-restore ang item. Subukan muli.' });
      }
    } catch (err) {
      setActionMsg({ type: 'error', text: 'Error sa pag-restore ng item.' });
    } finally {
      setIsLoading(false);
      setTimeout(() => setActionMsg(null), 4000);
    }
  };

  const handleRestoreAll = async () => {
    if (archiveItems.length === 0) return;
    if (!window.confirm(`Sigurado ka bang gusto mong i-restore ang LAHAT ng ${archiveItems.length} deleted items pabalik sa system?`)) {
      return;
    }

    setIsLoading(true);
    try {
      const count = await restoreAllArchivedItems();
      setActionMsg({
        type: 'success',
        text: `✓ Matagumpay na naibalik ang LAHAT ng ${count} na-delete na data pabalik sa live database!`,
      });
      await loadArchive();
      if (onDataRestored) onDataRestored();
    } catch (err) {
      setActionMsg({ type: 'error', text: 'Error sa pag-restore ng lahat ng items.' });
    } finally {
      setIsLoading(false);
      setTimeout(() => setActionMsg(null), 5000);
    }
  };

  const handlePermanentDeleteSingle = async (archiveId: string) => {
    if (!window.confirm('Sigurado ka bang tatanggalin ito nang tuluyan mula sa backup history?')) {
      return;
    }
    setIsLoading(true);
    await removeArchivedItemFromIndexedDB(archiveId);
    await loadArchive();
    setIsLoading(false);
  };

  const handlePermanentClearAll = async () => {
    if (!window.confirm('WARNING: Sigurado ka bang BURAHIN NANG TULUYAN ang LAHAT ng items sa backup storage? Hindi na ito mababawi!')) {
      return;
    }
    setIsLoading(true);
    await clearAllArchivedItemsFromFirestore();
    await loadArchive();
    setIsLoading(false);
    setActionMsg({ type: 'success', text: 'Permanently cleared backup archive.' });
    setTimeout(() => setActionMsg(null), 3000);
  };

  const filteredItems = archiveItems.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.details.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = typeFilter === 'ALL' || item.type === typeFilter;
    return matchesSearch && matchesType;
  });

  return (
    <div className="fixed inset-0 z-70 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-fade-in">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600/30 border border-indigo-400/40 rounded-2xl text-indigo-300">
              <Database className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-extrabold flex items-center gap-2">
                <span>Backup & Restore Database</span>
                <span className="px-2.5 py-0.5 rounded-full text-xs bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-400/30">
                  {archiveItems.length} items
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Talahanayan ng lahat ng na-delete o na-format na data na pwedeng i-restore.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-full hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Top Control Bar */}
        <div className="p-3 sm:p-4 bg-slate-50 border-b border-slate-200 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          {/* Search & Filter */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 flex-1">
            <div className="relative flex-1">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Mag-hanap sa deleted history..."
                className="w-full bg-white border border-slate-300 focus:border-indigo-600 focus:ring-2 focus:ring-indigo-500/20 rounded-xl pl-9 pr-4 py-2 text-xs font-semibold text-slate-900"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>

            {/* Type Filter Pills */}
            <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200">
              {(['ALL', 'Product', 'Sale', 'Utang'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setTypeFilter(t)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-extrabold transition-all ${
                    typeFilter === t
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {t === 'ALL' ? 'Lahat' : t === 'Product' ? 'Produkto' : t === 'Sale' ? 'Benta' : 'Utang'}
                </button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 shrink-0">
            {archiveItems.length > 0 && (
              <>
                <button
                  onClick={handleRestoreAll}
                  disabled={isLoading}
                  className="py-2 px-3.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
                  title="I-restore ang LAHAT ng deleted data pabalik sa live database"
                >
                  <RotateCcw className="w-4 h-4 stroke-[3px]" />
                  <span>I-RESTORE LAHAT</span>
                </button>

                <button
                  onClick={handlePermanentClearAll}
                  disabled={isLoading}
                  className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl text-xs font-bold border border-rose-200 transition-colors"
                  title="Burehin nang tuluyan ang backup history"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Action Status Toast Banner */}
        {actionMsg && (
          <div
            className={`mx-4 mt-3 p-3 rounded-2xl text-xs font-bold flex items-center gap-2 border ${
              actionMsg.type === 'success'
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                : 'bg-rose-50 text-rose-900 border-rose-200'
            }`}
          >
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{actionMsg.text}</span>
          </div>
        )}

        {/* Content Table Area */}
        <div className="flex-1 overflow-y-auto p-4">
          {isLoading && archiveItems.length === 0 ? (
            <div className="py-16 text-center text-slate-400 space-y-2">
              <RefreshCw className="w-8 h-8 animate-spin mx-auto text-indigo-600" />
              <p className="text-xs font-bold">Iniloload ang mga na-delete na datos...</p>
            </div>
          ) : filteredItems.length === 0 ? (
            <div className="py-16 text-center space-y-3 bg-slate-50 rounded-3xl border border-dashed border-slate-200">
              <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto border border-indigo-100">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-extrabold text-slate-800 text-sm">Walang Nahanap na Deleted Data</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-0.5">
                  Lahat ng i-delete o i-format mong produkto, benta, at utang ay awtomatikong maiipon dito para pwedeng i-restore kahit kailan!
                </p>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-2xl border border-slate-200 shadow-xs">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-200 text-[11px] font-black uppercase tracking-wider text-slate-600">
                    <th className="py-3 px-4">Uri</th>
                    <th className="py-3 px-4">Pangalan / Detalye</th>
                    <th className="py-3 px-4">Petsa Na-delete</th>
                    <th className="py-3 px-4 text-right">Aksyon</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs font-medium">
                  {filteredItems.map((item) => (
                    <tr key={item.archiveId} className="hover:bg-slate-50/80 transition-colors">
                      {/* Type Badge */}
                      <td className="py-3 px-4">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase ${
                            item.type === 'Product'
                              ? 'bg-blue-100 text-blue-800 border border-blue-200'
                              : item.type === 'Sale'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              : 'bg-amber-100 text-amber-800 border border-amber-200'
                          }`}
                        >
                          {item.type === 'Product' && <Package className="w-3 h-3" />}
                          {item.type === 'Sale' && <Receipt className="w-3 h-3" />}
                          {item.type === 'Utang' && <CreditCard className="w-3 h-3" />}
                          <span>{item.type}</span>
                        </span>
                      </td>

                      {/* Name & Details */}
                      <td className="py-3 px-4">
                        <div className="font-extrabold text-slate-900">{item.name}</div>
                        <div className="text-[11px] text-slate-500 font-mono">{item.details}</div>
                      </td>

                      {/* Date Deleted */}
                      <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                        {new Date(item.deletedAt).toLocaleString('en-PH', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
                        <button
                          onClick={() => handleRestoreSingle(item.archiveId, item.name)}
                          disabled={isLoading}
                          className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs inline-flex items-center gap-1 shadow-xs transition-all active:scale-95 disabled:opacity-50"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>I-restore</span>
                        </button>

                        <button
                          onClick={() => handlePermanentDeleteSingle(item.archiveId)}
                          disabled={isLoading}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                          title="Burehin sa backup"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs font-bold text-slate-600">
          <span>Kabuuang Na-backup: {archiveItems.length} records</span>
          <button
            onClick={onClose}
            className="py-2 px-4 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl font-bold transition-all"
          >
            Isara
          </button>
        </div>
      </div>
    </div>
  );
};
