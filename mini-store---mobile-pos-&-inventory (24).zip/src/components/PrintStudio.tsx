import React, { useState, useRef, useEffect } from 'react';
import {
  BondPaperPreset,
  CanvasElement,
  PrintDocumentProject,
  PrintDocumentPage,
  PhotoPresetSize,
  PrinterStatus,
  UserAccount,
} from '../types';
import {
  PAPER_DIMENSIONS_MM,
  PHOTO_PRESETS_MM,
  FONT_COLLECTIONS,
  savePrintProjectToDatabase,
  loadPrintProjectsFromFirestore,
  createDefaultPrintDocument,
  deletePrintProjectFromDatabase,
} from '../utils/printStudioStorage';
import {
  savePrintSaleTransaction,
  loadPrintSalesFromFirestore,
  PrintSaleTransaction,
} from '../utils/printSalesStorage';
import { ImageCropModal } from './ImageCropModal';
import { ReleaseDataButton } from './ReleaseDataButton';
import { playPrinterConnectedChime, playTickSound, playSuccessChime } from '../utils/sound';
import {
  Printer,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ArrowDown,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Image as ImageIcon,
  Type,
  Maximize,
  Minimize,
  Sliders,
  Sparkles,
  Trash2,
  Copy,
  RotateCw,
  RotateCcw,
  Crop,
  Scissors,
  FolderOpen,
  Save,
  Plus,
  Wifi,
  CheckCircle,
  HelpCircle,
  Eye,
  EyeOff,
  Minimize2,
  Maximize2,
  Gamepad2,
  Settings,
  Layers,
  ZoomIn,
  ZoomOut,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Bold,
  Italic,
  Underline,
  Move,
  Lock,
  Unlock,
  LogOut,
  Crosshair,
  Compass,
  SlidersHorizontal,
  Edit3,
  MousePointerClick,
  LayoutGrid,
  FilePlus,
  Files,
  Scaling,
  MoveHorizontal,
  MoveVertical,
  Check,
  Bell,
  ImagePlus,
  FileText,
  Square,
  Grid,
  Contact,
  SplitSquareVertical,
  Percent,
  Ruler,
  Undo2,
  Redo2,
  DollarSign,
  TrendingUp,
  Receipt,
  Coins,
  Calculator,
  RefreshCw,
  BarChart3,
} from 'lucide-react';

interface PrintStudioProps {
  activeUser: UserAccount;
  onBackToPortal: () => void;
}

export const PrintStudio: React.FC<PrintStudioProps> = ({ activeUser, onBackToPortal }) => {
  // Active Project State
  const [currentProject, setCurrentProject] = useState<PrintDocumentProject>(() => {
    return createDefaultPrintDocument();
  });
  const [savedProjects, setSavedProjects] = useState<PrintDocumentProject[]>([]);
  const [isProjectsModalOpen, setIsProjectsModalOpen] = useState(false);

  // Multi-Page & See All Grid States
  const [currentPageIndex, setCurrentPageIndex] = useState<number>(0);
  const [isSeeAllModalOpen, setIsSeeAllModalOpen] = useState<boolean>(false);
  const [printAllPagesMode, setPrintAllPagesMode] = useState<boolean>(true);

  // Selected Element for editing
  const [selectedElementId, setSelectedElementId] = useState<string | null>(null);

  // Quick Side Modals and Drawers
  const [isPaperSelectorOpen, setIsPaperSelectorOpen] = useState<boolean>(false);
  const [isPropertiesDrawerOpen, setIsPropertiesDrawerOpen] = useState<boolean>(false);
  const [isTextToolsOpen, setIsTextToolsOpen] = useState<boolean>(false);

  // Crop Photo Modal State
  const [isCropModalOpen, setIsCropModalOpen] = useState(false);
  const [cropImageSrc, setCropImageSrc] = useState<string>('');
  const [cropImageName, setCropImageName] = useState<string>('');
  const [cropTargetElementId, setCropTargetElementId] = useState<string | null>(null);

  // Direct Inline Text Editing on Bondpaper Canvas
  const [editingTextId, setEditingTextId] = useState<string | null>(null);
  const inlineInputRef = useRef<HTMLTextAreaElement | null>(null);

  // Canvas Viewport & Zoom (Default 50% Zoom as requested)
  const [zoomLevel, setZoomLevel] = useState<number>(50); // Always default to 50%
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showRulers, setShowRulers] = useState(true);
  const [showGrid, setShowGrid] = useState(false);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);

  // FULL UNDO & REDO HISTORY ENGINE
  const [undoStack, setUndoStack] = useState<PrintDocumentProject[]>([]);
  const [redoStack, setRedoStack] = useState<PrintDocumentProject[]>([]);

  const recordHistory = (prevProject: PrintDocumentProject) => {
    setUndoStack((prev) => [...prev.slice(-29), prevProject]);
    setRedoStack([]);
  };

  const handleUndo = () => {
    if (undoStack.length === 0) return;
    const previous = undoStack[undoStack.length - 1];
    const newUndo = undoStack.slice(0, undoStack.length - 1);
    setRedoStack((prev) => [...prev, currentProject]);
    setUndoStack(newUndo);
    setCurrentProject(previous);
    playTickSound();
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const next = redoStack[redoStack.length - 1];
    const newRedo = redoStack.slice(0, redoStack.length - 1);
    setUndoStack((prev) => [...prev, currentProject]);
    setRedoStack(newRedo);
    setCurrentProject(next);
    playTickSound();
  };

  // Custom Paper Dimensions Modal
  const [isCustomPaperModalOpen, setIsCustomPaperModalOpen] = useState(false);
  const [customWidthInput, setCustomWidthInput] = useState<number>(215.9);
  const [customHeightInput, setCustomHeightInput] = useState<number>(279.4);
  const [customUnit, setCustomUnit] = useState<'mm' | 'in' | 'cm'>('in');

  // Printer State (HP Smart Tank 580 & Universal Compatibility)
  const [printerStatus, setPrinterStatus] = useState<PrinterStatus>('idle');
  const [printerName] = useState('HP Smart Tank 580 All-in-One');
  const [printerIp, setPrinterIp] = useState('192.168.1.150');
  const [isPrinterModalOpen, setIsPrinterModalOpen] = useState(false);
  const [printLogMessage, setPrintLogMessage] = useState('');
  const [isPrinterScanning, setIsPrinterScanning] = useState(false);
  const [selectedPrinterBrand, setSelectedPrinterBrand] = useState<string>('hp');

  // POS PRINT BILLING & CONFIRMATION MODAL STATE
  const [isPrintConfirmModalOpen, setIsPrintConfirmModalOpen] = useState(false);
  const [printCopies, setPrintCopies] = useState<number>(1);
  const [isColorPrint, setIsColorPrint] = useState<boolean>(true);
  const [pricePerPage, setPricePerPage] = useState<number>(5); // default ₱5 for colored
  const [costPerPage, setCostPerPage] = useState<number>(2); // default ₱2 cost
  const [customerPaid, setCustomerPaid] = useState<number>(10);
  const [selectedPrintPaperPreset, setSelectedPrintPaperPreset] = useState<BondPaperPreset>('short');

  // SALES & PROFIT DASHBOARD STATE
  const [isSalesDashboardOpen, setIsSalesDashboardOpen] = useState(false);
  const [salesTransactions, setSalesTransactions] = useState<PrintSaleTransaction[]>([]);

  // Load sales transactions on mount
  useEffect(() => {
    loadPrintSalesFromFirestore().then((sales) => {
      setSalesTransactions(sales);
    });
  }, []);

  // Compute Sales Metrics (Araw, Linggo, Buwan)
  const getSalesMetrics = () => {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

    // Start of week (Sunday)
    const dayOfWeek = now.getDay();
    const startOfWeek = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dayOfWeek).getTime();

    // Start of month
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();

    let todayBenta = 0, todayPuhunan = 0, todayTubo = 0;
    let weekBenta = 0, weekPuhunan = 0, weekTubo = 0;
    let monthBenta = 0, monthPuhunan = 0, monthTubo = 0;

    salesTransactions.forEach((t) => {
      const tTime = new Date(t.timestamp).getTime();
      const benta = t.totalAmount || 0;
      const puhunan = t.costAmount || 0;
      const tubo = t.profitAmount || 0;

      if (tTime >= startOfToday) {
        todayBenta += benta;
        todayPuhunan += puhunan;
        todayTubo += tubo;
      }
      if (tTime >= startOfWeek) {
        weekBenta += benta;
        weekPuhunan += puhunan;
        weekTubo += tubo;
      }
      if (tTime >= startOfMonth) {
        monthBenta += benta;
        monthPuhunan += puhunan;
        monthTubo += tubo;
      }
    });

    return {
      today: { benta: todayBenta, puhunan: todayPuhunan, tubo: todayTubo },
      week: { benta: weekBenta, puhunan: weekPuhunan, tubo: weekTubo },
      month: { benta: monthBenta, puhunan: monthPuhunan, tubo: monthTubo },
    };
  };

  // 3-SECOND HOLD-TO-MOVE / DRAG UNLOCK STATE & 5-SECOND NOTIFICATION BANNER
  const [holdingElementId, setHoldingElementId] = useState<string | null>(null);
  const [holdProgress, setHoldProgress] = useState<number>(0);
  const [unlockedMoveElementIds, setUnlockedMoveElementIds] = useState<Record<string, boolean>>({});
  const [unlockedBannerMessage, setUnlockedBannerMessage] = useState<string | null>(null);
  const [bannerProgress, setBannerProgress] = useState<number>(100);
  const holdTimerRef = useRef<NodeJS.Timeout | null>(null);
  const holdIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const holdStartTimeRef = useRef<number>(0);
  const bannerTimerRef = useRef<NodeJS.Timeout | null>(null);
  const bannerIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // AUTOMATIC DIRECTIONAL MOVEMENT CONTROLLER STATE (Left, Right, Top, Down)
  const [moveStepMm, setMoveStepMm] = useState<number>(5);
  const [isDpadMinimized, setIsDpadMinimized] = useState<boolean>(false);
  const [isDpadHidden, setIsDpadHidden] = useState<boolean>(true);
  const repeatTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Dragging & Two-Finger Multi-Touch State
  const canvasRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStartPos, setDragStartPos] = useState<{ x: number; y: number } | null>(null);
  const [touchDistanceStart, setTouchDistanceStart] = useState<number | null>(null);
  const [initialScaleSize, setInitialScaleSize] = useState<{ width: number; height: number } | null>(null);

  // TOOLBAR STATE (PERMANENTLY VISIBLE AT ALL TIMES)
  const isToolbarHidden = false;
  const resetAutoHideTimer = React.useCallback(() => {}, []);

  // Disabled System Notification Toast as requested
  const showNotificationToast = (_message: string) => {
    // Completely silenced notification banners
  };

  const dismissNotification = () => {
    setUnlockedBannerMessage(null);
  };

  // Clear Hold Timers Helper
  const clearHoldTimer = () => {
    if (holdTimerRef.current) {
      clearTimeout(holdTimerRef.current);
      holdTimerRef.current = null;
    }
    if (holdIntervalRef.current) {
      clearInterval(holdIntervalRef.current);
      holdIntervalRef.current = null;
    }
    setHoldingElementId(null);
    setHoldProgress(0);
  };

  // Start 3-Second Hold Countdown for Free Movement Anywhere
  const startHoldForMove = (elementId: string) => {
    clearHoldTimer();
    setHoldingElementId(elementId);
    setHoldProgress(0);
    holdStartTimeRef.current = Date.now();

    // 50ms interval to smoothly tick progress from 0% to 100%
    holdIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - holdStartTimeRef.current;
      const pct = Math.min(100, (elapsed / 3000) * 100);
      setHoldProgress(pct);
    }, 50);

    // 3000ms timer
    holdTimerRef.current = setTimeout(() => {
      setUnlockedMoveElementIds((prev) => ({ ...prev, [elementId]: true }));
      showNotificationToast('🔓 3-SECOND HOLD UNLOCKED: Libre mo nang mai-move ang litrato kahit saan sa bondpaper!');
      playSuccessChime();
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate([80, 50, 120]);
      }
      clearHoldTimer();
    }, 3000);
  };

  // Toggle Free Move Mode Manually
  const toggleFreeMoveElement = (elementId: string) => {
    const isNowUnlocked = !unlockedMoveElementIds[elementId];
    setUnlockedMoveElementIds((prev) => ({ ...prev, [elementId]: isNowUnlocked }));
    if (isNowUnlocked) {
      playSuccessChime();
      showNotificationToast('🔓 FREE MOVE ACTIVE: Libre mo nang mai-move ang litrato kahit saan!');
    }
  };

  // Load Saved Projects from Firestore on mount
  useEffect(() => {
    loadPrintProjectsFromFirestore().then((projects) => {
      if (projects.length > 0) {
        setSavedProjects(projects);
      }
    });
    return () => {
      clearHoldTimer();
      if (bannerTimerRef.current) clearTimeout(bannerTimerRef.current);
      if (bannerIntervalRef.current) clearInterval(bannerIntervalRef.current);
    };
  }, []);

  // Compute Active Canvas Pixel Dimensions from mm
  const paperSpec = PAPER_DIMENSIONS_MM[currentProject.paperPreset] || PAPER_DIMENSIONS_MM.short;
  const rawWidthMm =
    currentProject.paperPreset === 'custom' ? currentProject.customWidthMm : paperSpec.width;
  const rawHeightMm =
    currentProject.paperPreset === 'custom' ? currentProject.customHeightMm : paperSpec.height;

  const activeWidthMm =
    currentProject.orientation === 'landscape'
      ? Math.max(rawWidthMm, rawHeightMm)
      : Math.min(rawWidthMm, rawHeightMm);
  const activeHeightMm =
    currentProject.orientation === 'landscape'
      ? Math.min(rawWidthMm, rawHeightMm)
      : Math.max(rawWidthMm, rawHeightMm);

  // Scale factor: 1 mm ≈ 3.78 px at 96 DPI
  const scaleMmToPx = 3.78 * (zoomLevel / 100);
  const canvasPixelWidth = activeWidthMm * scaleMmToPx;
  const canvasPixelHeight = activeHeightMm * scaleMmToPx;

  // Normalized Pages array (guaranteeing at least 1 valid page)
  const documentPages: PrintDocumentPage[] =
    currentProject.pages && currentProject.pages.length > 0
      ? currentProject.pages
      : [
          {
            id: `${currentProject.id}_p1`,
            pageNumber: 1,
            elements: currentProject.elements || [],
          },
        ];

  const safePageIndex = Math.max(0, Math.min(documentPages.length - 1, currentPageIndex));
  const activePage = documentPages[safePageIndex] || documentPages[0];
  const activeElements: CanvasElement[] = activePage?.elements || [];

  // Selected element reference from active page
  const selectedElement = activeElements.find((el) => el.id === selectedElementId) || null;
  const selectedTextElement =
    activeElements.find((el) => el.id === editingTextId && el.type === 'text') ||
    activeElements.find((el) => el.id === selectedElementId && el.type === 'text') ||
    activeElements.find((el) => el.type === 'text') ||
    null;

  // Helper to commit element updates to active page and project
  const updateActivePageElements = (newElements: CanvasElement[]) => {
    recordHistory(currentProject);
    const updatedPages = documentPages.map((pg, idx) =>
      idx === safePageIndex ? { ...pg, elements: newElements } : pg
    );
    setCurrentProject((prev) => ({
      ...prev,
      updatedAt: new Date().toISOString(),
      pages: updatedPages,
      elements: newElements,
    }));
  };

  // Update a single element property on active page
  const updateElement = (id: string, updates: Partial<CanvasElement>) => {
    const updated = activeElements.map((el) => (el.id === id ? { ...el, ...updates } : el));
    updateActivePageElements(updated);
  };

  // =========================================================================
  // MULTI-PAGE MANAGEMENT FUNCTIONS (Add Page, See All, Duplicate, Delete, Move)
  // =========================================================================
  const handleAddPage = () => {
    const newPageNum = documentPages.length + 1;
    const newPageId = `page_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;
    const newPage: PrintDocumentPage = {
      id: newPageId,
      pageNumber: newPageNum,
      elements: [],
    };
    const updatedPages = [...documentPages, newPage];
    const newIdx = updatedPages.length - 1;

    setCurrentProject((prev) => ({
      ...prev,
      updatedAt: new Date().toISOString(),
      pages: updatedPages,
      elements: [],
    }));
    setCurrentPageIndex(newIdx);
    setSelectedElementId(null);
    setEditingTextId(null);
    playSuccessChime();
    showNotificationToast(`📄 BAGONG BLANK PAGE: Naidagdag ang Pahina ${newPageNum}! Handa na para sa bagong layout.`);
  };

  const handleDuplicatePage = (idxToDup: number) => {
    const source = documentPages[idxToDup];
    if (!source) return;

    const clonedElements: CanvasElement[] = (source.elements || []).map((el) => ({
      ...el,
      id: `${el.type}_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
    }));

    const newPage: PrintDocumentPage = {
      id: `page_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      pageNumber: documentPages.length + 1,
      elements: clonedElements,
    };

    const nextPages = [...documentPages];
    nextPages.splice(idxToDup + 1, 0, newPage);
    const reindexed = nextPages.map((pg, i) => ({ ...pg, pageNumber: i + 1 }));

    setCurrentProject((prev) => ({
      ...prev,
      updatedAt: new Date().toISOString(),
      pages: reindexed,
      elements: clonedElements,
    }));
    setCurrentPageIndex(idxToDup + 1);
    setSelectedElementId(null);
    playSuccessChime();
    showNotificationToast(`📋 NA-DUPLICATE ANG PAHINA ${idxToDup + 1}: Handa na ang bagong kopya sa Pahina ${idxToDup + 2}!`);
  };

  const handleDeletePage = (idxToDel: number) => {
    if (documentPages.length <= 1) {
      const clearedPages = [{ ...documentPages[0], elements: [] }];
      setCurrentProject((prev) => ({
        ...prev,
        pages: clearedPages,
        elements: [],
      }));
      setSelectedElementId(null);
      showNotificationToast('🧹 NA-RESET ANG BONDPAPER: Blangko na muli ang kasalukuyang pahina.');
      return;
    }

    const nextPages = documentPages
      .filter((_, i) => i !== idxToDel)
      .map((pg, i) => ({ ...pg, pageNumber: i + 1 }));

    const nextIdx = Math.max(
      0,
      Math.min(
        nextPages.length - 1,
        idxToDel === safePageIndex
          ? idxToDel - 1
          : safePageIndex > idxToDel
          ? safePageIndex - 1
          : safePageIndex
      )
    );

    setCurrentProject((prev) => ({
      ...prev,
      pages: nextPages,
      elements: nextPages[nextIdx]?.elements || [],
    }));
    setCurrentPageIndex(nextIdx);
    setSelectedElementId(null);
    playTickSound();
    showNotificationToast(`🗑️ NA-DELETE ANG PAHINA: May ${nextPages.length} na natitirang pahina.`);
  };

  const handleMovePage = (fromIdx: number, toIdx: number) => {
    if (
      fromIdx < 0 ||
      fromIdx >= documentPages.length ||
      toIdx < 0 ||
      toIdx >= documentPages.length ||
      fromIdx === toIdx
    )
      return;

    const copy = [...documentPages];
    const [moved] = copy.splice(fromIdx, 1);
    copy.splice(toIdx, 0, moved);
    const reindexed = copy.map((pg, i) => ({ ...pg, pageNumber: i + 1 }));

    setCurrentProject((prev) => ({
      ...prev,
      pages: reindexed,
      elements: reindexed[toIdx]?.elements || [],
    }));
    setCurrentPageIndex(toIdx);
    playTickSound();
  };

  const handleSelectPage = (idx: number) => {
    if (idx < 0 || idx >= documentPages.length) return;
    setCurrentPageIndex(idx);
    setSelectedElementId(null);
    setEditingTextId(null);
    playTickSound();
  };

  // =========================================================================
  // VIEWPORT FIT HELPERS (Full Bond Paper Screen Fit for Easy Editing)
  // =========================================================================
  const handleFitToScreen = () => {
    if (!canvasRef.current) {
      setZoomLevel(75);
      return;
    }
    const containerW = canvasRef.current.clientWidth - (showRulers ? 64 : 32);
    const containerH = canvasRef.current.clientHeight - (showRulers ? 64 : 32);

    const baseW = activeWidthMm * 3.78;
    const baseH = activeHeightMm * 3.78;

    const scaleW = (containerW / baseW) * 100;
    const scaleH = (containerH / baseH) * 100;
    const bestScale = Math.max(35, Math.min(200, Math.floor(Math.min(scaleW, scaleH) * 0.94)));

    setZoomLevel(bestScale);
    playTickSound();
    showNotificationToast(`📐 BUONG BONDPAPER VIEW: Buong-buong nakikita ang ${paperSpec.name} (${bestScale}%) sa screen!`);
  };

  const handleFitWidth = () => {
    if (!canvasRef.current) {
      setZoomLevel(90);
      return;
    }
    const containerW = canvasRef.current.clientWidth - (showRulers ? 64 : 32);
    const baseW = activeWidthMm * 3.78;
    const scaleW = Math.max(40, Math.min(220, Math.floor((containerW / baseW) * 92)));
    setZoomLevel(scaleW);
    playTickSound();
    showNotificationToast(`↔️ FIT LAPAD: Na-fit ang lapad ng bond paper (${scaleW}%) sa screen!`);
  };

  // Add Image to Canvas
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const src = event.target?.result as string;
        const img = new Image();
        img.onload = () => {
          // Calculate initial size in mm: default 4R (101.6 x 152.4 mm) or fit inside paper
          const aspect = img.width / img.height;
          let initialW = 90; // mm
          let initialH = initialW / aspect;
          if (initialH > 120) {
            initialH = 120;
            initialW = initialH * aspect;
          }

          const newEl: CanvasElement = {
            id: `img_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
            type: 'image',
            src,
            name: file.name,
            x: Math.max(10, (activeWidthMm - initialW) / 2),
            y: Math.max(10, (activeHeightMm - initialH) / 2),
            width: initialW,
            height: initialH,
            rotation: 0,
            zIndex: activeElements.length + 1,
            opacity: 1,
            filter: 'none',
            borderRadius: 0,
            borderWidth: 0,
            borderColor: '#000000',
          };

          const nextElements = [...activeElements, newEl];
          updateActivePageElements(nextElements);
          setSelectedElementId(newEl.id);
          playTickSound();
        };
        img.src = src;
      };
      reader.readAsDataURL(file);
    });

    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Add Text Element to Canvas
  const handleAddText = () => {
    const newEl: CanvasElement = {
      id: `txt_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      type: 'text',
      text: 'I-type ang iyong teksto rito...',
      fontFamily: "'Inter', sans-serif",
      fontSize: 20,
      color: '#0f172a',
      bold: false,
      italic: false,
      underline: false,
      align: 'center',
      lineHeight: 1.3,
      letterSpacing: 0,
      x: 20,
      y: 20 + activeElements.length * 10,
      width: 160,
      height: 25,
      rotation: 0,
      zIndex: activeElements.length + 1,
    };

    const nextElements = [...activeElements, newEl];
    updateActivePageElements(nextElements);
    setSelectedElementId(newEl.id);
    setEditingTextId(newEl.id);
    setIsTextToolsOpen(true);
    playTickSound();

    setTimeout(() => {
      if (inlineInputRef.current) {
        inlineInputRef.current.focus();
        inlineInputRef.current.select();
      }
    }, 50);
  };

  // Handle Double-Click anywhere directly on the blank space of the bondpaper canvas
  const handleBondpaperDoubleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement;
    const isClickOnExistingEl = target.closest('[id^="canvas-el-"]');
    if (isClickOnExistingEl) return;

    const sheet = document.getElementById('printable-bondpaper-sheet');
    if (!sheet) return;

    const rect = sheet.getBoundingClientRect();
    const clickXPx = e.clientX - rect.left;
    const clickYPx = e.clientY - rect.top;

    // Convert pixel coordinate back to millimeter based on scale factor
    const clickXMm = Number((clickXPx / scaleMmToPx).toFixed(1));
    const clickYMm = Number((clickYPx / scaleMmToPx).toFixed(1));

    // Clamp inside paper boundaries safely
    const safeX = Math.max(10, Math.min(activeWidthMm - 70, clickXMm));
    const safeY = Math.max(10, Math.min(activeHeightMm - 25, clickYMm));

    const newEl: CanvasElement = {
      id: `txt_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      type: 'text',
      text: 'I-type ang teksto...',
      fontFamily: "'Inter', sans-serif",
      fontSize: 20,
      color: '#0f172a',
      bold: false,
      italic: false,
      underline: false,
      align: 'left',
      lineHeight: 1.3,
      letterSpacing: 0,
      x: safeX,
      y: safeY,
      width: Math.min(140, Math.max(70, activeWidthMm - safeX - 10)),
      height: 22,
      rotation: 0,
      zIndex: activeElements.length + 1,
    };

    const nextElements = [...activeElements, newEl];
    updateActivePageElements(nextElements);
    setSelectedElementId(newEl.id);
    setEditingTextId(newEl.id);
    setIsTextToolsOpen(true);
    playTickSound();

    // Automatically focus text cursor right at that spot
    setTimeout(() => {
      if (inlineInputRef.current) {
        inlineInputRef.current.focus();
        inlineInputRef.current.select();
      }
    }, 50);
  };

  // Rotate Selected Element by +/- Delta Degrees (e.g. +90°, -90°, +15°, etc.)
  const handleRotateElement = (deltaDegrees: number) => {
    let targetId = selectedElementId;
    if (!targetId) {
      const firstImg =
        activeElements.find((e) => e.type === 'image') || activeElements[0];
      if (firstImg) {
        targetId = firstImg.id;
        setSelectedElementId(firstImg.id);
      } else {
        return;
      }
    }
    const targetEl = activeElements.find((e) => e.id === targetId);
    if (!targetEl) return;

    const currentRot = targetEl.rotation || 0;
    const newRot = (currentRot + deltaDegrees + 360) % 360;
    updateElement(targetId, { rotation: newRot });
    playTickSound();
  };

  // Set Direct Exact Rotation Angle (0° to 360°)
  const handleSetRotationAngle = (angle: number) => {
    if (!selectedElementId) return;
    const clampedAngle = ((angle % 360) + 360) % 360;
    updateElement(selectedElementId, { rotation: clampedAngle });
  };

  // Open Crop Modal for an Image
  const handleOpenCropModal = (elementId?: string) => {
    const targetId = elementId || selectedElementId;
    const targetEl = activeElements.find((e) => e.id === targetId && e.type === 'image');
    if (!targetEl || !targetEl.src) return;

    setCropTargetElementId(targetEl.id);
    setCropImageSrc(targetEl.src);
    setCropImageName(targetEl.name || 'Selected Picture');
    setIsCropModalOpen(true);
    playTickSound();
  };

  // Apply Crop Result
  const handleApplyCrop = (croppedDataUrl: string) => {
    if (!cropTargetElementId) return;
    updateElement(cropTargetElementId, {
      src: croppedDataUrl,
    });
    playSuccessChime();
    showNotificationToast('✂️ TAGUMPAY: Na-crop na ang litrato!');
  };

  // Apply Photo Preset Size instantly to the selected image
  const applyPhotoPresetSize = (presetKey: PhotoPresetSize, targetId?: string) => {
    const elId = targetId || selectedElementId;
    const targetEl = activeElements.find((e) => e.id === elId && e.type === 'image');
    if (!targetEl || targetEl.type !== 'image') return;

    const applyCalculatedSize = (imgAspect: number) => {
      const safeAspect = imgAspect > 0 && !isNaN(imgAspect) ? imgAspect : 1;
      let targetW = 90;
      let targetH = 90;
      let targetX = targetEl.x;
      let targetY = targetEl.y;

      if (presetKey === 'full_page') {
        // FULL FIT INSIDE BONDPAPER: 100% of the picture is visible without any cropping or cutting
        const paperW = activeWidthMm;
        const paperH = activeHeightMm;
        const paperAspect = paperW / paperH;

        if (safeAspect >= paperAspect) {
          // Picture is wider than paper aspect ratio -> span full paper width, compute height
          targetW = paperW;
          targetH = targetW / safeAspect;
        } else {
          // Picture is taller than paper aspect ratio -> span full paper height, compute width
          targetH = paperH;
          targetW = targetH * safeAspect;
        }

        // Center precisely in the middle of the bondpaper canvas
        targetX = Number(((paperW - targetW) / 2).toFixed(1));
        targetY = Number(((paperH - targetH) / 2).toFixed(1));
      } else if (presetKey === 'half_page') {
        const maxW = activeWidthMm;
        const maxH = (activeHeightMm - 10) / 2;
        const halfAspect = maxW / maxH;

        if (safeAspect >= halfAspect) {
          targetW = maxW;
          targetH = targetW / safeAspect;
        } else {
          targetH = maxH;
          targetW = targetH * safeAspect;
        }
        targetX = Number(((activeWidthMm - targetW) / 2).toFixed(1));
        targetY = Number(((maxH - targetH) / 2).toFixed(1));
      } else {
        const spec = PHOTO_PRESETS_MM[presetKey];
        if (spec) {
          targetW = spec.width;
          targetH = spec.height;
          // Keep within paper boundaries
          targetX = Math.max(0, Math.min(activeWidthMm - targetW, targetEl.x));
          targetY = Math.max(0, Math.min(activeHeightMm - targetH, targetEl.y));
        }
      }

      updateElement(targetEl.id, {
        width: Number(targetW.toFixed(1)),
        height: Number(targetH.toFixed(1)),
        x: targetX,
        y: targetY,
      });

      playSuccessChime();
      if (presetKey === 'full_page') {
        showNotificationToast(`🖼️ FULL PAGE FIT: 100% buong litrato (${Math.round(targetW)}×${Math.round(targetH)} mm), kasya sa bondpaper nang walang putol!`);
      } else {
        showNotificationToast(`📐 Na-apply ang preset: ${presetKey.toUpperCase()}`);
      }
    };

    // Calculate true aspect ratio of image
    if (targetEl.src) {
      const tempImg = new Image();
      tempImg.onload = () => {
        const aspect = tempImg.naturalWidth / tempImg.naturalHeight;
        applyCalculatedSize(aspect || (targetEl.width / targetEl.height) || 1);
      };
      tempImg.onerror = () => {
        applyCalculatedSize((targetEl.width / targetEl.height) || 1);
      };
      tempImg.src = targetEl.src;
    } else {
      applyCalculatedSize((targetEl.width / targetEl.height) || 1);
    }
  };

  // Duplicate Selected Element
  const handleDuplicate = () => {
    if (!selectedElement) return;
    const cloned: CanvasElement = {
      ...selectedElement,
      id: `${selectedElement.type}_${Date.now()}_copy`,
      x: Math.min(activeWidthMm - selectedElement.width, selectedElement.x + 8),
      y: Math.min(activeHeightMm - selectedElement.height, selectedElement.y + 8),
      zIndex: activeElements.length + 1,
    };
    const nextElements = [...activeElements, cloned];
    updateActivePageElements(nextElements);
    setSelectedElementId(cloned.id);
    playTickSound();
  };

  // Delete Selected Element
  const handleDelete = () => {
    if (!selectedElementId) return;
    const nextElements = activeElements.filter((el) => el.id !== selectedElementId);
    updateActivePageElements(nextElements);
    setSelectedElementId(null);
  };

  // Layer Ordering
  const handleBringToFront = () => {
    if (!selectedElementId) return;
    const maxZ = Math.max(...activeElements.map((e) => e.zIndex), 0);
    updateElement(selectedElementId, { zIndex: maxZ + 1 });
  };

  const handleSendToBack = () => {
    if (!selectedElementId) return;
    const minZ = Math.min(...activeElements.map((e) => e.zIndex), 1);
    updateElement(selectedElementId, { zIndex: Math.max(0, minZ - 1) });
  };

  // =========================================================================
  // AUTOMATIC DIRECTIONAL MOVEMENT HANDLERS (Left, Right, Top/Up, Down)
  // =========================================================================
  // DIRECTIONAL MOVEMENT & CONTINUOUS MOVE LOGIC (Left, Right, Top, Down)
  // =========================================================================
  const stopContinuousMove = () => {
    if (repeatTimerRef.current) {
      clearInterval(repeatTimerRef.current);
      repeatTimerRef.current = null;
    }
  };

  // Directional Movement Handler for Arrow Keys & D-Pad (Left, Right, Top, Down)
  const handleMoveElement = (
    direction: 'up' | 'down' | 'left' | 'right',
    customStep?: number
  ) => {
    let targetId = selectedElementId;
    if (!targetId) {
      const firstImg =
        activeElements.find((e) => e.type === 'image') || activeElements[0];
      if (firstImg) {
        targetId = firstImg.id;
        setSelectedElementId(firstImg.id);
      } else {
        return;
      }
    }

    const targetEl = activeElements.find((e) => e.id === targetId);
    if (!targetEl) return;

    const step = customStep ?? moveStepMm;
    let newX = targetEl.x;
    let newY = targetEl.y;

    if (direction === 'left') {
      newX = Math.max(-50, targetEl.x - step);
    } else if (direction === 'right') {
      newX = Math.min(activeWidthMm + 50, targetEl.x + step);
    } else if (direction === 'up') {
      newY = Math.max(-50, targetEl.y - step);
    } else if (direction === 'down') {
      newY = Math.min(activeHeightMm + 50, targetEl.y + step);
    }

    updateElement(targetId, {
      x: Number(newX.toFixed(1)),
      y: Number(newY.toFixed(1)),
    });
    playTickSound();
  };

  // Start continuous move on long-press/hold
  const startContinuousMove = (direction: 'up' | 'down' | 'left' | 'right') => {
    handleMoveElement(direction);
    stopContinuousMove();
    repeatTimerRef.current = setInterval(() => {
      handleMoveElement(direction);
    }, 110);
  };

  // Fast Alignment Preset Helpers
  const handleAlignElement = (
    type: 'center' | 'center-h' | 'center-v' | 'top' | 'bottom' | 'left' | 'right'
  ) => {
    let targetId = selectedElementId;
    if (!targetId) {
      const firstImg =
        activeElements.find((e) => e.type === 'image') || activeElements[0];
      if (firstImg) {
        targetId = firstImg.id;
        setSelectedElementId(firstImg.id);
      } else {
        return;
      }
    }
    const targetEl = activeElements.find((e) => e.id === targetId);
    if (!targetEl) return;

    let newX = targetEl.x;
    let newY = targetEl.y;

    if (type === 'center') {
      newX = (activeWidthMm - targetEl.width) / 2;
      newY = (activeHeightMm - targetEl.height) / 2;
    } else if (type === 'center-h') {
      newX = (activeWidthMm - targetEl.width) / 2;
    } else if (type === 'center-v') {
      newY = (activeHeightMm - targetEl.height) / 2;
    } else if (type === 'top') {
      newY = 10;
    } else if (type === 'bottom') {
      newY = Math.max(0, activeHeightMm - targetEl.height - 10);
    } else if (type === 'left') {
      newX = 10;
    } else if (type === 'right') {
      newX = Math.max(0, activeWidthMm - targetEl.width - 10);
    }

    updateElement(targetId, {
      x: Number(newX.toFixed(1)),
      y: Number(newY.toFixed(1)),
    });
    playSuccessChime();
  };

  // Keyboard Arrow Keys Support (Desktop & Physical Keyboard)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeTagName = document.activeElement?.tagName.toLowerCase();
      if (activeTagName === 'input' || activeTagName === 'textarea' || activeTagName === 'select') return;

      if (e.key === 'ArrowUp') {
        e.preventDefault();
        handleMoveElement('up', e.shiftKey ? moveStepMm * 3 : moveStepMm);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        handleMoveElement('down', e.shiftKey ? moveStepMm * 3 : moveStepMm);
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handleMoveElement('left', e.shiftKey ? moveStepMm * 3 : moveStepMm);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        handleMoveElement('right', e.shiftKey ? moveStepMm * 3 : moveStepMm);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      stopContinuousMove();
    };
  }, [selectedElementId, moveStepMm, activeElements, activeWidthMm, activeHeightMm]);

  // Touch Gesture Handling for Two-Finger Pinch & Left/Right Handles + 3-Second Hold to Move
  const handleTouchStart = (e: React.TouchEvent, elementId: string) => {
    setSelectedElementId(elementId);
    if (e.touches.length === 2) {
      clearHoldTimer();
      // Two fingers detected on screen! Calculate initial Euclidean distance for pinch resize
      const touch1 = e.touches[0];
      const touch2 = e.touches[1];
      const dist = Math.hypot(touch2.clientX - touch1.clientX, touch2.clientY - touch1.clientY);
      setTouchDistanceStart(dist);
      const el = activeElements.find((item) => item.id === elementId);
      if (el) {
        setInitialScaleSize({ width: el.width, height: el.height });
      }
    } else if (e.touches.length === 1) {
      setIsDragging(true);
      const touch = e.touches[0];
      setDragStartPos({ x: touch.clientX, y: touch.clientY });

      // Start 3-second hold countdown!
      startHoldForMove(elementId);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!selectedElementId) return;
    const el = activeElements.find((item) => item.id === selectedElementId);
    if (!el) return;

    if (e.touches.length === 2 && touchDistanceStart && initialScaleSize) {
      // Two-Finger Pinch-To-Zoom / Resize
      const touch1 = e.touches[0];
      const touch2 = e.touches[1];
      const currentDist = Math.hypot(touch2.clientX - touch1.clientX, touch2.clientY - touch1.clientY);
      const scaleFactor = currentDist / touchDistanceStart;

      const newW = Math.max(10, Math.min(activeWidthMm * 1.5, initialScaleSize.width * scaleFactor));
      const newH = Math.max(10, Math.min(activeHeightMm * 1.5, initialScaleSize.height * scaleFactor));

      updateElement(selectedElementId, { width: newW, height: newH });
    } else if (e.touches.length === 1 && isDragging && dragStartPos) {
      const touch = e.touches[0];
      const deltaXmm = (touch.clientX - dragStartPos.x) / scaleMmToPx;
      const deltaYmm = (touch.clientY - dragStartPos.y) / scaleMmToPx;

      // If moved significantly before 3s, clear hold timer and perform normal movement
      if (Math.hypot(touch.clientX - dragStartPos.x, touch.clientY - dragStartPos.y) > 15 && holdProgress < 95) {
        clearHoldTimer();
      }

      // Smooth movement anywhere on the canvas
      updateElement(selectedElementId, {
        x: Math.max(-50, Math.min(activeWidthMm + 50, el.x + deltaXmm)),
        y: Math.max(-50, Math.min(activeHeightMm + 50, el.y + deltaYmm)),
      });
      setDragStartPos({ x: touch.clientX, y: touch.clientY });
    }
  };

  const handleTouchEnd = () => {
    clearHoldTimer();
    setIsDragging(false);
    setDragStartPos(null);
    setTouchDistanceStart(null);
    setInitialScaleSize(null);
  };

  // Mouse Drag on Desktop + 3-Second Hold
  const handleMouseDown = (e: React.MouseEvent, elementId: string) => {
    e.stopPropagation();
    setSelectedElementId(elementId);
    setIsDragging(true);
    setDragStartPos({ x: e.clientX, y: e.clientY });

    // Start 3-second hold countdown on mouse click too!
    startHoldForMove(elementId);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !dragStartPos || !selectedElementId) return;
    const el = activeElements.find((item) => item.id === selectedElementId);
    if (!el) return;

    const deltaXmm = (e.clientX - dragStartPos.x) / scaleMmToPx;
    const deltaYmm = (e.clientY - dragStartPos.y) / scaleMmToPx;

    // If moved noticeably while holding, clear hold timer
    if (Math.hypot(e.clientX - dragStartPos.x, e.clientY - dragStartPos.y) > 12 && holdProgress < 95) {
      clearHoldTimer();
    }

    updateElement(selectedElementId, {
      x: Math.max(-50, Math.min(activeWidthMm + 50, el.x + deltaXmm)),
      y: Math.max(-50, Math.min(activeHeightMm + 50, el.y + deltaYmm)),
    });
    setDragStartPos({ x: e.clientX, y: e.clientY });
  };

  const handleMouseUp = () => {
    clearHoldTimer();
    setIsDragging(false);
    setDragStartPos(null);
  };

  // Save Current Project to Firestore
  const handleSaveProject = async () => {
    await savePrintProjectToDatabase(currentProject);
    const refreshed = await loadPrintProjectsFromFirestore();
    setSavedProjects(refreshed);
    playSuccessChime();
    showNotificationToast(`💾 NA-SAVE: Na-save ang document "${currentProject.title}" sa Firebase Database!`);
  };

  // Universal Printer Network Scan / Refresh
  const handleScanPrinters = () => {
    setIsPrinterScanning(true);
    setPrinterStatus('searching');
    setPrintLogMessage(`Naghahanap ng mga printer sa local network (${selectedPrinterBrand.toUpperCase()})...`);
    playTickSound();

    setTimeout(() => {
      setIsPrinterScanning(false);
      setPrinterStatus('connected');
      setPrintLogMessage(`Nahanap at kumonekta nang matagumpay sa ${selectedPrinterBrand.toUpperCase()} Printer (${printerIp})! Ready to print.`);
      playPrinterConnectedChime();
    }, 1200);
  };

  // HP Smart Tank 580 Connection Simulation & Sound Chime
  const handleConnectPrinter = () => {
    setPrinterStatus('searching');
    setPrintLogMessage(`Naghahanap ng ${printerName} sa local network (${printerIp})...`);

    setTimeout(() => {
      setPrinterStatus('connecting');
      setPrintLogMessage(`Nakita ang ${printerName}! Kumokonekta via Wi-Fi Direct...`);

      setTimeout(() => {
        setPrinterStatus('connected');
        setPrintLogMessage(`Tagumpay! Nakakonekta na sa ${printerName}. Ready to print.`);
        // Play automatic connection sound requested by user!
        playPrinterConnectedChime();
      }, 1200);
    }, 1500);
  };

  // Open POS Billing Confirmation Modal Before Print
  const handleTriggerPrint = () => {
    setSelectedPrintPaperPreset(currentProject.paperPreset);
    setIsPrintConfirmModalOpen(true);
  };

  // Confirm Print & Log Sales Data into Firestore & LocalStorage
  const handleConfirmAndExecutePrint = async () => {
    const totalBenta = printCopies * pricePerPage * documentPages.length;
    const totalPuhunan = printCopies * costPerPage * documentPages.length;
    const totalTubo = totalBenta - totalPuhunan;
    const sukli = Math.max(0, customerPaid - totalBenta);

    // Close modals immediately so they don't block the printable canvas element
    setIsPrintConfirmModalOpen(false);
    setIsPreviewModalOpen(false);
    setIsPrinterModalOpen(false);

    // Save transaction in non-blocking background task
    const saleData = {
      copies: printCopies,
      pages: documentPages.length,
      paperSize: selectedPrintPaperPreset,
      colorMode: (isColorPrint ? 'colored' : 'bw') as 'colored' | 'bw',
      pricePerPage,
      costPerPage,
      totalAmount: totalBenta,
      costAmount: totalPuhunan,
      profitAmount: totalTubo,
      customerPaid,
      customerChange: sukli,
    };

    savePrintSaleTransaction(saleData)
      .then(() => loadPrintSalesFromFirestore())
      .then((updatedSales) => setSalesTransactions(updatedSales))
      .catch((e) => console.error('Error logging print sale:', e));

    if (printerStatus !== 'connected') {
      setPrinterStatus('connected');
    }

    playPrinterConnectedChime();
    showNotificationToast(
      `🖨️ PRINTING STARTED: Benta: ₱${totalBenta.toFixed(2)} | Tubo: ₱${totalTubo.toFixed(2)} | Sukli: ₱${sukli.toFixed(2)}`
    );

    // Trigger window.print after brief tick for DOM modal unmount
    setTimeout(() => {
      try {
        window.print();
      } catch (err) {
        console.error('Error triggering window.print():', err);
      }
    }, 150);
  };

  return (
    <div
      className={`min-h-screen w-full flex flex-col bg-slate-900 text-slate-100 select-none ${
        isFullscreen ? 'fixed inset-0 z-50' : 'relative'
      }`}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Hidden File Input for Image Upload */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={handleImageUpload}
      />

      {/* ALL-IN-ONE TOP HORIZONTAL TOOLBAR BAR (PERMANENTLY VISIBLE) */}
      <div
        className="no-print fixed top-1 left-1/2 -translate-x-1/2 z-30 flex flex-col gap-1 p-1.5 bg-slate-950/95 backdrop-blur-md border border-cyan-500/40 rounded-2xl shadow-2xl max-w-[98vw] sm:max-w-[96vw] w-full"
      >
        {/* ROW 1: PRIMARY ACTIONS & DOCUMENT HEADER */}
        <div className="flex items-center justify-between gap-1 sm:gap-2 overflow-x-auto scrollbar-none px-1">
          {/* Left Group: Exit & Title */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* EXIT BUTTON */}
            <button
              type="button"
              onClick={onBackToPortal}
              className="h-8 px-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1 shadow transition-all active:scale-95 touch-manipulation shrink-0 cursor-pointer"
              title="EXIT: Bumalik sa Home / Portal"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>EXIT</span>
            </button>

            {/* Document Title Input & Paper spec badge */}
            <div className="flex items-center gap-1 px-2 py-1 bg-slate-900 border border-slate-800 rounded-xl shrink-0">
              <input
                type="text"
                value={currentProject.title}
                onChange={(e) => setCurrentProject({ ...currentProject, title: e.target.value })}
                className="bg-transparent text-xs font-bold text-cyan-300 focus:outline-none max-w-[90px] sm:max-w-[140px] truncate"
                placeholder="Title..."
              />
              <button
                type="button"
                onClick={() => setIsPaperSelectorOpen(true)}
                className="text-[10px] font-mono text-cyan-400/90 hover:text-cyan-300 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-500/30 font-bold shrink-0 cursor-pointer"
                title="Baguhin ang Sukat ng Bond Paper"
              >
                {paperSpec.name} ({activeWidthMm}×{activeHeightMm}mm)
              </button>
            </div>
          </div>

          {/* Center Group: Primary Creation Buttons + Undo / Redo */}
          <div className="flex items-center gap-1 shrink-0">
            {/* UPLOAD PICTURE */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="h-8 px-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1 transition-all active:scale-95 touch-manipulation shrink-0 cursor-pointer"
              title="Upload / Maglagay ng Litrato"
            >
              <ImagePlus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Picture</span>
            </button>

            {/* ADD TEXT */}
            <button
              type="button"
              onClick={handleAddText}
              className="h-8 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 transition-all active:scale-95 touch-manipulation shrink-0 cursor-pointer"
              title="Mag-add ng Text"
            >
              <Type className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Text</span>
            </button>

            {/* TEXT TOOLS BUTTON */}
            <button
              type="button"
              onClick={() => {
                setIsTextToolsOpen(!isTextToolsOpen);
                playTickSound();
              }}
              className={`h-8 px-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95 touch-manipulation shrink-0 cursor-pointer ${
                isTextToolsOpen
                  ? 'bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/30'
                  : 'bg-amber-950/80 border border-amber-500/50 hover:bg-amber-900 text-amber-300'
              }`}
              title="Ipakita / I-toggle ang lahat ng Text Editing Tools"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Text Tools</span>
            </button>

            {/* RELEASE DATA TO DESKTOP */}
            <ReleaseDataButton variant="toolbar" accountId={activeUser.id} />

            {/* SAVE TO FIREBASE */}
            <button
              type="button"
              onClick={handleSaveProject}
              className="h-8 px-2.5 rounded-xl bg-cyan-950 border border-cyan-500/50 hover:bg-cyan-900 text-cyan-300 font-bold text-xs flex items-center gap-1 transition-all active:scale-95 touch-manipulation shrink-0 cursor-pointer"
              title="I-save sa Database"
            >
              <Save className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden md:inline">Save</span>
            </button>

            {/* SAVED DOCS */}
            <button
              type="button"
              onClick={() => setIsProjectsModalOpen(true)}
              className="h-8 px-2 rounded-xl bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-300 font-bold text-xs flex items-center gap-1 transition-all active:scale-95 touch-manipulation shrink-0 cursor-pointer"
              title="Naka-save na Mga Dokumento"
            >
              <FolderOpen className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Saved Docs</span>
            </button>



            {/* UNDO BUTTON */}
            <button
              type="button"
              disabled={undoStack.length === 0}
              onClick={handleUndo}
              className="h-8 px-2 rounded-xl bg-slate-900 border border-slate-700 hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed text-cyan-300 font-bold text-xs flex items-center gap-1 transition-all active:scale-95 touch-manipulation shrink-0 cursor-pointer"
              title="Undo"
            >
              <Undo2 className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden md:inline">Undo</span>
            </button>

            {/* REDO BUTTON */}
            <button
              type="button"
              disabled={redoStack.length === 0}
              onClick={handleRedo}
              className="h-8 px-2 rounded-xl bg-slate-900 border border-slate-700 hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed text-cyan-300 font-bold text-xs flex items-center gap-1 transition-all active:scale-95 touch-manipulation shrink-0 cursor-pointer"
              title="Redo"
            >
              <Redo2 className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden md:inline">Redo</span>
            </button>

            {/* DIRECT PRINT BUTTON */}
            <button
              id="print-studio-direct-print-btn"
              type="button"
              onClick={handleTriggerPrint}
              className="h-8 px-3 rounded-xl bg-gradient-to-tr from-cyan-500 to-teal-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-extrabold text-xs flex items-center gap-1 shadow-md shadow-cyan-500/30 transition-all active:scale-95 touch-manipulation shrink-0 cursor-pointer"
              title="I-print sa HP Smart Tank 580"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>PRINT</span>
            </button>
          </div>

          {/* Right Group: Fit & Zoom */}
          <div className="flex items-center gap-1 shrink-0">
            {/* Fit Screen */}
            <button
              type="button"
              onClick={handleFitToScreen}
              className="w-8 h-8 rounded-xl bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-300 flex items-center justify-center active:scale-95 transition-all touch-manipulation shrink-0 cursor-pointer"
              title="Fit Full Bondpaper sa Screen"
            >
              <Scaling className="w-3.5 h-3.5 text-cyan-400" />
            </button>

                {/* Fit Width */}
                <button
                  type="button"
                  onClick={handleFitWidth}
                  className="w-8 h-8 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 flex items-center justify-center active:scale-95 transition-all touch-manipulation shrink-0 cursor-pointer"
                  title="Fit Lapad ng Bondpaper"
                >
                  <MoveHorizontal className="w-3.5 h-3.5" />
                </button>

                {/* Zoom controls */}
                <div className="flex items-center gap-0.5 bg-slate-900 border border-slate-800 rounded-xl p-0.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => setZoomLevel(Math.max(35, zoomLevel - 15))}
                    className="w-7 h-7 rounded-lg hover:bg-slate-800 text-slate-300 flex items-center justify-center active:scale-95 transition-all cursor-pointer"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setZoomLevel(100)}
                    className="px-1.5 h-7 font-mono text-cyan-400 font-bold text-[11px] flex items-center justify-center hover:bg-slate-800 rounded active:scale-95 transition-all cursor-pointer"
                    title="Reset Zoom 100%"
                  >
                    {zoomLevel}%
                  </button>
                  <button
                    type="button"
                    onClick={() => setZoomLevel(Math.min(250, zoomLevel + 15))}
                    className="w-7 h-7 rounded-lg hover:bg-slate-800 text-slate-300 flex items-center justify-center active:scale-95 transition-all cursor-pointer"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* HP 580 Status Badge */}
                <div
                  onClick={() => setIsPrinterModalOpen(true)}
                  className="cursor-pointer flex items-center gap-1 px-2 h-8 rounded-xl bg-slate-900 border border-cyan-500/30 hover:border-cyan-400 transition-all text-[11px] shrink-0"
                  title="HP Smart Tank 580 Status"
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      printerStatus === 'connected'
                        ? 'bg-emerald-400 shadow-[0_0_8px_#34d399] animate-pulse'
                        : printerStatus === 'connecting' || printerStatus === 'searching'
                        ? 'bg-amber-400 animate-ping'
                        : 'bg-slate-500'
                    }`}
                  />
                  <Wifi className="w-3.5 h-3.5 text-cyan-400" />
                </div>
              </div>
            </div>

            {/* EXPANDED TEXT TOOLS EDITOR BAR */}
            {isTextToolsOpen && (
              <div className="flex items-center gap-2 overflow-x-auto scrollbar-none py-1.5 px-2 bg-slate-900/95 border border-amber-500/40 rounded-xl text-xs text-slate-200 shrink-0 my-0.5">
                <div className="flex items-center gap-1 text-[10px] font-black text-amber-400 uppercase shrink-0 pr-2 border-r border-slate-800">
                  <Type className="w-4 h-4 text-amber-400" />
                  <span>TEXT EDITOR:</span>
                </div>

                {/* Font Family Selector */}
                <div className="flex items-center gap-1 shrink-0">
                  <span className="text-[10px] text-slate-400 hidden sm:inline">Font:</span>
                  <select
                    value={selectedTextElement?.fontFamily || "'Inter', sans-serif"}
                    onChange={(e) => {
                      if (selectedTextElement) {
                        updateElement(selectedTextElement.id, { fontFamily: e.target.value });
                      } else {
                        handleAddText();
                      }
                    }}
                    className="h-7 bg-slate-950 border border-amber-500/30 rounded-lg px-2 text-white font-medium text-xs focus:ring-1 focus:ring-amber-400 max-w-[130px] cursor-pointer"
                  >
                    {FONT_COLLECTIONS.map((f) => (
                      <option key={f.name} value={f.font} style={{ fontFamily: f.font }}>
                        {f.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Font Size (+ / -) */}
                <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded-lg p-0.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedTextElement) {
                        updateElement(selectedTextElement.id, {
                          fontSize: Math.max(8, (selectedTextElement.fontSize || 20) - 2),
                        });
                      }
                    }}
                    className="w-6 h-6 rounded bg-slate-900 hover:bg-slate-800 text-slate-200 font-black flex items-center justify-center cursor-pointer active:scale-95"
                    title="Liitan ang Font Size (-2px)"
                  >
                    -
                  </button>
                  <span className="px-1 font-mono text-amber-300 font-bold text-[11px] min-w-[36px] text-center">
                    {selectedTextElement?.fontSize || 20}px
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedTextElement) {
                        updateElement(selectedTextElement.id, {
                          fontSize: Math.min(120, (selectedTextElement.fontSize || 20) + 2),
                        });
                      }
                    }}
                    className="w-6 h-6 rounded bg-slate-900 hover:bg-slate-800 text-slate-200 font-black flex items-center justify-center cursor-pointer active:scale-95"
                    title="Lakihan ang Font Size (+2px)"
                  >
                    +
                  </button>
                </div>

                {/* Bold, Italic, Underline */}
                <div className="flex items-center gap-0.5 bg-slate-950 border border-slate-800 p-0.5 rounded-lg shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedTextElement) {
                        updateElement(selectedTextElement.id, { bold: !selectedTextElement.bold });
                      }
                    }}
                    className={`w-6 h-6 rounded flex items-center justify-center transition-all cursor-pointer active:scale-95 ${
                      selectedTextElement?.bold
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'text-slate-300 hover:bg-slate-900'
                    }`}
                    title="Bold"
                  >
                    <Bold className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedTextElement) {
                        updateElement(selectedTextElement.id, { italic: !selectedTextElement.italic });
                      }
                    }}
                    className={`w-6 h-6 rounded flex items-center justify-center transition-all cursor-pointer active:scale-95 ${
                      selectedTextElement?.italic
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'text-slate-300 hover:bg-slate-900'
                    }`}
                    title="Italic"
                  >
                    <Italic className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedTextElement) {
                        updateElement(selectedTextElement.id, { underline: !selectedTextElement.underline });
                      }
                    }}
                    className={`w-6 h-6 rounded flex items-center justify-center transition-all cursor-pointer active:scale-95 ${
                      selectedTextElement?.underline
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'text-slate-300 hover:bg-slate-900'
                    }`}
                    title="Underline"
                  >
                    <Underline className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Text Alignment */}
                <div className="flex items-center gap-0.5 bg-slate-950 border border-slate-800 p-0.5 rounded-lg shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedTextElement) {
                        updateElement(selectedTextElement.id, { align: 'left' });
                      }
                    }}
                    className={`w-6 h-6 rounded flex items-center justify-center transition-all cursor-pointer active:scale-95 ${
                      selectedTextElement?.align === 'left'
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'text-slate-300 hover:bg-slate-900'
                    }`}
                    title="Align Left"
                  >
                    <AlignLeft className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedTextElement) {
                        updateElement(selectedTextElement.id, { align: 'center' });
                      }
                    }}
                    className={`w-6 h-6 rounded flex items-center justify-center transition-all cursor-pointer active:scale-95 ${
                      selectedTextElement?.align === 'center'
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'text-slate-300 hover:bg-slate-900'
                    }`}
                    title="Align Center"
                  >
                    <AlignCenter className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedTextElement) {
                        updateElement(selectedTextElement.id, { align: 'right' });
                      }
                    }}
                    className={`w-6 h-6 rounded flex items-center justify-center transition-all cursor-pointer active:scale-95 ${
                      selectedTextElement?.align === 'right'
                        ? 'bg-amber-500 text-slate-950 font-bold'
                        : 'text-slate-300 hover:bg-slate-900'
                    }`}
                    title="Align Right"
                  >
                    <AlignRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Text Color Picker */}
                <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 px-2 h-7 rounded-lg shrink-0">
                  <span className="text-[10px] text-slate-400 font-bold">Kulay:</span>
                  <input
                    type="color"
                    value={selectedTextElement?.color || '#0f172a'}
                    onChange={(e) => {
                      if (selectedTextElement) {
                        updateElement(selectedTextElement.id, { color: e.target.value });
                      }
                    }}
                    className="w-5 h-5 rounded border-0 bg-transparent cursor-pointer"
                    title="Pumili ng kulay ng teksto"
                  />
                </div>

                {/* Highlight Background Color */}
                <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 px-2 h-7 rounded-lg shrink-0">
                  <span className="text-[10px] text-slate-400 font-bold">Highlight:</span>
                  <input
                    type="color"
                    value={selectedTextElement?.backgroundColor || '#ffffff'}
                    onChange={(e) => {
                      if (selectedTextElement) {
                        updateElement(selectedTextElement.id, { backgroundColor: e.target.value });
                      }
                    }}
                    className="w-5 h-5 rounded border-0 bg-transparent cursor-pointer"
                    title="Pumili ng highlight background"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedTextElement) {
                        updateElement(selectedTextElement.id, { backgroundColor: undefined });
                      }
                    }}
                    className="text-[9px] text-slate-400 hover:text-white underline cursor-pointer"
                    title="Transparent Background"
                  >
                    Clear
                  </button>
                </div>

                {/* Quick Add Text Cursor Button */}
                <button
                  type="button"
                  onClick={handleAddText}
                  className="h-7 px-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center gap-1 active:scale-95 transition-all shrink-0 cursor-pointer ml-auto"
                  title="Maglagay ng bagong text cursor sa bondpaper"
                >
                  <Type className="w-3 h-3" />
                  <span>+ Add Text</span>
                </button>
              </div>
            )}

            {/* ROW 2: COMPACT RIBBON BAR (PRESETS, EDIT TOOLS, PAGES & TOGGLES) */}
            <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pt-1 border-t border-slate-800/80 px-1 text-xs">
              {/* PHOTO PRESET SIZES */}
              <div className="flex items-center gap-1 shrink-0 pr-1.5 border-r border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold hidden xl:inline">PRESETS:</span>
                <button
                  type="button"
                  onClick={() => applyPhotoPresetSize('full_page')}
                  className="h-7 px-2 rounded-lg bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-500/40 text-indigo-200 font-bold text-[11px] flex items-center gap-1 active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Full Page (100% Buong Litrato)"
                >
                  <Maximize2 className="w-3 h-3 text-cyan-400" />
                  <span>Full Page</span>
                </button>
                <button
                  type="button"
                  onClick={() => applyPhotoPresetSize('half_page')}
                  className="h-7 px-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-[11px] flex items-center gap-1 active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Half Page"
                >
                  <SplitSquareVertical className="w-3 h-3 text-cyan-400" />
                  <span>Half Page</span>
                </button>
                <button
                  type="button"
                  onClick={() => applyPhotoPresetSize('2x2')}
                  className="h-7 px-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-[11px] flex items-center gap-1 active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="2x2 in Photo"
                >
                  <Grid className="w-3 h-3 text-cyan-400" />
                  <span>2×2</span>
                </button>
                <button
                  type="button"
                  onClick={() => applyPhotoPresetSize('1x1')}
                  className="h-7 px-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-[11px] flex items-center gap-1 active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="1x1 in ID Photo"
                >
                  <Square className="w-3 h-3 text-cyan-400" />
                  <span>1×1</span>
                </button>
                <button
                  type="button"
                  onClick={() => applyPhotoPresetSize('passport')}
                  className="h-7 px-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-teal-300 font-bold text-[11px] flex items-center gap-1 active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Passport Size (35×45mm)"
                >
                  <Contact className="w-3 h-3 text-teal-400" />
                  <span>Passport</span>
                </button>
                <button
                  type="button"
                  onClick={() => applyPhotoPresetSize('4r')}
                  className="h-7 px-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-emerald-300 font-bold text-[11px] flex items-center gap-1 active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="4R Photo (4x6 in)"
                >
                  <ImageIcon className="w-3 h-3 text-emerald-400" />
                  <span>4R</span>
                </button>
              </div>

              {/* ELEMENT EDITING TOOLS */}
              <div className="flex items-center gap-1 shrink-0 pr-1.5 border-r border-slate-800">
                {/* Crop */}
                <button
                  type="button"
                  onClick={() => handleOpenCropModal()}
                  className="w-7 h-7 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="I-crop ang Litrato"
                >
                  <Scissors className="w-3.5 h-3.5" />
                </button>

                {/* Rotate Left */}
                <button
                  type="button"
                  onClick={() => handleRotateElement(-90)}
                  className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Rotate -90° Pakaliwa"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>

                {/* Rotate Right */}
                <button
                  type="button"
                  onClick={() => handleRotateElement(90)}
                  className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Rotate +90° Pakanan"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                </button>

                {/* Center */}
                <button
                  type="button"
                  onClick={() => handleAlignElement('center')}
                  className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-cyan-300 flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Igitna sa Bondpaper"
                >
                  <Crosshair className="w-3.5 h-3.5 text-cyan-400" />
                </button>

                {/* Free Move Mode */}
                <button
                  type="button"
                  onClick={() => {
                    if (selectedElementId) {
                      toggleFreeMoveElement(selectedElementId);
                    } else {
                      const first = activeElements.find((e) => e.type === 'image') || activeElements[0];
                      if (first) {
                        setSelectedElementId(first.id);
                        toggleFreeMoveElement(first.id);
                      }
                    }
                  }}
                  className={`w-7 h-7 rounded-lg border flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer ${
                    selectedElementId && unlockedMoveElementIds[selectedElementId]
                      ? 'bg-emerald-600 text-slate-950 border-emerald-400'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800'
                  }`}
                  title="Free Move Mode (Unlock Drag Anywhere)"
                >
                  {selectedElementId && unlockedMoveElementIds[selectedElementId] ? (
                    <Unlock className="w-3.5 h-3.5 text-slate-950" />
                  ) : (
                    <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                </button>

                {/* Bring to Front */}
                <button
                  type="button"
                  onClick={handleBringToFront}
                  className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Bring to Front"
                >
                  <Layers className="w-3.5 h-3.5" />
                </button>

                {/* Duplicate */}
                <button
                  type="button"
                  onClick={handleDuplicate}
                  className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Duplicate Element"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>

                {/* Delete */}
                <button
                  type="button"
                  onClick={handleDelete}
                  className="w-7 h-7 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Burahin ang Element"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>

                {/* Properties Panel Toggle */}
                <button
                  type="button"
                  onClick={() => setIsPropertiesDrawerOpen(!isPropertiesDrawerOpen)}
                  className={`h-7 px-2 rounded-lg border flex items-center gap-1 text-[11px] font-bold active:scale-95 transition-all shrink-0 cursor-pointer ${
                    isPropertiesDrawerOpen
                      ? 'bg-purple-600 text-white border-purple-400'
                      : 'bg-slate-900 hover:bg-slate-800 text-purple-300 border-slate-800'
                  }`}
                  title="Fine Controls & Properties"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5 text-purple-300" />
                  <span>Properties</span>
                </button>
              </div>

              {/* PAGE MANAGEMENT CONTROLS */}
              <div className="flex items-center gap-1 shrink-0 pr-1.5 border-r border-slate-800">
                <button
                  type="button"
                  onClick={() => handleSelectPage(safePageIndex - 1)}
                  disabled={safePageIndex === 0}
                  className="w-7 h-7 rounded-lg bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Previous Page"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>

                {/* Page number pill */}
                <div className="px-2 h-7 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-bold text-cyan-300 flex items-center gap-1 shrink-0">
                  <span>Pahina {safePageIndex + 1}/{documentPages.length}</span>
                </div>

                <button
                  type="button"
                  onClick={() => handleSelectPage(safePageIndex + 1)}
                  disabled={safePageIndex >= documentPages.length - 1}
                  className="w-7 h-7 rounded-lg bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Next Page"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={handleAddPage}
                  className="w-7 h-7 rounded-lg bg-teal-600 hover:bg-teal-500 text-white flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Add New Page"
                >
                  <FilePlus className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsSeeAllModalOpen(true);
                    playTickSound();
                  }}
                  className="w-7 h-7 rounded-lg bg-sky-600 hover:bg-sky-500 text-white flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="See All Grid Preview"
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* VIEW TOGGLES */}
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowRulers(!showRulers)}
                  className={`w-7 h-7 rounded-lg border flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer ${
                    showRulers
                      ? 'bg-cyan-950 border-cyan-500/50 text-cyan-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                  title="Rulers Toggle"
                >
                  <Ruler className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (isDpadHidden) {
                      setIsDpadHidden(false);
                      setIsDpadMinimized(false);
                    } else {
                      setIsDpadHidden(true);
                    }
                    playTickSound();
                  }}
                  className={`w-7 h-7 rounded-lg border flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer ${
                    !isDpadHidden
                      ? 'bg-cyan-950 border-cyan-500/50 text-cyan-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                  title="Move Controller Pad (D-Pad) Toggle"
                >
                  <Move className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => setIsFullscreen(!isFullscreen)}
                  className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Toggle Fullscreen"
                >
                  {isFullscreen ? <Minimize className="w-3.5 h-3.5" /> : <Maximize className="w-3.5 h-3.5" />}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsPreviewModalOpen(true);
                    playTickSound();
                  }}
                  className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-slate-800 border border-cyan-500/40 text-cyan-300 flex items-center justify-center active:scale-95 transition-all shrink-0 cursor-pointer"
                  title="Preview & Overview"
                >
                  <Eye className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
      </div>

      {/* BOTTOM FLOATING MULTI-PAGE DOCK (Uniform Buttons with Icons) */}
      <div className="no-print fixed bottom-3 left-1/2 -translate-x-1/2 z-30 flex items-center gap-1.5 p-1.5 bg-slate-950/90 backdrop-blur-md border border-cyan-500/30 rounded-2xl shadow-2xl max-w-[92vw] overflow-x-auto scrollbar-none">
        {/* Prev Page Button */}
        <button
          type="button"
          onClick={() => handleSelectPage(safePageIndex - 1)}
          disabled={safePageIndex === 0}
          className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center active:scale-95 transition-all shrink-0"
          title="Naunang Pahina (Previous Page)"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        {/* Page Selector Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto max-w-[260px] sm:max-w-[420px] scrollbar-none px-1">
          {documentPages.map((pg, idx) => {
            const isCurrent = idx === safePageIndex;
            const elCount = pg.elements ? pg.elements.length : 0;
            return (
              <button
                key={pg.id || idx}
                type="button"
                onClick={() => handleSelectPage(idx)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 border transition-all active:scale-95 shrink-0 ${
                  isCurrent
                    ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md shadow-cyan-500/20 ring-1 ring-cyan-400'
                    : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
                }`}
                title={`Pumunta sa Pahina ${idx + 1}`}
              >
                <span>Pahina {idx + 1}</span>
                {elCount > 0 && (
                  <span
                    className={`text-[9px] px-1 rounded-full font-mono font-normal ${
                      isCurrent ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {elCount}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Next Page Button */}
        <button
          type="button"
          onClick={() => handleSelectPage(safePageIndex + 1)}
          disabled={safePageIndex >= documentPages.length - 1}
          className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center active:scale-95 transition-all shrink-0"
          title="Susunod na Pahina (Next Page)"
        >
          <ChevronRight className="w-4 h-4" />
        </button>

        <div className="h-5 w-[1px] bg-slate-800 mx-1 shrink-0" />

        {/* Add Page Button */}
        <button
          type="button"
          onClick={handleAddPage}
          className="w-9 h-9 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow transition-all active:scale-95 shrink-0"
          title="Mag-add ng Pahina"
        >
          <FilePlus className="w-4 h-4" />
        </button>

        {/* Duplicate Page Button */}
        <button
          type="button"
          onClick={() => handleDuplicatePage(safePageIndex)}
          className="w-9 h-9 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-cyan-400 hover:text-cyan-300 flex items-center justify-center active:scale-95 transition-all shrink-0"
          title={`I-duplicate ang Pahina ${safePageIndex + 1}`}
        >
          <Files className="w-4 h-4" />
        </button>

        {/* Delete Page Button */}
        <button
          type="button"
          onClick={() => handleDeletePage(safePageIndex)}
          className="w-9 h-9 rounded-xl bg-slate-900 hover:bg-rose-950/50 border border-slate-800 text-rose-400 hover:text-rose-300 flex items-center justify-center active:scale-95 transition-all shrink-0"
          title={`Burahin ang Pahina ${safePageIndex + 1}`}
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* PAPER SIZE & ORIENTATION SELECTION POPUP MODAL */}
      {isPaperSelectorOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-cyan-500/40 rounded-2xl p-5 max-w-lg w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-cyan-300 flex items-center gap-2">
                <FileText className="w-5 h-5 text-cyan-400" />
                <span>Pumili ng Sukat ng Bond Paper (Paper Size)</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsPaperSelectorOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            {/* Orientation Options */}
            <div className="flex items-center gap-2">
              <label className="text-xs text-slate-400 font-bold">Orientation:</label>
              <button
                type="button"
                onClick={() =>
                  setCurrentProject({
                    ...currentProject,
                    orientation: 'portrait',
                  })
                }
                className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${
                  currentProject.orientation === 'portrait'
                    ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md'
                    : 'bg-slate-800 text-slate-300 border-slate-700'
                }`}
              >
                📄 Portrait (Patayo)
              </button>
              <button
                type="button"
                onClick={() =>
                  setCurrentProject({
                    ...currentProject,
                    orientation: 'landscape',
                  })
                }
                className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${
                  currentProject.orientation === 'landscape'
                    ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md'
                    : 'bg-slate-800 text-slate-300 border-slate-700'
                }`}
              >
                📑 Landscape (Pahiga)
              </button>
            </div>

            {/* Preset Paper Choices Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {[
                { id: 'short', name: 'Short Bond Paper', desc: '8.5" × 11" (Letter)' },
                { id: 'long', name: 'Long Bond Paper', desc: '8.5" × 13" (Folio)' },
                { id: 'a4', name: 'A4 Standard Paper', desc: '210 × 297 mm' },
                { id: 'legal', name: 'US Legal Size', desc: '8.5" × 14"' },
                { id: 'a3', name: 'A3 Poster Size', desc: '297 × 420 mm' },
                { id: 'a5', name: 'A5 Booklet', desc: '148 × 210 mm' },
                { id: '4r', name: '4R Photo Paper', desc: '4" × 6"' },
                { id: '3r', name: '3R Photo Paper', desc: '3.5" × 5"' },
                { id: '5r', name: '5R Photo Paper', desc: '5" × 7"' },
              ].map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    setCurrentProject({
                      ...currentProject,
                      paperPreset: p.id as BondPaperPreset,
                    });
                    setIsPaperSelectorOpen(false);
                    playTickSound();
                  }}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    currentProject.paperPreset === p.id
                      ? 'bg-cyan-950/80 border-cyan-400 text-cyan-200 ring-1 ring-cyan-400'
                      : 'bg-slate-800/80 hover:bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
                  }`}
                >
                  <p className="font-bold text-xs">{p.name}</p>
                  <p className="text-[10px] text-slate-400">{p.desc}</p>
                </button>
              ))}
            </div>

            {/* Custom Size button */}
            <button
              type="button"
              onClick={() => {
                setIsPaperSelectorOpen(false);
                setIsCustomPaperModalOpen(true);
              }}
              className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 font-bold text-xs transition-all text-center"
            >
              ⚙️ Custom Dimensions (I-type ang Sukat sa mm / in)
            </button>
          </div>
        </div>
      )}

      {/* WORKSPACE AREA: Sidebar Property Inspector + Centered Canvas */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
        {/* FLOATING PROPERTY INSPECTOR MODAL/DRAWER (Appears when toggled or selected without shrinking canvas) */}
        {isPropertiesDrawerOpen && selectedElement && (
          <aside className="no-print fixed top-16 right-16 z-40 w-80 max-h-[82vh] bg-slate-950/95 border border-cyan-500/40 rounded-2xl p-4 overflow-y-auto shadow-[0_20px_50px_rgba(0,0,0,0.9)] backdrop-blur-md text-xs">
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
              <span className="font-bold text-cyan-300 flex items-center gap-1.5">
                {selectedElement.type === 'image' ? <ImageIcon className="w-4 h-4" /> : <Type className="w-4 h-4" />}
                {selectedElement.type === 'image' ? 'Picture Controls' : 'Text Typography Controls'}
              </span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={handleDuplicate}
                  className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                  title="Duplicate"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={handleDelete}
                  className="p-1 rounded bg-red-500/20 hover:bg-red-500/40 text-red-300"
                  title="Delete"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setIsPropertiesDrawerOpen(false)}
                  className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 ml-1"
                  title="Close Controls"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* IMAGE CONTROLS */}
            {selectedElement.type === 'image' && (
              <div className="space-y-3">
                {/* PHOTO PRESET SIZES BUTTONS */}
                <div>
                  <label className="block text-slate-400 font-bold mb-1.5 text-[11px] uppercase tracking-wider">
                    ⚡ Quick Photo Size Presets (1-Tap):
                  </label>
                  <div className="grid grid-cols-3 gap-1.5">
                    <button
                      onClick={() => applyPhotoPresetSize('1x1')}
                      className="px-2 py-1.5 rounded-lg bg-slate-900 hover:bg-indigo-600/30 border border-slate-700 text-left"
                    >
                      <p className="font-bold text-white">1x1 in</p>
                      <p className="text-[9px] text-slate-400">ID Picture</p>
                    </button>
                    <button
                      onClick={() => applyPhotoPresetSize('2x2')}
                      className="px-2 py-1.5 rounded-lg bg-slate-900 hover:bg-indigo-600/30 border border-slate-700 text-left"
                    >
                      <p className="font-bold text-white">2x2 in</p>
                      <p className="text-[9px] text-slate-400">Passport/Visa</p>
                    </button>
                    <button
                      onClick={() => applyPhotoPresetSize('passport')}
                      className="px-2 py-1.5 rounded-lg bg-slate-900 hover:bg-indigo-600/30 border border-slate-700 text-left"
                    >
                      <p className="font-bold text-white">Passport</p>
                      <p className="text-[9px] text-slate-400">35×45 mm</p>
                    </button>
                    <button
                      onClick={() => applyPhotoPresetSize('2r')}
                      className="px-2 py-1.5 rounded-lg bg-slate-900 hover:bg-indigo-600/30 border border-slate-700 text-left"
                    >
                      <p className="font-bold text-white">2R Wallet</p>
                      <p className="text-[9px] text-slate-400">2.5×3.5 in</p>
                    </button>
                    <button
                      onClick={() => applyPhotoPresetSize('3r')}
                      className="px-2 py-1.5 rounded-lg bg-slate-900 hover:bg-indigo-600/30 border border-slate-700 text-left"
                    >
                      <p className="font-bold text-white">3R Photo</p>
                      <p className="text-[9px] text-slate-400">3.5×5 in</p>
                    </button>
                    <button
                      onClick={() => applyPhotoPresetSize('4r')}
                      className="px-2 py-1.5 rounded-lg bg-slate-900 hover:bg-indigo-600/30 border border-slate-700 text-left"
                    >
                      <p className="font-bold text-white">4R Photo</p>
                      <p className="text-[9px] text-slate-400">4×6 in</p>
                    </button>
                    <button
                      onClick={() => applyPhotoPresetSize('5r')}
                      className="px-2 py-1.5 rounded-lg bg-slate-900 hover:bg-indigo-600/30 border border-slate-700 text-left"
                    >
                      <p className="font-bold text-white">5R Photo</p>
                      <p className="text-[9px] text-slate-400">5×7 in</p>
                    </button>
                    <button
                      onClick={() => applyPhotoPresetSize('half_page')}
                      className="px-2 py-1.5 rounded-lg bg-slate-900 hover:bg-indigo-600/30 border border-slate-700 text-left transition-all"
                    >
                      <p className="font-bold text-white">Half Page</p>
                      <p className="text-[9px] text-slate-400">Kasya sa kalahati</p>
                    </button>
                    <button
                      onClick={() => applyPhotoPresetSize('full_page')}
                      className="px-2 py-1.5 rounded-lg bg-gradient-to-br from-indigo-950/80 to-cyan-950/80 hover:from-indigo-900/90 hover:to-cyan-900/90 border border-cyan-500/50 text-left transition-all shadow-sm group"
                      title="100% Full Fit sa bondpaper nang walang putol o bawas"
                    >
                      <p className="font-bold text-cyan-300 flex items-center gap-1">
                        <Maximize2 className="w-3 h-3 text-cyan-400" />
                        <span>Full Page</span>
                      </p>
                      <p className="text-[9px] text-cyan-400/80 font-medium">Full Fit (Walang Putol)</p>
                    </button>
                  </div>
                </div>

                {/* TWO-FINGER MULTI-TOUCH RESIZE & 3-SECOND HOLD GUIDE */}
                <div className="p-2.5 rounded-xl bg-gradient-to-r from-cyan-950/70 to-slate-900 border border-cyan-500/40 text-cyan-200 text-[11px] leading-relaxed space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="font-bold flex items-center gap-1.5 text-white">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                      3-Second Hold to Move:
                    </p>
                    <button
                      onClick={() => toggleFreeMoveElement(selectedElement.id)}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-all ${
                        unlockedMoveElementIds[selectedElement.id]
                          ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-sm'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
                      }`}
                    >
                      {unlockedMoveElementIds[selectedElement.id] ? '🔓 Free Move ON' : '🔒 Hold 3s / Click to Unlock'}
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-300">
                    💡 <strong>Tip:</strong> Pindutin at i-hold ang litrato sa canvas ng <strong>3 seconds</strong> (o pindutin ang button sa taas) para mai-move mo ito nang malaya kahit saan sa bondpaper!
                  </p>
                  <p className="text-[10px] text-slate-300">
                    👆 <strong>Two-Finger Resize:</strong> Gamitin ang 2 daliri sa left/right handles para i-pinch resize ang laki ng litrato.
                  </p>
                </div>

                {/* Precise Size Sliders */}
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-slate-400 text-[10px]">Lapad (Width mm):</label>
                    <input
                      type="number"
                      value={Math.round(selectedElement.width)}
                      onChange={(e) =>
                        updateElement(selectedElement.id, { width: Math.max(10, Number(e.target.value)) })
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 text-[10px]">Taas (Height mm):</label>
                    <input
                      type="number"
                      value={Math.round(selectedElement.height)}
                      onChange={(e) =>
                        updateElement(selectedElement.id, { height: Math.max(10, Number(e.target.value)) })
                      }
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white font-mono"
                    />
                  </div>
                </div>

                {/* Filters */}
                <div>
                  <label className="text-slate-400 text-[10px] block mb-1">Kulay / Effect Filter:</label>
                  <select
                    value={selectedElement.filter || 'none'}
                    onChange={(e) => updateElement(selectedElement.id, { filter: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white"
                  >
                    <option value="none">Original Colors</option>
                    <option value="grayscale(100%)">Black & White (Grayscale)</option>
                    <option value="contrast(140%) brightness(1.1)">High Contrast Document</option>
                    <option value="sepia(70%)">Sepia Vintage</option>
                    <option value="brightness(1.2)">Brighter Photo</option>
                  </select>
                </div>

                {/* ✂️ CROP & 🔄 ROTATE ACTIONS BAR */}
                <div className="pt-2 border-t border-slate-800 space-y-2">
                  <label className="block text-cyan-300 font-bold text-[11px] uppercase tracking-wider">
                    ✂️ Crop & 🔄 Rotate Picture:
                  </label>

                  {/* Big Interactive Crop Button */}
                  <button
                    onClick={() => handleOpenCropModal(selectedElement.id)}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95 transition-all text-xs cursor-pointer"
                    title="I-crop ang sukat ng litrato gamit ang Crop Tool"
                  >
                    <Scissors className="w-4 h-4" />
                    <span>I-CROP ANG LITRATO (Crop Tool)</span>
                  </button>

                  {/* Rotate Buttons Group */}
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-300 font-semibold text-[11px] flex items-center gap-1">
                        <RotateCw className="w-3.5 h-3.5 text-cyan-400" />
                        <span>I-Rotate ang Litrato:</span>
                      </span>
                      <span className="font-mono text-cyan-400 text-[10px] font-bold">
                        {selectedElement.rotation || 0}°
                      </span>
                    </div>

                    <div className="grid grid-cols-4 gap-1.5">
                      <button
                        onClick={() => handleRotateElement(-90)}
                        className="py-1.5 px-1 rounded-lg bg-slate-800 hover:bg-slate-700 active:bg-cyan-500 active:text-slate-950 text-slate-200 border border-slate-700 flex flex-col items-center justify-center text-[10px] font-bold transition-all"
                        title="Rotate -90° (Kaliwa)"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-cyan-400 mb-0.5" />
                        <span>-90°</span>
                      </button>
                      <button
                        onClick={() => handleRotateElement(90)}
                        className="py-1.5 px-1 rounded-lg bg-slate-800 hover:bg-slate-700 active:bg-cyan-500 active:text-slate-950 text-slate-200 border border-slate-700 flex flex-col items-center justify-center text-[10px] font-bold transition-all"
                        title="Rotate +90° (Kanan)"
                      >
                        <RotateCw className="w-3.5 h-3.5 text-cyan-400 mb-0.5" />
                        <span>+90°</span>
                      </button>
                      <button
                        onClick={() => handleRotateElement(180)}
                        className="py-1.5 px-1 rounded-lg bg-slate-800 hover:bg-slate-700 active:bg-cyan-500 active:text-slate-950 text-slate-200 border border-slate-700 flex flex-col items-center justify-center text-[10px] font-bold transition-all"
                        title="Baliktarin (180°)"
                      >
                        <RotateCw className="w-3.5 h-3.5 text-cyan-400 mb-0.5" />
                        <span>180°</span>
                      </button>
                      <button
                        onClick={() => handleSetRotationAngle(0)}
                        className="py-1.5 px-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 flex flex-col items-center justify-center text-[10px] font-bold transition-all"
                        title="I-reset ang angulo sa 0°"
                      >
                        <span>0°</span>
                        <span className="text-[8px] text-slate-500">Reset</span>
                      </button>
                    </div>

                    {/* Fine Rotation Slider */}
                    <div>
                      <div className="flex justify-between text-[9px] text-slate-400 mb-0.5">
                        <span>Pino na Angulo (Slider):</span>
                        <span className="font-mono text-cyan-300 font-bold">{selectedElement.rotation || 0}°</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="360"
                        step="1"
                        value={selectedElement.rotation || 0}
                        onChange={(e) => handleSetRotationAngle(Number(e.target.value))}
                        className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                      />
                    </div>
                  </div>
                </div>

                {/* Border & Rounded Corners */}
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-slate-400 text-[10px]">Border Width:</label>
                    <input
                      type="range"
                      min="0"
                      max="10"
                      value={selectedElement.borderWidth || 0}
                      onChange={(e) =>
                        updateElement(selectedElement.id, { borderWidth: Number(e.target.value) })
                      }
                      className="w-full"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 text-[10px]">Corner Radius:</label>
                    <input
                      type="range"
                      min="0"
                      max="40"
                      value={selectedElement.borderRadius || 0}
                      onChange={(e) =>
                        updateElement(selectedElement.id, { borderRadius: Number(e.target.value) })
                      }
                      className="w-full"
                    />
                  </div>
                </div>

                {/* AUTOMATIC DIRECTIONAL MOVEMENT D-PAD & ALIGNMENT */}
                <div className="pt-2 border-t border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-cyan-300 font-bold text-[11px] flex items-center gap-1.5 uppercase tracking-wider">
                      <Move className="w-3.5 h-3.5 text-cyan-400" />
                      Move Picture (Top, Down, Left, Right):
                    </label>
                    <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-500/30">
                      Step: {moveStepMm}mm
                    </span>
                  </div>

                  {/* Step Selector Buttons */}
                  <div className="flex items-center gap-1">
                    <span className="text-[9px] text-slate-400">Bilis/Laki:</span>
                    {[1, 5, 10, 20].map((s) => (
                      <button
                        key={s}
                        onClick={() => setMoveStepMm(s)}
                        className={`flex-1 py-1 rounded text-[10px] font-mono font-bold border transition-all ${
                          moveStepMm === s
                            ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-sm'
                            : 'bg-slate-900 text-slate-300 border-slate-700 hover:text-white'
                        }`}
                      >
                        {s}mm
                      </button>
                    ))}
                  </div>

                  {/* D-PAD / DIRECTIONAL CROSS CONTROLS */}
                  <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-2.5 flex flex-col items-center">
                    {/* TOP / UP BUTTON */}
                    <button
                      onClick={() => handleMoveElement('up')}
                      onMouseDown={() => startContinuousMove('up')}
                      onMouseUp={stopContinuousMove}
                      onMouseLeave={stopContinuousMove}
                      onTouchStart={() => startContinuousMove('up')}
                      onTouchEnd={stopContinuousMove}
                      className="w-24 py-2 rounded-xl bg-gradient-to-b from-slate-700 to-slate-800 hover:from-cyan-600 hover:to-cyan-700 active:from-cyan-500 active:to-cyan-600 text-white font-bold flex flex-col items-center justify-center shadow border border-slate-600/80 transition-all select-none"
                      title="Move Up (Taas) - Pindutin o i-hold"
                    >
                      <ChevronUp className="w-5 h-5 text-cyan-300" />
                      <span className="text-[9px] tracking-wide text-cyan-100">▲ TAAS (Top)</span>
                    </button>

                    {/* MIDDLE ROW: LEFT, CENTER, RIGHT */}
                    <div className="flex items-center gap-2 my-1.5 w-full justify-center">
                      {/* LEFT BUTTON */}
                      <button
                        onClick={() => handleMoveElement('left')}
                        onMouseDown={() => startContinuousMove('left')}
                        onMouseUp={stopContinuousMove}
                        onMouseLeave={stopContinuousMove}
                        onTouchStart={() => startContinuousMove('left')}
                        onTouchEnd={stopContinuousMove}
                        className="flex-1 max-w-[90px] py-2 rounded-xl bg-gradient-to-r from-slate-700 to-slate-800 hover:from-cyan-600 hover:to-cyan-700 active:from-cyan-500 active:to-cyan-600 text-white font-bold flex flex-col items-center justify-center shadow border border-slate-600/80 transition-all select-none"
                        title="Move Left (Kaliwa) - Pindutin o i-hold"
                      >
                        <ChevronLeft className="w-5 h-5 text-cyan-300" />
                        <span className="text-[9px] tracking-wide text-cyan-100">◀ KALIWA</span>
                      </button>

                      {/* CENTER BUTTON */}
                      <button
                        onClick={() => handleAlignElement('center')}
                        className="w-12 h-12 rounded-xl bg-slate-950 hover:bg-slate-800 border-2 border-cyan-500/40 text-cyan-300 flex flex-col items-center justify-center shadow-inner text-[8px] font-bold select-none"
                        title="Center on Bondpaper"
                      >
                        <Crosshair className="w-4 h-4 text-cyan-400 mb-0.5" />
                        <span>GITNA</span>
                      </button>

                      {/* RIGHT BUTTON */}
                      <button
                        onClick={() => handleMoveElement('right')}
                        onMouseDown={() => startContinuousMove('right')}
                        onMouseUp={stopContinuousMove}
                        onMouseLeave={stopContinuousMove}
                        onTouchStart={() => startContinuousMove('right')}
                        onTouchEnd={stopContinuousMove}
                        className="flex-1 max-w-[90px] py-2 rounded-xl bg-gradient-to-l from-slate-700 to-slate-800 hover:from-cyan-600 hover:to-cyan-700 active:from-cyan-500 active:to-cyan-600 text-white font-bold flex flex-col items-center justify-center shadow border border-slate-600/80 transition-all select-none"
                        title="Move Right (Kanan) - Pindutin o i-hold"
                      >
                        <ChevronRight className="w-5 h-5 text-cyan-300" />
                        <span className="text-[9px] tracking-wide text-cyan-100">KANAN ▶</span>
                      </button>
                    </div>

                    {/* DOWN / BOTTOM BUTTON */}
                    <button
                      onClick={() => handleMoveElement('down')}
                      onMouseDown={() => startContinuousMove('down')}
                      onMouseUp={stopContinuousMove}
                      onMouseLeave={stopContinuousMove}
                      onTouchStart={() => startContinuousMove('down')}
                      onTouchEnd={stopContinuousMove}
                      className="w-24 py-2 rounded-xl bg-gradient-to-t from-slate-700 to-slate-800 hover:from-cyan-600 hover:to-cyan-700 active:from-cyan-500 active:to-cyan-600 text-white font-bold flex flex-col items-center justify-center shadow border border-slate-600/80 transition-all select-none"
                      title="Move Down (Baba) - Pindutin o i-hold"
                    >
                      <span className="text-[9px] tracking-wide text-cyan-100">▼ BABA (Down)</span>
                      <ChevronDown className="w-5 h-5 text-cyan-300" />
                    </button>
                  </div>

                  {/* 1-Tap Quick Alignment Shortcuts */}
                  <div>
                    <label className="text-[9px] text-slate-400 block mb-1">⚡ Quick Snap Alignment:</label>
                    <div className="grid grid-cols-3 gap-1">
                      <button
                        onClick={() => handleAlignElement('left')}
                        className="px-1.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[10px]"
                      >
                        Align Kaliwa
                      </button>
                      <button
                        onClick={() => handleAlignElement('center-h')}
                        className="px-1.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[10px]"
                      >
                        Center Horizontal
                      </button>
                      <button
                        onClick={() => handleAlignElement('right')}
                        className="px-1.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[10px]"
                      >
                        Align Kanan
                      </button>
                      <button
                        onClick={() => handleAlignElement('top')}
                        className="px-1.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[10px]"
                      >
                        Align Taas
                      </button>
                      <button
                        onClick={() => handleAlignElement('center-v')}
                        className="px-1.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[10px]"
                      >
                        Center Vertical
                      </button>
                      <button
                        onClick={() => handleAlignElement('bottom')}
                        className="px-1.5 py-1 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[10px]"
                      >
                        Align Baba
                      </button>
                    </div>
                  </div>

                  {/* Position Coordinates with +/- nudge */}
                  <div className="grid grid-cols-2 gap-2 bg-slate-950 p-2 rounded-lg border border-slate-800">
                    <div>
                      <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                        <span>X (Pahalang mm):</span>
                        <span className="font-mono text-cyan-400 font-bold">{Math.round(selectedElement.x)}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleMoveElement('left', 1)}
                          className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-white font-bold text-xs"
                          title="-1mm"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          value={Math.round(selectedElement.x)}
                          onChange={(e) =>
                            updateElement(selectedElement.id, { x: Number(e.target.value) })
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded px-1 py-0.5 text-white font-mono text-center text-xs"
                        />
                        <button
                          onClick={() => handleMoveElement('right', 1)}
                          className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-white font-bold text-xs"
                          title="+1mm"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                        <span>Y (Pataas mm):</span>
                        <span className="font-mono text-cyan-400 font-bold">{Math.round(selectedElement.y)}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleMoveElement('up', 1)}
                          className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-white font-bold text-xs"
                          title="-1mm"
                        >
                          -
                        </button>
                        <input
                          type="number"
                          value={Math.round(selectedElement.y)}
                          onChange={(e) =>
                            updateElement(selectedElement.id, { y: Number(e.target.value) })
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded px-1 py-0.5 text-white font-mono text-center text-xs"
                        />
                        <button
                          onClick={() => handleMoveElement('down', 1)}
                          className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-white font-bold text-xs"
                          title="+1mm"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TEXT TYPOGRAPHY CONTROLS */}
            {selectedElement.type === 'text' && (
              <div className="space-y-3">
                <div>
                  <label className="text-slate-400 text-[10px] block mb-1">Teksto Content:</label>
                  <textarea
                    rows={2}
                    value={selectedElement.text || ''}
                    onChange={(e) => updateElement(selectedElement.id, { text: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white text-xs focus:ring-1 focus:ring-cyan-400 focus:outline-none"
                  />
                </div>

                {/* ALL FONT STYLES SELECTOR (Huge library) */}
                <div>
                  <label className="text-slate-400 text-[10px] block mb-1 font-bold text-cyan-300">
                    🔤 Lahat ng Font Styles ({FONT_COLLECTIONS.length} Designs):
                  </label>
                  <select
                    value={selectedElement.fontFamily || "'Inter', sans-serif"}
                    onChange={(e) => updateElement(selectedElement.id, { fontFamily: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-white font-medium focus:ring-1 focus:ring-cyan-400"
                  >
                    {FONT_COLLECTIONS.map((f) => (
                      <option key={f.name} value={f.font} style={{ fontFamily: f.font }}>
                        {f.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* FONT SIZE SLIDER & NUMBER INPUT */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-slate-400 text-[10px]">Font Size (px):</label>
                    <span className="text-cyan-400 font-mono font-bold text-xs">
                      {selectedElement.fontSize || 20} px
                    </span>
                  </div>
                  <input
                    type="range"
                    min="8"
                    max="96"
                    value={selectedElement.fontSize || 20}
                    onChange={(e) =>
                      updateElement(selectedElement.id, { fontSize: Number(e.target.value) })
                    }
                    className="w-full"
                  />
                </div>

                {/* TEXT STYLING BUTTONS */}
                <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
                  <button
                    onClick={() => updateElement(selectedElement.id, { bold: !selectedElement.bold })}
                    className={`p-1.5 rounded ${
                      selectedElement.bold ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300'
                    }`}
                    title="Bold"
                  >
                    <Bold className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => updateElement(selectedElement.id, { italic: !selectedElement.italic })}
                    className={`p-1.5 rounded ${
                      selectedElement.italic ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300'
                    }`}
                    title="Italic"
                  >
                    <Italic className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() =>
                      updateElement(selectedElement.id, { underline: !selectedElement.underline })
                    }
                    className={`p-1.5 rounded ${
                      selectedElement.underline ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300'
                    }`}
                    title="Underline"
                  >
                    <Underline className="w-3.5 h-3.5" />
                  </button>
                  <div className="h-4 w-[1px] bg-slate-700 mx-1" />
                  <button
                    onClick={() => updateElement(selectedElement.id, { align: 'left' })}
                    className={`p-1.5 rounded ${
                      selectedElement.align === 'left' ? 'bg-cyan-500 text-slate-950' : 'text-slate-300'
                    }`}
                  >
                    <AlignLeft className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => updateElement(selectedElement.id, { align: 'center' })}
                    className={`p-1.5 rounded ${
                      selectedElement.align === 'center' ? 'bg-cyan-500 text-slate-950' : 'text-slate-300'
                    }`}
                  >
                    <AlignCenter className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => updateElement(selectedElement.id, { align: 'right' })}
                    className={`p-1.5 rounded ${
                      selectedElement.align === 'right' ? 'bg-cyan-500 text-slate-950' : 'text-slate-300'
                    }`}
                  >
                    <AlignRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* TEXT COLOR & HIGHLIGHT */}
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-slate-400 text-[10px] block mb-1">Kulay ng Font:</label>
                    <div className="flex items-center gap-1">
                      <input
                        type="color"
                        value={selectedElement.color || '#0f172a'}
                        onChange={(e) => updateElement(selectedElement.id, { color: e.target.value })}
                        className="w-7 h-7 rounded border border-slate-700 bg-transparent cursor-pointer"
                      />
                      <span className="font-mono text-[10px] text-slate-300">{selectedElement.color}</span>
                    </div>
                  </div>
                  <div>
                    <label className="text-slate-400 text-[10px] block mb-1">Highlight Bg:</label>
                    <div className="flex items-center gap-1">
                      <input
                        type="color"
                        value={selectedElement.backgroundColor || '#ffffff'}
                        onChange={(e) =>
                          updateElement(selectedElement.id, { backgroundColor: e.target.value })
                        }
                        className="w-7 h-7 rounded border border-slate-700 bg-transparent cursor-pointer"
                      />
                      <button
                        onClick={() => updateElement(selectedElement.id, { backgroundColor: undefined })}
                        className="text-[9px] text-slate-400 underline"
                      >
                        Transparent
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* LAYER CONTROLS */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-slate-400 text-[10px]">Layer Arrange:</span>
              <div className="flex items-center gap-1">
                <button
                  onClick={handleSendToBack}
                  className="px-2 py-1 rounded bg-slate-800 text-[10px] text-slate-300 hover:text-white"
                >
                  Send Back
                </button>
                <button
                  onClick={handleBringToFront}
                  className="px-2 py-1 rounded bg-slate-800 text-[10px] text-slate-300 hover:text-white"
                >
                  Bring Front
                </button>
              </div>
            </div>
          </aside>
        )}

        {/* FULLSCREEN BONDPAPER CANVAS VIEWPORT */}
        <div
          ref={canvasRef}
          onClick={() => setSelectedElementId(null)}
          className="flex-1 overflow-auto pt-16 sm:pt-20 pb-16 px-4 sm:px-10 flex flex-col items-center justify-center bg-slate-900/90 relative min-h-screen"
          style={{
            backgroundImage: `radial-gradient(circle, rgba(255, 255, 255, 0.05) 1px, transparent 1px)`,
            backgroundSize: '20px 20px',
          }}
        >
          {/* RULER + BONDPAPER CONTAINER */}
          <div className="flex flex-col items-center">
            {/* TOP HORIZONTAL RULER (Millimeters) */}
            <div
              className="no-print h-5 bg-slate-950/80 border-b border-slate-800 flex items-end justify-between px-1 text-[8px] font-mono text-slate-400 select-none mb-1 rounded-t"
              style={{ width: `${canvasPixelWidth}px` }}
            >
              <span>0mm</span>
              <span>{Math.round(activeWidthMm * 0.25)}mm</span>
              <span className="text-cyan-400 font-bold">{Math.round(activeWidthMm * 0.5)}mm</span>
              <span>{Math.round(activeWidthMm * 0.75)}mm</span>
              <span>{Math.round(activeWidthMm)}mm</span>
            </div>

            <div className="flex items-start">
              {/* LEFT VERTICAL RULER (Millimeters) */}
              <div
                className="no-print w-5 bg-slate-950/80 border-r border-slate-800 flex flex-col justify-between py-1 text-[8px] font-mono text-slate-400 select-none mr-1 rounded-l items-center"
                style={{ height: `${canvasPixelHeight}px` }}
              >
                <span>0</span>
                <span>{Math.round(activeHeightMm * 0.25)}</span>
                <span className="text-cyan-400 font-bold">{Math.round(activeHeightMm * 0.5)}</span>
                <span>{Math.round(activeHeightMm * 0.75)}</span>
                <span>{Math.round(activeHeightMm)}</span>
              </div>

              {/* THE BONDPAPER SHEET (Prints precisely as styled - Pure White Blank Canvas) */}
              <div
                id="printable-bondpaper-sheet"
                onDoubleClick={handleBondpaperDoubleClick}
                className="bg-white text-slate-900 shadow-[0_10px_40px_rgba(0,0,0,0.5)] transition-all relative overflow-hidden flex-shrink-0 cursor-text"
                style={{
                  width: `${canvasPixelWidth}px`,
                  height: `${canvasPixelHeight}px`,
                  minWidth: `${canvasPixelWidth}px`,
                  minHeight: `${canvasPixelHeight}px`,
                }}
              >
                {/* Render Elements on Current Page of Bondpaper */}
                {activeElements.map((el) => {
                  const isSelected = el.id === selectedElementId;
                  const isHoldingThis = holdingElementId === el.id && holdProgress > 0;
                  const isUnlockedMove = !!unlockedMoveElementIds[el.id];
                  const isEditingThisText = el.type === 'text' && editingTextId === el.id;
                  const elPixelX = el.x * scaleMmToPx;
                  const elPixelY = el.y * scaleMmToPx;
                  const elPixelW = el.width * scaleMmToPx;
                  const elPixelH = el.height * scaleMmToPx;

                  return (
                    <div
                      key={el.id}
                      id={`canvas-el-${el.id}`}
                      onMouseDown={(e) => {
                        if (!isEditingThisText) handleMouseDown(e, el.id);
                      }}
                      onTouchStart={(e) => {
                        if (!isEditingThisText) handleTouchStart(e, el.id);
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedElementId(el.id);
                      }}
                      onDoubleClick={(e) => {
                        e.stopPropagation();
                        if (el.type === 'text') {
                          setSelectedElementId(el.id);
                          setEditingTextId(el.id);
                          setTimeout(() => {
                            if (inlineInputRef.current) {
                              inlineInputRef.current.focus();
                              inlineInputRef.current.select();
                            }
                          }, 50);
                        } else if (el.type === 'image') {
                          handleOpenCropModal(el.id);
                        }
                      }}
                      className={`absolute transition-shadow select-none ${
                        el.type === 'text'
                          ? isEditingThisText
                            ? 'cursor-text z-50 bg-transparent border-0 outline-none p-0 ring-0 shadow-none'
                            : 'cursor-pointer border-0 outline-none p-0 ring-0 shadow-none'
                          : isEditingThisText
                          ? 'cursor-text ring-2 ring-cyan-500 bg-white/95 z-50'
                          : 'cursor-move'
                      } ${
                        isSelected && !isEditingThisText && el.type !== 'text'
                          ? isUnlockedMove
                            ? 'ring-2 ring-emerald-400 ring-offset-2 shadow-2xl'
                            : 'ring-2 ring-cyan-500 ring-offset-1 shadow-lg'
                          : ''
                      }`}
                      style={{
                        left: `${elPixelX}px`,
                        top: `${elPixelY}px`,
                        width: `${elPixelW}px`,
                        height: `${elPixelH}px`,
                        zIndex: isEditingThisText ? 999 : el.zIndex,
                        transform: `rotate(${el.rotation || 0}deg)`,
                        // Print physical dimension custom properties
                        ['--el-x-mm' as any]: `${el.x}mm`,
                        ['--el-y-mm' as any]: `${el.y}mm`,
                        ['--el-w-mm' as any]: `${el.width}mm`,
                        ['--el-h-mm' as any]: `${el.height}mm`,
                        ['--el-font-size-px' as any]: `${el.fontSize || 20}px`,
                      }}
                    >
                      {/* 3-SECOND HOLD COUNTDOWN CIRCLE HUD OVERLAY */}
                      {isHoldingThis && (
                        <div className="no-print absolute inset-0 bg-slate-950/70 backdrop-blur-[2px] z-50 rounded flex flex-col items-center justify-center pointer-events-none animate-pulse">
                          <div className="relative w-14 h-14 flex items-center justify-center">
                            <svg className="w-full h-full transform -rotate-90">
                              <circle
                                cx="28"
                                cy="28"
                                r="22"
                                stroke="rgba(255,255,255,0.2)"
                                strokeWidth="4"
                                fill="transparent"
                              />
                              <circle
                                cx="28"
                                cy="28"
                                r="22"
                                stroke="#10b981"
                                strokeWidth="4"
                                fill="transparent"
                                strokeDasharray={2 * Math.PI * 22}
                                strokeDashoffset={2 * Math.PI * 22 * (1 - holdProgress / 100)}
                                strokeLinecap="round"
                              />
                            </svg>
                            <span className="absolute text-xs font-mono font-bold text-white">
                              {Math.max(1, Math.ceil((3000 - (holdProgress / 100) * 3000) / 1000))}s
                            </span>
                          </div>
                          <span className="text-[10px] font-bold text-emerald-300 mt-1 text-center px-1">
                            Holding 3s to Unlock Move...
                          </span>
                        </div>
                      )}

                      {/* IMAGE ELEMENT */}
                      {el.type === 'image' && el.src && (
                        <div className="w-full h-full relative overflow-hidden flex items-center justify-center group">
                          {/* HOVER / CORNER ENLARGE BUTTONS: Kapag tinuro ang cursor sa kantuhang side ng box, lumalabas ang quick enlarge button */}
                          <div className="no-print absolute inset-0 pointer-events-none z-30">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                updateElement(el.id, {
                                  width: Math.min(activeWidthMm, el.width + 12),
                                  height: Math.min(activeHeightMm, el.height + 12),
                                });
                                playTickSound();
                              }}
                              className="absolute -top-2.5 -left-2.5 w-6 h-6 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs shadow-xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-auto cursor-nwse-resize"
                              title="Palakihin (Enlarge Top-Left)"
                            >
                              +
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                updateElement(el.id, {
                                  width: Math.min(activeWidthMm, el.width + 12),
                                  height: Math.min(activeHeightMm, el.height + 12),
                                });
                                playTickSound();
                              }}
                              className="absolute -top-2.5 -right-2.5 w-6 h-6 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs shadow-xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-auto cursor-nesw-resize"
                              title="Palakihin (Enlarge Top-Right)"
                            >
                              +
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                updateElement(el.id, {
                                  width: Math.min(activeWidthMm, el.width + 12),
                                  height: Math.min(activeHeightMm, el.height + 12),
                                });
                                playTickSound();
                              }}
                              className="absolute -bottom-2.5 -left-2.5 w-6 h-6 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs shadow-xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-auto cursor-nesw-resize"
                              title="Palakihin (Enlarge Bottom-Left)"
                            >
                              +
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                updateElement(el.id, {
                                  width: Math.min(activeWidthMm, el.width + 12),
                                  height: Math.min(activeHeightMm, el.height + 12),
                                });
                                playTickSound();
                              }}
                              className="absolute -bottom-2.5 -right-2.5 w-6 h-6 rounded-full bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs shadow-xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-auto cursor-nwse-resize"
                              title="Palakihin (Enlarge Bottom-Right)"
                            >
                              +
                            </button>
                          </div>

                          <img
                            src={el.src || undefined}
                            alt={el.name || 'Uploaded picture'}
                            className="w-full h-full object-contain pointer-events-none"
                            style={{
                              filter: el.filter || 'none',
                              borderRadius: `${el.borderRadius || 0}px`,
                              border: el.borderWidth ? `${el.borderWidth}px solid ${el.borderColor || '#000'}` : 'none',
                              opacity: el.opacity ?? 1,
                            }}
                          />

                          {/* UNLOCKED MOVE BADGE */}
                          {isUnlockedMove && (
                            <div className="no-print absolute top-1 left-1 bg-emerald-600/90 text-slate-950 font-bold px-1.5 py-0.5 rounded text-[9px] shadow flex items-center gap-1 z-30">
                              <span>🔓 MOVE ANYWHERE</span>
                            </div>
                          )}

                          {/* FLOATING ACTION TOOLBAR OVER SELECTED IMAGE */}
                          {isSelected && (
                            <div
                              onClick={(e) => e.stopPropagation()}
                              className="no-print absolute -top-10 left-1/2 -translate-x-1/2 bg-slate-950/95 border border-cyan-500/60 rounded-full px-2 py-1 flex items-center gap-1.5 shadow-2xl z-40"
                            >
                              <button
                                onClick={() => applyPhotoPresetSize('full_page', el.id)}
                                className="px-2.5 py-0.5 rounded-full bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-400 hover:to-cyan-400 text-slate-950 font-extrabold text-[10px] flex items-center gap-1 shadow transition-all active:scale-95"
                                title="Full Page Fit: 100% Buong Litrato nang Walang Putol"
                              >
                                <Maximize2 className="w-3 h-3" />
                                <span>Full Page</span>
                              </button>
                              <button
                                onClick={() => handleOpenCropModal(el.id)}
                                className="px-2 py-0.5 rounded-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-[10px] flex items-center gap-1 shadow transition-all active:scale-95"
                                title="I-crop ang litrato"
                              >
                                <Scissors className="w-3 h-3" />
                                <span>Crop</span>
                              </button>
                              <button
                                onClick={() => handleRotateElement(-90)}
                                className="p-1 rounded-full bg-slate-800 hover:bg-slate-700 text-cyan-300 transition-colors"
                                title="Rotate -90°"
                              >
                                <RotateCcw className="w-3 h-3" />
                              </button>
                              <button
                                onClick={() => handleRotateElement(90)}
                                className="p-1 rounded-full bg-slate-800 hover:bg-slate-700 text-cyan-300 transition-colors"
                                title="Rotate +90°"
                              >
                                <RotateCw className="w-3 h-3" />
                              </button>
                              <div className="w-[1px] h-3 bg-slate-700 mx-0.5" />
                              <button
                                onClick={handleDelete}
                                className="p-1 rounded-full bg-red-500/20 hover:bg-red-500/40 text-red-300"
                                title="Burahin"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          )}

                          {/* MULTI-TOUCH / TWO-FINGER RESIZE HANDLES ON SIDES FOR IMAGES ONLY */}
                          {isSelected && el.type === 'image' && (
                            <>
                              {/* Left Handle */}
                              <div
                                className="no-print absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 w-5 h-7 rounded-full bg-cyan-500 border-2 border-white shadow-md flex items-center justify-center cursor-ew-resize z-30 touch-none"
                                title="Two-finger pinch left handle"
                              >
                                <div className="w-1 h-3 bg-white rounded-full" />
                              </div>

                              {/* Right Handle */}
                              <div
                                className="no-print absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-5 h-7 rounded-full bg-cyan-500 border-2 border-white shadow-md flex items-center justify-center cursor-ew-resize z-30 touch-none"
                                title="Two-finger pinch right handle"
                              >
                                <div className="w-1 h-3 bg-white rounded-full" />
                              </div>

                              {/* Corner Handles */}
                              <div className="no-print absolute -top-1.5 -left-1.5 w-3.5 h-3.5 bg-cyan-500 border-2 border-white rounded-sm shadow" />
                              <div className="no-print absolute -top-1.5 -right-1.5 w-3.5 h-3.5 bg-cyan-500 border-2 border-white rounded-sm shadow" />
                              <div className="no-print absolute -bottom-1.5 -left-1.5 w-3.5 h-3.5 bg-cyan-500 border-2 border-white rounded-sm shadow" />
                              <div className="no-print absolute -bottom-1.5 -right-1.5 w-3.5 h-3.5 bg-cyan-500 border-2 border-white rounded-sm shadow" />

                              {/* Size Pill Tag */}
                              <div className="no-print absolute -bottom-6 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-slate-900/90 text-cyan-300 text-[10px] font-mono whitespace-nowrap shadow border border-cyan-500/40">
                                {Math.round(el.width)} × {Math.round(el.height)} mm • ({Math.round(el.x)}, {Math.round(el.y)}) • {el.rotation || 0}°
                              </div>
                            </>
                          )}
                        </div>
                      )}

                      {/* TEXT ELEMENT */}
                      {el.type === 'text' && (
                        <div
                          className="w-full h-full flex items-center p-1 relative"
                          style={{
                            fontFamily: el.fontFamily || "'Inter', sans-serif",
                            fontSize: `${(el.fontSize || 20) * (zoomLevel / 100)}px`,
                            color: el.color || '#0f172a',
                            fontWeight: el.bold ? 700 : 400,
                            fontStyle: el.italic ? 'italic' : 'normal',
                            textDecoration: el.underline ? 'underline' : 'none',
                            textAlign: el.align || 'center',
                            justifyContent:
                              el.align === 'left'
                                ? 'flex-start'
                                : el.align === 'right'
                                ? 'flex-end'
                                : 'center',
                            lineHeight: el.lineHeight || 1.3,
                            backgroundColor: el.backgroundColor || 'transparent',
                            letterSpacing: `${el.letterSpacing || 0}px`,
                          }}
                        >
                          {/* INLINE TEXTAREA EDITOR WHEN ACTIVE ON BONDPAPER */}
                          {isEditingThisText ? (
                            <textarea
                              ref={inlineInputRef}
                              value={el.text}
                              onChange={(e) => updateElement(el.id, { text: e.target.value })}
                              onBlur={() => setEditingTextId(null)}
                              onKeyDown={(e) => {
                                if (e.key === 'Escape') setEditingTextId(null);
                              }}
                              onClick={(e) => e.stopPropagation()}
                              onMouseDown={(e) => e.stopPropagation()}
                              className="w-full h-full resize-none bg-transparent border-0 outline-none focus:outline-none focus:ring-0 ring-0 p-0 m-0 text-inherit font-inherit overflow-hidden shadow-none cursor-text"
                              style={{
                                textAlign: el.align || 'left',
                                minHeight: '100%',
                                color: el.color || '#0f172a',
                                caretColor: el.color || '#0f172a',
                              }}
                            />
                          ) : (
                            <span className="w-full break-words bg-transparent border-0 outline-none">{el.text}</span>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>


        </div>
      </div>



      {/* ALWAYS VISIBLE FIXED ZOOM CONTROLS WIDGET */}
      <div className="no-print fixed bottom-3 left-3 sm:bottom-5 sm:left-5 z-40 flex items-center gap-1 p-1.5 bg-slate-950/95 border-2 border-cyan-500/60 rounded-2xl shadow-[0_10px_30px_rgba(0,0,0,0.8)] backdrop-blur-md select-none">
        <button
          type="button"
          onClick={() => setZoomLevel(Math.max(25, zoomLevel - 10))}
          className="w-8 h-8 rounded-xl bg-slate-900 hover:bg-slate-800 active:bg-cyan-950 text-cyan-300 flex items-center justify-center active:scale-95 transition-all cursor-pointer border border-slate-800"
          title="Zoom Out (Liitan)"
        >
          <ZoomOut className="w-4 h-4 text-cyan-400" />
        </button>

        <button
          type="button"
          onClick={() => setZoomLevel(50)}
          className="px-2.5 h-8 font-mono text-cyan-300 font-extrabold text-xs flex items-center justify-center hover:bg-slate-800 rounded-xl bg-cyan-950/90 border border-cyan-500/40 active:scale-95 transition-all cursor-pointer shadow-inner"
          title="Reset Zoom 50% (Default)"
        >
          🔍 {zoomLevel}%
        </button>

        <button
          type="button"
          onClick={() => setZoomLevel(Math.min(250, zoomLevel + 10))}
          className="w-8 h-8 rounded-xl bg-slate-900 hover:bg-slate-800 active:bg-cyan-950 text-cyan-300 flex items-center justify-center active:scale-95 transition-all cursor-pointer border border-slate-800"
          title="Zoom In (Lakihan)"
        >
          <ZoomIn className="w-4 h-4 text-cyan-400" />
        </button>

        <div className="w-[1px] h-5 bg-slate-800 mx-0.5" />

        <button
          type="button"
          onClick={handleFitToScreen}
          className="h-8 px-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white font-bold text-xs flex items-center gap-1 transition-all active:scale-95 cursor-pointer border border-slate-800"
          title="Fit Full Bond Paper sa Screen"
        >
          <Maximize className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden sm:inline">Fit Screen</span>
        </button>
      </div>

      {/* SEE ALL PAGES OVERVIEW MODAL (GRID VIEW OF ALL BONDPAPER PAGES) */}
      {isSeeAllModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col p-3 sm:p-6 overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 max-w-6xl mx-auto w-full shrink-0">
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <LayoutGrid className="w-5 h-5 text-cyan-400" />
                <span>Lahat ng Bondpaper ({documentPages.length} Pahina)</span>
              </h3>
              <p className="text-xs text-slate-400">
                Piliin ang bondpaper na nais i-edit, mag-add ng blank space, o i-organisa ang mga pahina
              </p>
            </div>

            <div className="flex items-center gap-2">
              {/* Quick Add Page inside modal */}
              <button
                type="button"
                onClick={() => {
                  handleAddPage();
                  playSuccessChime();
                }}
                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-600/30 active:scale-95 transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>+ Mag-add ng Page</span>
              </button>

              {/* Direct Print All */}
              <button
                type="button"
                onClick={() => {
                  setIsSeeAllModalOpen(false);
                  handleTriggerPrint();
                }}
                className="px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-500/30 active:scale-95 transition-all"
              >
                <Printer className="w-4 h-4" />
                <span>I-print Lahat</span>
              </button>

              <button
                type="button"
                onClick={() => setIsSeeAllModalOpen(false)}
                className="min-w-[36px] min-h-[36px] p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center font-bold"
                title="Isara ang Grid View"
              >
                ✕
              </button>
            </div>
          </div>

          {/* Grid of All Bond Paper Pages */}
          <div className="flex-1 max-w-6xl mx-auto w-full py-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 items-start">
              {documentPages.map((page, idx) => {
                const isCurrent = idx === safePageIndex;
                const pageEls = page.elements || [];

                return (
                  <div
                    key={page.id || idx}
                    className={`rounded-2xl bg-slate-900 border-2 transition-all p-3 flex flex-col gap-3 relative group ${
                      isCurrent
                        ? 'border-cyan-400 shadow-[0_0_25px_rgba(6,182,212,0.35)] ring-2 ring-cyan-400/40'
                        : 'border-slate-800 hover:border-slate-700 shadow-lg'
                    }`}
                  >
                    {/* Top Label & Page Badges */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                            isCurrent ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          Pahina {idx + 1}
                        </span>
                        {isCurrent && (
                          <span className="text-[10px] text-cyan-400 font-bold tracking-wider">
                            ● ACTIVE
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] font-mono text-slate-400">
                        {pageEls.length} element{pageEls.length === 1 ? '' : 's'}
                      </span>
                    </div>

                    {/* Miniature Bond Paper Thumbnail Container */}
                    <div
                      onClick={() => {
                        handleSelectPage(idx);
                        setIsSeeAllModalOpen(false);
                      }}
                      className="w-full bg-white rounded-md shadow-inner overflow-hidden relative cursor-pointer group-hover:ring-2 group-hover:ring-cyan-500 transition-all border border-slate-300"
                      style={{
                        aspectRatio: `${activeWidthMm} / ${activeHeightMm}`,
                        maxHeight: '280px',
                      }}
                      title={`Pindutin para buksan at i-edit ang Pahina ${idx + 1}`}
                    >
                      {/* Blank Space Watermark when page is empty */}
                      {pageEls.length === 0 ? (
                        <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 p-3 text-center">
                          <MousePointerClick className="w-5 h-5 text-slate-300 mb-1" />
                          <span className="text-[11px] font-semibold text-slate-400">Blank Space</span>
                          <span className="text-[9px] text-slate-400">Pindutin para mag-edit</span>
                        </div>
                      ) : (
                        pageEls.map((el) => {
                          const leftPct = (el.x / activeWidthMm) * 100;
                          const topPct = (el.y / activeHeightMm) * 100;
                          const widthPct = (el.width / activeWidthMm) * 100;
                          const heightPct = (el.height / activeHeightMm) * 100;

                          return (
                            <div
                              key={el.id}
                              className="absolute overflow-hidden pointer-events-none"
                              style={{
                                left: `${leftPct}%`,
                                top: `${topPct}%`,
                                width: `${widthPct}%`,
                                height: `${heightPct}%`,
                                transform: `rotate(${el.rotation || 0}deg)`,
                              }}
                            >
                              {el.type === 'image' && el.src && (
                                <img
                                  src={el.src || undefined}
                                  alt=""
                                  className="w-full h-full object-contain"
                                  style={{
                                    filter: el.filter || 'none',
                                    borderRadius: `${(el.borderRadius || 0) * 0.3}px`,
                                  }}
                                />
                              )}
                              {el.type === 'text' && (
                                <div
                                  className="w-full h-full flex items-center p-0.5 text-[6px] leading-tight break-words"
                                  style={{
                                    color: el.color || '#0f172a',
                                    fontWeight: el.bold ? 700 : 400,
                                    fontStyle: el.italic ? 'italic' : 'normal',
                                    textAlign: el.align || 'left',
                                    backgroundColor: el.backgroundColor || 'transparent',
                                  }}
                                >
                                  {el.text}
                                </div>
                              )}
                            </div>
                          );
                        })
                      )}
                    </div>

                    {/* Page Actions Toolbar */}
                    <div className="flex items-center justify-between gap-1 pt-1 border-t border-slate-800/80">
                      <button
                        type="button"
                        onClick={() => {
                          handleSelectPage(idx);
                          setIsSeeAllModalOpen(false);
                        }}
                        className="flex-1 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500 text-cyan-300 hover:text-slate-950 font-bold text-[11px] transition-all flex items-center justify-center gap-1"
                      >
                        <Edit3 className="w-3 h-3" />
                        <span>I-edit Ito</span>
                      </button>

                      <div className="flex items-center gap-0.5">
                        {/* Move Left */}
                        <button
                          type="button"
                          onClick={() => handleMovePage(idx, idx - 1)}
                          disabled={idx === 0}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-20 transition-all"
                          title="I-move pakaliwa"
                        >
                          <ArrowLeft className="w-3 h-3" />
                        </button>

                        {/* Move Right */}
                        <button
                          type="button"
                          onClick={() => handleMovePage(idx, idx + 1)}
                          disabled={idx >= documentPages.length - 1}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-20 transition-all"
                          title="I-move pakanan"
                        >
                          <ArrowRight className="w-3 h-3" />
                        </button>

                        {/* Duplicate */}
                        <button
                          type="button"
                          onClick={() => handleDuplicatePage(idx)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 transition-all"
                          title="I-duplicate ang pahinang ito"
                        >
                          <Files className="w-3 h-3" />
                        </button>

                        {/* Delete */}
                        <button
                          type="button"
                          onClick={() => handleDeletePage(idx)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-red-900/60 text-red-400 transition-all"
                          title="Burahin ang pahinang ito"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* CARD TO ADD A NEW BLANK PAGE IN GRID */}
              <button
                type="button"
                onClick={() => {
                  handleAddPage();
                  playSuccessChime();
                }}
                className="rounded-2xl border-2 border-dashed border-cyan-500/40 hover:border-cyan-400 bg-slate-900/40 hover:bg-slate-900/80 p-6 flex flex-col items-center justify-center gap-3 transition-all group min-h-[220px] cursor-pointer"
              >
                <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform shadow-lg shadow-cyan-500/10">
                  <FilePlus className="w-7 h-7" />
                </div>
                <div className="text-center">
                  <p className="font-bold text-white text-sm group-hover:text-cyan-300 transition-colors">
                    + Mag-add ng Bagong Blank Page
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    Gagawa ng bagong blank space na bondpaper para sa karagdagang layout
                  </p>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* UNIVERSAL PRINTER MANAGER MODAL */}
      {isPrinterModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-cyan-500/30 rounded-3xl p-6 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                  <Printer className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Universal Printer Manager</h3>
                  <p className="text-xs text-cyan-400">Wi-Fi Direct / Network WebPrint / USB Spooler</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsPrinterModalOpen(false)}
                className="text-slate-400 hover:text-white text-lg font-bold min-w-[36px] min-h-[36px] flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <div className="py-4 space-y-4 text-xs">
              {/* Brand Selector */}
              <div>
                <label className="text-[11px] font-bold text-slate-300 block mb-1">
                  Pumili ng Brand ng Printer:
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { id: 'hp', name: 'HP Smart' },
                    { id: 'epson', name: 'Epson Eco' },
                    { id: 'canon', name: 'Canon Pixma' },
                    { id: 'brother', name: 'Brother' },
                    { id: 'kyocera', name: 'Kyocera' },
                    { id: 'pos', name: 'POS Thermal' },
                  ].map((b) => (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => setSelectedPrinterBrand(b.id)}
                      className={`py-1.5 px-2 rounded-xl border text-[11px] font-bold transition-all ${
                        selectedPrinterBrand === b.id
                          ? 'bg-cyan-500/30 border-cyan-400 text-cyan-200'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {b.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Status Box */}
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <p className="text-slate-400 text-[11px]">Active Target Printer:</p>
                  <p className="text-sm font-bold text-white">{selectedPrinterBrand.toUpperCase()} Wireless / USB</p>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">IP: {printerIp} (Port 9100)</p>
                </div>
                <span
                  className={`px-2.5 py-1 rounded-full font-bold text-[10px] ${
                    printerStatus === 'connected'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  {printerStatus.toUpperCase()}
                </span>
              </div>

              {printLogMessage && (
                <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-cyan-200 text-xs font-mono">
                  {printLogMessage}
                </div>
              )}

              <div className="flex flex-col gap-2">
                {/* SCAN / REFRESH BUTTON */}
                <button
                  type="button"
                  onClick={handleScanPrinters}
                  disabled={isPrinterScanning}
                  className="w-full py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
                >
                  <RefreshCw className={`w-4 h-4 ${isPrinterScanning ? 'animate-spin text-amber-400' : ''}`} />
                  <span>{isPrinterScanning ? 'Naghahanap ng Printer...' : '🔄 Refresh & Scan Nearby Network Printers'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleConnectPrinter}
                  disabled={printerStatus === 'searching' || printerStatus === 'connecting'}
                  className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-500/30 transition-all disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Wifi className="w-4 h-4" />
                  <span>
                    {printerStatus === 'connected' ? 'Re-test Printer Connection' : 'Connect to Printer Now'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsPrinterModalOpen(false);
                    handleTriggerPrint();
                  }}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Diretsong Mag-Print Ngayon</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsPrinterModalOpen(false);
                    setIsSalesDashboardOpen(true);
                  }}
                  className="w-full py-2.5 rounded-xl bg-emerald-950/90 hover:bg-emerald-900 border border-emerald-500/50 text-emerald-300 font-bold text-xs shadow-md flex items-center justify-center gap-2 cursor-pointer mt-1"
                >
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                  <span>📊 Business History & Print Transactions</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* POS PRINT BILLING & CONFIRMATION MODAL */}
      {isPrintConfirmModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="w-full max-w-lg bg-slate-900 border border-cyan-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl text-slate-100 my-auto">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-teal-400 text-slate-950 flex items-center justify-center font-extrabold shadow-md">
                  <Printer className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white">POS Print Confirmation & Billing</h3>
                  <p className="text-xs text-cyan-400">Kwenta ng Benta, Sukli at Puhunan bago mag-print</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsPrintConfirmModalOpen(false)}
                className="text-slate-400 hover:text-white text-lg font-bold min-w-[36px] min-h-[36px] flex items-center justify-center rounded-full hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            <div className="py-4 space-y-4 text-xs">
              {/* Paper & Pages Summary */}
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 grid grid-cols-2 gap-3">
                <div>
                  <p className="text-slate-400 text-[10px] font-bold">SUKAT NG BONDPAPER:</p>
                  <p className="text-sm font-extrabold text-cyan-300 capitalize">{selectedPrintPaperPreset}</p>
                  <p className="text-[10px] text-slate-500">
                    {activeWidthMm} × {activeHeightMm} mm
                  </p>
                </div>
                <div>
                  <p className="text-slate-400 text-[10px] font-bold">BILANG NG PAHINA:</p>
                  <p className="text-sm font-extrabold text-emerald-400">{documentPages.length} Pahina</p>
                  <p className="text-[10px] text-slate-500">Pahina 1 hanggang {documentPages.length}</p>
                </div>
              </div>

              {/* Copies & Color Mode Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Copies Counter */}
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between">
                  <label className="text-[10px] font-bold text-slate-400 mb-1 block">BILANG NG COPIES:</label>
                  <div className="flex items-center justify-between bg-slate-900 border border-slate-700 rounded-xl p-1">
                    <button
                      type="button"
                      onClick={() => setPrintCopies((c) => Math.max(1, c - 1))}
                      className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-lg flex items-center justify-center active:scale-95"
                    >
                      -
                    </button>
                    <span className="text-base font-extrabold text-white">{printCopies} copy</span>
                    <button
                      type="button"
                      onClick={() => setPrintCopies((c) => c + 1)}
                      className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-lg flex items-center justify-center active:scale-95"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* Color Mode Toggle */}
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between">
                  <label className="text-[10px] font-bold text-slate-400 mb-1 block">PRINT MODE / KULAY:</label>
                  <div className="grid grid-cols-2 gap-1 bg-slate-900 p-1 rounded-xl border border-slate-700">
                    <button
                      type="button"
                      onClick={() => {
                        setIsColorPrint(true);
                        setPricePerPage(5);
                        setCostPerPage(2);
                      }}
                      className={`py-1.5 rounded-lg text-xs font-bold transition-all ${
                        isColorPrint ? 'bg-cyan-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      🎨 Colored
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsColorPrint(false);
                        setPricePerPage(3);
                        setCostPerPage(1);
                      }}
                      className={`py-1.5 rounded-lg text-xs font-bold transition-all ${
                        !isColorPrint ? 'bg-slate-700 text-white shadow' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      ⚫ Black/White
                    </button>
                  </div>
                </div>
              </div>

              {/* Price & Puhunan Customization */}
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 block mb-1">Presyo kada Pahina (₱):</label>
                  <input
                    type="number"
                    value={pricePerPage}
                    onChange={(e) => setPricePerPage(Number(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 font-bold text-white text-xs focus:border-cyan-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 block mb-1">Puhunan kada Pahina (₱):</label>
                  <input
                    type="number"
                    value={costPerPage}
                    onChange={(e) => setCostPerPage(Number(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 font-bold text-white text-xs focus:border-cyan-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* Billing Summary Box */}
              {(() => {
                const totalBenta = printCopies * pricePerPage * documentPages.length;
                const totalPuhunan = printCopies * costPerPage * documentPages.length;
                const totalTubo = totalBenta - totalPuhunan;
                const sukli = Math.max(0, customerPaid - totalBenta);

                return (
                  <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-950 to-slate-900 border border-emerald-500/40 space-y-3">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <span className="text-slate-400 font-bold">KABUOANG BENTA (TOTAL):</span>
                      <span className="text-xl font-black text-emerald-400">₱{totalBenta.toFixed(2)}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Puhunan (Ink/Paper):</span>
                        <span className="font-bold text-amber-300">₱{totalPuhunan.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Malinis na Tubo:</span>
                        <span className="font-bold text-cyan-300">₱{totalTubo.toFixed(2)}</span>
                      </div>
                    </div>

                    {/* Customer Bayad & Sukli Calculator */}
                    <div className="pt-2 border-t border-slate-800/80 space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <label className="text-slate-300 font-bold shrink-0">Bayad ng Customer (₱):</label>
                        <input
                          type="number"
                          value={customerPaid}
                          onChange={(e) => setCustomerPaid(Number(e.target.value) || 0)}
                          className="w-28 bg-slate-900 border border-emerald-500/50 rounded-xl px-3 py-1.5 text-right font-black text-emerald-300 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-400"
                        />
                      </div>

                      {/* Quick Payment Buttons */}
                      <div className="flex items-center gap-1.5 justify-end">
                        <span className="text-[10px] text-slate-500 font-bold">Quick:</span>
                        {[totalBenta, 20, 50, 100, 500, 1000].map((amt) => (
                          <button
                            key={amt}
                            type="button"
                            onClick={() => setCustomerPaid(amt)}
                            className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-slate-300 border border-slate-700"
                          >
                            ₱{amt}
                          </button>
                        ))}
                      </div>

                      {/* Sukli Box */}
                      <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/50 flex items-center justify-between">
                        <span className="font-extrabold text-emerald-200">SUKLI NG CUSTOMER:</span>
                        <span className="text-lg font-black text-emerald-300">₱{sukli.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsPrintConfirmModalOpen(false)}
                  className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-all active:scale-95"
                >
                  Kanselahin
                </button>
                <button
                  type="button"
                  onClick={handleConfirmAndExecutePrint}
                  className="flex-[2] py-3 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-sm shadow-xl shadow-emerald-500/30 flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>I-PRINT AT I-SAVE ANG BENTA 🖨️</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* BENTA, TUBO AT PUHUNAN DASHBOARD MODAL */}
      {isSalesDashboardOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="w-full max-w-3xl bg-slate-900 border border-emerald-500/40 rounded-3xl p-5 sm:p-6 shadow-2xl text-slate-100 my-auto">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-extrabold text-white">Dashboard ng Benta, Tubo at Puhunan</h3>
                  <p className="text-xs text-emerald-400">Arawan, Lingguhan at Buwanang Ulat mula sa Print Studio</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsSalesDashboardOpen(false)}
                className="text-slate-400 hover:text-white text-lg font-bold min-w-[36px] min-h-[36px] flex items-center justify-center rounded-full hover:bg-slate-800"
              >
                ✕
              </button>
            </div>

            <div className="py-4 space-y-5 text-xs">
              {/* Sales Metrics Cards (Araw, Linggo, Buwan) */}
              {(() => {
                const metrics = getSalesMetrics();
                return (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {/* Today */}
                    <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-950 to-emerald-950/40 border border-emerald-500/30 space-y-2">
                      <div className="flex items-center justify-between text-emerald-400 font-extrabold">
                        <span>KASALUKUYANG ARAW</span>
                        <Coins className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-400">Total Benta:</p>
                        <p className="text-xl font-black text-white">₱{metrics.today.benta.toFixed(2)}</p>
                      </div>
                      <div className="pt-2 border-t border-slate-800/80 grid grid-cols-2 gap-1 text-[10px]">
                        <div>
                          <p className="text-slate-500">Puhunan:</p>
                          <p className="font-bold text-amber-300">₱{metrics.today.puhunan.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-slate-500">Malinis na Tubo:</p>
                          <p className="font-bold text-emerald-300">₱{metrics.today.tubo.toFixed(2)}</p>
                        </div>
                      </div>
                    </div>

                    {/* Week */}
                    <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-950 to-cyan-950/40 border border-cyan-500/30 space-y-2">
                      <div className="flex items-center justify-between text-cyan-400 font-extrabold">
                        <span>NGAYONG LINGGO</span>
                        <TrendingUp className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-400">Total Benta:</p>
                        <p className="text-xl font-black text-white">₱{metrics.week.benta.toFixed(2)}</p>
                      </div>
                      <div className="pt-2 border-t border-slate-800/80 grid grid-cols-2 gap-1 text-[10px]">
                        <div>
                          <p className="text-slate-500">Puhunan:</p>
                          <p className="font-bold text-amber-300">₱{metrics.week.puhunan.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-slate-500">Malinis na Tubo:</p>
                          <p className="font-bold text-cyan-300">₱{metrics.week.tubo.toFixed(2)}</p>
                        </div>
                      </div>
                    </div>

                    {/* Month */}
                    <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-950 to-indigo-950/40 border border-indigo-500/30 space-y-2">
                      <div className="flex items-center justify-between text-indigo-400 font-extrabold">
                        <span>NGAYONG BUWAN</span>
                        <Receipt className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-400">Total Benta:</p>
                        <p className="text-xl font-black text-white">₱{metrics.month.benta.toFixed(2)}</p>
                      </div>
                      <div className="pt-2 border-t border-slate-800/80 grid grid-cols-2 gap-1 text-[10px]">
                        <div>
                          <p className="text-slate-500">Puhunan:</p>
                          <p className="font-bold text-amber-300">₱{metrics.month.puhunan.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-slate-500">Malinis na Tubo:</p>
                          <p className="font-bold text-indigo-300">₱{metrics.month.tubo.toFixed(2)}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Transactions History Table */}
              <div>
                <h4 className="font-bold text-slate-300 text-xs mb-2 flex items-center justify-between">
                  <span>Kasaysayan ng mga Print Sale ({salesTransactions.length} Resibo):</span>
                  <span className="text-[10px] text-emerald-400">Auto-saved sa Firebase</span>
                </h4>

                <div className="max-h-60 overflow-y-auto rounded-2xl bg-slate-950 border border-slate-800 p-2">
                  {salesTransactions.length === 0 ? (
                    <p className="text-center py-6 text-slate-500 italic">
                      Wala pang naitalang print sale. Mag-print sa Print Studio para magkaroon ng benta records!
                    </p>
                  ) : (
                    <table className="w-full text-left text-[11px]">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400 font-bold">
                          <th className="p-2">Oras / Petsa</th>
                          <th className="p-2">Details</th>
                          <th className="p-2 text-right">Benta</th>
                          <th className="p-2 text-right">Puhunan</th>
                          <th className="p-2 text-right">Tubo</th>
                        </tr>
                      </thead>
                      <tbody>
                        {salesTransactions.slice(0, 30).map((t) => (
                          <tr key={t.id} className="border-b border-slate-900 hover:bg-slate-900/60 transition-colors">
                            <td className="p-2 text-slate-400 font-mono text-[10px]">
                              {new Date(t.timestamp).toLocaleDateString()} {new Date(t.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </td>
                            <td className="p-2">
                              <span className="font-bold text-white">{t.copies} copy</span> ({t.pages} page/s, {t.paperSize}, {t.colorMode})
                            </td>
                            <td className="p-2 text-right font-extrabold text-emerald-400">₱{t.totalAmount.toFixed(2)}</td>
                            <td className="p-2 text-right font-bold text-amber-300">₱{t.costAmount.toFixed(2)}</td>
                            <td className="p-2 text-right font-extrabold text-cyan-300">₱{t.profitAmount.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>

              {/* Close Button */}
              <button
                type="button"
                onClick={() => setIsSalesDashboardOpen(false)}
                className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-all active:scale-95"
              >
                Isara ang Dashboard
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FULL BONDPAPER OVERVIEW / PREVIEW MODAL - FULLY RESPONSIVE FOR MOBILE */}
      {isPreviewModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col p-3 sm:p-6 overflow-y-auto">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 max-w-4xl mx-auto w-full shrink-0">
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-1.5">
                <Eye className="w-4 h-4 text-cyan-400" />
                <span>Overview ng Bondpaper (Pahina {safePageIndex + 1} ng {documentPages.length})</span>
              </h3>
              <p className="text-[11px] sm:text-xs text-slate-400">
                {paperSpec.name} ({activeWidthMm} × {activeHeightMm} mm)
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setIsPreviewModalOpen(false);
                  handleTriggerPrint();
                }}
                onTouchEnd={(e) => {
                  e.preventDefault();
                  setIsPreviewModalOpen(false);
                  handleTriggerPrint();
                }}
                className="px-3.5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 active:bg-cyan-300 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-cyan-500/30 touch-manipulation cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print</span>
              </button>
              <button
                type="button"
                onClick={() => setIsPreviewModalOpen(false)}
                onTouchEnd={(e) => {
                  e.preventDefault();
                  setIsPreviewModalOpen(false);
                }}
                className="min-w-[40px] min-h-[40px] p-2 rounded-xl bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-slate-300 hover:text-white flex items-center justify-center touch-manipulation cursor-pointer text-base font-bold"
                title="Isara ang Preview"
              >
                ✕
              </button>
            </div>
          </div>

          <div className="flex-1 flex items-center justify-center py-4 px-1 overflow-auto">
            {/* Responsively fitted bondpaper preview sheet */}
            <div
              className="bg-white text-slate-900 shadow-2xl overflow-hidden relative rounded-sm my-auto transition-all"
              style={{
                width: 'min(92vw, 460px)',
                height: `calc(min(92vw, 460px) * ${activeHeightMm / activeWidthMm})`,
                maxHeight: '75vh',
              }}
            >
              {activeElements.map((el) => {
                const leftPercent = (el.x / activeWidthMm) * 100;
                const topPercent = (el.y / activeHeightMm) * 100;
                const widthPercent = (el.width / activeWidthMm) * 100;
                const heightPercent = (el.height / activeHeightMm) * 100;

                return (
                  <div
                    key={el.id}
                    className="absolute"
                    style={{
                      left: `${leftPercent}%`,
                      top: `${topPercent}%`,
                      width: `${widthPercent}%`,
                      height: `${heightPercent}%`,
                      transform: `rotate(${el.rotation || 0}deg)`,
                    }}
                  >
                    {el.type === 'image' && el.src && (
                      <img
                        src={el.src || undefined}
                        alt=""
                        className="w-full h-full object-contain"
                        style={{
                          filter: el.filter || 'none',
                          borderRadius: `${(el.borderRadius || 0) * 0.5}px`,
                          border: el.borderWidth ? `${el.borderWidth}px solid ${el.borderColor || '#000'}` : 'none',
                        }}
                      />
                    )}
                    {el.type === 'text' && (
                      <div
                        className="w-full h-full flex items-center text-center p-0.5 overflow-hidden break-words"
                        style={{
                          fontFamily: el.fontFamily || "'Inter', sans-serif",
                          fontSize: `clamp(8px, 2.2vw, ${(el.fontSize || 20) * 0.7}px)`,
                          color: el.color || '#0f172a',
                          fontWeight: el.bold ? 700 : 400,
                          fontStyle: el.italic ? 'italic' : 'normal',
                          textAlign: el.align || 'center',
                          justifyContent:
                            el.align === 'left'
                              ? 'flex-start'
                              : el.align === 'right'
                              ? 'flex-end'
                              : 'center',
                        }}
                      >
                        {el.text}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* CUSTOM PAPER SIZE MODAL */}
      {isCustomPaperModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-5 text-slate-100 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-1">Custom Bondpaper Size</h3>
            <p className="text-xs text-slate-400 mb-4">Itakda ang pasadyang lapad at taas ng papel</p>

            <div className="space-y-3 text-xs">
              <div className="flex gap-2">
                <button
                  onClick={() => setCustomUnit('in')}
                  className={`flex-1 py-1 rounded font-bold ${
                    customUnit === 'in' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  Inches (in)
                </button>
                <button
                  onClick={() => setCustomUnit('mm')}
                  className={`flex-1 py-1 rounded font-bold ${
                    customUnit === 'mm' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  Millimeters (mm)
                </button>
                <button
                  onClick={() => setCustomUnit('cm')}
                  className={`flex-1 py-1 rounded font-bold ${
                    customUnit === 'cm' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  Centimeters (cm)
                </button>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Lapad (Width):</label>
                <input
                  type="number"
                  step="0.1"
                  value={
                    customUnit === 'in'
                      ? (customWidthInput / 25.4).toFixed(2)
                      : customUnit === 'cm'
                      ? (customWidthInput / 10).toFixed(2)
                      : customWidthInput
                  }
                  onChange={(e) => {
                    const v = Number(e.target.value);
                    if (customUnit === 'in') setCustomWidthInput(v * 25.4);
                    else if (customUnit === 'cm') setCustomWidthInput(v * 10);
                    else setCustomWidthInput(v);
                  }}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Taas (Height):</label>
                <input
                  type="number"
                  step="0.1"
                  value={
                    customUnit === 'in'
                      ? (customHeightInput / 25.4).toFixed(2)
                      : customUnit === 'cm'
                      ? (customHeightInput / 10).toFixed(2)
                      : customHeightInput
                  }
                  onChange={(e) => {
                    const v = Number(e.target.value);
                    if (customUnit === 'in') setCustomHeightInput(v * 25.4);
                    else if (customUnit === 'cm') setCustomHeightInput(v * 10);
                    else setCustomHeightInput(v);
                  }}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white font-mono"
                />
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  onClick={() => setIsCustomPaperModalOpen(false)}
                  className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    setCurrentProject({
                      ...currentProject,
                      paperPreset: 'custom',
                      customWidthMm: customWidthInput,
                      customHeightMm: customHeightInput,
                    });
                    setIsCustomPaperModalOpen(false);
                  }}
                  className="flex-1 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold"
                >
                  I-apply Size
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SAVED DOCUMENTS MODAL */}
      {isProjectsModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-3xl p-6 shadow-2xl text-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <FolderOpen className="w-5 h-5 text-cyan-400" />
                Mga Naka-save na Document Project
              </h3>
              <button
                onClick={() => setIsProjectsModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto pr-1 text-xs">
              {savedProjects.length === 0 ? (
                <p className="text-slate-500 text-center py-6">Walang naka-save na document.</p>
              ) : (
                savedProjects.map((p) => (
                  <div
                    key={p.id}
                    className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between hover:border-cyan-500/40 transition-colors"
                  >
                    <div>
                      <h4 className="font-bold text-white">{p.title}</h4>
                      <p className="text-[10px] text-slate-400">
                        {p.paperPreset.toUpperCase()} • {p.elements.length} elements
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setCurrentProject(p);
                          setIsProjectsModalOpen(false);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 font-bold hover:bg-cyan-500/40"
                      >
                        Buksan
                      </button>
                      <button
                        onClick={async () => {
                          await deletePrintProjectFromDatabase(p.id);
                          setSavedProjects((prev) => prev.filter((item) => item.id !== p.id));
                        }}
                        className="p-1 rounded-lg text-red-400 hover:bg-red-500/20"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800">
              <button
                onClick={() => {
                  setCurrentProject(createDefaultPrintDocument());
                  setIsProjectsModalOpen(false);
                }}
                className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-bold flex items-center justify-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Gumawa ng Bagong Blank Document</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* IMAGE CROP MODAL */}
      <ImageCropModal
        isOpen={isCropModalOpen}
        onClose={() => setIsCropModalOpen(false)}
        imageSrc={cropImageSrc}
        imageName={cropImageName}
        onApplyCrop={handleApplyCrop}
      />

      {/* PRECISION PRINT MEDIA STYLES */}
      <style>{`
        @media print {
          body, html, #root {
            background: white !important;
            color: black !important;
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
            height: 100% !important;
          }
          .no-print {
            display: none !important;
          }
          #printable-bondpaper-sheet {
            box-shadow: none !important;
            position: absolute !important;
            top: 0 !important;
            left: 0 !important;
            width: ${activeWidthMm}mm !important;
            height: ${activeHeightMm}mm !important;
            min-width: ${activeWidthMm}mm !important;
            min-height: ${activeHeightMm}mm !important;
            max-width: ${activeWidthMm}mm !important;
            max-height: ${activeHeightMm}mm !important;
            margin: 0 !important;
            padding: 0 !important;
            page-break-after: always;
            overflow: hidden !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          #printable-bondpaper-sheet div[id^="canvas-el-"] {
            left: var(--el-x-mm) !important;
            top: var(--el-y-mm) !important;
            width: var(--el-w-mm) !important;
            height: var(--el-h-mm) !important;
            box-shadow: none !important;
            outline: none !important;
            --tw-ring-shadow: none !important;
            --tw-ring-offset-shadow: none !important;
          }
          @page {
            size: ${activeWidthMm}mm ${activeHeightMm}mm ${currentProject.orientation};
            margin: 0;
          }
        }
      `}</style>
    </div>
  );
};
