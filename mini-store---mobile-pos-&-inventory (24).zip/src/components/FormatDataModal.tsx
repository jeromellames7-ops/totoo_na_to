import React, { useState } from 'react';
import { verifyAdminPin, formatAllData, formatAllAccountsData, getAdminPin } from '../utils/storage';
import {
  Trash2,
  X,
  AlertTriangle,
  Lock,
  KeyRound,
  CheckCircle2,
  RefreshCw,
  Database,
  Eye,
  EyeOff,
} from 'lucide-react';

interface FormatDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetAccountId?: string;
  accountName?: string;
}

export const FormatDataModal: React.FC<FormatDataModalProps> = ({
  isOpen,
  onClose,
  targetAccountId,
  accountName = 'Current Account',
}) => {
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [formatScope, setFormatScope] = useState<'single' | 'all'>('single');

  const [isFormatting, setIsFormatting] = useState(false);

  if (!isOpen) return null;

  const handleFormatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    // Verify entered PIN against admin PIN (default 1234)
    if (!verifyAdminPin(pin.trim())) {
      setErrorMsg('Incorrect PIN Code! The default PIN is 1234. Please try again.');
      return;
    }

    setIsFormatting(true);
    try {
      // Execute format based on scope
      if (formatScope === 'all') {
        await formatAllAccountsData();
        setSuccessMsg('Nai-format na ang LAHAT ng Accounts sa system at Firebase! Inimbak ang backup sa Restore Table.');
      } else {
        await formatAllData(targetAccountId);
        setSuccessMsg(`Nai-format na ang ${accountName} sa system at Firebase! Inimbak ang backup sa Restore Table.`);
      }

      setPin('');
      setTimeout(() => {
        setSuccessMsg('');
        setIsFormatting(false);
        onClose();
      }, 2500);
    } catch (err) {
      setErrorMsg('May nangyaring error sa pag-format. Subukang muli.');
      setIsFormatting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-70 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-2xl w-full max-w-md space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-rose-100 text-rose-600 rounded-2xl border border-rose-200">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900">
                Format Database / Clear All Data
              </h3>
              <p className="text-[11px] text-slate-500">
                Requires PIN Code (1234) before wiping database.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Warning Banner */}
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-3.5 space-y-1.5 text-rose-900">
          <div className="flex items-center gap-2 font-extrabold text-xs text-rose-700 uppercase">
            <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>FORMATTING WARNING:</span>
          </div>
          <p className="text-xs leading-relaxed font-medium">
            Proceeding with database format will <strong>PERMANENTLY DELETE ALL</strong> products, prices, stock history, and sales. This action cannot be undone.
          </p>
        </div>

        {/* Success Alert */}
        {successMsg && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Format Form */}
        <form onSubmit={handleFormatSubmit} className="space-y-4">
          {/* Format Scope Option */}
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1.5">
              Select Format Scope:
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setFormatScope('single')}
                className={`p-2.5 rounded-xl border text-xs font-bold text-left transition-all ${
                  formatScope === 'single'
                    ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="font-extrabold">{accountName}</div>
                <div className="text-[10px] opacity-80 font-normal">Format target account only</div>
              </button>

              <button
                type="button"
                onClick={() => setFormatScope('all')}
                className={`p-2.5 rounded-xl border text-xs font-bold text-left transition-all ${
                  formatScope === 'all'
                    ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="font-extrabold">All Accounts</div>
                <div className="text-[10px] opacity-80 font-normal">Wipe entire database across stores</div>
              </button>
            </div>
          </div>

          {/* PIN Input */}
          <div>
            <label className="text-xs font-bold text-slate-700 flex items-center justify-between mb-1">
              <span className="flex items-center gap-1">
                <Lock className="w-3.5 h-3.5 text-rose-600" />
                <span>Enter Admin PIN Code *</span>
              </span>
              <span className="text-[10px] font-mono text-slate-400">Default PIN: 1234</span>
            </label>

            <div className="relative">
              <input
                type={showPin ? 'text' : 'password'}
                required
                maxLength={8}
                value={pin}
                onChange={(e) => {
                  setPin(e.target.value);
                  if (errorMsg) setErrorMsg('');
                }}
                placeholder="Enter 1234..."
                className="w-full bg-slate-50 border border-slate-200 focus:border-rose-600 focus:ring-2 focus:ring-rose-500/20 rounded-xl pl-9 pr-10 py-2.5 text-sm font-mono font-bold text-slate-900 tracking-widest text-center"
              />
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />

              <button
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
              >
                {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            {errorMsg && (
              <p className="text-[11px] font-bold text-rose-600 mt-1.5 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>{errorMsg}</span>
              </p>
            )}
          </div>

          {/* Buttons */}
          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold border border-slate-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!pin || isFormatting}
              className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 disabled:bg-slate-300 text-white rounded-xl text-xs font-bold shadow-md shadow-rose-200 flex items-center justify-center gap-1.5 transition-all active:scale-95"
            >
              {isFormatting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>FORMATTING...</span>
                </>
              ) : (
                <>
                  <Trash2 className="w-4 h-4" />
                  <span>FORMAT NOW</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
