import React, { useState, useEffect } from 'react';
import {
  SecurityAuditLog,
  SecuritySettings,
  UserAccount,
} from '../types';
import {
  getSecurityLogs,
  clearSecurityLogs,
  getSecuritySettings,
  saveSecuritySettings,
  verifyDataIntegrity,
  addSecurityLog,
} from '../utils/storage';
import { getLanguage, LANG_CHANGE_EVENT, Language } from '../utils/language';
import {
  ShieldAlert,
  ShieldCheck,
  Lock,
  X,
  Trash2,
  RefreshCw,
  Sliders,
  History,
  AlertTriangle,
  CheckCircle2,
  KeyRound,
  FileText,
  Clock,
  HardDrive,
  Eye,
  Check,
} from 'lucide-react';

interface SecurityAuditModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeUser: UserAccount;
  onLockTerminalNow: () => void;
}

export const SecurityAuditModal: React.FC<SecurityAuditModalProps> = ({
  isOpen,
  onClose,
  activeUser,
  onLockTerminalNow,
}) => {
  const [activeTab, setActiveTab] = useState<'logs' | 'settings' | 'integrity'>('logs');
  const [logs, setLogs] = useState<SecurityAuditLog[]>([]);
  const [settings, setSettings] = useState<SecuritySettings>(getSecuritySettings());
  const [integrityStatus, setIntegrityStatus] = useState<any>(null);
  const [filterSeverity, setFilterSeverity] = useState<string>('ALL');
  const [lang, setLang] = useState<Language>(getLanguage());

  const refreshLogs = () => {
    setLogs(getSecurityLogs());
    setIntegrityStatus(verifyDataIntegrity());
  };

  useEffect(() => {
    const handleLangChange = () => setLang(getLanguage());
    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
  }, []);

  useEffect(() => {
    if (isOpen) {
      setSettings(getSecuritySettings());
      refreshLogs();
      setLang(getLanguage());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isTl = lang === 'tl';

  const filteredLogs = logs.filter((log) => {
    if (filterSeverity === 'ALL') return true;
    return log.severity === filterSeverity;
  });

  const handleToggleSetting = (key: keyof SecuritySettings) => {
    if (typeof settings[key] === 'boolean') {
      const updated = { ...settings, [key]: !settings[key] };
      setSettings(updated);
      saveSecuritySettings(updated);
    }
  };

  const handleAutoLockChange = (minutes: number) => {
    const updated = { ...settings, autoLockMinutes: minutes };
    setSettings(updated);
    saveSecuritySettings(updated);
  };

  const handleClearLogs = () => {
    if (window.confirm('Sigurado ka bang gusto mong burahin ang lahat ng security audit logs?')) {
      clearSecurityLogs();
      refreshLogs();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-2xl bg-white border border-slate-200/90 rounded-3xl shadow-2xl overflow-hidden flex flex-col h-[85vh] animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 px-5 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/20 rounded-2xl border border-indigo-400/30 text-indigo-300">
              <ShieldAlert className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-sm font-black tracking-wide flex items-center gap-2">
                System Security & Audit Trail Center
                <span className="text-[9px] bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-400/30 font-bold">
                  Protected
                </span>
              </h3>
              <p className="text-[11px] text-slate-300">
                {isTl
                  ? 'Awtomatikong nakatala ang lahat ng sensitive POS transactions at security events.'
                  : 'Automatically records all sensitive POS transactions and security events.'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onLockTerminalNow();
              }}
              className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
              title="I-lock agad ang Terminal Screen"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Lock Terminal</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="bg-slate-100 border-b border-slate-200 p-2 flex items-center gap-2 shrink-0">
          <button
            onClick={() => setActiveTab('logs')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'logs'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Audit Trail Logs ({logs.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'settings'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Security Settings</span>
          </button>

          <button
            onClick={() => setActiveTab('integrity')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'integrity'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            <HardDrive className="w-3.5 h-3.5" />
            <span>Data Integrity Check</span>
          </button>
        </div>

        {/* Modal Content View */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {activeTab === 'logs' && (
            <div className="space-y-3">
              {/* Filter & Actions Bar */}
              <div className="flex items-center justify-between gap-2 bg-slate-50 p-2 rounded-2xl border border-slate-200 text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-slate-600">Filter Severity:</span>
                  {['ALL', 'INFO', 'WARNING', 'CRITICAL'].map((sev) => (
                    <button
                      key={sev}
                      onClick={() => setFilterSeverity(sev)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold border transition-all ${
                        filterSeverity === sev
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {sev}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={refreshLogs}
                    className="p-1.5 bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 rounded-xl"
                    title="I-refresh logs"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                  {logs.length > 0 && (
                    <button
                      onClick={handleClearLogs}
                      className="px-2.5 py-1 bg-rose-50 border border-rose-200 text-rose-700 hover:bg-rose-100 font-bold rounded-xl text-[10px] flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3 text-rose-600" />
                      Clear Logs
                    </button>
                  )}
                </div>
              </div>

              {/* Logs List Table */}
              {filteredLogs.length === 0 ? (
                <div className="py-12 text-center text-slate-400 space-y-2">
                  <ShieldCheck className="w-10 h-10 stroke-1 mx-auto text-emerald-500 opacity-60" />
                  <p className="font-bold text-slate-700 text-xs">Walang nakatalang security alert o issue.</p>
                  <p className="text-[11px] text-slate-500">
                    Lahat ng transactions at system events ay malinis at ligtas.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredLogs.map((log) => {
                    const isCritical = log.severity === 'CRITICAL';
                    const isWarning = log.severity === 'WARNING';
                    return (
                      <div
                        key={log.id}
                        className={`p-3 rounded-2xl border text-xs flex items-start justify-between gap-3 transition-all ${
                          isCritical
                            ? 'bg-rose-50/70 border-rose-200 text-rose-950'
                            : isWarning
                            ? 'bg-amber-50/70 border-amber-200 text-amber-950'
                            : 'bg-slate-50 border-slate-200 text-slate-900'
                        }`}
                      >
                        <div className="flex items-start gap-2.5">
                          <div
                            className={`p-2 rounded-xl mt-0.5 shrink-0 ${
                              isCritical
                                ? 'bg-rose-600 text-white'
                                : isWarning
                                ? 'bg-amber-500 text-slate-900'
                                : 'bg-indigo-600 text-white'
                            }`}
                          >
                            {isCritical ? (
                              <ShieldAlert className="w-4 h-4" />
                            ) : isWarning ? (
                              <AlertTriangle className="w-4 h-4" />
                            ) : (
                              <FileText className="w-4 h-4" />
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span
                                className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${
                                  isCritical
                                    ? 'bg-rose-100 border-rose-300 text-rose-800'
                                    : isWarning
                                    ? 'bg-amber-100 border-amber-300 text-amber-900'
                                    : 'bg-indigo-100 border-indigo-200 text-indigo-800'
                                }`}
                              >
                                {log.eventType}
                              </span>
                              <span className="text-[10px] text-slate-500 font-semibold flex items-center gap-1">
                                <Clock className="w-3 h-3 text-slate-400" />
                                {new Date(log.timestamp).toLocaleString([], {
                                  month: 'short',
                                  day: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                  second: '2-digit',
                                })}
                              </span>
                            </div>
                            <p className="font-bold mt-1 text-slate-900">{log.description}</p>
                            <p className="text-[10px] text-slate-500 mt-0.5 font-medium">
                              Isinagawa ni: <strong>{log.actorName}</strong> ({log.actorRole})
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-4 text-xs">
              {/* Inactivity Auto-Lock Settings */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-indigo-600" />
                    <div>
                      <h4 className="font-extrabold text-slate-900">Inactivity Auto-Lock Terminal Timer</h4>
                      <p className="text-[11px] text-slate-500">
                        Awtomatikong iko-lock ang POS terminal kapag walang gumagalaw sa screen.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-2 pt-1">
                  {[0, 3, 5, 10].map((mins) => {
                    const isSelected = settings.autoLockMinutes === mins;
                    return (
                      <button
                        key={mins}
                        onClick={() => handleAutoLockChange(mins)}
                        className={`py-2 px-2 rounded-xl font-extrabold text-xs border transition-all ${
                          isSelected
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {mins === 0 ? 'Naka-Off' : `${mins} Mins`}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* PIN Enforcement Policies */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <h4 className="font-extrabold text-slate-900 flex items-center gap-1.5">
                  <KeyRound className="w-4 h-4 text-indigo-600" /> Security PIN Protection Policies
                </h4>

                <div className="space-y-2">
                  <label className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-50">
                    <div>
                      <span className="font-bold text-slate-800 block">Kailangan ng PIN sa Pag-Void ng Benta</span>
                      <span className="text-[11px] text-slate-500">Hihingi ng Admin PIN kapag ikakansela ang resibo.</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.requirePinForVoid}
                      onChange={() => handleToggleSetting('requirePinForVoid')}
                      className="w-4 h-4 text-indigo-600 rounded"
                    />
                  </label>

                  <label className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-50">
                    <div>
                      <span className="font-bold text-slate-800 block">Kailangan ng PIN sa Pagbura ng Produkto</span>
                      <span className="text-[11px] text-slate-500">
                        Hihingi ng Admin PIN bago ma-delete ang anumang inventory item.
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.requirePinForDelete}
                      onChange={() => handleToggleSetting('requirePinForDelete')}
                      className="w-4 h-4 text-indigo-600 rounded"
                    />
                  </label>

                  <label className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-50">
                    <div>
                      <span className="font-bold text-slate-800 block">Kailangan ng PIN sa Database Reset/Format</span>
                      <span className="text-[11px] text-slate-500">
                        Proprotektahan ang buong IndexedDB/LocalStorage mula sa di-awtorisadong wipe.
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.requirePinForFormat}
                      onChange={() => handleToggleSetting('requirePinForFormat')}
                      className="w-4 h-4 text-indigo-600 rounded"
                    />
                  </label>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'integrity' && (
            <div className="space-y-3 text-xs">
              <div className="p-4 rounded-2xl bg-indigo-950 text-white border border-indigo-800 space-y-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-6 h-6 text-emerald-400" />
                  <div>
                    <h4 className="font-black text-sm text-white">System Cryptographic Integrity Verification</h4>
                    <p className="text-[11px] text-slate-300">
                      Ise-verify kung intact at walang illegal tampered modifications sa iyong POS records.
                    </p>
                  </div>
                </div>

                {integrityStatus && (
                  <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Integrity Status:</span>
                      <span className="font-black text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Verified Healthy & Intact
                      </span>
                    </div>
                    <div className="flex items-center justify-between border-t border-slate-800 pt-1 text-[11px]">
                      <span className="text-slate-400">Current Checksum Hash:</span>
                      <span className="font-mono font-bold text-amber-300">{integrityStatus.currentHash}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
