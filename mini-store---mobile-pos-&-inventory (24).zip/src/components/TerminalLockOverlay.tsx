import React, { useState, useEffect } from 'react';
import { Lock, ShieldAlert, KeyRound, CheckCircle } from 'lucide-react';
import { verifyAdminPin, addSecurityLog } from '../utils/storage';
import { getLanguage, LANG_CHANGE_EVENT, Language } from '../utils/language';

interface TerminalLockOverlayProps {
  isLocked: boolean;
  onUnlock: () => void;
  activeUserName?: string;
}

export const TerminalLockOverlay: React.FC<TerminalLockOverlayProps> = ({
  isLocked,
  onUnlock,
  activeUserName = 'Admin / Cashier',
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const [lang, setLang] = useState<Language>(getLanguage());

  useEffect(() => {
    const handleLangChange = () => setLang(getLanguage());
    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
  }, []);

  if (!isLocked) return null;

  const isTl = lang === 'tl';

  const handleKeyPress = (num: string) => {
    if (pin.length < 4) {
      const nextPin = pin + num;
      setPin(nextPin);
      setError(false);

      if (nextPin.length === 4) {
        setTimeout(() => {
          if (verifyAdminPin(nextPin)) {
            addSecurityLog('UNLOCK_TERMINAL', `Unlocked terminal by ${activeUserName}`, 'INFO');
            setPin('');
            setError(false);
            onUnlock();
          } else {
            addSecurityLog('PIN_FAILED', `Incorrect PIN attempt on terminal lock by ${activeUserName}`, 'WARNING');
            setError(true);
            setPin('');
          }
        }, 150);
      }
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setError(false);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950/95 backdrop-blur-xl flex items-center justify-center p-4 animate-in fade-in duration-300">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 text-center text-white space-y-5 animate-in zoom-in-95 duration-200">
        {/* Shield Icon */}
        <div className="w-16 h-16 rounded-3xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center mx-auto text-indigo-400 shadow-inner">
          <Lock className="w-8 h-8 animate-pulse" />
        </div>

        <div>
          <h2 className="text-lg font-black tracking-wide">Terminal Locked</h2>
          <p className="text-xs text-slate-400 mt-1">
            {isTl
              ? 'Naka-lock ang POS System. I-enter ang 4-digit Admin PIN upang mabuksan.'
              : 'POS System Locked. Enter 4-digit Admin PIN to unlock.'}
          </p>
        </div>

        {/* 4 Pin Circles */}
        <div className="flex justify-center items-center gap-3 py-2">
          {[0, 1, 2, 3].map((idx) => {
            const isFilled = pin.length > idx;
            return (
              <div
                key={idx}
                className={`w-4 h-4 rounded-full transition-all duration-200 ${
                  error
                    ? 'bg-rose-500 ring-4 ring-rose-500/30 animate-shake'
                    : isFilled
                    ? 'bg-indigo-500 scale-110 shadow-lg shadow-indigo-500/50'
                    : 'bg-slate-800 border border-slate-700'
                }`}
              />
            );
          })}
        </div>

        {error && (
          <div className="flex items-center justify-center gap-1.5 text-xs text-rose-400 bg-rose-500/10 border border-rose-500/20 py-1.5 px-3 rounded-xl">
            <ShieldAlert className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{isTl ? 'Maling PIN! (Default: 1234)' : 'Incorrect PIN! (Default: 1234)'}</span>
          </div>
        )}

        {/* Keypad */}
        <div className="grid grid-cols-3 gap-2.5 max-w-[240px] mx-auto pt-2">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
            <button
              key={num}
              onClick={() => handleKeyPress(num)}
              className="h-12 bg-slate-800/80 hover:bg-slate-700 active:bg-indigo-600 text-white font-extrabold text-base rounded-2xl border border-slate-700/80 transition-all active:scale-95 flex items-center justify-center shadow-xs"
            >
              {num}
            </button>
          ))}
          <button
            onClick={() => setPin('')}
            className="h-12 bg-slate-800/40 hover:bg-slate-800 text-slate-400 font-bold text-xs rounded-2xl border border-slate-800 flex items-center justify-center"
          >
            Clear
          </button>
          <button
            onClick={() => handleKeyPress('0')}
            className="h-12 bg-slate-800/80 hover:bg-slate-700 active:bg-indigo-600 text-white font-extrabold text-base rounded-2xl border border-slate-700/80 transition-all active:scale-95 flex items-center justify-center shadow-xs"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="h-12 bg-slate-800/40 hover:bg-slate-800 text-slate-400 font-bold text-xs rounded-2xl border border-slate-800 flex items-center justify-center"
          >
            Del
          </button>
        </div>
      </div>
    </div>
  );
};
