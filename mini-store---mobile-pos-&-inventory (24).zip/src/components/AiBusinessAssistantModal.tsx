import React, { useState, useEffect } from 'react';
import { Product, Sale } from '../types';
import { getProducts, getSales, DATA_CHANGE_EVENT } from '../utils/storage';
import { GoogleGenAI } from '@google/genai';
import { X, Sparkles, TrendingUp, AlertTriangle, Lightbulb, PackageCheck, Bot, Send, Zap, ArrowRight, RefreshCw, BarChart2, ShieldAlert } from 'lucide-react';

interface AiBusinessAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ChatMessage {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
}

export const AiBusinessAssistantModal: React.FC<AiBusinessAssistantModalProps> = ({ isOpen, onClose }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [activeTab, setActiveTab] = useState<'FORECAST' | 'PRICING' | 'COMBOS' | 'CHAT'>('FORECAST');

  // AI Chat state
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-1',
      sender: 'ai',
      text: 'Kamusta boss! Ako ang iyong AI Store Advisor. Maaari mo akong tanungin tungkol sa iyong daily sales, pinakamalakas na benta, restock predictions, o paano mapalaki ang kita ng sari-sari store mo.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isAiThinking, setIsAiThinking] = useState(false);

  const loadData = () => {
    setProducts(getProducts());
    setSales(getSales());
  };

  useEffect(() => {
    if (isOpen) loadData();
    window.addEventListener(DATA_CHANGE_EVENT, loadData);
    return () => window.removeEventListener(DATA_CHANGE_EVENT, loadData);
  }, [isOpen]);

  if (!isOpen) return null;

  // 1. FORECAST LOGIC: Calculate Sales Velocity & Days Remaining
  const restockPredictions = products
    .map((p) => {
      // Find sales count in the last 7 days
      let totalUnitsSoldInPastWeek = 0;
      sales.forEach((s) => {
        s.items.forEach((item) => {
          if (item.product.id === p.id) {
            totalUnitsSoldInPastWeek += item.quantity;
          }
        });
      });

      const dailyBurnRate = totalUnitsSoldInPastWeek > 0 ? totalUnitsSoldInPastWeek / 7 : 0.5; // fallback
      const daysRemaining = p.stock > 0 ? Math.round((p.stock / dailyBurnRate) * 10) / 10 : 0;

      return {
        product: p,
        dailyBurnRate: Math.round(dailyBurnRate * 10) / 10,
        daysRemaining,
        urgency: daysRemaining <= 2 ? 'CRITICAL' : daysRemaining <= 5 ? 'WARNING' : 'STABLE',
      };
    })
    .sort((a, b) => a.daysRemaining - b.daysRemaining);

  // 2. PRICING & PROFIT LOGIC: Find low margin items
  const lowMarginProducts = products
    .map((p) => {
      const marginPercent = p.price > 0 ? ((p.price - p.costPrice) / p.price) * 100 : 0;
      const profitPerItem = p.price - p.costPrice;
      const suggestedPrice = Math.ceil(p.costPrice * 1.25); // 25% recommended markup

      return {
        product: p,
        marginPercent: Math.round(marginPercent),
        profitPerItem,
        suggestedPrice,
      };
    })
    .filter((item) => item.marginPercent < 20)
    .sort((a, b) => a.marginPercent - b.marginPercent);

  // 3. PRODUCT COMBOS: Detect co-purchased items
  const pairCounts: { [key: string]: { nameA: string; nameB: string; count: number } } = {};
  sales.forEach((s) => {
    if (s.items.length >= 2) {
      for (let i = 0; i < s.items.length; i++) {
        for (let j = i + 1; j < s.items.length; j++) {
          const nameA = s.items[i].product.name;
          const nameB = s.items[j].product.name;
          const key = [nameA, nameB].sort().join(' + ');
          if (!pairCounts[key]) {
            pairCounts[key] = { nameA, nameB, count: 0 };
          }
          pairCounts[key].count += 1;
        }
      }
    }
  });

  const topCombos = Object.values(pairCounts)
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  // AI Chat Handler
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || isAiThinking) return;

    const userText = inputMessage.trim();
    const newMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, newMsg]);
    setInputMessage('');
    setIsAiThinking(true);

    try {
      // Build context summary for Gemini AI
      const totalRev = sales.reduce((sum, s) => sum + s.totalAmount, 0);
      const totalProfit = sales.reduce((sum, s) => sum + s.profit, 0);
      const topSellingName = products.length > 0 ? products[0].name : 'N/A';

      const promptContext = `You are TindahanPOS AI Assistant, a helpful Filipino business advisor for sari-sari store owners.
Store Context:
- Total Sales: ₱${totalRev}
- Total Profit: ₱${totalProfit}
- Total Active Products: ${products.length}
- Sample Best Sellers: ${topSellingName}

User asked: "${userText}"

Provide a friendly, concise response in Taglish (Tagalog/English) with actionable business tips for the store owner. Keep it short and readable.`;

      let responseText = '';
      const customKey = localStorage.getItem('custom_gemini_api_key') || undefined;

      try {
        const res = await fetch('/api/business-chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: promptContext, customApiKey: customKey }),
        });
        if (res.ok) {
          const json = await res.json();
          if (json.success && json.text) {
            responseText = json.text;
          }
        }
      } catch (e) {
        console.warn('Backend business-chat call fallback:', e);
      }

      if (!responseText) {
        const apiKey =
          process.env.GEMINI_API_KEY ||
          (import.meta as any).env?.VITE_GEMINI_API_KEY ||
          localStorage.getItem('custom_gemini_api_key');

        if (apiKey) {
          const ai = new GoogleGenAI({
            apiKey,
            httpOptions: {
              headers: {
                'User-Agent': 'aistudio-build',
              },
            },
          });
          const response = await ai.models.generateContent({
            model: 'gemini-3.7-flash',
            contents: promptContext,
          });
          responseText = response.text || 'Pasensya na boss, subukan muli ang iyong tanong.';
        } else {
          // High quality offline fallback responses
          const lower = userText.toLowerCase();
          if (lower.includes('benta') || lower.includes('sales')) {
            responseText = `Ang iyong kabuuang naitalang benta sa system ay ₱${totalRev.toFixed(2)} na may tantyang kita na ₱${totalProfit.toFixed(2)}. Ipagpatuloy ang magandang pamamahala!`;
          } else if (lower.includes('restock') || lower.includes('ubos')) {
            const criticals = restockPredictions.filter((r) => r.urgency === 'CRITICAL').map((r) => r.product.name);
            responseText = criticals.length > 0
              ? `May ${criticals.length} produkto ka na malapit nang maubos: ${criticals.join(', ')}. Bisitahin ang Restock Forecast tab para sa buong detalye!`
              : 'Maganda ang antas ng iyong imbentaryo ngayon boss! Walang critical out of stock items.';
          } else {
            responseText = `Salamat sa tanong boss! Para sa mas magandang kita ng tindahan: 1) I-bundle ang mabilis maubos na items, 2) Siguraduhing may 20%-25% profit margin ka sa paninda, at 3) I-track nang maayos ang mga nag-utang sa Utang Ledger.`;
          }
        }
      }

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setChatMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      console.error('AI response error:', err);
      const fallbackMsg: ChatMessage = {
        id: `ai-err-${Date.now()}`,
        sender: 'ai',
        text: `Ang kabuuang benta mo ay ₱${sales.reduce((s, r) => s + r.totalAmount, 0).toFixed(2)}. Siguraduhing mag-restock sa mga produktong nasa Restock Forecast tab.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setChatMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsAiThinking(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-200 text-slate-900 flex items-center justify-center shadow-lg shadow-amber-400/20">
              <Sparkles className="w-5 h-5 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight flex items-center gap-2">
                <span>AI Store Advisor & Restock Intelligence</span>
              </h3>
              <p className="text-xs text-indigo-200">
                Powered by Gemini AI for smart stock predictions & profit optimization
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="bg-slate-100 p-1.5 border-b border-slate-200 flex items-center gap-1 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveTab('FORECAST')}
            className={`flex-1 min-w-[110px] py-2 px-3 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'FORECAST'
                ? 'bg-white text-indigo-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <TrendingUp className="w-4 h-4 text-indigo-600" />
            <span>Restock Forecast</span>
          </button>

          <button
            onClick={() => setActiveTab('PRICING')}
            className={`flex-1 min-w-[110px] py-2 px-3 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'PRICING'
                ? 'bg-white text-amber-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Lightbulb className="w-4 h-4 text-amber-600" />
            <span>Profit Optimizer</span>
          </button>

          <button
            onClick={() => setActiveTab('COMBOS')}
            className={`flex-1 min-w-[110px] py-2 px-3 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'COMBOS'
                ? 'bg-white text-emerald-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <PackageCheck className="w-4 h-4 text-emerald-600" />
            <span>Smart Bundles</span>
          </button>

          <button
            onClick={() => setActiveTab('CHAT')}
            className={`flex-1 min-w-[110px] py-2 px-3 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'CHAT'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Bot className="w-4 h-4 text-purple-600" />
            <span>AI Chat Assistant</span>
          </button>
        </div>

        {/* Tab Content Area */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-50/50">
          {/* 1. RESTOCK FORECAST TAB */}
          {activeTab === 'FORECAST' && (
            <div className="space-y-3">
              <div className="bg-indigo-50 border border-indigo-200/80 rounded-2xl p-3 text-xs text-indigo-900 flex items-start gap-2.5">
                <Sparkles className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-extrabold">Automated Demand Velocity Engine:</span>
                  <p className="text-[11px] text-indigo-700 mt-0.5">
                    Tinataya ng AI kung ilang araw na lang tatagal ang iyong mga paninda base sa nakaraang bilis ng benta.
                  </p>
                </div>
              </div>

              {restockPredictions.length === 0 ? (
                <div className="text-center py-10 text-slate-400">Walang paninda na kailangan suriin.</div>
              ) : (
                restockPredictions.map((item) => (
                  <div
                    key={item.product.id}
                    className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-xs flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={item.product.imageUrl || undefined}
                        alt=""
                        className="w-12 h-12 rounded-xl object-cover bg-slate-100 shrink-0"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src =
                            'https://images.unsplash.com/photo-1542838132-92c53300491e?w=200';
                        }}
                      />
                      <div className="min-w-0">
                        <h4 className="font-bold text-xs sm:text-sm text-slate-900 truncate">
                          {item.product.name}
                        </h4>
                        <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                          <span>Kasalukuyang Stock: <strong className="text-slate-800">{item.product.stock}</strong></span>
                          <span>•</span>
                          <span>Benta/Araw: <strong>~{item.dailyBurnRate} pcs</strong></span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span
                        className={`inline-block px-2.5 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider ${
                          item.urgency === 'CRITICAL'
                            ? 'bg-rose-100 text-rose-800 border border-rose-200'
                            : item.urgency === 'WARNING'
                            ? 'bg-amber-100 text-amber-800 border border-amber-200'
                            : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        }`}
                      >
                        {item.daysRemaining <= 0 ? 'UBOS NA' : `${item.daysRemaining} Araw Na Lang`}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* 2. PROFIT OPTIMIZER TAB */}
          {activeTab === 'PRICING' && (
            <div className="space-y-3">
              <div className="bg-amber-50 border border-amber-200/80 rounded-2xl p-3 text-xs text-amber-900 flex items-start gap-2.5">
                <Lightbulb className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-extrabold">Profit Margin Analysis (&lt;20% Margin):</span>
                  <p className="text-[11px] text-amber-700 mt-0.5">
                    Inaalarma ng AI ang mga paninda na masyadong mababa ang tubo upang mapataas ang kita ng tindahan.
                  </p>
                </div>
              </div>

              {lowMarginProducts.length === 0 ? (
                <div className="text-center py-10 text-slate-500 text-xs font-bold">
                  Maganda ang lahat ng profit margins mo! Walang mababang tubo (&lt;20%).
                </div>
              ) : (
                lowMarginProducts.map((item) => (
                  <div
                    key={item.product.id}
                    className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row gap-3 justify-between sm:items-center"
                  >
                    <div>
                      <h4 className="font-bold text-xs sm:text-sm text-slate-900">{item.product.name}</h4>
                      <div className="flex items-center gap-3 text-[11px] text-slate-500 mt-1">
                        <span>Puhunan: ₱{item.product.costPrice}</span>
                        <span>Benta: ₱{item.product.price}</span>
                        <span className="text-amber-700 font-extrabold">Tubo: ₱{item.profitPerItem} ({item.marginPercent}%)</span>
                      </div>
                    </div>

                    <div className="bg-amber-50 border border-amber-200 rounded-xl p-2 text-right shrink-0">
                      <div className="text-[10px] font-bold text-amber-800 uppercase">AI Recommended Price</div>
                      <div className="text-sm font-black text-amber-900">₱{item.suggestedPrice}.00</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* 3. SMART COMBOS TAB */}
          {activeTab === 'COMBOS' && (
            <div className="space-y-3">
              <div className="bg-emerald-50 border border-emerald-200/80 rounded-2xl p-3 text-xs text-emerald-900 flex items-start gap-2.5">
                <PackageCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-extrabold">Co-Purchased Product Pairings:</span>
                  <p className="text-[11px] text-emerald-700 mt-0.5">
                    Mga produktong madalas pinagsasabay bilhin ng mga customer. I-bundle ang mga ito bilang promo!
                  </p>
                </div>
              </div>

              {topCombos.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs font-bold">
                  Mag-record muna ng higit pang mga benta para ma-analyze ng AI ang combo trends!
                </div>
              ) : (
                topCombos.map((combo, idx) => (
                  <div
                    key={idx}
                    className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-xs flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2 text-xs font-black text-slate-800">
                      <span className="bg-indigo-100 text-indigo-700 w-6 h-6 rounded-lg flex items-center justify-center font-bold text-[10px]">
                        #{idx + 1}
                      </span>
                      <span>{combo.nameA}</span>
                      <span className="text-slate-400">+</span>
                      <span>{combo.nameB}</span>
                    </div>

                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-extrabold px-2.5 py-1 rounded-full">
                      Pinag-isa ng {combo.count} beses
                    </span>
                  </div>
                ))
              )}
            </div>
          )}

          {/* 4. AI CHAT ASSISTANT TAB */}
          {activeTab === 'CHAT' && (
            <div className="flex flex-col h-[350px]">
              <div className="flex-1 overflow-y-auto space-y-3 p-2">
                {chatMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl p-3 text-xs shadow-xs ${
                        msg.sender === 'user'
                          ? 'bg-indigo-600 text-white rounded-br-none'
                          : 'bg-white border border-slate-200 text-slate-800 rounded-bl-none'
                      }`}
                    >
                      <p className="leading-relaxed font-medium">{msg.text}</p>
                      <span
                        className={`text-[9px] block text-right mt-1 ${
                          msg.sender === 'user' ? 'text-indigo-200' : 'text-slate-400'
                        }`}
                      >
                        {msg.timestamp}
                      </span>
                    </div>
                  </div>
                ))}
                {isAiThinking && (
                  <div className="flex justify-start">
                    <div className="bg-white border border-slate-200 text-slate-500 rounded-2xl p-3 text-xs rounded-bl-none flex items-center gap-2">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-purple-600" />
                      <span>Nag-iisip ang AI Advisor...</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Input Form */}
              <form onSubmit={handleSendMessage} className="pt-2 flex gap-2">
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder="Magtanong sa AI tungkol sa tindahan mo..."
                  className="flex-1 px-3.5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <button
                  type="submit"
                  disabled={isAiThinking}
                  className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shadow-md shadow-purple-100 flex items-center justify-center shrink-0 active:scale-95 transition-all disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-slate-100 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-colors"
          >
            Isara Assistant
          </button>
        </div>
      </div>
    </div>
  );
};
