import React, { useState } from 'react';
import { Lock, Delete, X, ShieldAlert, KeyRound } from 'lucide-react';
import { verifyAdminPin, getAdminPin } from '../utils/storage';

interface PinModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  title?: string;
  subtitle?: string;
}

export const PinModal: React.FC<PinModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  title = 'Admin Protection PIN Required',
  subtitle = 'I-enter ang 4-digit PIN ng Admin para mag-proceed.',
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const [attempts, setAttempts] = useState(0);

  if (!isOpen) return null;

  const handleKeyPress = (num: string) => {
    if (pin.length < 4) {
      const nextPin = pin + num;
      setPin(nextPin);
      setError(false);

      if (nextPin.length === 4) {
        // Auto-verify when 4 digits reached
        setTimeout(() => {
          if (verifyAdminPin(nextPin)) {
            setPin('');
            setError(false);
            onSuccess();
          } else {
            setError(true);
            setAttempts((prev) => prev + 1);
            setPin('');
          }
        }, 150);
      }
    }
  };

  const handleDelete = () => {
    setPin((prev) => prev.slice(0, -1));
    setError(false);
  };

  const handleClear = () => {
    setPin('');
    setError(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-xs bg-white border border-slate-200/80 rounded-3xl shadow-2xl overflow-hidden p-6 text-center animate-in fade-in zoom-in-95 duration-200 relative">
        {/* Header */}
        <div className="flex justify-between items-start mb-4">
          <div className="w-10 h-10 rounded-full bg-indigo-50 border border-indigo-100 flex items-center justify-center mx-auto text-indigo-600">
            <Lock className="w-5 h-5" />
          </div>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-slate-400 hover:text-slate-800 p-1 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <h3 className="text-base font-bold text-slate-900">{title}</h3>
        <p className="text-xs text-slate-500 mt-1 mb-5">{subtitle}</p>

        {/* 4 Pin Circles */}
        <div className="flex justify-center items-center gap-3 mb-6">
          {[0, 1, 2, 3].map((idx) => {
            const isFilled = pin.length > idx;
            return (
              <div
                key={idx}
                className={`w-4 h-4 rounded-full transition-all duration-200 ${
                  error
                    ? 'bg-rose-500 ring-4 ring-rose-500/20 animate-shake'
                    : isFilled
                    ? 'bg-indigo-600 scale-110 shadow-md shadow-indigo-200'
                    : 'bg-slate-100 border border-slate-300'
                }`}
              />
            );
          })}
        </div>

        {error && (
          <div className="flex items-center justify-center gap-1.5 text-xs text-rose-600 bg-rose-50 border border-rose-200 py-1.5 px-3 rounded-xl mb-4">
            <ShieldAlert className="w-3.5 h-3.5 flex-shrink-0" />
            <span>Maling PIN! Subukang muli. (Default: 1234)</span>
          </div>
        )}

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-2.5 max-w-[210px] mx-auto mb-2">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
            <button
              key={num}
              onClick={() => handleKeyPress(num)}
              className="h-12 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-800 text-lg font-bold border border-slate-200 active:scale-95 transition-all flex items-center justify-center shadow-xs"
            >
              {num}
            </button>
          ))}
          <button
            onClick={handleClear}
            className="h-12 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 text-xs font-semibold border border-slate-200 active:scale-95 transition-all flex items-center justify-center"
          >
            Clear
          </button>
          <button
            onClick={() => handleKeyPress('0')}
            className="h-12 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-800 text-lg font-bold border border-slate-200 active:scale-95 transition-all flex items-center justify-center shadow-xs"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="h-12 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-bold border border-slate-200 active:scale-95 transition-all flex items-center justify-center"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        <p className="text-[11px] text-slate-400 mt-3">
          Default Admin PIN: <code className="bg-slate-100 px-1.5 py-0.5 rounded text-indigo-600 font-mono font-bold">1234</code>
        </p>
      </div>
    </div>
  );
};
