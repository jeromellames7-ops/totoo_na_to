import React, { useState, useEffect, useRef } from 'react';
import {
  ElectricBillRecord,
  WaterBillRecord,
  GasStoveLpgRecord,
  MenstruationCycleRecord,
  PillMonitoringPlan,
  UserAccount,
} from '../types';
import {
  getLocalElectricBills,
  saveElectricBillToDb,
  deleteElectricBillFromDb,
  getLocalWaterBills,
  saveWaterBillToDb,
  deleteWaterBillFromDb,
  getLocalGasRecords,
  saveGasRecordToDb,
  deleteGasRecordFromDb,
  getLocalMenstruationRecords,
  saveMenstruationRecordToDb,
  deleteMenstruationRecordFromDb,
  getLocalPillPlan,
  savePillPlanToDb,
  deletePillPlanFromDb,
  recordPillTaken,
  deletePillLog,
  syncAllHomeMonitoringFromFirestore,
} from '../utils/homeMonitoringStorage';
import {
  playSuccessChime,
  playWarningBeep,
  playLpgDueAlarm,
  playPillReminderAlarm,
} from '../utils/sound';
import {
  requestNotificationPermission,
  showSystemNotification,
  getNotificationPermissionStatus,
  calculateOneMonthDueDate,
  getLpgDaysRemaining,
} from '../utils/notificationHelper';
import { ReleaseDataButton } from './ReleaseDataButton';
import {
  Zap,
  Droplets,
  Flame,
  Heart,
  Pill,
  Plus,
  Trash2,
  CheckCircle,
  Clock,
  AlertTriangle,
  Calendar,
  DollarSign,
  TrendingUp,
  ShieldCheck,
  Phone,
  RefreshCw,
  Eye,
  EyeOff,
  LogOut,
  Bell,
  BellRing,
  Sparkles,
  Volume2,
  Check,
  RotateCcw,
  Play,
} from 'lucide-react';

interface HomeMonitoringProps {
  activeUser: UserAccount;
  onBackToPortal: () => void;
}

type TabType = 'electric' | 'water' | 'gas' | 'pills' | 'menstruation';

export const HomeMonitoring: React.FC<HomeMonitoringProps> = ({ activeUser, onBackToPortal }) => {
  const [activeTab, setActiveTab] = useState<TabType>('electric');

  // Datasets (Default 0 records)
  const [electricBills, setElectricBills] = useState<ElectricBillRecord[]>([]);
  const [waterBills, setWaterBills] = useState<WaterBillRecord[]>([]);
  const [gasRecords, setGasRecords] = useState<GasStoveLpgRecord[]>([]);
  const [mensRecords, setMensRecords] = useState<MenstruationCycleRecord[]>([]);
  const [pillPlan, setPillPlan] = useState<PillMonitoringPlan | null>(null);

  // Modals
  const [isAddElectricModalOpen, setIsAddElectricModalOpen] = useState(false);
  const [isAddWaterModalOpen, setIsAddWaterModalOpen] = useState(false);
  const [isAddGasModalOpen, setIsAddGasModalOpen] = useState(false);
  const [isAddMensModalOpen, setIsAddMensModalOpen] = useState(false);
  const [isStartPillsModalOpen, setIsStartPillsModalOpen] = useState(false);
  const [isPrivacyProtected, setIsPrivacyProtected] = useState(false);

  // Notification Status
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>('default');
  const [activeAlertBanner, setActiveAlertBanner] = useState<{
    title: string;
    message: string;
    type: 'gas' | 'pill';
    timestamp: number;
  } | null>(null);
  const [alertBannerProgress, setAlertBannerProgress] = useState<number>(100);
  const alertBannerTimerRef = useRef<NodeJS.Timeout | null>(null);
  const alertBannerIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Helper to show alert banner for exactly 5 seconds (5000ms) with countdown
  const triggerAlertBanner = (title: string, message: string, type: 'gas' | 'pill') => {
    if (alertBannerTimerRef.current) clearTimeout(alertBannerTimerRef.current);
    if (alertBannerIntervalRef.current) clearInterval(alertBannerIntervalRef.current);

    const startTime = Date.now();
    setActiveAlertBanner({ title, message, type, timestamp: startTime });
    setAlertBannerProgress(100);

    alertBannerIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remainingPct = Math.max(0, 100 - (elapsed / 5000) * 100);
      setAlertBannerProgress(remainingPct);
    }, 50);

    alertBannerTimerRef.current = setTimeout(() => {
      setActiveAlertBanner(null);
      if (alertBannerIntervalRef.current) clearInterval(alertBannerIntervalRef.current);
    }, 5000);
  };

  // Notification / Alarm Checker Interval Ref
  const lastCheckedMinuteRef = useRef<string>('');

  // Initial Load & DB Sync
  useEffect(() => {
    setNotifPermission(getNotificationPermissionStatus());
    syncAllHomeMonitoringFromFirestore().then(() => {
      setElectricBills(getLocalElectricBills());
      setWaterBills(getLocalWaterBills());
      setGasRecords(getLocalGasRecords());
      setMensRecords(getLocalMenstruationRecords());
      setPillPlan(getLocalPillPlan());
    });
  }, []);

  // Request Notification Permission Handler
  const handleEnableNotifications = async () => {
    const perm = await requestNotificationPermission();
    setNotifPermission(perm);
    if (perm === 'granted') {
      playSuccessChime();
      showSystemNotification('🔔 Notifications Activated!', {
        body: 'Naka-enable na ang notifications para sa Gasul 1-Month Expiry at 7:00 PM Pill Reminder!',
        playSound: 'pill',
      });
    }
  };

  // Cleanup alert timers on unmount
  useEffect(() => {
    return () => {
      if (alertBannerTimerRef.current) clearTimeout(alertBannerTimerRef.current);
      if (alertBannerIntervalRef.current) clearInterval(alertBannerIntervalRef.current);
    };
  }, []);

  // =========================================================================
  // ELECTRIC BILL FORM STATE & HANDLERS
  // =========================================================================
  const [elecMonth, setElecMonth] = useState('September 2026');
  const [elecPrevReading, setElecPrevReading] = useState(0);
  const [elecCurrentReading, setElecCurrentReading] = useState(0);
  const [elecRate, setElecRate] = useState(12.0);
  const [elecDueDate, setElecDueDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [elecNotes, setElecNotes] = useState('');

  const handleAddElectricBill = async (e: React.FormEvent) => {
    e.preventDefault();
    const usedKwh = Math.max(0, elecCurrentReading - elecPrevReading);
    const totalAmt = Number((usedKwh * elecRate).toFixed(2));

    const newRecord: ElectricBillRecord = {
      id: `elec_${Date.now()}`,
      billingMonth: elecMonth,
      prevReadingKwh: Number(elecPrevReading),
      currentReadingKwh: Number(elecCurrentReading),
      totalKwhUsed: usedKwh,
      ratePerKwh: Number(elecRate),
      totalBillAmount: totalAmt,
      dueDate: elecDueDate,
      isPaid: false,
      notes: elecNotes,
      createdAt: new Date().toISOString(),
    };

    await saveElectricBillToDb(newRecord);
    setElectricBills(getLocalElectricBills());
    setIsAddElectricModalOpen(false);
    playSuccessChime();
  };

  const handleToggleElectricPaid = async (bill: ElectricBillRecord) => {
    const updated: ElectricBillRecord = {
      ...bill,
      isPaid: !bill.isPaid,
      paidDate: !bill.isPaid ? new Date().toISOString().split('T')[0] : undefined,
    };
    await saveElectricBillToDb(updated);
    setElectricBills(getLocalElectricBills());
    playSuccessChime();
  };

  const handleDeleteElectric = async (id: string) => {
    if (!confirm('Sigurado ka bang nais mong tanggalin ang bill record na ito?')) return;
    await deleteElectricBillFromDb(id);
    setElectricBills(getLocalElectricBills());
  };

  // =========================================================================
  // WATER BILL FORM STATE & HANDLERS
  // =========================================================================
  const [waterMonth, setWaterMonth] = useState('September 2026');
  const [waterPrevReading, setWaterPrevReading] = useState(0);
  const [waterCurrentReading, setWaterCurrentReading] = useState(0);
  const [waterRate, setWaterRate] = useState(29.0);
  const [waterDueDate, setWaterDueDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [waterNotes, setWaterNotes] = useState('');

  const handleAddWaterBill = async (e: React.FormEvent) => {
    e.preventDefault();
    const usedCuM = Math.max(0, waterCurrentReading - waterPrevReading);
    const totalAmt = Number((usedCuM * waterRate).toFixed(2));

    const newRecord: WaterBillRecord = {
      id: `water_${Date.now()}`,
      billingMonth: waterMonth,
      prevReadingCuM: Number(waterPrevReading),
      currentReadingCuM: Number(waterCurrentReading),
      totalCuMUsed: usedCuM,
      ratePerCuM: Number(waterRate),
      totalBillAmount: totalAmt,
      dueDate: waterDueDate,
      isPaid: false,
      notes: waterNotes,
      createdAt: new Date().toISOString(),
    };

    await saveWaterBillToDb(newRecord);
    setWaterBills(getLocalWaterBills());
    setIsAddWaterModalOpen(false);
    playSuccessChime();
  };

  const handleToggleWaterPaid = async (bill: WaterBillRecord) => {
    const updated: WaterBillRecord = {
      ...bill,
      isPaid: !bill.isPaid,
      paidDate: !bill.isPaid ? new Date().toISOString().split('T')[0] : undefined,
    };
    await saveWaterBillToDb(updated);
    setWaterBills(getLocalWaterBills());
    playSuccessChime();
  };

  const handleDeleteWater = async (id: string) => {
    if (!confirm('Sigurado ka bang nais mong tanggalin ang water bill record na ito?')) return;
    await deleteWaterBillFromDb(id);
    setWaterBills(getLocalWaterBills());
  };

  // =========================================================================
  // GAS STOVE / LPG TANK HANDLERS (With 1-Month Auto Countdown & Alerts)
  // =========================================================================
  const [gasBrand, setGasBrand] = useState('Petron Gasul');
  const [gasPurchaseDate, setGasPurchaseDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [gasCapacity, setGasCapacity] = useState(11);
  const [gasCost, setGasCost] = useState(980);
  const [gasDailyHours, setGasDailyHours] = useState(1.5);
  const [gasSupplier, setGasSupplier] = useState('0917-889-1234 (Kuya Jun LPG)');
  const [gasNotes, setGasNotes] = useState('');

  const handleAddGasRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    const calculatedDueDate = calculateOneMonthDueDate(gasPurchaseDate);
    const daysEst = Math.round((gasCapacity * 5) / (gasDailyHours || 1));

    const newRecord: GasStoveLpgRecord = {
      id: `gas_${Date.now()}`,
      brand: gasBrand,
      purchaseDate: gasPurchaseDate,
      tankCapacityKg: Number(gasCapacity),
      tareWeightKg: 13.5,
      currentLevelPercent: 100,
      installedDate: gasPurchaseDate,
      dueDate: calculatedDueDate, // Exact 1-month from purchase date
      cost: Number(gasCost),
      dailyHoursUsed: Number(gasDailyHours),
      estimatedDaysRemaining: daysEst,
      isSafetyChecked: true,
      lastSafetyCheckDate: gasPurchaseDate,
      supplierContact: gasSupplier,
      notes: gasNotes,
      updatedAt: new Date().toISOString(),
    };

    await saveGasRecordToDb(newRecord);
    setGasRecords(getLocalGasRecords());
    setIsAddGasModalOpen(false);
    playSuccessChime();

    // Show initial confirmation
    showSystemNotification('🔥 Bagong Gasul Naitala!', {
      body: `${newRecord.brand} (Binili: ${newRecord.purchaseDate}) - Awtomatikong magbibilang ng 1 buwan hanggang ${calculatedDueDate}!`,
      playSound: 'none',
    });
  };

  const handleUpdateGasLevel = async (record: GasStoveLpgRecord, newLevel: number) => {
    const updated: GasStoveLpgRecord = {
      ...record,
      currentLevelPercent: newLevel,
      updatedAt: new Date().toISOString(),
    };
    await saveGasRecordToDb(updated);
    setGasRecords(getLocalGasRecords());
  };

  const handleDeleteGas = async (id: string) => {
    if (!confirm('Tanggalin ang Gasul record na ito?')) return;
    await deleteGasRecordFromDb(id);
    setGasRecords(getLocalGasRecords());
  };

  const handleTestGasAlarm = (gas: GasStoveLpgRecord) => {
    playLpgDueAlarm();
    showSystemNotification('🔥 [TEST] Gasul 1-Month Due Alert!', {
      body: `Testing Alert: Ang iyong ${gas.brand} ay umabot na sa 1 buwan!`,
      playSound: 'lpg',
    });
    triggerAlertBanner(
      '🔥 Test Gasul 1-Month Alarm',
      `Tumunog at nag-notif na ang 1-month alert para sa ${gas.brand}!`,
      'gas'
    );
  };

  // =========================================================================
  // PILLS MONITORING PLAN HANDLERS (7:00 PM Daily Reminder & Counter)
  // =========================================================================
  const [pillBrandName, setPillBrandName] = useState('Trust Pill');
  const [pillPackType, setPillPackType] = useState<'28_day' | '21_day'>('28_day');
  const [pillStartDate, setPillStartDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [pillReminderTime, setPillReminderTime] = useState('19:00'); // 7:00 PM

  const handleStartPillsPlan = async (e: React.FormEvent) => {
    e.preventDefault();
    const totalPills = pillPackType === '28_day' ? 28 : 21;

    const newPlan: PillMonitoringPlan = {
      id: `pill_plan_${Date.now()}`,
      isActive: true,
      pillBrand: pillBrandName,
      packType: pillPackType,
      startDate: pillStartDate,
      reminderTime: pillReminderTime,
      totalPillsInPack: totalPills,
      currentPillIndex: 1,
      totalPillsTaken: 0,
      streakDays: 0,
      logs: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await savePillPlanToDb(newPlan);
    setPillPlan(newPlan);
    setIsStartPillsModalOpen(false);
    playPillReminderAlarm();

    showSystemNotification('💊 Pills Monitoring Sinimulan!', {
      body: `Aktibo na ang ${newPlan.pillBrand} (${totalPills} Pills). Awtomatikong tutunog at magno-notif araw-araw tuwing ${pillReminderTime === '19:00' ? '7:00 PM' : pillReminderTime}!`,
      playSound: 'pill',
    });
  };

  const handleManualMarkPillTaken = () => {
    if (!pillPlan) return;
    const todayStr = new Date().toISOString().split('T')[0];
    const alreadyTakenToday = pillPlan.logs.some((l) => l.date === todayStr && l.taken);

    if (alreadyTakenToday) {
      playSuccessChime();
      showSystemNotification('💊 Na-check na ang Pill!', {
        body: 'Nainom na ang pill para sa araw na ito. 1 pill lamang bawat araw!',
        playSound: 'pill',
      });
      return;
    }

    playSuccessChime();
    const updated = recordPillTaken(pillPlan, false, 'Manually marked as taken');
    setPillPlan(updated);
  };

  const handleTestPillReminder = () => {
    if (!pillPlan) return;
    playPillReminderAlarm();

    const todayStr = new Date().toISOString().split('T')[0];
    const alreadyTakenToday = pillPlan.logs.some((l) => l.date === todayStr && l.taken);

    if (alreadyTakenToday) {
      showSystemNotification('💊 [TEST] 7:00 PM Daily Pill Alarm!', {
        body: `Tumunog ang 7:00 PM alarm! (Paalala: Na-check na ang pill para sa araw na ito kaya hindi na idodoble ang bilang).`,
        playSound: 'pill',
      });
      triggerAlertBanner(
        '💊 Test 7:00 PM Alarm Triggered',
        `Tumunog ang paalala! Na-check na ang pill ngayong araw (1 pill kada araw).`,
        'pill'
      );
      return;
    }

    showSystemNotification('💊 [TEST] 7:00 PM Daily Pill Alarm!', {
      body: `Testing Reminder: Oras na uminom ng iyong ${pillPlan.pillBrand} (Pill #${pillPlan.currentPillIndex})!`,
      playSound: 'pill',
    });
    // Auto count test
    const updated = recordPillTaken(pillPlan, true, 'Test 7:00 PM reminder triggered');
    setPillPlan(updated);
    triggerAlertBanner(
      '💊 Test 7:00 PM Alarm Triggered',
      `Tumunog at awtomatikong naitala ang Pill #${pillPlan.currentPillIndex} sa bilang ng iniinom na pills!`,
      'pill'
    );
  };

  const handleDeletePillLog = async (logId: string, pillNumber: number, logDate: string) => {
    if (!pillPlan) return;
    if (!confirm(`Nais mo bang burahin ang naitalang record para sa Pill #${pillNumber} (${logDate})?`)) return;

    const updated = deletePillLog(pillPlan, logId);
    setPillPlan(updated);
    playSuccessChime();
    showSystemNotification('🗑️ Nabura ang Pill Log', {
      body: `Matagumpay na nabura ang Pill #${pillNumber} sa monitoring.`,
    });
  };

  const handleUndoTodayPill = async () => {
    if (!pillPlan) return;
    const todayStr = new Date().toISOString().split('T')[0];
    const todayLog = pillPlan.logs.find((l) => l.date === todayStr && l.taken);
    if (!todayLog) return;

    if (!confirm('Nais mo bang i-undo o burahin ang pag-check ng Pill para sa araw na ito?')) return;
    const updated = deletePillLog(pillPlan, todayLog.id);
    setPillPlan(updated);
    playSuccessChime();
  };

  const handleResetPillsPlan = async () => {
    if (!confirm('Sigurado ka bang nais mong i-delete at linisin ang lahat ng data sa Pills Monitoring?')) return;
    if (pillPlan) {
      await deletePillPlanFromDb(pillPlan.id);
      setPillPlan(null);
      playSuccessChime();
      showSystemNotification('🗑️ Nabura ang Lahat ng Pills Data', {
        body: 'Matagumpay na nabura ang buong pill plan at monitoring records.',
      });
    }
  };

  // =========================================================================
  // MENSTRUATION TRACKER HANDLERS
  // =========================================================================
  const [mensStartDate, setMensStartDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [mensCycleLength, setMensCycleLength] = useState(28);
  const [mensPeriodDuration, setMensPeriodDuration] = useState(5);
  const [mensFlow, setMensFlow] = useState<'Light' | 'Medium' | 'Heavy' | 'Spotting'>('Medium');
  const [mensCramps, setMensCramps] = useState<'None' | 'Mild' | 'Moderate' | 'Severe'>('Mild');
  const [mensMood, setMensMood] = useState<
    'Normal' | 'Happy' | 'Tired' | 'Irritable' | 'Emotional' | 'Anxious' | 'Energetic'
  >('Normal');
  const [mensSymptoms, setMensSymptoms] = useState<string[]>(['Mild Cramps']);
  const [mensNotes, setMensNotes] = useState('');

  const toggleSymptom = (sym: string) => {
    if (mensSymptoms.includes(sym)) {
      setMensSymptoms(mensSymptoms.filter((s) => s !== sym));
    } else {
      setMensSymptoms([...mensSymptoms, sym]);
    }
  };

  const handleAddMensRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    const newRecord: MenstruationCycleRecord = {
      id: `mens_${Date.now()}`,
      startDate: mensStartDate,
      cycleLengthDays: Number(mensCycleLength),
      periodDurationDays: Number(mensPeriodDuration),
      flow: mensFlow,
      cramps: mensCramps,
      mood: mensMood,
      symptoms: mensSymptoms,
      notes: mensNotes,
      createdAt: new Date().toISOString(),
    };

    await saveMenstruationRecordToDb(newRecord);
    setMensRecords(getLocalMenstruationRecords());
    setIsAddMensModalOpen(false);
    playSuccessChime();
  };

  const handleDeleteMens = async (id: string) => {
    if (!confirm('Tanggalin ang cycle record na ito?')) return;
    await deleteMenstruationRecordFromDb(id);
    setMensRecords(getLocalMenstruationRecords());
  };

  // Compute Next Period Prediction from latest record
  const latestMens = mensRecords[0];
  let nextPeriodDateString = 'None';
  let daysUntilNextPeriod = 0;
  if (latestMens && latestMens.startDate) {
    const start = new Date(latestMens.startDate);
    const nextDate = new Date(start);
    nextDate.setDate(start.getDate() + (latestMens.cycleLengthDays || 28));
    nextPeriodDateString = nextDate.toISOString().split('T')[0];

    const today = new Date();
    const diffMs = nextDate.getTime() - today.getTime();
    daysUntilNextPeriod = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
  }

  const todayDateStr = new Date().toISOString().split('T')[0];
  const isPillTakenToday = pillPlan?.logs.some((l) => l.date === todayDateStr && l.taken) ?? false;

  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col select-none">
      {/* ACTIVE NOTIFICATION ALERT BANNER (5 Seconds Extended Reminder) */}
      {activeAlertBanner && (
        <div className="relative overflow-hidden bg-gradient-to-r from-orange-600 via-pink-600 to-emerald-600 text-white px-4 py-2.5 flex items-center justify-between text-xs font-bold shadow-xl">
          <div className="flex items-center gap-2 z-10">
            <BellRing className="w-4 h-4 animate-bounce shrink-0" />
            <span>
              <strong>{activeAlertBanner.title}:</strong> {activeAlertBanner.message}
            </span>
          </div>
          <div className="flex items-center gap-2 z-10">
            <span className="text-[10px] bg-black/40 px-2 py-0.5 rounded-full font-mono font-bold">
              ⏱ 5s Reminder
            </span>
            <button
              onClick={() => {
                setActiveAlertBanner(null);
                if (alertBannerTimerRef.current) clearTimeout(alertBannerTimerRef.current);
                if (alertBannerIntervalRef.current) clearInterval(alertBannerIntervalRef.current);
              }}
              className="px-2.5 py-1 rounded-lg bg-black/40 hover:bg-black/60 active:scale-95 text-[11px] font-bold transition-all cursor-pointer"
            >
              I-dismiss (✕)
            </button>
          </div>
          {/* 5-second animated progress bar */}
          <div
            className="absolute bottom-0 left-0 h-1 bg-white/70 transition-all ease-linear"
            style={{ width: `${alertBannerProgress}%`, transitionDuration: '50ms' }}
          />
        </div>
      )}

      {/* HEADER */}
      <header className="px-4 sm:px-6 py-4 bg-slate-900 border-b border-emerald-500/20 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToPortal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black transition-all border border-rose-500 shadow-md shadow-rose-600/20 active:scale-95 cursor-pointer group"
            title="EXIT: Bumalik sa Front Page (Main Hub)"
          >
            <LogOut className="w-4 h-4 text-white group-hover:-translate-x-0.5 transition-transform" />
            <span className="uppercase tracking-wider">EXIT</span>
          </button>
          <div>
            <h1 className="text-base sm:text-lg font-extrabold text-white flex items-center gap-2">
              HOME & FAMILY MONITORING
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Live Sync
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Kuryente, Tubig, Gasul (1-Month Auto Alarm), at 7:00 PM Pills Tracker
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {notifPermission !== 'granted' && (
            <button
              onClick={handleEnableNotifications}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-orange-500/20 animate-pulse"
              title="I-activate ang outside-app sound notifications"
            >
              <Bell className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Enable Sound Notifications</span>
            </button>
          )}

          {/* RELEASE DATA TO DESKTOP BUTTON */}
          <ReleaseDataButton variant="header" accountId={activeUser.id} />

          <button
            onClick={() => {
              syncAllHomeMonitoringFromFirestore();
              setElectricBills(getLocalElectricBills());
              setWaterBills(getLocalWaterBills());
              setGasRecords(getLocalGasRecords());
              setMensRecords(getLocalMenstruationRecords());
              setPillPlan(getLocalPillPlan());
            }}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 border border-slate-700"
            title="Refresh from Firebase"
          >
            <RefreshCw className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">Sync DB</span>
          </button>
        </div>
      </header>

      {/* 5 NAVIGATION TABS */}
      <div className="px-4 sm:px-6 py-3 bg-slate-900/60 border-b border-slate-800 flex items-center gap-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('electric')}
          className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all whitespace-nowrap ${
            activeTab === 'electric'
              ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <Zap className="w-4 h-4" />
          <span>Electric Bill ({electricBills.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('water')}
          className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all whitespace-nowrap ${
            activeTab === 'water'
              ? 'bg-sky-500 text-slate-950 shadow-lg shadow-sky-500/30'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <Droplets className="w-4 h-4" />
          <span>Water Bill ({waterBills.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('gas')}
          className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all whitespace-nowrap ${
            activeTab === 'gas'
              ? 'bg-orange-500 text-slate-950 shadow-lg shadow-orange-500/30'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <Flame className="w-4 h-4" />
          <span>Gasul / LPG 1-Month ({gasRecords.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('pills')}
          className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all whitespace-nowrap ${
            activeTab === 'pills'
              ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/30'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <Pill className="w-4 h-4" />
          <span>💊 Pills Monitoring (7:00 PM Alarm)</span>
          {pillPlan && pillPlan.isActive && (
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('menstruation')}
          className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all whitespace-nowrap ${
            activeTab === 'menstruation'
              ? 'bg-pink-500 text-slate-950 shadow-lg shadow-pink-500/30'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>Menstruation Tracker ({mensRecords.length})</span>
        </button>
      </div>

      {/* TAB CONTENT AREA */}
      <main className="flex-1 p-4 sm:p-6 max-w-6xl w-full mx-auto overflow-y-auto">
        {/* =========================================================================
            TAB 1: ELECTRIC BILL TRACKER (Clean 0 Default)
        ========================================================================= */}
        {activeTab === 'electric' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Zap className="w-5 h-5 text-amber-400" />
                  Kuryente / Electric Bill Tracker (kWh)
                </h2>
                <p className="text-xs text-slate-400">
                  Subaybayan ang konsumo ng kuryente at submeter readings (0 Default Records)
                </p>
              </div>

              <button
                onClick={() => setIsAddElectricModalOpen(true)}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-amber-500/20"
              >
                <Plus className="w-4 h-4" />
                <span>Mag-add ng Bagong Electric Bill</span>
              </button>
            </div>

            {/* Table */}
            <div className="rounded-3xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
              <div className="p-4 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
                <h3 className="font-bold text-sm text-white">Kasaysayan ng mga Bills</h3>
                <span className="text-xs text-slate-400">{electricBills.length} Naitalang Records</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase font-semibold">
                    <tr>
                      <th className="py-3 px-4">Buwan</th>
                      <th className="py-3 px-4">Metro (Prev → Curr)</th>
                      <th className="py-3 px-4">Konsumo</th>
                      <th className="py-3 px-4">Rate</th>
                      <th className="py-3 px-4">Kabuuang Bayarin</th>
                      <th className="py-3 px-4">Due Date</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {electricBills.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-12 text-center text-slate-500">
                          <Zap className="w-8 h-8 mx-auto mb-2 opacity-30 text-amber-400" />
                          <span>Walang electric bill records (0 laman). Pindutin ang "Mag-add ng Bagong Electric Bill" upang magsimula.</span>
                        </td>
                      </tr>
                    ) : (
                      electricBills.map((bill) => (
                        <tr key={bill.id} className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3 px-4 font-bold text-white">{bill.billingMonth}</td>
                          <td className="py-3 px-4 font-mono text-slate-300">
                            {bill.prevReadingKwh} → {bill.currentReadingKwh}
                          </td>
                          <td className="py-3 px-4 font-bold text-amber-300">{bill.totalKwhUsed} kWh</td>
                          <td className="py-3 px-4 font-mono text-slate-400">₱{bill.ratePerKwh}</td>
                          <td className="py-3 px-4 font-black text-emerald-400 text-sm">
                            ₱{bill.totalBillAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="py-3 px-4 text-slate-400">{bill.dueDate}</td>
                          <td className="py-3 px-4">
                            <button
                              onClick={() => handleToggleElectricPaid(bill)}
                              className={`px-2.5 py-1 rounded-full font-bold text-[10px] flex items-center gap-1 ${
                                bill.isPaid
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
                              }`}
                            >
                              {bill.isPaid ? <CheckCircle className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                              <span>{bill.isPaid ? 'PAID' : 'MARK PAID'}</span>
                            </button>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <button
                              onClick={() => handleDeleteElectric(bill.id)}
                              className="p-1.5 rounded-lg text-red-400 hover:bg-red-500/20 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 2: WATER BILL TRACKER (Clean 0 Default)
        ========================================================================= */}
        {activeTab === 'water' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Droplets className="w-5 h-5 text-sky-400" />
                  Tubig / Water Bill Tracker (m³)
                </h2>
                <p className="text-xs text-slate-400">
                  Subaybayan ang metro at konsumo ng tubig (0 Default Records)
                </p>
              </div>

              <button
                onClick={() => setIsAddWaterModalOpen(true)}
                className="px-4 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-sky-500/20"
              >
                <Plus className="w-4 h-4" />
                <span>Mag-add ng Bagong Water Bill</span>
              </button>
            </div>

            {/* Table */}
            <div className="rounded-3xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
              <div className="p-4 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
                <h3 className="font-bold text-sm text-white">Kasaysayan ng Water Bills</h3>
                <span className="text-xs text-slate-400">{waterBills.length} Naitalang Records</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase font-semibold">
                    <tr>
                      <th className="py-3 px-4">Buwan</th>
                      <th className="py-3 px-4">Metro (Prev → Curr)</th>
                      <th className="py-3 px-4">Konsumo</th>
                      <th className="py-3 px-4">Rate</th>
                      <th className="py-3 px-4">Kabuuang Bayarin</th>
                      <th className="py-3 px-4">Due Date</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {waterBills.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-12 text-center text-slate-500">
                          <Droplets className="w-8 h-8 mx-auto mb-2 opacity-30 text-sky-400" />
                          <span>Walang water bill records (0 laman). Pindutin ang "Mag-add ng Bagong Water Bill" upang mag-log.</span>
                        </td>
                      </tr>
                    ) : (
                      waterBills.map((bill) => (
                        <tr key={bill.id} className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3 px-4 font-bold text-white">{bill.billingMonth}</td>
                          <td className="py-3 px-4 font-mono text-slate-300">
                            {bill.prevReadingCuM} → {bill.currentReadingCuM}
                          </td>
                          <td className="py-3 px-4 font-bold text-sky-300">{bill.totalCuMUsed} m³</td>
                          <td className="py-3 px-4 font-mono text-slate-400">₱{bill.ratePerCuM}</td>
                          <td className="py-3 px-4 font-black text-emerald-400 text-sm">
                            ₱{bill.totalBillAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </td>
                          <td className="py-3 px-4 text-slate-400">{bill.dueDate}</td>
                          <td className="py-3 px-4">
                            <button
                              onClick={() => handleToggleWaterPaid(bill)}
                              className={`px-2.5 py-1 rounded-full font-bold text-[10px] flex items-center gap-1 ${
                                bill.isPaid
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                  : 'bg-sky-500/20 text-sky-300 border border-sky-500/30 animate-pulse'
                              }`}
                            >
                              {bill.isPaid ? <CheckCircle className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                              <span>{bill.isPaid ? 'PAID' : 'MARK PAID'}</span>
                            </button>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <button
                              onClick={() => handleDeleteWater(bill.id)}
                              className="p-1.5 rounded-lg text-red-400 hover:bg-red-500/20 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 3: GAS STOVE / LPG TANK (With Automatic 1-Month Countdown & Alarm)
        ========================================================================= */}
        {activeTab === 'gas' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Flame className="w-5 h-5 text-orange-400" />
                  Gasul / LPG Tank Monitor (1-Month Auto Countdown & Audio Alarm)
                </h2>
                <p className="text-xs text-slate-400">
                  I-enter ang petsa ng pagbili ng Gasul. Awtomatikong magbibilang ng 1 buwan at tutunog kapag expired o due na!
                </p>
              </div>

              <button
                onClick={() => setIsAddGasModalOpen(true)}
                className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-orange-500/20"
              >
                <Plus className="w-4 h-4" />
                <span>Mag-add ng Bagong Gasul (Set Date Bought)</span>
              </button>
            </div>

            {/* Active LPG Tanks Grid */}
            {gasRecords.length === 0 ? (
              <div className="p-12 rounded-3xl bg-slate-900 border border-slate-800 text-center text-slate-500">
                <Flame className="w-12 h-12 mx-auto mb-3 text-orange-400/40" />
                <h3 className="text-base font-bold text-slate-300">Walang Gasul Tank Record (0 Laman)</h3>
                <p className="text-xs text-slate-500 mt-1 mb-4">
                  Mag-add ng date kung kailan mo binili ang Gasul upang awtomatikong magsimula ang 1-month countdown at alarm notification.
                </p>
                <button
                  onClick={() => setIsAddGasModalOpen(true)}
                  className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-400 text-slate-950 font-bold text-xs inline-flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>I-log ang Petsa ng Pagbili ng Gasul</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {gasRecords.map((tank) => {
                  const countdown = getLpgDaysRemaining(tank.purchaseDate, tank.dueDate);
                  return (
                    <div
                      key={tank.id}
                      className={`p-5 rounded-3xl bg-slate-900 border transition-all shadow-xl relative overflow-hidden flex flex-col justify-between ${
                        countdown.isDue
                          ? 'border-red-500 ring-2 ring-red-500/40 bg-gradient-to-br from-red-950/40 to-slate-900'
                          : 'border-slate-800'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <h3 className="text-lg font-bold text-white flex items-center gap-2">
                              {tank.brand}
                              {countdown.isDue && (
                                <span className="px-2 py-0.5 rounded-full bg-red-600 text-white font-bold text-[10px] animate-pulse">
                                  ⚠️ 1-MONTH DUE / EXPIRED!
                                </span>
                              )}
                            </h3>
                            <p className="text-xs text-slate-400">
                              {tank.tankCapacityKg} kg Tank Capacity • Refill: ₱{tank.cost}
                            </p>
                          </div>
                          <button
                            onClick={() => handleTestGasAlarm(tank)}
                            className="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-orange-300 font-bold text-[10px] border border-orange-500/30 flex items-center gap-1"
                            title="Test Sound & Notification Alert"
                          >
                            <Volume2 className="w-3.5 h-3.5 text-orange-400" />
                            <span>Test Alarm</span>
                          </button>
                        </div>

                        {/* 1-MONTH AUTOMATIC COUNTDOWN BAR */}
                        <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 mb-4 space-y-2">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-slate-400 font-bold flex items-center gap-1.5">
                              <Clock className="w-3.5 h-3.5 text-orange-400" />
                              1-Month Countdown:
                            </span>
                            <span
                              className={`font-black text-sm font-mono ${
                                countdown.isDue
                                  ? 'text-red-400 animate-pulse'
                                  : countdown.daysRemaining <= 5
                                  ? 'text-amber-400'
                                  : 'text-emerald-400'
                              }`}
                            >
                              {countdown.isDue
                                ? '🚨 1-Month Reached (Dapat palitan na!)'
                                : `${countdown.daysRemaining} Araw Natitira sa 1 Buwan`}
                            </span>
                          </div>

                          <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-800">
                            <div
                              className={`h-full rounded-full transition-all duration-500 ${
                                countdown.isDue
                                  ? 'bg-red-500 animate-pulse'
                                  : countdown.progressPercent > 80
                                  ? 'bg-gradient-to-r from-amber-500 to-red-500'
                                  : 'bg-gradient-to-r from-emerald-500 to-teal-400'
                              }`}
                              style={{ width: `${countdown.progressPercent}%` }}
                            />
                          </div>

                          <div className="flex justify-between text-[10px] text-slate-400 pt-1">
                            <span>📅 Binili: <strong>{tank.purchaseDate}</strong></span>
                            <span>🎯 1-Month Due: <strong className="text-orange-300">{countdown.dueDate}</strong></span>
                          </div>
                        </div>

                        {/* Stats */}
                        <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                            <p className="text-slate-400 text-[10px]">Pang-araw-araw na Luto:</p>
                            <p className="text-sm font-bold text-white mt-0.5">{tank.dailyHoursUsed} oras / araw</p>
                          </div>
                          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                            <p className="text-slate-400 text-[10px]">Tinatayang Tagal:</p>
                            <p className="text-sm font-bold text-orange-400 mt-0.5">30 Araw (1 Buwan)</p>
                          </div>
                        </div>

                        {/* Supplier Info */}
                        {tank.supplierContact && (
                          <p className="text-[11px] text-slate-300 flex items-center gap-1.5 mb-2">
                            <Phone className="w-3.5 h-3.5 text-cyan-400" />
                            <span>Supplier Hotline: {tank.supplierContact}</span>
                          </p>
                        )}
                      </div>

                      <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between">
                        <button
                          onClick={() => {
                            const newDate = new Date().toISOString().split('T')[0];
                            const updated: GasStoveLpgRecord = {
                              ...tank,
                              purchaseDate: newDate,
                              dueDate: calculateOneMonthDueDate(newDate),
                              currentLevelPercent: 100,
                              updatedAt: new Date().toISOString(),
                            };
                            saveGasRecordToDb(updated);
                            setGasRecords(getLocalGasRecords());
                            playSuccessChime();
                          }}
                          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-orange-300 font-bold text-xs"
                        >
                          🔄 Kakabili lang ulit (Reset 1-Month)
                        </button>
                        <button
                          onClick={() => handleDeleteGas(tank.id)}
                          className="p-1.5 rounded-lg text-red-400 hover:bg-red-500/20"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* =========================================================================
            TAB 4: PILLS MONITORING TRACKER (7:00 PM Daily Reminder & Auto Counter)
        ========================================================================= */}
        {activeTab === 'pills' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Pill className="w-5 h-5 text-emerald-400" />
                  Pills Monitoring (Araw-araw na 7:00 PM Alarm & Auto Count)
                </h2>
                <p className="text-xs text-slate-400">
                  Pindutin ang "Start Pills" para awtomatikong mag-notif with sound tuwing 7:00 PM at mag-count sa pag-inom.
                </p>
              </div>

              {!pillPlan || !pillPlan.isActive ? (
                <button
                  onClick={() => setIsStartPillsModalOpen(true)}
                  className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-extrabold text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/30 transform active:scale-95"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>START PILLS BUTTON (Simulan ang Cycle)</span>
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleTestPillReminder}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 font-bold text-xs border border-emerald-500/30 flex items-center gap-1.5"
                    title="Test 7:00 PM Alarm Sound & Count"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Test 7:00 PM Alarm</span>
                  </button>
                  <button
                    onClick={handleResetPillsPlan}
                    className="px-3 py-1.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-300 font-bold text-xs border border-red-500/40 flex items-center gap-1.5 shadow"
                    title="Delete All / I-delete Lahat ng Pills Data at Logs"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-red-400" />
                    <span>Delete All (I-delete Lahat)</span>
                  </button>
                </div>
              )}
            </div>

            {/* ACTIVE PILL PLAN DASHBOARD */}
            {!pillPlan || !pillPlan.isActive ? (
              <div className="p-12 rounded-3xl bg-slate-900 border border-slate-800 text-center text-slate-500">
                <Pill className="w-14 h-14 mx-auto mb-3 text-emerald-400/40" />
                <h3 className="text-base font-bold text-slate-200">Walang Aktibong Pill Cycle (0 Laman)</h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto mt-2 mb-6">
                  Pindutin ang <strong>"START PILLS BUTTON"</strong> sa itaas o sa ibaba upang simulan ang iyong 28-day o 21-day pack. Awtomatikong magpapatunog ng melodious sound alarm at notification ang system araw-araw tuwing <strong>7:00 PM</strong> at ibibilang ito sa iyong pag-inom!
                </p>
                <button
                  onClick={() => setIsStartPillsModalOpen(true)}
                  className="px-6 py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm inline-flex items-center gap-2 shadow-xl shadow-emerald-500/30"
                >
                  <Play className="w-5 h-5 fill-current" />
                  <span>START PILLS BUTTON</span>
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {/* Highlight Stats Banner */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-3 shadow-md">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-black">
                      #{pillPlan.currentPillIndex}
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-400 font-bold uppercase">Kasalukuyang Pill</p>
                      <h4 className="text-lg font-black text-white">
                        Pill #{pillPlan.currentPillIndex} of {pillPlan.totalPillsInPack}
                      </h4>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-3 shadow-md">
                    <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
                      <Clock className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-400 font-bold uppercase">Araw-araw na Alarm</p>
                      <h4 className="text-lg font-black text-cyan-300">
                        {pillPlan.reminderTime === '19:00' ? '7:00 PM' : pillPlan.reminderTime}
                      </h4>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-3 shadow-md">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-400 font-bold uppercase">Kabuuang Nainom</p>
                      <h4 className="text-lg font-black text-amber-300">
                        {pillPlan.totalPillsTaken} Pills
                      </h4>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-3 shadow-md">
                    <div className="w-10 h-10 rounded-xl bg-pink-500/10 text-pink-400 flex items-center justify-center font-mono">
                      🔥
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-400 font-bold uppercase">Streak Record</p>
                      <h4 className="text-lg font-black text-pink-300">
                        {pillPlan.streakDays} Araw Sunod-sunod
                      </h4>
                    </div>
                  </div>
                </div>

                {/* TODAY INTAKE ACTION CARD */}
                <div className="p-6 rounded-3xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-slate-900 border border-emerald-500/40 shadow-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-xs border border-emerald-500/30">
                        {pillPlan.pillBrand} ({pillPlan.packType === '28_day' ? '28-Day Pack' : '21-Day Pack'})
                      </span>
                      <span className="text-xs text-slate-400">Nagsimula noong {pillPlan.startDate}</span>
                    </div>
                    <h3 className="text-lg font-extrabold text-white">
                      {isPillTakenToday
                        ? '✅ Nainom na ang Pill para sa Araw na Ito!'
                        : `💊 Oras ng Pag-inom: Araw-araw tuwing 7:00 PM`}
                    </h3>
                    <p className="text-xs text-slate-300 mt-1">
                      {isPillTakenToday
                        ? 'Naitala na ang pill para sa araw na ito (1 check kada araw). Kung nagkamali, puwede mong i-undo/burahin gamit ang delete button.'
                        : 'Kapag tumunog ang 7:00 PM alarm o pinindot ang reminder, 1 pill lamang bawat araw ang ma-che-check.'}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleManualMarkPillTaken}
                      disabled={isPillTakenToday}
                      className={`px-5 py-3 rounded-2xl font-black text-xs flex items-center gap-2 shadow-lg transition-all ${
                        isPillTakenToday
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 cursor-default'
                          : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/30 transform active:scale-95'
                      }`}
                    >
                      {isPillTakenToday ? (
                        <>
                          <Check className="w-4 h-4" />
                          <span>Nainom na Ngayong Araw</span>
                        </>
                      ) : (
                        <>
                          <Pill className="w-4 h-4" />
                          <span>I-log: Uminom na ng Pill Ngayon</span>
                        </>
                      )}
                    </button>

                    {isPillTakenToday && (
                      <button
                        onClick={handleUndoTodayPill}
                        className="px-3.5 py-3 rounded-2xl bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-300 font-bold text-xs flex items-center gap-1.5 shadow transition-all active:scale-95"
                        title="I-undo / Burahin ang Pagka-check Ngayong Araw"
                      >
                        <Trash2 className="w-4 h-4 text-red-400" />
                        <span>Burahin ang Check</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* 28-DAY / 21-DAY BLISTER PACK GRID */}
                <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="font-extrabold text-sm text-white">Visual Pill Pack Blister Grid</h4>
                      <p className="text-xs text-slate-400">
                        {pillPlan.packType === '28_day'
                          ? '21 Active Hormone Pills (Pills 1-21) + 7 Placebo/Reminder Pills (Pills 22-28)'
                          : '21 Active Hormone Pills (Pills 1-21)'}
                      </p>
                    </div>
                    <div className="flex items-center gap-3 text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-full bg-emerald-500" /> Nainom Na
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-full bg-cyan-400 ring-2 ring-white" /> Kasalukuyan
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-3 h-3 rounded-full bg-slate-700" /> Susunod
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-7 gap-2.5 sm:gap-3 p-4 rounded-2xl bg-slate-950 border border-slate-800">
                    {Array.from({ length: pillPlan.totalPillsInPack }).map((_, idx) => {
                      const pillNum = idx + 1;
                      const isTaken = pillNum < pillPlan.currentPillIndex || (pillNum === pillPlan.currentPillIndex && isPillTakenToday);
                      const isCurrent = pillNum === pillPlan.currentPillIndex && !isPillTakenToday;
                      const isPlacebo = pillPlan.packType === '28_day' && pillNum > 21;

                      return (
                        <div
                          key={pillNum}
                          className={`flex flex-col items-center justify-center p-2.5 rounded-2xl border transition-all ${
                            isTaken
                              ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300'
                              : isCurrent
                              ? 'bg-cyan-500 text-slate-950 border-white ring-2 ring-cyan-400 animate-pulse font-black'
                              : isPlacebo
                              ? 'bg-slate-900 border-pink-500/30 text-pink-300'
                              : 'bg-slate-900 border-slate-800 text-slate-400'
                          }`}
                        >
                          <span className="text-[10px] font-mono">Day {pillNum}</span>
                          <div className="my-1">
                            {isTaken ? (
                              <CheckCircle className="w-5 h-5 text-emerald-400" />
                            ) : (
                              <Pill className={`w-5 h-5 ${isPlacebo ? 'text-pink-400' : 'text-slate-400'}`} />
                            )}
                          </div>
                          <span className="text-[9px] font-bold">
                            {isPlacebo ? 'Placebo' : 'Active'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* INTAKE HISTORY LOG */}
                <div className="rounded-3xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
                  <div className="p-4 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
                    <h4 className="font-bold text-sm text-white">Kasaysayan ng mga Nainom na Pills</h4>
                    <span className="text-xs text-slate-400">{pillPlan.logs.length} Total Logs</span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs text-slate-300">
                      <thead className="bg-slate-950 text-slate-400 uppercase font-semibold">
                        <tr>
                          <th className="py-3 px-4">Pill #</th>
                          <th className="py-3 px-4">Petsa</th>
                          <th className="py-3 px-4">Oras</th>
                          <th className="py-3 px-4">Paraan</th>
                          <th className="py-3 px-4">Status</th>
                          <th className="py-3 px-4 text-right">Aksyon</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800">
                        {pillPlan.logs.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="py-8 text-center text-slate-500">
                              Wala pang naitalang logs.
                            </td>
                          </tr>
                        ) : (
                          pillPlan.logs.map((log) => (
                            <tr key={log.id} className="hover:bg-slate-800/40">
                              <td className="py-2.5 px-4 font-bold text-white">Pill #{log.pillNumber}</td>
                              <td className="py-2.5 px-4 font-mono">{log.date}</td>
                              <td className="py-2.5 px-4 font-mono text-cyan-300">{log.time}</td>
                              <td className="py-2.5 px-4">
                                {log.autoCounted ? (
                                  <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-bold">
                                    ⏰ Auto-Counted at 7:00 PM
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px]">
                                    👆 Manual Click
                                  </span>
                                )}
                              </td>
                              <td className="py-2.5 px-4">
                                <span className="text-emerald-400 font-bold flex items-center gap-1">
                                  <CheckCircle className="w-3.5 h-3.5" /> Nainom
                                </span>
                              </td>
                              <td className="py-2.5 px-4 text-right">
                                <button
                                  onClick={() => handleDeletePillLog(log.id, log.pillNumber, log.date)}
                                  className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/40 text-red-300 transition-all inline-flex items-center gap-1 font-bold text-[11px]"
                                  title="Burahin ang na-check na record"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>Burahin</span>
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* =========================================================================
            TAB 5: WOMEN'S MENSTRUATION & PERIOD CYCLE (Clean 0 Default)
        ========================================================================= */}
        {activeTab === 'menstruation' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Heart className="w-5 h-5 text-pink-400" />
                  Women's Menstruation & Period Cycle Tracker
                </h2>
                <p className="text-xs text-slate-400">
                  Subaybayan ang buwanang regla, cycle dates, symptoms, at mood (0 Default Records)
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsPrivacyProtected(!isPrivacyProtected)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1.5 border border-slate-700"
                  title="Toggle Privacy Blur"
                >
                  {isPrivacyProtected ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  <span className="hidden sm:inline">
                    {isPrivacyProtected ? 'Ipakita' : 'Privacy Mode'}
                  </span>
                </button>

                <button
                  onClick={() => setIsAddMensModalOpen(true)}
                  className="px-4 py-2 rounded-xl bg-pink-500 hover:bg-pink-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-pink-500/20"
                >
                  <Plus className="w-4 h-4" />
                  <span>Mag-log ng Bagong Period</span>
                </button>
              </div>
            </div>

            {/* Records List */}
            {mensRecords.length === 0 ? (
              <div className="p-12 rounded-3xl bg-slate-900 border border-slate-800 text-center text-slate-500">
                <Heart className="w-12 h-12 mx-auto mb-3 text-pink-400/40" />
                <h3 className="text-base font-bold text-slate-300">Walang Menstruation Records (0 Laman)</h3>
                <p className="text-xs text-slate-500 mt-1 mb-4">
                  Mag-log ng petsa ng regla upang makita ang predictions at cycle history.
                </p>
                <button
                  onClick={() => setIsAddMensModalOpen(true)}
                  className="px-4 py-2 rounded-xl bg-pink-500 hover:bg-pink-400 text-slate-950 font-bold text-xs inline-flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Mag-log ng Unang Cycle</span>
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {mensRecords.map((m) => (
                  <div key={m.id} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-white text-sm">Simula: {m.startDate} ({m.cycleLengthDays} Araw Cycle)</h4>
                      <p className="text-xs text-slate-400">Flow: {m.flow} • Cramps: {m.cramps} • Mood: {m.mood}</p>
                    </div>
                    <button
                      onClick={() => handleDeleteMens(m.id)}
                      className="p-1.5 rounded-lg text-red-400 hover:bg-red-500/20"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* =========================================================================
          MODALS
      ========================================================================= */}

      {/* START PILLS MODAL */}
      {isStartPillsModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-emerald-500/40 rounded-3xl p-6 shadow-2xl text-slate-100 text-xs">
            <h3 className="text-base font-extrabold text-white mb-1 flex items-center gap-2">
              <Pill className="w-5 h-5 text-emerald-400" />
              Simulan ang Pills Monitoring
            </h3>
            <p className="text-slate-400 mb-4">
              I-setup ang iyong contraceptive / medication pills. Awtomatiko itong magpapatunog ng melodious alarm araw-araw tuwing <strong>7:00 PM</strong> at itatala ang bilang ng nainom!
            </p>

            <form onSubmit={handleStartPillsPlan} className="space-y-3">
              <div>
                <label className="text-slate-400 block mb-1">Pangalan / Brand ng Pill:</label>
                <input
                  type="text"
                  required
                  value={pillBrandName}
                  onChange={(e) => setPillBrandName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
                  placeholder="e.g. Trust Pill, Diane-35, Althea, Marvelon, Charlize"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 block mb-1">Pack Type (Bilang ng Pills):</label>
                  <select
                    value={pillPackType}
                    onChange={(e) => setPillPackType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
                  >
                    <option value="28_day">28-Day Pack (21+7 Placebo)</option>
                    <option value="21_day">21-Day Pack (21 Active)</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Petsa ng Simula (Start Date):</label>
                  <input
                    type="date"
                    required
                    value={pillStartDate}
                    onChange={(e) => setPillStartDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Araw-araw na Oras ng Alarm:</label>
                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between text-emerald-300 font-bold">
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-4 h-4" /> 7:00 PM (19:00 Nightly)
                  </span>
                  <span className="text-[10px] text-emerald-400">Fixed Daily Reminder</span>
                </div>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsStartPillsModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black shadow-lg shadow-emerald-500/30"
                >
                  🚀 I-activate ang Pills Alarm
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD GAS STOVE LPG MODAL (With Date Bought) */}
      {isAddGasModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-orange-500/40 rounded-3xl p-6 shadow-2xl text-slate-100 text-xs">
            <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
              <Flame className="w-5 h-5 text-orange-400" />
              Mag-add ng Gasul (Set Date Bought)
            </h3>
            <p className="text-slate-400 mb-4">
              I-enter kung kailan mo binili ang Gasul. Awtomatikong magbibilang ng 1 buwan (30 araw) at magpapatunog ng sound alarm kapag expired na!
            </p>

            <form onSubmit={handleAddGasRecord} className="space-y-3">
              <div>
                <label className="text-slate-400 block mb-1">Brand ng Gasul:</label>
                <input
                  type="text"
                  required
                  value={gasBrand}
                  onChange={(e) => setGasBrand(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
                  placeholder="e.g. Petron Gasul, Solane, Prycegas"
                />
              </div>

              <div>
                <label className="text-orange-400 font-bold block mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5" /> Petsa kung Kailan Binili (Purchase Date):
                </label>
                <input
                  type="date"
                  required
                  value={gasPurchaseDate}
                  onChange={(e) => setGasPurchaseDate(e.target.value)}
                  className="w-full bg-slate-950 border border-orange-500/50 rounded-xl p-2.5 text-white font-bold"
                />
                <p className="text-[10px] text-slate-400 mt-1">
                  💡 Awtomatikong 1-Month Due: <strong className="text-orange-300">{calculateOneMonthDueDate(gasPurchaseDate)}</strong>
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 block mb-1">Capacity (kg):</label>
                  <select
                    value={gasCapacity}
                    onChange={(e) => setGasCapacity(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  >
                    <option value={11}>11 kg (Standard)</option>
                    <option value={2.7}>2.7 kg (Small)</option>
                    <option value={22}>22 kg (Commercial)</option>
                    <option value={50}>50 kg (Industrial)</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Presyo ng Bili / Refill (₱):</label>
                  <input
                    type="number"
                    required
                    value={gasCost}
                    onChange={(e) => setGasCost(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 block mb-1">Oras ng Luto / Araw:</label>
                  <input
                    type="number"
                    step="0.5"
                    value={gasDailyHours}
                    onChange={(e) => setGasDailyHours(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Supplier Hotline:</label>
                  <input
                    type="text"
                    value={gasSupplier}
                    onChange={(e) => setGasSupplier(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                    placeholder="0917..."
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddGasModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-400 text-slate-950 font-black shadow-lg shadow-orange-500/30"
                >
                  I-save at Simulan ang 1-Month Count
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD ELECTRIC BILL MODAL */}
      {isAddElectricModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl text-slate-100 text-xs">
            <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-400" />
              Mag-add ng Electric Bill (Kuryente)
            </h3>
            <form onSubmit={handleAddElectricBill} className="space-y-3">
              <div>
                <label className="text-slate-400 block mb-1">Buwan:</label>
                <input
                  type="text"
                  required
                  value={elecMonth}
                  onChange={(e) => setElecMonth(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 block mb-1">Nakaraang Metro (kWh):</label>
                  <input
                    type="number"
                    required
                    value={elecPrevReading}
                    onChange={(e) => setElecPrevReading(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Kasalukuyang Metro (kWh):</label>
                  <input
                    type="number"
                    required
                    value={elecCurrentReading}
                    onChange={(e) => setElecCurrentReading(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 block mb-1">Rate bawat kWh (₱):</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={elecRate}
                    onChange={(e) => setElecRate(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Due Date:</label>
                  <input
                    type="date"
                    required
                    value={elecDueDate}
                    onChange={(e) => setElecDueDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>
              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddElectricModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                >
                  I-save ang Bill
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD WATER BILL MODAL */}
      {isAddWaterModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-sky-500/30 rounded-3xl p-6 shadow-2xl text-slate-100 text-xs">
            <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
              <Droplets className="w-5 h-5 text-sky-400" />
              Mag-add ng Water Bill (Tubig)
            </h3>
            <form onSubmit={handleAddWaterBill} className="space-y-3">
              <div>
                <label className="text-slate-400 block mb-1">Buwan:</label>
                <input
                  type="text"
                  required
                  value={waterMonth}
                  onChange={(e) => setWaterMonth(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 block mb-1">Nakaraang Metro (m³):</label>
                  <input
                    type="number"
                    required
                    value={waterPrevReading}
                    onChange={(e) => setWaterPrevReading(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Kasalukuyang Metro (m³):</label>
                  <input
                    type="number"
                    required
                    value={waterCurrentReading}
                    onChange={(e) => setWaterCurrentReading(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 block mb-1">Rate bawat m³ (₱):</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={waterRate}
                    onChange={(e) => setWaterRate(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Due Date:</label>
                  <input
                    type="date"
                    required
                    value={waterDueDate}
                    onChange={(e) => setWaterDueDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  />
                </div>
              </div>
              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddWaterModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold"
                >
                  I-save ang Bill
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD MENSTRUATION MODAL */}
      {isAddMensModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-slate-900 border border-pink-500/30 rounded-3xl p-6 shadow-2xl text-slate-100 text-xs">
            <h3 className="text-base font-bold text-white mb-1 flex items-center gap-2">
              <Heart className="w-5 h-5 text-pink-400" />
              Mag-log ng Menstrual Period Cycle
            </h3>
            <form onSubmit={handleAddMensRecord} className="space-y-3">
              <div>
                <label className="text-slate-400 block mb-1">Petsa ng Simula (Start Date):</label>
                <input
                  type="date"
                  required
                  value={mensStartDate}
                  onChange={(e) => setMensStartDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-400 block mb-1">Flow (Lakas):</label>
                  <select
                    value={mensFlow}
                    onChange={(e) => setMensFlow(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  >
                    <option value="Light">Light (Mahina)</option>
                    <option value="Medium">Medium (Katamtaman)</option>
                    <option value="Heavy">Heavy (Malakas)</option>
                    <option value="Spotting">Spotting (Kaunti)</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Cramps (Sakit):</label>
                  <select
                    value={mensCramps}
                    onChange={(e) => setMensCramps(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                  >
                    <option value="None">None (Walang Sakit)</option>
                    <option value="Mild">Mild (Bahagya)</option>
                    <option value="Moderate">Moderate (Katamtaman)</option>
                    <option value="Severe">Severe (Matindi)</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Mood / Pakiramdam:</label>
                <select
                  value={mensMood}
                  onChange={(e) =>
                    setMensMood(
                      e.target.value as
                        | 'Normal'
                        | 'Happy'
                        | 'Tired'
                        | 'Irritable'
                        | 'Emotional'
                        | 'Anxious'
                        | 'Energetic'
                    )
                  }
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
                >
                  <option value="Normal">Normal / Kalmado</option>
                  <option value="Happy">Happy / Masayahin</option>
                  <option value="Tired">Tired / Pagod</option>
                  <option value="Irritable">Irritable / Mabilis mairita</option>
                  <option value="Emotional">Emotional / Malungkutin</option>
                </select>
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Symptoms:</label>
                <div className="flex flex-wrap gap-1.5">
                  {['Mild Cramps', 'Headache', 'Bloating', 'Backache', 'Acne', 'Cravings', 'Tiredness'].map(
                    (sym) => (
                      <button
                        type="button"
                        key={sym}
                        onClick={() => toggleSymptom(sym)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border ${
                          mensSymptoms.includes(sym)
                            ? 'bg-pink-500/30 text-pink-200 border-pink-500/60'
                            : 'bg-slate-950 text-slate-400 border-slate-800'
                        }`}
                      >
                        {sym}
                      </button>
                    )
                  )}
                </div>
              </div>
              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddMensModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-pink-500 hover:bg-pink-400 text-slate-950 font-bold"
                >
                  I-save ang Cycle
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
