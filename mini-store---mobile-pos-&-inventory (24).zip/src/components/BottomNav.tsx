import React, { useState, useEffect } from 'react';
import { TabType } from '../types';
import { getLanguage, t, LANG_CHANGE_EVENT } from '../utils/language';
import { ScanBarcode, Package, LayoutDashboard, History, UserCheck } from 'lucide-react';

interface BottomNavProps {
  activeTab: TabType;
  onChangeTab: (tab: TabType) => void;
  cartItemCount: number;
  lowStockCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  cartItemCount,
  lowStockCount,
}) => {
  const [, setLangState] = useState(getLanguage());

  useEffect(() => {
    const handleLangChange = () => setLangState(getLanguage());
    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
  }, []);

  const navItems: { id: TabType; labelKey: 'tabPos' | 'tabInventory' | 'tabDashboard' | 'tabHistory' | 'tabAccounts'; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'pos', labelKey: 'tabPos', icon: ScanBarcode },
    { id: 'inventory', labelKey: 'tabInventory', icon: Package },
    { id: 'dashboard', labelKey: 'tabDashboard', icon: LayoutDashboard },
    { id: 'history', labelKey: 'tabHistory', icon: History },
    { id: 'accounts', labelKey: 'tabAccounts', icon: UserCheck },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-slate-200/80 shadow-lg shadow-slate-200/50 print:hidden">
      <div className="max-w-md mx-auto px-2 flex items-center justify-around h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          const label = t(item.labelKey);

          return (
            <button
              key={item.id}
              onClick={() => onChangeTab(item.id)}
              className={`relative flex flex-col items-center justify-center flex-1 h-full py-1 transition-all ${
                isActive ? 'text-indigo-600 font-bold scale-105' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5px]' : 'stroke-2'}`} />
                {item.id === 'pos' && cartItemCount > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-indigo-600 text-white font-extrabold text-[10px] w-4 h-4 rounded-full flex items-center justify-center shadow-xs animate-bounce">
                    {cartItemCount}
                  </span>
                )}
                {item.id === 'inventory' && lowStockCount > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-orange-500 text-white font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center shadow-xs">
                    {lowStockCount}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-1 tracking-tight leading-none whitespace-nowrap">{label}</span>
              {isActive && (
                <div className="w-6 h-0.5 bg-indigo-600 rounded-full mt-1 animate-pulse" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
