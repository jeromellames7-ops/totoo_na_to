import React, { useState, useEffect } from 'react';
import { Product, QrSheetSlot } from '../types';
import { getLanguage, t } from '../utils/language';
import {
  getSavedQrSheet,
  saveQrSheet,
  clearQrSheet,
  getEffectiveAccountId,
} from '../utils/storage';
import {
  Printer,
  X,
  Sparkles,
  CheckCircle2,
  QrCode,
  Edit,
  Trash2,
  Plus,
  Save,
  RotateCcw,
  AlertCircle,
  Package,
  Check,
} from 'lucide-react';

interface PrintableQrSheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  highlightedBarcode?: string;
  storeName?: string;
}

export const PrintableQrSheetModal: React.FC<PrintableQrSheetModalProps> = ({
  isOpen,
  onClose,
  products,
  highlightedBarcode,
  storeName = 'MINI STORE',
}) => {
  const lang = getLanguage();
  const accountId = getEffectiveAccountId();

  // 20 QR slots per Bondpaper sheet (4 columns x 5 rows grid)
  const TOTAL_SLOTS = 20;

  // Slots state
  const [slots, setSlots] = useState<(QrSheetSlot | null)[]>([]);
  const [editingSlotIndex, setEditingSlotIndex] = useState<number | null>(null);
  const [notification, setNotification] = useState<string>('');

  // Print warning modal state if sheet is not 20/20 full
  const [showIncompletePrintModal, setShowIncompletePrintModal] = useState(false);

  // Form state for slot editor
  const [selectedProdId, setSelectedProdId] = useState<string>('');
  const [customForm, setCustomForm] = useState({
    name: '',
    price: 0,
    barcode: '',
  });

  // Initialize or load draft slots
  const loadSheetData = () => {
    let saved = getSavedQrSheet(accountId);

    // If highlighted product was just created, ensure it's placed into the first empty slot or slot 0
    if (highlightedBarcode) {
      const targetProd = products.find((p) => p.barcode === highlightedBarcode);
      if (targetProd) {
        const alreadyInSheet = saved.some((s) => s && s.barcode === highlightedBarcode);
        if (!alreadyInSheet) {
          const emptyIdx = saved.findIndex((s) => s === null);
          const newSlotItem: QrSheetSlot = {
            id: targetProd.id,
            name: targetProd.name,
            price: targetProd.price,
            barcode: targetProd.barcode,
            category: targetProd.category,
          };
          if (emptyIdx !== -1) {
            saved[emptyIdx] = newSlotItem;
          } else {
            saved[0] = newSlotItem;
          }
          saveQrSheet(saved, accountId);
        }
      }
    }

    // If completely empty, auto-populate initial slots from inventory for user convenience
    const filledCount = saved.filter(Boolean).length;
    if (filledCount === 0 && products.length > 0) {
      const initialSlots: (QrSheetSlot | null)[] = Array(TOTAL_SLOTS).fill(null);
      products.slice(0, TOTAL_SLOTS).forEach((p, idx) => {
        initialSlots[idx] = {
          id: p.id,
          name: p.name,
          price: p.price,
          barcode: p.barcode,
          category: p.category,
        };
      });
      saved = initialSlots;
      saveQrSheet(saved, accountId);
    }

    setSlots(saved);
  };

  useEffect(() => {
    if (isOpen) {
      loadSheetData();
    }
  }, [isOpen, accountId, highlightedBarcode]);

  if (!isOpen) return null;

  const filledCount = slots.filter(Boolean).length;
  const isFull = filledCount === TOTAL_SLOTS;

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(''), 3000);
  };

  // Save current sheet to localStorage
  const handleSaveDraft = () => {
    saveQrSheet(slots, accountId);
    showToast(`Successfully saved ${filledCount}/${TOTAL_SLOTS} QR Codes to Bondpaper Draft!`);
  };

  // Auto-fill remaining empty slots with products from store inventory
  const handleAutofillRemaining = () => {
    const updated = [...slots];
    let prodIdx = 0;
    for (let i = 0; i < TOTAL_SLOTS; i++) {
      if (!updated[i]) {
        // Find next product from inventory not already in sheet if possible
        const candidate = products[prodIdx % products.length];
        if (candidate) {
          updated[i] = {
            id: candidate.id + `_slot_${i}`,
            name: candidate.name,
            price: candidate.price,
            barcode: candidate.barcode,
            category: candidate.category,
          };
        }
        prodIdx++;
      }
    }
    setSlots(updated);
    saveQrSheet(updated, accountId);
    showToast('Automatically filled 20/20 slots with store inventory products!');
  };

  // Clear sheet
  const handleResetSheet = () => {
    if (confirm('Are you sure you want to clear all 20 QR slots on the bond paper sheet?')) {
      const empty = Array(TOTAL_SLOTS).fill(null);
      setSlots(empty);
      clearQrSheet(accountId);
      showToast('QR sheet has been cleared.');
    }
  };

  // Open slot editor
  const handleOpenEditSlot = (index: number) => {
    setEditingSlotIndex(index);
    const item = slots[index];
    if (item) {
      setSelectedProdId(item.id);
      setCustomForm({
        name: item.name,
        price: item.price,
        barcode: item.barcode,
      });
    } else {
      // Default to first available store product or blank
      const firstProd = products[0];
      if (firstProd) {
        setSelectedProdId(firstProd.id);
        setCustomForm({
          name: firstProd.name,
          price: firstProd.price,
          barcode: firstProd.barcode,
        });
      } else {
        setSelectedProdId('');
        setCustomForm({
          name: '',
          price: 0,
          barcode: Date.now().toString().slice(-6),
        });
      }
    }
  };

  // Select store product in editor
  const handleSelectProductChange = (prodId: string) => {
    setSelectedProdId(prodId);
    const prod = products.find((p) => p.id === prodId);
    if (prod) {
      setCustomForm({
        name: prod.name,
        price: prod.price,
        barcode: prod.barcode,
      });
    }
  };

  // Save slot changes
  const handleSaveSlotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingSlotIndex === null) return;

    const updated = [...slots];
    updated[editingSlotIndex] = {
      id: selectedProdId || `custom_${Date.now()}`,
      name: customForm.name.trim() || 'Custom Tag',
      price: Number(customForm.price) || 0,
      barcode: customForm.barcode.trim() || Date.now().toString().slice(-6),
      isCustom: !selectedProdId,
    };

    setSlots(updated);
    saveQrSheet(updated, accountId);
    setEditingSlotIndex(null);
    showToast(`Updated Slot #${editingSlotIndex + 1}! Saved to draft.`);
  };

  // Clear specific slot
  const handleClearSingleSlot = (index: number) => {
    const updated = [...slots];
    updated[index] = null;
    setSlots(updated);
    saveQrSheet(updated, accountId);
    setEditingSlotIndex(null);
    showToast(`Cleared Slot #${index + 1}.`);
  };

  // Print handler with strict/friendly check
  const handlePrintClick = () => {
    if (isFull) {
      window.print();
    } else {
      setShowIncompletePrintModal(true);
    }
  };

  const handleConfirmPrintAsIs = () => {
    setShowIncompletePrintModal(false);
    setTimeout(() => {
      window.print();
    }, 150);
  };

  const handleConfirmAutofillAndPrint = () => {
    handleAutofillRemaining();
    setShowIncompletePrintModal(false);
    setTimeout(() => {
      window.print();
    }, 150);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl overflow-hidden my-auto border border-slate-200 flex flex-col max-h-[94vh] print:max-h-none print:shadow-none print:border-none print:w-full print:m-0">
        
        {/* Header - Hidden on Print */}
        <div className="bg-slate-900 px-4 sm:px-6 py-4 border-b border-slate-800 flex items-center justify-between text-white shrink-0 print:hidden">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/30 text-white shrink-0">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold flex items-center gap-2">
                <span>Bondpaper 20-QR Code Sheet Builder</span>
                <span className={`text-[10px] px-2.5 py-0.5 rounded-full font-black border ${
                  isFull
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                    : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                }`}>
                  {isFull ? 'Full Sheet (20/20)' : `Draft: ${filledCount}/20 Slots`}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Edit or customize QR tags on the bond paper sheet. Save to draft and print when all 20 slots are filled.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveDraft}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs rounded-xl border border-slate-700 flex items-center gap-1.5 transition-all shadow-xs"
              title="Save Draft to Browser"
            >
              <Save className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">Save Draft</span>
            </button>

            <button
              onClick={handlePrintClick}
              className={`px-4 py-2 font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 transition-all active:scale-95 ${
                isFull
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30 ring-2 ring-emerald-400/40'
                  : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-600/30'
              }`}
            >
              <Printer className="w-4 h-4" />
              <span>{isFull ? 'Print (Full 20/20)' : `Print (${filledCount}/20)`}</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Status & Control Toolbar - Hidden on Print */}
        <div className="bg-amber-50/90 border-b border-amber-200/80 px-4 sm:px-6 py-2.5 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 shrink-0 print:hidden">
          <div className="flex items-center gap-3">
            {/* Progress Counter */}
            <div className="flex items-center gap-2 shrink-0">
              <div className="w-32 bg-amber-200 h-2.5 rounded-full overflow-hidden border border-amber-300">
                <div
                  className={`h-full transition-all duration-300 ${isFull ? 'bg-emerald-600' : 'bg-amber-600'}`}
                  style={{ width: `${(filledCount / TOTAL_SLOTS) * 100}%` }}
                />
              </div>
              <span className="text-xs font-black text-amber-900 font-mono">
                {filledCount}/{TOTAL_SLOTS}
              </span>
            </div>

            <p className="text-xs text-amber-900 font-medium">
              {isFull ? (
                <strong className="text-emerald-700 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 inline" />
                  Bondpaper sheet is full! Ready to print.
                </strong>
              ) : (
                <span>
                  Saved in draft. There are <strong>{TOTAL_SLOTS - filledCount} empty slots</strong> remaining.
                </span>
              )}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleAutofillRemaining}
              className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl border border-indigo-200 flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>Autofill 20 Slots</span>
            </button>

            <button
              onClick={handleResetSheet}
              className="px-2.5 py-1.5 bg-white hover:bg-rose-50 text-rose-600 font-bold text-xs rounded-xl border border-rose-200 flex items-center gap-1 transition-colors shadow-xs"
              title="Clear all slots"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          </div>
        </div>

        {/* Notifications */}
        {notification && (
          <div className="bg-emerald-600 text-white px-4 py-2 text-xs font-bold text-center flex items-center justify-center gap-2 shrink-0 print:hidden">
            <Check className="w-4 h-4" />
            <span>{notification}</span>
          </div>
        )}

        {/* Bondpaper Printable Grid Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-100 print:bg-white print:p-0 select-text">
          <div className="printable-bondpaper-area max-w-[210mm] mx-auto bg-white p-5 sm:p-7 rounded-2xl shadow-md border border-slate-200 print:shadow-none print:border-none print:p-0 print:m-0 print:w-full">
            
            {/* Store Paper Title Header */}
            <div className="text-center pb-3 mb-4 border-b-2 border-slate-900 print:pb-2 print:mb-3">
              <div className="flex justify-between items-center text-xs text-slate-500 mb-1">
                <span className="font-bold text-indigo-700 font-mono tracking-widest">{storeName} - OFFICIAL QR TAGS</span>
                <span className="font-mono">Bondpaper Printable Grid (20 QR Items)</span>
              </div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight uppercase">PRODUCT QR CODE PRICE TAGS SHEET</h2>
              <p className="text-[10px] text-slate-500 font-sans print:text-black">
                Cut along the dotted lines to attach QR code price tags onto products or store shelves.
              </p>
            </div>

            {/* 4 Columns x 5 Rows Grid (Exactly 20 Slots Layout) */}
            <div className="grid grid-cols-4 gap-2.5 sm:gap-3.5 print:grid-cols-4 print:gap-2 print:w-full">
              {slots.map((item, idx) => {
                const isHighlighted = item && item.barcode === highlightedBarcode;

                if (!item) {
                  // Empty interactive slot card
                  return (
                    <div
                      key={`empty-${idx}`}
                      onClick={() => handleOpenEditSlot(idx)}
                      className="border-2 border-dashed border-amber-300 hover:border-indigo-500 hover:bg-indigo-50/40 rounded-xl p-2.5 flex flex-col items-center justify-center text-center h-[130px] bg-amber-50/30 transition-all cursor-pointer group relative print:bg-white print:border-slate-300"
                    >
                      <span className="text-[10px] text-amber-700 font-mono font-bold mb-1 group-hover:text-indigo-600">
                        Slot #{idx + 1} (Empty)
                      </span>
                      <div className="w-10 h-10 rounded-xl bg-amber-100/60 group-hover:bg-indigo-100 border border-amber-200 group-hover:border-indigo-300 flex items-center justify-center text-amber-600 group-hover:text-indigo-600 transition-colors">
                        <Plus className="w-5 h-5" />
                      </div>
                      <span className="text-[10px] font-bold text-amber-800 group-hover:text-indigo-700 mt-2">
                        + Click to Edit
                      </span>
                    </div>
                  );
                }

                // QR Code Image URL
                const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(
                  item.barcode
                )}`;

                return (
                  <div
                    key={`slot-${idx}`}
                    className={`border-2 rounded-xl p-2 flex flex-col items-center text-center justify-between h-[130px] transition-all relative group cursor-pointer ${
                      isHighlighted
                        ? 'border-indigo-600 bg-indigo-50/40 ring-2 ring-indigo-500/30 print:border-slate-800 print:bg-white'
                        : 'border-slate-300 hover:border-indigo-500 hover:shadow-md bg-white'
                    }`}
                    onClick={() => handleOpenEditSlot(idx)}
                    title="Click to edit or change QR details for this slot"
                  >
                    {/* Hover Edit Overlay indicator (Hidden on print) */}
                    <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity bg-indigo-600 text-white p-1 rounded-md shadow-xs print:hidden">
                      <Edit className="w-3 h-3" />
                    </div>

                    {/* Slot Number Badge */}
                    <span className="absolute top-1 left-1 font-mono text-[9px] font-bold text-slate-400 bg-slate-100 px-1 rounded print:hidden">
                      #{idx + 1}
                    </span>

                    {/* Item Name */}
                    <div className="w-full pt-1">
                      <p className="text-[10px] font-black text-slate-900 line-clamp-1 leading-tight tracking-tight uppercase">
                        {item.name}
                      </p>
                      <p className="text-[11px] font-extrabold text-indigo-700 leading-none mt-0.5">
                        ₱{item.price.toFixed(2)}
                      </p>
                    </div>

                    {/* QR Code Image */}
                    <div className="my-0.5 p-1 bg-white rounded-lg border border-slate-200 shadow-xs flex items-center justify-center">
                      <img
                        src={qrUrl || undefined}
                        alt={`QR ${item.barcode}`}
                        className="w-[50px] h-[50px] object-contain print:w-[48px] print:h-[48px]"
                        loading="lazy"
                      />
                    </div>

                    {/* Barcode String */}
                    <div className="w-full pt-0.5 border-t border-dashed border-slate-200">
                      <p className="text-[9px] font-mono font-bold text-slate-700 tracking-tighter truncate">
                        {item.barcode}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Print Footer Note */}
            <div className="mt-4 pt-2 border-t border-slate-200 text-center text-[10px] text-slate-400 flex justify-between items-center print:mt-2">
              <span>Printed from MINI STORE POS • 20 QR Items Bondpaper Printable Sheet</span>
              <span>Total Store Products: {products.length}</span>
            </div>
          </div>
        </div>

        {/* Footer & Print Controls - Hidden on Print */}
        <div className="bg-slate-50 px-5 py-3 border-t border-slate-200 flex items-center justify-between shrink-0 print:hidden">
          <div className="text-xs text-slate-500 font-medium">
            Bondpaper Grid Status: <strong className="text-slate-900 font-extrabold">{filledCount} of {TOTAL_SLOTS} QR Codes</strong> ready
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveDraft}
              className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-800 font-bold text-xs rounded-xl border border-slate-200 flex items-center gap-1.5 shadow-xs"
            >
              <Save className="w-4 h-4 text-indigo-600" />
              <span>Save Draft</span>
            </button>

            <button
              onClick={handlePrintClick}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-100 flex items-center gap-2 active:scale-95 transition-all"
            >
              <Printer className="w-4 h-4" />
              <span>{isFull ? 'Print 20 QR Codes' : 'Print Sheet'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Edit Slot Modal */}
      {editingSlotIndex !== null && (
        <div className="fixed inset-0 z-60 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-2xl w-full max-w-md space-y-4 animate-fade-in">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                <Edit className="w-4 h-4 text-indigo-600" />
                <span>Edit QR Slot #{editingSlotIndex + 1} on Bondpaper</span>
              </h4>
              <button
                onClick={() => setEditingSlotIndex(null)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSlotSubmit} className="space-y-3">
              {/* Option 1: Pick from store products */}
              {products.length > 0 && (
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Select from Store Products:
                  </label>
                  <select
                    value={selectedProdId}
                    onChange={(e) => handleSelectProductChange(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="">-- Manually Type Custom QR Details --</option>
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} - ₱{p.price.toFixed(2)} (Barcode: {p.barcode})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="border-t border-slate-100 pt-3 space-y-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Product Name for QR Tag *
                  </label>
                  <input
                    type="text"
                    required
                    value={customForm.name}
                    onChange={(e) => setCustomForm({ ...customForm, name: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="e.g. Instant Noodles"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Price (₱) *
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      required
                      value={customForm.price}
                      onChange={(e) =>
                        setCustomForm({ ...customForm, price: parseFloat(e.target.value) || 0 })
                      }
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 block mb-1">
                      Barcode / QR Code String *
                    </label>
                    <input
                      type="text"
                      required
                      value={customForm.barcode}
                      onChange={(e) => setCustomForm({ ...customForm, barcode: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              </div>

              <div className="flex gap-2 pt-3">
                {slots[editingSlotIndex] && (
                  <button
                    type="button"
                    onClick={() => handleClearSingleSlot(editingSlotIndex)}
                    className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-xl text-xs font-bold border border-rose-200 flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear Slot</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setEditingSlotIndex(null)}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold border border-slate-200"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-100 flex items-center justify-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>Save to Slot #{editingSlotIndex + 1}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Incomplete Print Warning Modal */}
      {showIncompletePrintModal && (
        <div className="fixed inset-0 z-60 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-2xl w-full max-w-md space-y-4 text-center animate-fade-in">
            <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-2xl mx-auto flex items-center justify-center">
              <AlertCircle className="w-6 h-6" />
            </div>

            <div>
              <h4 className="text-base font-extrabold text-slate-900">
                The 20 QR slots on Bondpaper are not yet full!
              </h4>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                You have saved <strong>{filledCount} out of 20 QR codes</strong>. There are still <strong>{TOTAL_SLOTS - filledCount} empty slots</strong>. Do you want to print now or autofill remaining slots first?
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                onClick={handleConfirmAutofillAndPrint}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-100 flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>Autofill (20/20) with products & Print now!</span>
              </button>

              <button
                onClick={handleConfirmPrintAsIs}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl border border-slate-200"
              >
                Print current draft as is ({filledCount} Items)
              </button>

              <button
                onClick={() => setShowIncompletePrintModal(false)}
                className="w-full py-2 text-slate-500 hover:text-slate-700 font-bold text-xs"
              >
                Return to sheet draft
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
