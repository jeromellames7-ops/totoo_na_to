import React, { useState, useEffect } from 'react';
import { UserAccount, UserRole } from '../types';
import {
  getAccounts,
  setActiveUser,
  registerNewAccount,
  adminUpdateUserCredentials,
  deleteUserAccount,
  isCurrentUserAdmin,
} from '../utils/storage';
import { playSuccessChime, playWarningBeep } from '../utils/sound';
import {
  Shield,
  UserPlus,
  Users,
  CheckCircle2,
  AlertCircle,
  X,
  Search,
  Lock,
  Mail,
  Store,
  KeyRound,
  Eye,
  EyeOff,
  Edit,
  Trash2,
  LogIn,
  ArrowRight,
  Sparkles,
  Phone,
  Save,
  Check,
  RefreshCw,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface AdminRegisterAccountsModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeUser: UserAccount;
  onUserChanged: (newUser: UserAccount) => void;
}

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
];

export const AdminRegisterAccountsModal: React.FC<AdminRegisterAccountsModalProps> = ({
  isOpen,
  onClose,
  activeUser,
  onUserChanged,
}) => {
  const [activeTab, setActiveTab] = useState<'list' | 'register'>('list');
  const [accounts, setAccounts] = useState<UserAccount[]>(getAccounts());
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Register Form State
  const [regName, setRegName] = useState('');
  const [regStoreName, setRegStoreName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regRole, setRegRole] = useState<UserRole>('Cashier');
  const [regPhone, setRegPhone] = useState('');
  const [regPin, setRegPin] = useState('1234');
  const [regAvatar, setRegAvatar] = useState(AVATAR_PRESETS[0]);
  const [showRegPassword, setShowRegPassword] = useState(false);

  // Edit Account Credentials State
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [editName, setEditName] = useState('');
  const [editStoreName, setEditStoreName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [editPin, setEditPin] = useState('');
  const [editRole, setEditRole] = useState<UserRole>('Cashier');
  const [editPhone, setEditPhone] = useState('');

  const refreshAccountsList = () => {
    setAccounts(getAccounts());
  };

  useEffect(() => {
    if (isOpen) {
      refreshAccountsList();
      setToastMessage(null);
      setEditingUser(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isAdmin = isCurrentUserAdmin(activeUser);

  // Security Check: If non-admin user attempts access
  if (!isAdmin) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
        <div className="bg-slate-900 border border-rose-500/50 rounded-3xl p-6 text-center text-white max-w-md shadow-2xl">
          <div className="w-14 h-14 bg-rose-500/20 border border-rose-500/40 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <Shield className="w-7 h-7 text-rose-400" />
          </div>
          <h3 className="text-lg font-extrabold text-white">Admin Access Only</h3>
          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            Ang pag-register at pamamahala ng mga account ay eksklusibo lamang para sa <strong>Admin Account</strong>.
          </p>
          <button
            onClick={onClose}
            className="mt-5 px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-all"
          >
            Isara
          </button>
        </div>
      </div>
    );
  }

  // Automatic Switch / Open Account on Click
  const handleOpenAccount = (targetUser: UserAccount) => {
    if (targetUser.id === activeUser.id) {
      setToastMessage({
        type: 'success',
        text: `Kasalukuyan mo nang gamit ang account ni ${targetUser.name}!`,
      });
      return;
    }

    const switched = setActiveUser(targetUser.id);
    if (switched) {
      playSuccessChime();
      onUserChanged(switched);
      setToastMessage({
        type: 'success',
        text: `⚡ Matagumpay na binuksan ang account ni "${switched.name}" (${switched.storeName || 'Store'})!`,
      });
      refreshAccountsList();

      setTimeout(() => {
        onClose();
      }, 700);
    } else {
      playWarningBeep();
      setToastMessage({
        type: 'error',
        text: 'Hindi mabuksan ang account. Pakisubukan muli.',
      });
    }
  };

  // Handle Register New Account Submit
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setToastMessage(null);

    if (!regName.trim()) {
      setToastMessage({ type: 'error', text: 'Pakilagay ang Pangalan ng Account / Cashier.' });
      return;
    }
    if (!regEmail.trim() || !regEmail.includes('@')) {
      setToastMessage({ type: 'error', text: 'Pakilagay ang wastong Gmail o Email Address.' });
      return;
    }
    if (!regPassword.trim() || regPassword.length < 4) {
      setToastMessage({ type: 'error', text: 'Ang password ay dapat hindi bababa sa 4 characters.' });
      return;
    }
    if (regPassword !== regConfirmPassword) {
      setToastMessage({ type: 'error', text: 'Hindi magkatugma ang Password at Confirm Password.' });
      return;
    }

    setLoading(true);
    try {
      const created = await registerNewAccount({
        name: regName.trim(),
        email: regEmail.trim(),
        password: regPassword.trim(),
        role: regRole,
        storeName: regStoreName.trim() || `${regName.trim()}'s Mini Store`,
        phone: regPhone.trim(),
        pin: regPin.trim() || '1234',
        avatar: regAvatar,
      });

      playSuccessChime();
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });

      setToastMessage({
        type: 'success',
        text: `Matagumpay na nagawa ang bagong account ni "${created.name}"!`,
      });

      // Clear Form
      setRegName('');
      setRegStoreName('');
      setRegEmail('');
      setRegPassword('');
      setRegConfirmPassword('');
      setRegPhone('');
      setRegPin('1234');

      refreshAccountsList();
      setActiveTab('list');
    } catch (err: any) {
      playWarningBeep();
      setToastMessage({
        type: 'error',
        text: err.message || 'May naganap na error sa pagrehistro ng account.',
      });
    } finally {
      setLoading(false);
    }
  };

  // Edit User Credentials
  const handleStartEdit = (user: UserAccount, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingUser(user);
    setEditName(user.name);
    setEditStoreName(user.storeName || '');
    setEditEmail(user.email || '');
    setEditPassword(user.password || '');
    setEditPin(user.pin || '1234');
    setEditRole(user.role);
    setEditPhone(user.phone || '');
    setToastMessage(null);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    setLoading(true);
    try {
      const updated = await adminUpdateUserCredentials(editingUser.id, {
        name: editName.trim(),
        email: editEmail.trim(),
        password: editPassword.trim(),
        pin: editPin.trim(),
        storeName: editStoreName.trim(),
        role: editRole,
        phone: editPhone.trim(),
      });

      playSuccessChime();
      setToastMessage({
        type: 'success',
        text: `Na-update ang credentials ni "${updated.name}"!`,
      });
      setEditingUser(null);
      refreshAccountsList();

      if (activeUser.id === updated.id) {
        onUserChanged(updated);
      }
    } catch (err: any) {
      playWarningBeep();
      setToastMessage({
        type: 'error',
        text: err.message || 'Nabigo sa pag-update ng account.',
      });
    } finally {
      setLoading(false);
    }
  };

  // Delete User Account
  const handleDeleteUser = async (user: UserAccount, e: React.MouseEvent) => {
    e.stopPropagation();
    if (user.id === 'user-admin' || user.email?.toLowerCase() === 'jeromellames7@gmail.com') {
      alert('Hindi maaaring burahin ang Primary Admin Account.');
      return;
    }

    if (confirm(`Sigurado ka bang nais mong burahin ang account ni "${user.name}" (${user.email || user.id})?`)) {
      try {
        await deleteUserAccount(user.id);
        playSuccessChime();
        setToastMessage({
          type: 'success',
          text: `Nabura ang account ni "${user.name}".`,
        });
        refreshAccountsList();
      } catch (err: any) {
        setToastMessage({
          type: 'error',
          text: err.message || 'Nabigo sa pagbura ng account.',
        });
      }
    }
  };

  // Filter accounts by search query
  const filteredAccounts = accounts.filter((acc) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      acc.name.toLowerCase().includes(q) ||
      (acc.email && acc.email.toLowerCase().includes(q)) ||
      (acc.storeName && acc.storeName.toLowerCase().includes(q)) ||
      (acc.role && acc.role.toLowerCase().includes(q)) ||
      (acc.pin && acc.pin.includes(q))
    );
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto select-none animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-slate-900 border border-amber-500/40 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.9)] overflow-hidden text-white relative my-4 animate-in zoom-in-95 duration-200 flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="px-5 sm:px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 via-orange-500 to-amber-600 p-0.5 shadow-lg shadow-amber-500/30 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <Shield className="w-5 h-5 text-amber-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm sm:text-base font-extrabold text-white tracking-tight">
                  ADMIN ACCOUNT MANAGER & REGISTER
                </h3>
                <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase">
                  Admin Access
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Tingnan ang lahat ng account, magrehistro ng bago, at i-tap para awtomatikong mabuksan
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-full hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-5 sm:px-6 pt-3 pb-2 border-b border-slate-800/80 bg-slate-950/50 flex items-center gap-2">
          <button
            onClick={() => {
              setActiveTab('list');
              setEditingUser(null);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
              activeTab === 'list'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Lahat ng Account ({accounts.length})</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('register');
              setEditingUser(null);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
              activeTab === 'register'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            <span>+ Magrehistro ng Bagong Account</span>
          </button>
        </div>

        {/* Feedback Banner */}
        {toastMessage && (
          <div
            className={`mx-5 sm:mx-6 mt-3 p-3 rounded-2xl border text-xs flex items-center gap-2.5 animate-in fade-in duration-200 ${
              toastMessage.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-500/40 text-emerald-300'
                : 'bg-rose-950/90 border-rose-500/40 text-rose-300'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span className="font-medium">{toastMessage.text}</span>
          </div>
        )}

        {/* Modal Main Content Area */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-4">
          {/* ========================================================= */}
          {/* TAB 1: LIST OF ALL REGISTERED ACCOUNTS */}
          {/* ========================================================= */}
          {activeTab === 'list' && (
            <div className="space-y-4">
              {/* Search Bar & Stats */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Maghanap ng account ayon sa pangalan, tindahan, o email..."
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-amber-400 transition-all"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={refreshAccountsList}
                    className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold border border-slate-700 flex items-center gap-1.5 transition-all"
                    title="I-refresh ang listahan"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Refresh</span>
                  </button>
                </div>
              </div>

              {/* Edit Account Modal / Drawer Inline */}
              {editingUser && (
                <div className="p-4 rounded-2xl bg-slate-800/95 border-2 border-amber-500/80 shadow-2xl space-y-3 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-700">
                    <h4 className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                      <Edit className="w-4 h-4 text-amber-400" />
                      <span>Palitan ang Credentials ni: {editingUser.name}</span>
                    </h4>
                    <button
                      type="button"
                      onClick={() => setEditingUser(null)}
                      className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-700"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <form onSubmit={handleSaveEdit} className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-300 mb-1">Pangalan ng User *</label>
                        <input
                          type="text"
                          required
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-amber-400 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-300 mb-1">Pangalan ng Tindahan</label>
                        <input
                          type="text"
                          value={editStoreName}
                          onChange={(e) => setEditStoreName(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-amber-400 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-300 mb-1">Gmail / Email *</label>
                        <input
                          type="email"
                          required
                          value={editEmail}
                          onChange={(e) => setEditEmail(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-amber-400 focus:outline-none font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-300 mb-1">Password *</label>
                        <input
                          type="text"
                          required
                          value={editPassword}
                          onChange={(e) => setEditPassword(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-amber-300 text-xs focus:border-amber-400 focus:outline-none font-mono font-bold"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-300 mb-1">4-Digit PIN</label>
                        <input
                          type="text"
                          maxLength={4}
                          value={editPin}
                          onChange={(e) => setEditPin(e.target.value.replace(/\D/g, ''))}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-cyan-300 text-xs focus:border-amber-400 focus:outline-none font-mono font-bold"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setEditingUser(null)}
                        className="flex-1 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold transition-all"
                      >
                        Kanselahin
                      </button>
                      <button
                        type="submit"
                        disabled={loading}
                        className="flex-1 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-extrabold shadow-lg shadow-amber-500/20 active:scale-95 transition-all flex items-center justify-center gap-1.5"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>{loading ? 'Sine-save...' : 'I-save ang Credentials'}</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Instructions banner */}
              <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>
                    <strong>1-Tap Instant Open:</strong> I-click ang kahit anong account card sa ibaba para <strong>awtomatikong mabuksan ang account</strong> nito!
                  </span>
                </div>
              </div>

              {/* Accounts Cards List */}
              <div className="space-y-3">
                {filteredAccounts.length === 0 ? (
                  <div className="py-10 text-center text-slate-500">
                    <Users className="w-10 h-10 mx-auto mb-2 opacity-40" />
                    <p className="text-xs">Walang account na tumutugma sa iyong search.</p>
                  </div>
                ) : (
                  filteredAccounts.map((user) => {
                    const isActive = activeUser.id === user.id;
                    const isUserAdmin = isCurrentUserAdmin(user);

                    return (
                      <div
                        key={user.id}
                        onClick={() => handleOpenAccount(user)}
                        className={`group relative p-4 rounded-2xl border transition-all cursor-pointer overflow-hidden ${
                          isActive
                            ? 'bg-gradient-to-r from-indigo-950/80 via-slate-900 to-slate-900 border-indigo-500/80 shadow-lg shadow-indigo-500/20 ring-2 ring-indigo-500/40'
                            : 'bg-slate-800/60 hover:bg-slate-800 border-slate-700/80 hover:border-amber-500/60'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          {/* Left: Avatar & Info */}
                          <div className="flex items-center gap-3.5 min-w-0">
                            <div className="relative shrink-0">
                              <img
                                src={user.avatar || undefined}
                                alt={user.name}
                                className={`w-12 h-12 rounded-2xl object-cover ring-2 transition-transform group-hover:scale-105 ${
                                  isActive
                                    ? 'ring-indigo-400'
                                    : isUserAdmin
                                    ? 'ring-amber-400'
                                    : 'ring-slate-600'
                                }`}
                              />
                              {isUserAdmin ? (
                                <Shield className="w-4 h-4 text-amber-400 absolute -bottom-1 -right-1 bg-slate-950 rounded-full p-0.5 border border-amber-500/50" />
                              ) : isActive ? (
                                <Check className="w-4 h-4 text-indigo-400 absolute -bottom-1 -right-1 bg-slate-950 rounded-full p-0.5 border border-indigo-500/50" />
                              ) : null}
                            </div>

                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h4 className="text-sm font-extrabold text-white group-hover:text-amber-300 transition-colors truncate">
                                  {user.name}
                                </h4>
                                {isUserAdmin ? (
                                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                                    <Shield className="w-2.5 h-2.5" /> Admin Account
                                  </span>
                                ) : (
                                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-700 text-slate-300 border border-slate-600">
                                    Cashier / User
                                  </span>
                                )}

                                {isActive && (
                                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-indigo-500/30 text-indigo-300 border border-indigo-500/50 flex items-center gap-1 animate-pulse">
                                    <CheckCircle2 className="w-3 h-3" /> Kasalukuyang Aktibo
                                  </span>
                                )}
                              </div>

                              <p className="text-xs text-indigo-300 font-medium mt-0.5 truncate flex items-center gap-1.5">
                                <Store className="w-3 h-3 text-indigo-400 shrink-0" />
                                <span>{user.storeName || `${user.name}'s Store`}</span>
                              </p>

                              <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1 font-mono flex-wrap">
                                {user.email && (
                                  <span className="flex items-center gap-1 text-cyan-300">
                                    <Mail className="w-3 h-3 text-cyan-400" />
                                    <span className="truncate max-w-[160px]">{user.email}</span>
                                  </span>
                                )}
                                <span>
                                  Pass: <strong className="text-amber-300">{user.password || '123456'}</strong>
                                </span>
                                <span>
                                  PIN: <strong className="text-cyan-300">{user.pin || '1234'}</strong>
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* Right: Actions & 1-Click Open Button */}
                          <div className="flex items-center gap-2 self-end sm:self-center shrink-0 flex-wrap">
                            {/* Edit Button */}
                            <button
                              type="button"
                              onClick={(e) => handleStartEdit(user, e)}
                              className="px-2.5 py-1.5 rounded-xl bg-slate-700/80 hover:bg-amber-500 text-slate-300 hover:text-slate-950 text-xs font-bold border border-slate-600 hover:border-amber-500 flex items-center gap-1 transition-all"
                              title="Baguhin ang Credentials"
                            >
                              <Edit className="w-3 h-3" />
                              <span className="hidden sm:inline">Edit</span>
                            </button>

                            {/* Delete Button (if not main admin) */}
                            {!isUserAdmin && user.id !== 'user-admin' && (
                              <button
                                type="button"
                                onClick={(e) => handleDeleteUser(user, e)}
                                className="p-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 transition-all"
                                title="Burahin ang account"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}

                            {/* Prominent Open Button */}
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleOpenAccount(user);
                              }}
                              className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold flex items-center gap-1.5 transition-all shadow-md active:scale-95 ${
                                isActive
                                  ? 'bg-indigo-600 text-white border border-indigo-400'
                                  : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 border border-amber-400 shadow-amber-500/20'
                              }`}
                            >
                              <LogIn className="w-3.5 h-3.5" />
                              <span>{isActive ? 'Aktibo' : 'Buksan ang Account'}</span>
                              {!isActive && <ArrowRight className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 2: REGISTER NEW ACCOUNT FORM */}
          {/* ========================================================= */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-200 text-xs flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 animate-pulse" />
                <span>
                  <strong>Awtomatikong Firebase Database Sync:</strong> Ang bawat bagong account ay awtomatikong magkakaroon ng sariling nakahiwalay na database para sa mga produkto, benta, at inventory.
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Pangalan ng User / Cashier *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="hal. Maria Santos"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400 transition-all font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Pangalan ng Tindahan / Negosyo</label>
                  <input
                    type="text"
                    placeholder="hal. Maria Sari-Sari Store"
                    value={regStoreName}
                    onChange={(e) => setRegStoreName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400 transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Gmail / Email Address * (Gagamitin sa Login at Firebase)</span>
                </label>
                <input
                  type="email"
                  required
                  placeholder="hal. maria@gmail.com"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-emerald-400 transition-all"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Password *</label>
                  <div className="relative">
                    <input
                      type={showRegPassword ? 'text' : 'password'}
                      required
                      placeholder="Minimum 4 characters"
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400 pr-9 transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowRegPassword(!showRegPassword)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                    >
                      {showRegPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Kumpirmahin ang Password *</label>
                  <input
                    type={showRegPassword ? 'text' : 'password'}
                    required
                    placeholder="I-type muli ang password"
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400 transition-all"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1">
                    <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                    <span>4-Digit Security PIN *</span>
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    placeholder="hal. 1234"
                    value={regPin}
                    onChange={(e) => setRegPin(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-cyan-300 font-mono font-bold tracking-widest text-xs focus:outline-none focus:border-emerald-400 transition-all"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>Contact Phone Number (Optional)</span>
                  </label>
                  <input
                    type="text"
                    placeholder="hal. 0917-123-4567"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-400 transition-all"
                  />
                </div>
              </div>

              {/* Avatar Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-2">Pumili ng Profile Avatar:</label>
                <div className="flex items-center gap-2.5 overflow-x-auto pb-2">
                  {AVATAR_PRESETS.map((url, i) => (
                    <img
                      key={i}
                      src={url || undefined}
                      alt="Avatar Preset"
                      onClick={() => setRegAvatar(url)}
                      className={`w-11 h-11 rounded-2xl object-cover cursor-pointer transition-all ${
                        regAvatar === url
                          ? 'ring-3 ring-emerald-400 scale-110 shadow-lg shadow-emerald-500/20'
                          : 'opacity-60 hover:opacity-100 hover:scale-105'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('list')}
                  className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-all"
                >
                  Bumalik sa Listahan
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-extrabold text-xs shadow-lg shadow-emerald-500/25 active:scale-98 transition-all flex items-center justify-center gap-2"
                >
                  <UserPlus className="w-4 h-4 text-slate-950" />
                  <span>{loading ? 'Gumagawa ng Account...' : 'I-rehistro at Gumawa ng Account'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
