import React, { useState, useEffect } from 'react';
import { UserAccount } from '../types';
import {
  getAccounts,
  setActiveUser,
  setAdminPin,
  resetToSampleData,
  saveUserAccount,
  getAdminTargetAccountId,
  setAdminTargetAccountId,
  adminUpdateUserCredentials,
  isCurrentUserAdmin,
} from '../utils/storage';
import { getLanguage, t, LANG_CHANGE_EVENT } from '../utils/language';
import { AdminDatabaseModal } from './AdminDatabaseModal';
import { FormatDataModal } from './FormatDataModal';
import { BackupRestoreModal } from './BackupRestoreModal';
import { UserCheck, Shield, KeyRound, RefreshCw, CheckCircle, Lock, Layers, Database, Edit, Phone, Info, X, Save, ExternalLink, Trash2 } from 'lucide-react';

interface AccountsManagerProps {
  activeUser: UserAccount;
  onRequestAdminPin: (onSuccess: () => void, message?: string) => void;
  onUserChanged: (newUser: UserAccount) => void;
}

export const AccountsManager: React.FC<AccountsManagerProps> = ({
  activeUser,
  onRequestAdminPin,
  onUserChanged,
}) => {
  const isAdmin = isCurrentUserAdmin(activeUser);
  const [accounts, setAccountsState] = useState<UserAccount[]>(getAccounts());
  const [adminTargetId, setAdminTargetIdState] = useState<string | null>(
    isAdmin ? getAdminTargetAccountId() : null
  );

  const [isDbModalOpen, setIsDbModalOpen] = useState(false);
  const [dbModalAccountId, setDbModalAccountId] = useState<string>('user-admin');
  const [isFormatModalOpen, setIsFormatModalOpen] = useState(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);

  const [isChangingPin, setIsChangingPin] = useState(false);
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [pinSuccessMsg, setPinSuccessMsg] = useState(false);
  const [pinError, setPinError] = useState('');
  const [, setLangState] = useState(getLanguage());

  // State for Editing User Account Information
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [editFormName, setEditFormName] = useState('');
  const [editFormEmail, setEditFormEmail] = useState('');
  const [editFormPassword, setEditFormPassword] = useState('');
  const [editFormStoreName, setEditFormStoreName] = useState('');
  const [editFormPin, setEditFormPin] = useState('');
  const [editFormShift, setEditFormShift] = useState('');
  const [editFormInfo, setEditFormInfo] = useState('');
  const [editFormPhone, setEditFormPhone] = useState('');
  const [editFormAvatar, setEditFormAvatar] = useState('');

  const refreshAccounts = () => {
    setAccountsState(getAccounts());
  };

  useEffect(() => {
    const handleLangChange = () => setLangState(getLanguage());
    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
  }, []);

  const handleSelectAccount = (targetUser: UserAccount) => {
    if (targetUser.id === activeUser.id) return;

    if (targetUser.role === 'Admin') {
      // Require Admin PIN before switching to Admin account!
      onRequestAdminPin(() => {
        const switched = setActiveUser(targetUser.id);
        if (switched) {
          setAdminTargetIdState(null);
          onUserChanged(switched);
          refreshAccounts();
        }
      });
    } else {
      // Standard switch
      const switched = setActiveUser(targetUser.id);
      if (switched) {
        setAdminTargetIdState(null);
        onUserChanged(switched);
        refreshAccounts();
      }
    }
  };

  const handleAdminSelectTargetAccount = (targetAccountId: string | null) => {
    if (!isAdmin) return;
    setAdminTargetAccountId(targetAccountId);
    setAdminTargetIdState(targetAccountId);
  };

  const handleOpenEditUser = (userToEdit: UserAccount, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingUser(userToEdit);
    setEditFormName(userToEdit.name);
    setEditFormEmail(userToEdit.email || '');
    setEditFormPassword(userToEdit.password || '');
    setEditFormStoreName(userToEdit.storeName || '');
    setEditFormPin(userToEdit.pin || '');
    setEditFormShift(userToEdit.shift || '');
    setEditFormInfo(userToEdit.info || '');
    setEditFormPhone(userToEdit.phone || '');
    setEditFormAvatar(userToEdit.avatar || '');
  };

  const handleSaveUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    const updated: UserAccount = {
      ...editingUser,
      name: editFormName.trim() || editingUser.name,
      email: editFormEmail.trim() || undefined,
      password: editFormPassword.trim() || undefined,
      storeName: editFormStoreName.trim() || undefined,
      pin: editFormPin.trim() || undefined,
      shift: editFormShift.trim(),
      info: editFormInfo.trim(),
      phone: editFormPhone.trim(),
      avatar: editFormAvatar.trim() || editingUser.avatar,
    };

    if (isAdmin) {
      adminUpdateUserCredentials(editingUser.id, {
        email: updated.email,
        password: updated.password,
        pin: updated.pin,
        storeName: updated.storeName,
        name: updated.name,
        phone: updated.phone,
      });
    }

    saveUserAccount(updated);
    refreshAccounts();

    if (activeUser.id === updated.id) {
      onUserChanged(updated);
    }

    setEditingUser(null);
  };

  const handleChangePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.length !== 4 || isNaN(Number(newPin))) {
      setPinError('Dapat 4-digit number ang PIN!');
      return;
    }
    if (newPin !== confirmPin) {
      setPinError('Hindi magkamukha ang kinonfirm na PIN!');
      return;
    }

    // Require current Admin PIN confirmation
    onRequestAdminPin(() => {
      setAdminPin(newPin);
      setPinSuccessMsg(true);
      setIsChangingPin(false);
      setNewPin('');
      setConfirmPin('');
      setPinError('');
      setTimeout(() => setPinSuccessMsg(false), 3000);
    });
  };

  const handleResetData = () => {
    onRequestAdminPin(() => {
      if (confirm('Sigurado ka bang gusto mong i-reset ang lahat ng data sa default sample products at sales?')) {
        resetToSampleData();
        alert('Nareset na ang database!');
        window.location.reload();
      }
    });
  };

  const handleOpenAccountDbModal = (accountId: string | null) => {
    handleAdminSelectTargetAccount(accountId);
    setDbModalAccountId(accountId || 'user-admin');
    setIsDbModalOpen(true);
  };

  // Filter accounts: if admin, show all; if regular user, show only their own account
  const visibleAccounts = isAdmin ? accounts : [activeUser];

  return (
    <div className="space-y-4 pb-40 sm:pb-44 max-w-xl mx-auto">
      {/* Header */}
      <div className="bg-white border border-slate-200/80 p-4 rounded-3xl shadow-xs">
        <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
          <UserCheck className="w-5 h-5 text-indigo-600" />
          <span>{t('accountsTitle')}</span>
        </h2>
        <p className="text-xs text-slate-500 mt-1">{t('accountsSub')}</p>
      </div>

      {/* Admin Cross-Account Store Control Panel */}
      {isAdmin && (
        <div className="bg-amber-50 border border-amber-200 rounded-3xl p-4 space-y-3 shadow-xs">
          <div className="flex items-center justify-between text-amber-900 font-bold text-xs">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-600" />
              <span>Admin Control: {t('adminCrossControl')}</span>
            </div>
            <button
              onClick={() => handleOpenAccountDbModal(adminTargetId || 'user-admin')}
              className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-[11px] font-extrabold flex items-center gap-1 shadow-xs transition-transform active:scale-95"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Buksan Pop-up DB Table</span>
            </button>
          </div>

          <p className="text-xs text-amber-800 leading-snug">
            I-click ang kahit anong button sa ibaba upang <strong>awtomatikong mag-pop up ang interactive database table</strong> ng bawat cashier/account para tingnan o i-edit ang mga na-scan na produkto at benta.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
            <button
              onClick={() => handleOpenAccountDbModal(null)}
              className={`p-2.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-xs ${
                adminTargetId === null
                  ? 'bg-amber-600 text-white border-amber-600 ring-2 ring-amber-500/30'
                  : 'bg-white text-slate-700 border-amber-200 hover:bg-amber-100/70'
              }`}
            >
              <Database className="w-3.5 h-3.5 text-amber-500" />
              <span>Admin DB (Own)</span>
            </button>

            {accounts
              .filter((a) => a.role !== 'Admin')
              .map((acc) => {
                const isSelected = adminTargetId === acc.id;
                return (
                  <button
                    key={acc.id}
                    onClick={() => handleOpenAccountDbModal(acc.id)}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 truncate shadow-xs ${
                      isSelected
                        ? 'bg-amber-600 text-white border-amber-600 ring-2 ring-amber-500/30'
                        : 'bg-white text-slate-700 border-amber-200 hover:bg-amber-100/70'
                    }`}
                  >
                    <Layers className="w-3.5 h-3.5 text-amber-500" />
                    <span>{acc.name.split(' ')[0]} DB</span>
                  </button>
                );
              })}
          </div>
        </div>
      )}

      {/* Account Cards */}
      <div className="space-y-3">
        <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block px-1">
          {isAdmin ? 'Lahat ng Nakarehistrong Account:' : 'Ang Iyong Aktibong Account:'}
        </label>

        {visibleAccounts.map((user) => {
          const isActive = activeUser.id === user.id;
          return (
            <div
              key={user.id}
              onClick={() => isAdmin ? handleSelectAccount(user) : undefined}
              className={`p-4 rounded-2xl border transition-all ${isAdmin ? 'cursor-pointer' : ''} space-y-3 shadow-xs ${
                isActive
                  ? 'bg-white border-indigo-600 ring-2 ring-indigo-600/10'
                  : 'bg-white/90 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start space-x-3 min-w-0 flex-1">
                  <div className="relative shrink-0">
                    <img src={user.avatar || undefined} alt={user.name} className="w-12 h-12 rounded-full object-cover ring-2 ring-slate-100" />
                    {user.role === 'Admin' && (
                      <Shield className="w-4 h-4 text-amber-500 absolute -bottom-1 -right-1 bg-white rounded-full p-0.5 border border-slate-200" />
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <h3 className="text-sm font-bold text-slate-900 truncate">{user.name}</h3>
                      {user.role === 'Admin' ? (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200 flex items-center gap-1 shrink-0">
                          <Lock className="w-2.5 h-2.5" /> PIN Protected
                        </span>
                      ) : (
                        <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 shrink-0">
                          User Account
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-indigo-600 font-medium mt-0.5">{user.storeName || user.shift}</p>

                    {user.email && (
                      <p className="text-[11px] text-slate-500 font-mono mt-0.5 truncate">
                        {user.email}
                      </p>
                    )}

                    {user.phone && (
                      <p className="text-[11px] text-slate-500 flex items-center gap-1 mt-1 font-mono">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{user.phone}</span>
                      </p>
                    )}

                    {user.info && (
                      <p className="text-[11px] text-slate-600 bg-slate-50 border border-slate-100 p-2 rounded-xl mt-1.5 leading-tight">
                        {user.info}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex flex-col items-end gap-2 shrink-0">
                  {isActive ? (
                    <div className="flex items-center gap-1 text-indigo-600 text-xs font-bold bg-indigo-50 px-2.5 py-1 rounded-xl border border-indigo-100">
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>{t('activeStatus')}</span>
                    </div>
                  ) : isAdmin ? (
                    <button className="px-3 py-1 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-200">
                      Switch
                    </button>
                  ) : null}

                  {/* Edit User Info Button */}
                  <button
                    onClick={(e) => handleOpenEditUser(user, e)}
                    className="px-2.5 py-1 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold border border-indigo-200 flex items-center gap-1 transition-colors"
                    title="Baguhin ang Impormasyon ng Account"
                  >
                    <Edit className="w-3 h-3 text-indigo-600" />
                    <span>Edit Profile</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Admin Security Settings */}
      {isAdmin && (
        <div className="bg-white border border-slate-200/80 rounded-3xl p-5 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <KeyRound className="w-4 h-4 text-amber-500" />
                <span>Admin Protection PIN Settings</span>
              </h3>
              <p className="text-xs text-slate-500">
                Protected by 4-Digit Admin Security PIN
              </p>
            </div>

            <button
              onClick={() => setIsChangingPin(!isChangingPin)}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-200"
            >
              {isChangingPin ? t('cancel') : 'Baguhin ang PIN'}
            </button>
          </div>

          {pinSuccessMsg && (
            <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-bold flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              <span>Matagumpay na nabago ang Admin Security PIN!</span>
            </div>
          )}

          {isChangingPin && (
            <form onSubmit={handleChangePinSubmit} className="space-y-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Bagong 4-Digit PIN:</label>
                  <input
                    type="password"
                    maxLength={4}
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value)}
                    placeholder="e.g. 5678"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">I-confirm Bagong PIN:</label>
                  <input
                    type="password"
                    maxLength={4}
                    value={confirmPin}
                    onChange={(e) => setConfirmPin(e.target.value)}
                    placeholder="e.g. 5678"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:border-indigo-600"
                  />
                </div>
              </div>

              {pinError && <p className="text-xs text-rose-500 font-medium">{pinError}</p>}

              <button
                type="submit"
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-100"
              >
                I-save Bagong Admin PIN
              </button>
            </form>
          )}

          <div className="pt-2 border-t border-slate-100 space-y-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                onClick={() => setIsFormatModalOpen(true)}
                className="py-2.5 px-3 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-md shadow-rose-200 flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                <Trash2 className="w-4 h-4" />
                <span>Format Database (PIN 1234)</span>
              </button>

              <button
                onClick={() => setIsBackupModalOpen(true)}
                className="py-2.5 px-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-200 flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                <Database className="w-4 h-4" />
                <span>Backup / Restore Data</span>
              </button>
            </div>

            <button
              onClick={handleResetData}
              className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
              <span>Reset to Original Sample Data & PIN (1234)</span>
            </button>
          </div>
        </div>
      )}

      {/* Edit User Information Modal */}
      {editingUser && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white border border-slate-200/80 rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Edit className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold text-slate-900">Edit User Information</h3>
              </div>
              <button
                onClick={() => setEditingUser(null)}
                className="p-1 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveUserSubmit} className="space-y-3 max-h-[75vh] overflow-y-auto pr-1">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Pangalan ng User / Cashier *</label>
                <input
                  type="text"
                  required
                  value={editFormName}
                  onChange={(e) => setEditFormName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-bold focus:outline-none focus:border-indigo-600 focus:bg-white"
                  placeholder="e.g. Ate Maria"
                />
              </div>

              {/* Store Name */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Pangalan ng Tindahan / Store Name</label>
                <input
                  type="text"
                  value={editFormStoreName}
                  onChange={(e) => setEditFormStoreName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 focus:bg-white"
                  placeholder="e.g. Maria Sari-Sari Store"
                />
              </div>

              {/* Email / Gmail (Admin Editable) */}
              <div>
                <label className="text-xs font-bold text-slate-700 flex items-center justify-between mb-1">
                  <span>Gmail / Email Address</span>
                  <span className="text-[10px] text-indigo-600 font-mono">Firebase Auth</span>
                </label>
                <input
                  type="email"
                  value={editFormEmail}
                  onChange={(e) => setEditFormEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:border-indigo-600 focus:bg-white"
                  placeholder="e.g. maria@gmail.com"
                />
              </div>

              {/* Password (Admin Editable) */}
              <div>
                <label className="text-xs font-bold text-slate-700 flex items-center justify-between mb-1">
                  <span>Password</span>
                  <span className="text-[10px] text-amber-600 font-mono">Admin Override</span>
                </label>
                <input
                  type="text"
                  value={editFormPassword}
                  onChange={(e) => setEditFormPassword(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:border-indigo-600 focus:bg-white"
                  placeholder="e.g. pass1234"
                />
              </div>

              {/* 4-digit PIN */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">4-Digit Security PIN</label>
                <input
                  type="text"
                  maxLength={4}
                  value={editFormPin}
                  onChange={(e) => setEditFormPin(e.target.value.replace(/\D/g, ''))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono font-bold tracking-widest focus:outline-none focus:border-indigo-600 focus:bg-white"
                  placeholder="e.g. 1234"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Shift / Schedule</label>
                <input
                  type="text"
                  value={editFormShift}
                  onChange={(e) => setEditFormShift(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 focus:bg-white"
                  placeholder="e.g. Morning Shift (7:00 AM - 3:00 PM)"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Phone Number</label>
                <input
                  type="text"
                  value={editFormPhone}
                  onChange={(e) => setEditFormPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:border-indigo-600 focus:bg-white"
                  placeholder="e.g. 0917-123-4567"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Information / Store Note</label>
                <textarea
                  rows={2}
                  value={editFormInfo}
                  onChange={(e) => setEditFormInfo(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 focus:bg-white"
                  placeholder="e.g. Counter 1 - Grocery cashier"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Avatar Image URL</label>
                <input
                  type="text"
                  value={editFormAvatar}
                  onChange={(e) => setEditFormAvatar(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:border-indigo-600 focus:bg-white"
                  placeholder="https://..."
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold border border-slate-200"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-100 flex items-center justify-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>I-save User Info</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Admin Interactive Pop-up Database Table Modal */}
      <AdminDatabaseModal
        isOpen={isDbModalOpen}
        onClose={() => setIsDbModalOpen(false)}
        initialAccountId={dbModalAccountId}
      />

      {/* Format Data PIN Modal */}
      <FormatDataModal
        isOpen={isFormatModalOpen}
        onClose={() => {
          setIsFormatModalOpen(false);
          refreshAccounts();
        }}
        targetAccountId={activeUser.id}
        accountName={activeUser.storeName || activeUser.name}
      />

      {/* Backup & Restore Data Modal */}
      <BackupRestoreModal
        isOpen={isBackupModalOpen}
        onClose={() => {
          setIsBackupModalOpen(false);
          refreshAccounts();
        }}
      />
    </div>
  );
};
