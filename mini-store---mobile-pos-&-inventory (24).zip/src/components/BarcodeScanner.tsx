import React, { useEffect, useRef, useState } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { Product } from '../types';
import { findProductByBarcode, getProducts } from '../utils/storage';
import { playScanBeep } from '../utils/sound';
import { getLanguage, t, LANG_CHANGE_EVENT } from '../utils/language';
import { Camera, CameraOff, RefreshCw, Search, PlusCircle, AlertCircle, Sparkles, Volume2 } from 'lucide-react';

interface BarcodeScannerProps {
  onProductScanned: (product: Product) => void;
  onUnregisteredBarcodeScanned: (barcode: string) => void;
  onOpenAddProduct: () => void;
}

export const BarcodeScanner: React.FC<BarcodeScannerProps> = ({
  onProductScanned,
  onUnregisteredBarcodeScanned,
  onOpenAddProduct,
}) => {
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [manualBarcode, setManualBarcode] = useState<string>('');
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [lastScannedCode, setLastScannedCode] = useState<string | null>(null);
  const [scanSuccessFlash, setScanSuccessFlash] = useState<boolean>(false);
  const [, setLangState] = useState(getLanguage());

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const lastScanTimeRef = useRef<{ code: string; time: number }>({ code: '', time: 0 });
  const qrCodeRegionId = 'html5qr-code-full-region';

  // Active store products for quick test tap buttons
  const allProducts = getProducts();

  useEffect(() => {
    const handleLangChange = () => setLangState(getLanguage());
    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
  }, []);

  const startScanner = async () => {
    setCameraError(null);
    try {
      if (scannerRef.current) {
        try {
          if (scannerRef.current.isScanning) {
            await scannerRef.current.stop();
          }
          scannerRef.current.clear();
        } catch (e) {
          // ignore cleanup
        }
      }

      const html5Qrcode = new Html5Qrcode(qrCodeRegionId, {
        formatsToSupport: [
          Html5QrcodeSupportedFormats.QR_CODE,
          Html5QrcodeSupportedFormats.EAN_13,
          Html5QrcodeSupportedFormats.EAN_8,
          Html5QrcodeSupportedFormats.UPC_A,
          Html5QrcodeSupportedFormats.UPC_E,
          Html5QrcodeSupportedFormats.CODE_128,
          Html5QrcodeSupportedFormats.CODE_39,
          Html5QrcodeSupportedFormats.ITF,
          Html5QrcodeSupportedFormats.DATA_MATRIX,
        ],
        verbose: false,
      });

      scannerRef.current = html5Qrcode;

      const config = {
        fps: 25,
        qrbox: (viewfinderWidth: number, viewfinderHeight: number) => {
          const minEdge = Math.min(viewfinderWidth, viewfinderHeight);
          return {
            width: Math.floor(minEdge * 0.95),
            height: Math.floor(minEdge * 0.7),
          };
        },
        aspectRatio: 1.0,
      };

      // Robust device initialization for iPhone / iOS / Android
      // On iOS Safari, passing exact deviceId from getCameras before permission can fail; facingMode environment is safest.
      let cameraConfig: any = { facingMode: facingMode };
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);

      if (!isIOS) {
        try {
          const devices = await Html5Qrcode.getCameras();
          if (devices && devices.length > 0) {
            const matchedCam = devices.find((d) => {
              const label = d.label.toLowerCase();
              if (facingMode === 'environment') {
                return label.includes('back') || label.includes('rear') || label.includes('environment') || label.includes('main');
              } else {
                return label.includes('front') || label.includes('user');
              }
            });
            if (matchedCam) {
              cameraConfig = { deviceId: { exact: matchedCam.id } };
            }
          }
        } catch (camErr) {
          cameraConfig = { facingMode: facingMode };
        }
      } else {
        // iOS Safari loves facingMode object with ideal/exact
        cameraConfig = { facingMode: { ideal: 'environment' } };
      }

      try {
        await html5Qrcode.start(
          cameraConfig,
          config,
          (decodedText) => {
            handleScannedBarcode(decodedText);
          },
          () => {
            // frame scan error - safe to ignore
          }
        );
      } catch (firstStartErr) {
        // Ultimate fallback for strict iPhone Safari constraints
        await html5Qrcode.start(
          { facingMode: 'environment' },
          config,
          (decodedText) => {
            handleScannedBarcode(decodedText);
          },
          () => {}
        );
      }

      setIsCameraActive(true);
    } catch (err: unknown) {
      console.warn('Camera failed to start:', err);
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
      setCameraError(
        isIOS
          ? 'Sa iPhone: Pakisiguradong naka-allow ang Camera sa Safari Settings, o buksan ang app sa Safari browser (hindi sa Facebook/Messenger in-app browser).'
          : getLanguage() === 'tl'
          ? 'Hindi mabuksan ang camera. Gamitin ang manual search o quick test barcodes sa ibaba.'
          : 'Unable to open camera. Use manual search or quick test barcodes below.'
      );
      setIsCameraActive(false);
    }
  };

  const stopScanner = async () => {
    if (scannerRef.current && scannerRef.current.isScanning) {
      try {
        await scannerRef.current.stop();
        scannerRef.current.clear();
      } catch (err) {
        console.warn('Error stopping scanner:', err);
      }
    }
    setIsCameraActive(false);
  };

  const handleScannedBarcode = (barcode: string) => {
    const cleanCode = barcode.trim();
    if (!cleanCode) return;

    // Cooldown check (1.5 seconds) to avoid double scanning the same code immediately
    const now = Date.now();
    if (lastScanTimeRef.current.code === cleanCode && now - lastScanTimeRef.current.time < 1500) {
      return;
    }
    lastScanTimeRef.current = { code: cleanCode, time: now };

    // Trigger audio beep feedback for instant scan confirmation
    playScanBeep();

    // Trigger green visual flash
    setScanSuccessFlash(true);
    setTimeout(() => setScanSuccessFlash(false), 500);

    setLastScannedCode(cleanCode);

    const foundProduct = findProductByBarcode(cleanCode);

    if (foundProduct) {
      onProductScanned(foundProduct);
    } else {
      onUnregisteredBarcodeScanned(cleanCode);
    }
  };

  const handleToggleFacingMode = async () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
    if (isCameraActive) {
      await stopScanner();
      setTimeout(() => startScanner(), 200);
    }
  };

  const handleManualSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualBarcode.trim()) {
      handleScannedBarcode(manualBarcode.trim());
    }
  };

  useEffect(() => {
    startScanner();
    return () => {
      stopScanner();
    };
  }, [facingMode]);

  return (
    <div className="space-y-4 max-w-lg mx-auto pb-40 sm:pb-44">
      {/* Scanner View Box */}
      <div className={`bg-white border rounded-3xl overflow-hidden shadow-sm transition-all relative ${
        scanSuccessFlash ? 'border-emerald-500 ring-4 ring-emerald-500/20' : 'border-slate-200/80'
      }`}>
        {/* Header Bar */}
        <div className="bg-slate-50 px-4 py-3 border-b border-slate-200/80 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              {t('liveScanner')}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <div className="flex items-center gap-1 text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full font-bold">
              <Volume2 className="w-3 h-3 text-emerald-600" />
              <span className="hidden sm:inline">Beep Audio Sound</span>
            </div>

            <button
              onClick={handleToggleFacingMode}
              className="p-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-700 text-xs flex items-center gap-1 border border-slate-200 transition-colors shadow-xs"
              title="Camera switch"
            >
              <RefreshCw className="w-3.5 h-3.5 text-indigo-600" />
              <span className="hidden xs:inline text-[11px] font-semibold">{facingMode === 'environment' ? 'Back' : 'Front'}</span>
            </button>

            <button
              onClick={isCameraActive ? stopScanner : startScanner}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-all shadow-xs ${
                isCameraActive
                  ? 'bg-rose-50 text-rose-600 border border-rose-200 hover:bg-rose-100'
                  : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-indigo-100'
              }`}
            >
              {isCameraActive ? (
                <>
                  <CameraOff className="w-3.5 h-3.5" /> Stop
                </>
              ) : (
                <>
                  <Camera className="w-3.5 h-3.5" /> Start
                </>
              )}
            </button>
          </div>
        </div>

        {/* Camera Video Container */}
        <div className="relative bg-slate-900 w-full h-72 sm:h-80 flex items-center justify-center overflow-hidden">
          {/* Target Scanning Reticle Overlay */}
          <div id={qrCodeRegionId} className="w-full h-full absolute inset-0" />

          {/* Animated Laser Scanning Line Overlay */}
          {isCameraActive && (
            <div className="absolute inset-x-6 top-1/2 -translate-y-1/2 z-10 pointer-events-none flex flex-col items-center">
              <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-rose-500 to-transparent shadow-[0_0_12px_#f43f5e] animate-pulse" />
              <span className="text-[10px] font-bold text-rose-300 bg-slate-900/80 px-2.5 py-0.5 rounded-full border border-rose-500/30 mt-2 tracking-wide uppercase shadow-lg">
                I-tapat ang Barcode (Guhit-Guhit na Black) sa Line
              </span>
            </div>
          )}

          {!isCameraActive && (
            <div className="p-6 text-center space-y-3 z-10">
              <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center mx-auto text-white">
                <Camera className="w-7 h-7" />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">{t('cameraOff')}</p>
                <p className="text-xs text-slate-300 mt-1 max-w-xs mx-auto">
                  {t('cameraOffSub')}
                </p>
              </div>
              <button
                onClick={startScanner}
                className="py-2.5 px-5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-500/30"
              >
                {t('startCamera')}
              </button>
            </div>
          )}

          {cameraError && (
            <div className="absolute inset-0 bg-slate-900/95 p-4 flex flex-col items-center justify-center text-center z-20">
              <AlertCircle className="w-8 h-8 text-orange-400 mb-2" />
              <p className="text-xs text-slate-200 font-medium max-w-xs">{cameraError}</p>
              <button
                onClick={startScanner}
                className="mt-3 px-3 py-1.5 bg-white text-indigo-600 text-xs font-bold rounded-lg border border-slate-200 shadow-xs"
              >
                Retry
              </button>
            </div>
          )}
        </div>

        {/* Quick Fast Scan Instruction Banner */}
        <div className="bg-slate-50 px-4 py-2 border-t border-slate-200/80 flex items-center justify-between text-xs">
          <span className="text-slate-500 font-medium truncate">{t('fastScanHint')}</span>
          {lastScannedCode && (
            <span className="font-mono text-indigo-600 font-bold bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-100 flex-shrink-0">
              {lastScannedCode}
            </span>
          )}
        </div>
      </div>

      {/* Manual Entry Search */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-4 shadow-xs">
        <div className="flex items-center justify-between mb-2">
          <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <Search className="w-3.5 h-3.5 text-indigo-600" />
            <span>{t('manualSearch')}</span>
          </label>
          <button
            onClick={onOpenAddProduct}
            className="text-xs font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            {t('addProduct')}
          </button>
        </div>

        <form onSubmit={handleManualSearch} className="flex gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={manualBarcode}
              onChange={(e) => setManualBarcode(e.target.value)}
              placeholder={t('manualSearchPlaceholder')}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 placeholder-slate-400 font-mono focus:outline-none focus:border-indigo-600 focus:bg-white"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-100 transition-all active:scale-95"
          >
            Search
          </button>
        </form>
      </div>

      {/* 1-Click Sample Barcodes (Audio & Popup Testing Helper) */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-4 shadow-xs">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
            <Sparkles className="w-4 h-4 text-orange-500" />
            <span>{t('quickTestBarcodes')}</span>
          </div>
          <span className="text-[10px] text-slate-400 font-medium">{t('tapToSimulate')}</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {allProducts.slice(0, 6).map((item) => (
            <button
              key={item.id}
              onClick={() => handleScannedBarcode(item.barcode)}
              className="p-2 bg-slate-50 hover:bg-indigo-50/50 border border-slate-200 hover:border-indigo-200 rounded-xl text-left transition-all group flex items-center gap-2"
            >
              <img
                src={item.imageUrl || undefined}
                alt={item.name}
                className="w-8 h-8 rounded-lg object-cover bg-slate-200 border border-slate-200"
              />
              <div className="min-w-0 flex-1">
                <p className="text-[11px] font-bold text-slate-800 truncate group-hover:text-indigo-600">
                  {item.name}
                </p>
                <div className="flex items-center justify-between mt-0.5 text-[10px]">
                  <span className="font-mono text-slate-400">{item.barcode.slice(-6)}</span>
                  <span className="font-bold text-indigo-600">₱{item.price}</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
