import React, { useState, useEffect } from 'react';
import { UtangRecord } from '../types';
import { getUtangRecords, addUtangRecord, recordUtangPayment, DATA_CHANGE_EVENT } from '../utils/storage';
import { X, BookOpen, CreditCard, Plus, DollarSign, Calendar, Search, CheckCircle, UserCheck, Phone, TrendingUp, Sparkles } from 'lucide-react';

interface UtangLedgerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UtangLedgerModal: React.FC<UtangLedgerModalProps> = ({ isOpen, onClose }) => {
  const [utangList, setUtangList] = useState<UtangRecord[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'ALL' | 'UNPAID' | 'PAID'>('UNPAID');

  // Add new Credit Record modal state
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newCustomerName, setNewCustomerName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newAmount, setNewAmount] = useState('');
  const [newMarkup, setNewMarkup] = useState('');
  const [newSummary, setNewSummary] = useState('');
  const [newDueDate, setNewDueDate] = useState('');

  // Payment settlement modal state
  const [payRecord, setPayRecord] = useState<UtangRecord | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payNotes, setPayNotes] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const loadData = () => {
    setUtangList(getUtangRecords());
  };

  useEffect(() => {
    if (isOpen) loadData();
    window.addEventListener(DATA_CHANGE_EVENT, loadData);
    return () => window.removeEventListener(DATA_CHANGE_EVENT, loadData);
  }, [isOpen]);

  if (!isOpen) return null;

  const totalOutstanding = utangList
    .filter((u) => u.status !== 'PAID')
    .reduce((sum, u) => sum + u.balanceRemaining, 0);

  const totalCustomersWithUtang = utangList.filter((u) => u.status !== 'PAID').length;

  const filteredRecords = utangList.filter((r) => {
    const matchesSearch =
      r.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (r.customerPhone && r.customerPhone.includes(searchQuery)) ||
      r.itemsSummary.toLowerCase().includes(searchQuery.toLowerCase());

    if (selectedFilter === 'UNPAID') return matchesSearch && r.status !== 'PAID';
    if (selectedFilter === 'PAID') return matchesSearch && r.status === 'PAID';
    return matchesSearch;
  });

  const handleAddUtangSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomerName.trim() || !newAmount || parseFloat(newAmount) <= 0) return;

    const parsedAmount = parseFloat(newAmount);
    const parsedMarkup = newMarkup ? parseFloat(newMarkup) : undefined;

    addUtangRecord({
      customerName: newCustomerName.trim(),
      customerPhone: newPhone.trim() || undefined,
      itemsSummary: newSummary.trim() || 'General Store Credit',
      totalAmount: parsedAmount,
      markupAmount: parsedMarkup,
      dueDate: newDueDate || undefined,
    });

    setNewCustomerName('');
    setNewPhone('');
    setNewAmount('');
    setNewMarkup('');
    setNewSummary('');
    setNewDueDate('');
    setIsAddOpen(false);
    setSuccessMsg('Store Credit record added successfully!');
    setTimeout(() => setSuccessMsg(''), 3500);
  };

  const handleRecordPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payRecord || !payAmount || parseFloat(payAmount) <= 0) return;

    const numAmount = parseFloat(payAmount);
    recordUtangPayment(payRecord.id, numAmount, payNotes.trim() || undefined);
    setPayRecord(null);
    setPayAmount('');
    setPayNotes('');
    setSuccessMsg('Payment settlement recorded and added to cash sales!');
    setTimeout(() => setSuccessMsg(''), 3500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight flex items-center gap-2">
                <span>Store Credit & Debt Ledger</span>
                <span className="bg-amber-400 text-slate-900 text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider">
                  STORE CREDIT DEBT
                </span>
              </h3>
              <p className="text-xs text-slate-300">
                Track customer credit balances, manage debts, and record payments or settlements
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Banner */}
        {successMsg && (
          <div className="bg-emerald-600 text-white px-4 py-2.5 text-xs font-bold text-center flex items-center justify-center gap-2 animate-in slide-in-from-top">
            <CheckCircle className="w-4 h-4" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Summary Metric Strip */}
        <div className="p-4 bg-slate-50 border-b border-slate-200/80 grid grid-cols-2 gap-3">
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-3 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-amber-800 uppercase tracking-wide">TOTAL OUTSTANDING BALANCE (COLLECTIBLES)</p>
              <h4 className="text-xl font-black text-amber-900 mt-0.5">₱{totalOutstanding.toFixed(2)}</h4>
            </div>
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold">
              ₱
            </div>
          </div>

          <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-2xl p-3 flex items-center justify-between">
            <div>
              <p className="text-[11px] font-bold text-indigo-800 uppercase tracking-wide">CUSTOMERS WITH STORE CREDIT</p>
              <h4 className="text-xl font-black text-indigo-900 mt-0.5">{totalCustomersWithUtang} {totalCustomersWithUtang === 1 ? 'Customer' : 'Customers'}</h4>
            </div>
            <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
              <UserCheck className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* Toolbar & Filter Bar */}
        <div className="p-3 sm:p-4 border-b border-slate-100 flex flex-col sm:flex-row gap-2 items-stretch sm:items-center justify-between bg-white">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search customer name, phone number, or items..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <div className="bg-slate-100 p-1 rounded-xl flex items-center gap-1">
              <button
                onClick={() => setSelectedFilter('UNPAID')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  selectedFilter === 'UNPAID'
                    ? 'bg-amber-500 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Unpaid Credit
              </button>
              <button
                onClick={() => setSelectedFilter('PAID')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  selectedFilter === 'PAID'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Fully Paid
              </button>
              <button
                onClick={() => setSelectedFilter('ALL')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  selectedFilter === 'ALL'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All Records
              </button>
            </div>

            <button
              onClick={() => setIsAddOpen(true)}
              className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-md shadow-indigo-100 flex items-center gap-1.5 shrink-0 active:scale-95 transition-all"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>Add Credit Record</span>
            </button>
          </div>
        </div>

        {/* Utang Record List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/50">
          {filteredRecords.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <BookOpen className="w-12 h-12 mx-auto stroke-1 text-slate-300 mb-2" />
              <p className="text-xs font-bold text-slate-600">No Store Credit records found.</p>
              <p className="text-[11px] text-slate-400 mt-1">Click "Add Credit Record" to create one.</p>
            </div>
          ) : (
            filteredRecords.map((item) => {
              const paidPercent = Math.round(
                ((item.totalAmount - item.balanceRemaining) / item.totalAmount) * 100
              );

              return (
                <div
                  key={item.id}
                  className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs hover:border-indigo-300 transition-all flex flex-col sm:flex-row gap-3 sm:items-center justify-between"
                >
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-sm text-slate-900 truncate">
                        {item.customerName}
                      </span>
                      {item.customerPhone && (
                        <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                          <Phone className="w-3 h-3 text-slate-400" />
                          {item.customerPhone}
                        </span>
                      )}
                      <span
                        className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                          item.status === 'PAID'
                            ? 'bg-emerald-100 text-emerald-800'
                            : item.status === 'PARTIAL'
                            ? 'bg-sky-100 text-sky-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {item.status}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 font-medium line-clamp-1">
                      {item.itemsSummary}
                    </p>

                    <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400 font-medium">
                      <span>Date: {new Date(item.createdAt).toLocaleDateString()}</span>
                      {item.saleReceiptNo && <span>Receipt: #{item.saleReceiptNo}</span>}
                      {item.dueDate && (
                        <span className="text-rose-600 font-bold flex items-center gap-1">
                          <Calendar className="w-3 h-3" /> Due: {item.dueDate}
                        </span>
                      )}
                      {item.markupAmount !== undefined && item.markupAmount > 0 && (
                        <span className="text-indigo-600 font-bold flex items-center gap-1 bg-indigo-50 px-2 py-0.5 rounded-md">
                          <TrendingUp className="w-3 h-3" /> Profit / Markup: ₱{item.markupAmount.toFixed(2)}
                        </span>
                      )}
                    </div>

                    {/* Payment Progress Bar */}
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-1 flex">
                      <div
                        className="bg-emerald-500 h-full transition-all duration-300"
                        style={{ width: `${paidPercent}%` }}
                      />
                    </div>
                  </div>

                  {/* Right Side Balances & Action */}
                  <div className="flex items-center justify-between sm:justify-end gap-4 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100 shrink-0">
                    <div className="text-left sm:text-right">
                      <div className="text-[10px] text-slate-400 uppercase font-bold">REMAINING BALANCE</div>
                      <div className="text-base font-black text-rose-600">
                        ₱{item.balanceRemaining.toFixed(2)}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Total: ₱{item.totalAmount.toFixed(2)}
                      </div>
                    </div>

                    {item.balanceRemaining > 0 && (
                      <button
                        onClick={() => {
                          setPayRecord(item);
                          setPayAmount(item.balanceRemaining.toFixed(2));
                        }}
                        className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-100 flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                      >
                        <DollarSign className="w-4 h-4 stroke-[3]" />
                        <span>Record Payment</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-slate-100 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-colors"
          >
            Close Ledger
          </button>
        </div>
      </div>

      {/* SUB-MODAL: Add New Utang */}
      {isAddOpen && (
        <div className="fixed inset-0 z-60 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                <Plus className="w-4 h-4 text-indigo-600" />
                <span>Add New Store Credit Record</span>
              </h4>
              <button onClick={() => setIsAddOpen(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddUtangSubmit} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Customer / Suki Name *</label>
                <input
                  type="text"
                  required
                  value={newCustomerName}
                  onChange={(e) => setNewCustomerName(e.target.value)}
                  placeholder="e.g. Mareng Lisa / Aling Nena"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Cellphone No. (Optional)</label>
                  <input
                    type="text"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    placeholder="0917XXXXXXX"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Credit Amount (₱) *</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={newAmount}
                    onChange={(e) => setNewAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-extrabold focus:outline-none focus:ring-2 focus:ring-indigo-500 text-indigo-900"
                  />
                </div>
              </div>

              {/* Profit / Markup Field (Tubo) */}
              <div>
                <label className="font-bold text-slate-700 block mb-1 flex items-center justify-between">
                  <span className="flex items-center gap-1 text-indigo-700">
                    <TrendingUp className="w-3.5 h-3.5 text-indigo-600" />
                    Profit / Markup Amount (₱) (Tubo)
                  </span>
                  <span className="text-[10px] text-slate-400 font-normal">Optional</span>
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={newMarkup}
                  onChange={(e) => setNewMarkup(e.target.value)}
                  placeholder="e.g. 15.00"
                  className="w-full px-3 py-2 bg-indigo-50/50 border border-indigo-200 rounded-xl font-bold text-indigo-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Item Details / Description</label>
                <input
                  type="text"
                  value={newSummary}
                  onChange={(e) => setNewSummary(e.target.value)}
                  placeholder="e.g. 2 Pancit Canton, 1 Coke 1.5L, 1 Egg"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Target Due Date (Optional)</label>
                <input
                  type="date"
                  value={newDueDate}
                  onChange={(e) => setNewDueDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddOpen(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold shadow-md shadow-indigo-100"
                >
                  Save Credit Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SUB-MODAL: Record Payment / Settlement */}
      {payRecord && (
        <div className="fixed inset-0 z-60 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 animate-in fade-in">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-600" />
                <span>Record Payment: {payRecord.customerName}</span>
              </h4>
              <button onClick={() => setPayRecord(null)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-3 text-xs space-y-1">
              <div className="text-amber-900 font-extrabold">Remaining Balance: ₱{payRecord.balanceRemaining.toFixed(2)}</div>
              <p className="text-[11px] text-amber-700">
                This settlement amount will automatically be added to today's Cash Sales!
              </p>
            </div>

            <form onSubmit={handleRecordPaymentSubmit} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Payment Amount (₱) *</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  min="0.01"
                  value={payAmount}
                  onChange={(e) => setPayAmount(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-lg font-black text-emerald-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Notes / Remarks</label>
                <input
                  type="text"
                  value={payNotes}
                  onChange={(e) => setPayNotes(e.target.value)}
                  placeholder="e.g. Partial payment / Full settlement"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPayRecord(null)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold shadow-md shadow-emerald-100 cursor-pointer"
                >
                  Save Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
