import React, { useState, useEffect } from 'react';
import { UserAccount } from '../types';
import { saveUserAccount, isCurrentUserAdmin } from '../utils/storage';
import { playSuccessChime, playWarningBeep } from '../utils/sound';
import {
  X,
  Lock,
  Mail,
  User,
  Store,
  KeyRound,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  Shield,
  Phone,
  Sparkles,
  Save,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface AccountSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeUser: UserAccount;
  onUserChanged: (newUser: UserAccount) => void;
}

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80',
];

export const AccountSettingsModal: React.FC<AccountSettingsModalProps> = ({
  isOpen,
  onClose,
  activeUser,
  onUserChanged,
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [pin, setPin] = useState('');
  const [storeName, setStoreName] = useState('');
  const [phone, setPhone] = useState('');
  const [avatar, setAvatar] = useState('');

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const isAdmin = isCurrentUserAdmin(activeUser);

  useEffect(() => {
    if (isOpen && activeUser) {
      setName(activeUser.name || '');
      setEmail(activeUser.email || '');
      setPassword(activeUser.password || 'admin2803');
      setPin(activeUser.pin || '2803');
      setStoreName(activeUser.storeName || '');
      setPhone(activeUser.phone || '');
      setAvatar(activeUser.avatar || AVATAR_PRESETS[0]);
      setErrorMsg('');
      setSuccessMsg('');
      setShowPassword(false);
    }
  }, [isOpen, activeUser]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    // Validation
    const cleanEmail = email.trim().toLowerCase();
    const cleanPassword = password.trim();
    const cleanPin = pin.trim();
    const cleanName = name.trim();

    if (!cleanName) {
      setErrorMsg('Pakilagay ang iyong Pangalan.');
      playWarningBeep();
      return;
    }

    if (!cleanEmail || !cleanEmail.includes('@')) {
      setErrorMsg('Pakilagay ang tamang Gmail / Email address (dapat may @).');
      playWarningBeep();
      return;
    }

    if (!cleanPassword || cleanPassword.length < 4) {
      setErrorMsg('Ang bagong password ay dapat hindi bababa sa 4 characters.');
      playWarningBeep();
      return;
    }

    if (!cleanPin || cleanPin.length !== 4 || isNaN(Number(cleanPin))) {
      setErrorMsg('Ang Security PIN ay dapat na eksaktong 4-digit na numero (e.g. 2803, 1234).');
      playWarningBeep();
      return;
    }

    setLoading(true);

    try {
      const updatedAccount: UserAccount = {
        ...activeUser,
        name: cleanName,
        email: cleanEmail,
        password: cleanPassword,
        pin: cleanPin,
        storeName: storeName.trim() || activeUser.storeName,
        phone: phone.trim() || activeUser.phone,
        avatar: avatar || activeUser.avatar,
        updatedAt: new Date().toISOString(),
      };

      const saved = saveUserAccount(updatedAccount);
      onUserChanged(saved);

      playSuccessChime();
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
      });

      setSuccessMsg('Matagumpay na na-update ang iyong Email, Password, at 4-Digit Security PIN!');
      setLoading(false);

      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: any) {
      setLoading(false);
      playWarningBeep();
      setErrorMsg(err.message || 'Nagkaroon ng error sa pag-save. Pakisubukan muli.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto select-none">
      <div className="w-full max-w-md bg-slate-900 border border-cyan-500/30 rounded-3xl p-5 sm:p-6 shadow-2xl text-slate-100 my-auto relative animate-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-full hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-indigo-600 text-slate-950 flex items-center justify-center font-extrabold shadow-lg shadow-cyan-500/25 shrink-0">
            <KeyRound className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-1.5">
              <span>Account Settings</span>
              {isAdmin && (
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                  <Shield className="w-3 h-3" /> Admin
                </span>
              )}
            </h3>
            <p className="text-xs text-cyan-400">
              Baguhin ang iyong Email, Password, at 4-Digit PIN para sa 3 Front Page Buttons
            </p>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="py-4 space-y-4 text-xs">
          {/* Success Banner */}
          {successMsg && (
            <div className="p-3 rounded-2xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-200 flex items-start gap-2 animate-pulse">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <p className="font-bold">{successMsg}</p>
            </div>
          )}

          {/* Error Banner */}
          {errorMsg && (
            <div className="p-3 rounded-2xl bg-rose-950/80 border border-rose-500/50 text-rose-200 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <p className="font-bold">{errorMsg}</p>
            </div>
          )}

          {/* Avatar Selector */}
          <div>
            <label className="text-[11px] font-bold text-slate-300 block mb-1.5">
              Pumili ng Profile Avatar:
            </label>
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {AVATAR_PRESETS.map((url, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setAvatar(url)}
                  className={`relative rounded-full p-0.5 transition-all shrink-0 ${
                    avatar === url
                      ? 'ring-2 ring-cyan-400 scale-110'
                      : 'opacity-60 hover:opacity-100'
                  }`}
                >
                  <img
                    src={url || undefined}
                    alt={`Avatar ${idx}`}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Full Name Field */}
          <div>
            <label className="text-[11px] font-bold text-slate-300 block mb-1">
              Pangalan ng User / Owner Name:
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Jerome Llames"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-white font-bold text-xs focus:border-cyan-400 focus:outline-none"
              />
            </div>
          </div>

          {/* Email Address Field */}
          <div>
            <label className="text-[11px] font-bold text-slate-300 block mb-1 flex items-center justify-between">
              <span>Gmail / Email Address:</span>
              <span className="text-[10px] text-cyan-400 font-mono">Auto-syncs to Firebase</span>
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-cyan-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="jeromellames7@gmail.com"
                className="w-full bg-slate-950 border border-cyan-500/40 rounded-xl pl-9 pr-3 py-2 text-white font-bold text-xs focus:border-cyan-400 focus:outline-none"
              />
            </div>
          </div>

          {/* Password Field */}
          <div>
            <label className="text-[11px] font-bold text-slate-300 block mb-1">
              Bagong Password:
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-indigo-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="I-enter ang bagong password"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-10 py-2 text-white font-bold text-xs focus:border-cyan-400 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* 4-Digit Security PIN Field for Front Page Buttons */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-emerald-500/40 space-y-1.5">
            <label className="text-[11px] font-extrabold text-emerald-300 block flex items-center gap-1.5">
              <KeyRound className="w-4 h-4 text-emerald-400" />
              <span>4-Digit Security PIN (Para sa 3 Buttons sa Front Page):</span>
            </label>
            <p className="text-[10px] text-slate-400">
              Ito ang 4-digit code na pwedeng gamitin upang mabuksan ang <strong>Mini Store POS</strong>, <strong>Print Studio</strong>, at <strong>Home Monitoring</strong>.
            </p>
            <div className="relative pt-1">
              <input
                type="text"
                maxLength={4}
                value={pin}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '');
                  if (val.length <= 4) setPin(val);
                }}
                placeholder="e.g. 2803"
                className="w-full bg-slate-900 border border-emerald-500/50 rounded-xl px-3 py-2 text-center tracking-[0.4em] font-mono text-base font-black text-emerald-300 focus:border-emerald-400 focus:outline-none"
              />
            </div>
          </div>

          {/* Store Name & Phone Number (Optional Grid) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] font-bold text-slate-400 block mb-1">
                Pangalan ng Tindahan / Store:
              </label>
              <div className="relative">
                <Store className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  placeholder="Jerome's Mini Store"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-2.5 py-1.5 text-white font-bold text-xs focus:border-cyan-400 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 block mb-1">
                CP / Phone Number:
              </label>
              <div className="relative">
                <Phone className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="09123456789"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-2.5 py-1.5 text-white font-bold text-xs focus:border-cyan-400 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-all active:scale-95"
            >
              Kanselahin
            </button>

            <button
              type="submit"
              disabled={loading}
              className="flex-[2] py-3 rounded-2xl bg-gradient-to-tr from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-black text-xs shadow-xl shadow-cyan-500/30 flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4 text-slate-950" />
              <span>{loading ? 'Ina-update...' : 'I-SAVE ANG SETTINGS'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
