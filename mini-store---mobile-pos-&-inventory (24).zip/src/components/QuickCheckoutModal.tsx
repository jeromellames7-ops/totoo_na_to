import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { getLanguage, t, LANG_CHANGE_EVENT } from '../utils/language';
import { X, ShoppingBag, Zap, CheckCircle2, AlertTriangle, Plus, Minus, Barcode, BookOpen, User, Phone, TrendingUp } from 'lucide-react';

interface QuickCheckoutModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
  onQuickCheckoutNow: (
    product: Product,
    quantity: number,
    paymentMethod: 'Cash' | 'Utang',
    customerInfo?: { name: string; phone?: string; markup?: number }
  ) => void;
}

export const QuickCheckoutModal: React.FC<QuickCheckoutModalProps> = ({
  product,
  isOpen,
  onClose,
  onAddToCart,
  onQuickCheckoutNow,
}) => {
  const [quantity, setQuantity] = useState<number>(1);
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Utang'>('Cash');
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [customMarkup, setCustomMarkup] = useState<string>('');
  const [, setLangState] = useState(getLanguage());

  useEffect(() => {
    const handleLangChange = () => setLangState(getLanguage());
    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
  }, []);

  useEffect(() => {
    if (isOpen) {
      setQuantity(1);
      setPaymentMethod('Cash');
      setCustomerName('');
      setCustomerPhone('');
      setCustomMarkup('');
    }
  }, [isOpen, product]);

  if (!isOpen || !product) return null;

  const subtotal = product.price * quantity;
  const estimatedCost = (product.costPrice || product.price * 0.8) * quantity;
  const defaultProfit = Math.max(0, subtotal - estimatedCost);
  const isOutOfStock = product.stock <= 0;
  const isLowStock = product.stock > 0 && product.stock <= product.lowStockThreshold;

  const handleIncrement = () => {
    if (quantity < product.stock) {
      setQuantity((prev) => prev + 1);
    }
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity((prev) => prev - 1);
    }
  };

  const handleAdd = () => {
    onAddToCart(product, quantity);
    onClose();
  };

  const handleCheckoutSubmit = () => {
    if (paymentMethod === 'Utang') {
      if (!customerName.trim()) return;
      onQuickCheckoutNow(product, quantity, 'Utang', {
        name: customerName.trim(),
        phone: customerPhone.trim() || undefined,
        markup: customMarkup ? parseFloat(customMarkup) : defaultProfit,
      });
    } else {
      onQuickCheckoutNow(product, quantity, 'Cash');
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-md bg-white border border-slate-200/80 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Scanned Badge Banner */}
        <div className="bg-slate-900 px-4 py-3 text-white flex items-center justify-between font-bold text-xs sm:text-sm">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Manual / Quick Checkout Confirmation</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-white/10 transition-colors text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Product Details Card */}
        <div className="p-4 sm:p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          <div className="flex gap-4 items-start">
            {/* Product Image */}
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-slate-100 border border-slate-200 overflow-hidden flex-shrink-0 relative shadow-xs">
              <img
                src={product.imageUrl || undefined}
                alt={product.name}
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&auto=format&fit=crop&q=80';
                }}
              />
              <span className="absolute top-1 left-1 bg-white/95 text-indigo-700 font-mono text-[9px] px-1.5 py-0.5 rounded-md border border-slate-200 flex items-center gap-0.5 shadow-xs font-bold">
                <Barcode className="w-2.5 h-2.5" />
                {product.barcode.slice(-6)}
              </span>
            </div>

            {/* Product Info */}
            <div className="flex-1 min-w-0">
              <span className="inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-600 border border-slate-200 mb-1">
                {product.category}
              </span>
              <h3 className="text-sm sm:text-base font-bold text-slate-900 line-clamp-2 leading-tight">
                {product.name}
              </h3>

              <div className="mt-2 flex items-baseline justify-between">
                <div>
                  <span className="text-xs text-slate-500 font-medium">Price: </span>
                  <span className="text-lg font-black text-indigo-600">
                    ₱{product.price.toFixed(2)}
                  </span>
                </div>

                {/* Stock Tag */}
                {isOutOfStock ? (
                  <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-rose-50 text-rose-600 border border-rose-200 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" /> Out of Stock!
                  </span>
                ) : isLowStock ? (
                  <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-orange-50 text-orange-700 border border-orange-200">
                    {product.stock} Low Stock
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                    Stock: {product.stock}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Details / Notes */}
          {product.details && (
            <p className="text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
              {product.details}
            </p>
          )}

          {/* Quantity Selector */}
          {!isOutOfStock && (
            <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3 flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-500 font-medium">Quantity:</p>
                <p className="text-xs font-semibold text-slate-700">
                  Total Amount: <span className="text-indigo-600 font-bold text-sm">₱{subtotal.toFixed(2)}</span>
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={handleDecrement}
                  disabled={quantity <= 1}
                  className="w-9 h-9 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 disabled:opacity-40 text-slate-800 flex items-center justify-center font-bold text-lg active:scale-95 transition-all shadow-xs cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-10 text-center text-lg font-black text-slate-900">{quantity}</span>
                <button
                  onClick={handleIncrement}
                  disabled={quantity >= product.stock}
                  className="w-9 h-9 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white flex items-center justify-center font-bold text-lg active:scale-95 transition-all shadow-xs cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Payment Method Option Selector */}
          {!isOutOfStock && (
            <div className="space-y-3 pt-1 border-t border-slate-100">
              <label className="text-xs font-extrabold text-slate-800 block">
                Select Payment Type:
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('Cash')}
                  className={`p-3 rounded-2xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    paymentMethod === 'Cash'
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-100'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Zap className="w-4 h-4" />
                  <span>Cash Payment</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('Utang')}
                  className={`p-3 rounded-2xl border text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    paymentMethod === 'Utang'
                      ? 'bg-amber-500 text-slate-900 border-amber-500 shadow-md shadow-amber-200'
                      : 'bg-amber-50 text-amber-900 border-amber-200 hover:bg-amber-100'
                  }`}
                >
                  <BookOpen className="w-4 h-4 text-slate-900" />
                  <span>Store Credit / Debt (Utang)</span>
                </button>
              </div>

              {/* Store Credit Form Fields */}
              {paymentMethod === 'Utang' && (
                <div className="p-3 bg-amber-50/90 rounded-2xl border border-amber-200 space-y-2.5 text-xs animate-in fade-in">
                  <div className="font-extrabold text-amber-950 flex items-center gap-1.5">
                    <User className="w-4 h-4 text-amber-700" />
                    <span>Customer Credit Details</span>
                  </div>

                  <div>
                    <label className="font-bold text-amber-900 block mb-1">
                      Customer / Suki Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g. Mareng Lisa / Aling Nena"
                      className="w-full px-3 py-2 bg-white border border-amber-300 rounded-xl font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>

                  <div>
                    <label className="font-semibold text-amber-800 block mb-1">
                      Phone Number (Optional)
                    </label>
                    <input
                      type="text"
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="0917XXXXXXX"
                      className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>

                  <div>
                    <label className="font-semibold text-amber-800 block mb-1 flex items-center justify-between">
                      <span className="flex items-center gap-1">
                        <TrendingUp className="w-3.5 h-3.5 text-indigo-600" />
                        Profit / Markup Amount (₱) (Tubo)
                      </span>
                      <span className="text-[10px] text-amber-700">Estimated: ₱{defaultProfit.toFixed(2)}</span>
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={customMarkup}
                      onChange={(e) => setCustomMarkup(e.target.value)}
                      placeholder={`₱${defaultProfit.toFixed(2)}`}
                      className="w-full px-3 py-2 bg-white border border-amber-200 rounded-xl font-bold text-indigo-900 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Action Buttons */}
          <div className="pt-2 grid grid-cols-2 gap-3">
            <button
              onClick={handleAdd}
              disabled={isOutOfStock}
              className="py-3 px-3 rounded-2xl bg-slate-100 hover:bg-slate-200 disabled:opacity-50 text-slate-800 font-bold text-xs sm:text-sm border border-slate-200 flex items-center justify-center gap-2 transition-all active:scale-98 shadow-xs cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4 text-indigo-600" />
              <span>Add to Cart</span>
            </button>

            <button
              onClick={handleCheckoutSubmit}
              disabled={isOutOfStock || (paymentMethod === 'Utang' && !customerName.trim())}
              className={`py-3 px-3 rounded-2xl text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all active:scale-98 shadow-md cursor-pointer disabled:opacity-40 ${
                paymentMethod === 'Utang'
                  ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-200'
                  : 'bg-indigo-600 hover:bg-indigo-500 shadow-indigo-100'
              }`}
            >
              {paymentMethod === 'Utang' ? (
                <>
                  <BookOpen className="w-4 h-4 text-white" />
                  <span>Save as Store Credit</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 fill-white" />
                  <span>Quick Checkout Now</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
