import React, { useState, useEffect } from 'react';
import { Lock, Delete, X, ShieldAlert, Store, Printer, Home, Sparkles, KeyRound, CheckCircle2, FileText } from 'lucide-react';
import { playSuccessChime, playWarningBeep, playScanBeep } from '../utils/sound';
import { AppModule } from '../types';
import { getActiveUser } from '../utils/storage';

interface PortalPinModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetModule: AppModule | null;
  onSuccess: (module: AppModule) => void;
}

interface ModulePinConfig {
  name: string;
  sub: string;
  pin: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  bgGradient: string;
  badge: string;
}

const MODULE_PIN_CONFIGS: Record<string, ModulePinConfig> = {
  ministore: {
    name: 'Mini Store POS & Inventory',
    sub: 'Tindahan POS, Barcode Scanner, Utang Ledger at Sales',
    pin: '2803',
    icon: Store,
    color: 'from-indigo-600 to-indigo-800',
    bgGradient: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    badge: 'PIN Protected',
  },
  printstudio: {
    name: 'Print Studio & Bondpaper Editor',
    sub: 'Full-Screen Bondpaper Canvas, HP Smart Tank 580 Print',
    pin: '2623',
    icon: Printer,
    color: 'from-cyan-600 to-teal-700',
    bgGradient: 'bg-cyan-50 text-cyan-700 border-cyan-200',
    badge: 'PIN Protected',
  },
  homemonitoring: {
    name: 'Home Monitoring System',
    sub: 'Electric, Water, Gas LPG, at Menstruation Tracker',
    pin: '0000',
    icon: Home,
    color: 'from-emerald-600 to-teal-800',
    bgGradient: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    badge: 'PIN Protected',
  },
  docscanner: {
    name: 'AI Form & Document Extractor',
    sub: 'AI Vision Scanner para sa handwritten forms, tables, checkboxes, at multi-page documents',
    pin: '1234',
    icon: FileText,
    color: 'from-amber-500 to-orange-600',
    bgGradient: 'bg-amber-50 text-amber-700 border-amber-200',
    badge: 'PIN Protected',
  },
};

export const PortalPinModal: React.FC<PortalPinModalProps> = ({
  isOpen,
  onClose,
  targetModule,
  onSuccess,
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setPin('');
      setError(false);
      setIsSuccess(false);
    }
  }, [isOpen, targetModule]);

  const activeUser = getActiveUser();
  const isAdmin = activeUser?.email?.toLowerCase() === 'jeromellames7@gmail.com';

  if (!isOpen || !targetModule) return null;

  const config = MODULE_PIN_CONFIGS[targetModule] || {
    name: 'Security PIN Verification',
    sub: 'I-enter ang 4-digit PIN upang ma-access ang module',
    pin: '1234',
    icon: Lock,
    color: 'from-indigo-600 to-indigo-800',
    bgGradient: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    badge: 'PIN Required',
  };

  const TargetIcon = config.icon;

  const handleKeyPress = (num: string) => {
    if (isSuccess) return;
    playScanBeep();

    if (pin.length < 4) {
      const nextPin = pin + num;
      setPin(nextPin);
      setError(false);

      if (nextPin.length === 4) {
        // Auto verify upon 4th digit (accepts user personal PIN, module default PIN, or master PIN)
        const userPin = activeUser?.pin;
        const isMatch =
          nextPin === config.pin ||
          (userPin && nextPin === userPin) ||
          nextPin === '2803' ||
          nextPin === '1234';

        if (isMatch) {
          setIsSuccess(true);
          playSuccessChime();
          setTimeout(() => {
            onSuccess(targetModule);
            onClose();
          }, 350);
        } else {
          playWarningBeep();
          setError(true);
          setTimeout(() => {
            setPin('');
          }, 600);
        }
      }
    }
  };

  const handleDelete = () => {
    if (isSuccess) return;
    setPin((prev) => prev.slice(0, -1));
    setError(false);
  };

  const handleClear = () => {
    if (isSuccess) return;
    setPin('');
    setError(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 select-none animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-slate-900 border-2 border-slate-700/80 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.8)] overflow-hidden p-6 text-center text-white relative animate-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1.5 rounded-full hover:bg-slate-800 transition-colors"
          title="Isara"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Module Icon & Branding Header */}
        <div className="flex flex-col items-center mb-4">
          <div
            className={`w-16 h-16 rounded-2xl bg-gradient-to-tr ${config.color} p-0.5 shadow-xl flex items-center justify-center mb-3`}
          >
            <div className="w-full h-full bg-slate-900/90 rounded-[14px] flex items-center justify-center">
              <TargetIcon className="w-8 h-8 text-white" />
            </div>
          </div>

          <span className="text-[10px] uppercase font-mono font-bold tracking-widest px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 mb-1 flex items-center gap-1">
            <KeyRound className="w-3 h-3 text-cyan-400" />
            <span>4-Digit Security PIN</span>
          </span>

          <h3 className="text-lg font-extrabold text-white tracking-tight">{config.name}</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-[260px] leading-relaxed">
            I-enter ang 4-digit PIN code para buksan ang system na ito.
          </p>
        </div>

        {/* 4 PIN Indicators */}
        <div className="flex justify-center items-center gap-3.5 my-5">
          {[0, 1, 2, 3].map((idx) => {
            const isFilled = pin.length > idx;
            return (
              <div
                key={idx}
                className={`w-4 h-4 rounded-full transition-all duration-200 ${
                  isSuccess
                    ? 'bg-emerald-400 ring-4 ring-emerald-400/30 scale-125'
                    : error
                    ? 'bg-rose-500 ring-4 ring-rose-500/40 animate-shake scale-110'
                    : isFilled
                    ? 'bg-cyan-400 scale-110 shadow-lg shadow-cyan-500/50'
                    : 'bg-slate-800 border border-slate-700'
                }`}
              />
            );
          })}
        </div>

        {/* Status / Feedback Banner */}
        {isSuccess ? (
          <div className="flex items-center justify-center gap-1.5 text-xs text-emerald-300 bg-emerald-950/80 border border-emerald-500/40 py-2 px-3 rounded-xl mb-4 animate-pulse">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span className="font-bold">PIN Accepted! Binubuksan na ang system...</span>
          </div>
        ) : error ? (
          <div className="flex items-center justify-center gap-1.5 text-xs text-rose-300 bg-rose-950/80 border border-rose-500/40 py-2 px-3 rounded-xl mb-4">
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
            <span className="font-bold">Maling PIN Code! Pakisubukan muli.</span>
          </div>
        ) : (
          <div className="text-[11px] text-slate-400 mb-4 font-mono">
            <span>Security PIN Protected Module</span>
          </div>
        )}

        {/* Numeric Touch Keypad */}
        <div className="grid grid-cols-3 gap-2.5 max-w-[240px] mx-auto mb-2">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
            <button
              key={num}
              onClick={() => handleKeyPress(num)}
              className="h-13 rounded-2xl bg-slate-800/90 hover:bg-slate-700 active:bg-cyan-600 text-white text-xl font-bold border border-slate-700 active:scale-95 transition-all flex items-center justify-center shadow-lg hover:border-cyan-500/40"
            >
              {num}
            </button>
          ))}
          <button
            onClick={handleClear}
            className="h-13 rounded-2xl bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-white text-xs font-semibold border border-slate-700 active:scale-95 transition-all flex items-center justify-center"
          >
            Clear
          </button>
          <button
            onClick={() => handleKeyPress('0')}
            className="h-13 rounded-2xl bg-slate-800/90 hover:bg-slate-700 active:bg-cyan-600 text-white text-xl font-bold border border-slate-700 active:scale-95 transition-all flex items-center justify-center shadow-lg hover:border-cyan-500/40"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="h-13 rounded-2xl bg-slate-800/60 hover:bg-slate-700 text-slate-300 hover:text-white text-sm font-bold border border-slate-700 active:scale-95 transition-all flex items-center justify-center"
            title="Burahin ang huling number"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Reset PIN Button */}
        <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-slate-400">Nakalimutan ang PIN?</span>
          <button
            onClick={() => {
              const defaults: Record<string, string> = {
                ministore: '2803',
                printstudio: '2623',
                homemonitoring: '0000',
                docscanner: '1234',
              };
              const def = defaults[targetModule] || '2803';
              alert(`Na-reset ang PIN ng module na ito sa default code: ${def}`);
              setPin('');
            }}
            className="px-2.5 py-1 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 font-bold rounded-lg text-[11px] border border-cyan-500/30 transition-all"
          >
            Reset PIN to Default
          </button>
        </div>
      </div>
    </div>
  );
};
