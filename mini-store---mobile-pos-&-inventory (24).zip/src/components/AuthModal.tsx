import React, { useState } from 'react';
import { UserAccount, UserRole } from '../types';
import {
  getAccounts,
  setActiveUser,
  registerNewAccount,
  loginUserWithCredentials,
  adminUpdateUserCredentials,
  deleteUserAccount,
  getAdminTargetAccountId,
  setAdminTargetAccountId,
} from '../utils/storage';
import { playSuccessChime, playWarningBeep } from '../utils/sound';
import {
  X,
  Lock,
  Mail,
  User,
  Store,
  Shield,
  KeyRound,
  Eye,
  EyeOff,
  UserPlus,
  LogIn,
  CheckCircle2,
  AlertCircle,
  Database,
  Layers,
  Sparkles,
  Phone,
  Edit,
  Trash2,
  ExternalLink,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeUser: UserAccount;
  onUserChanged: (newUser: UserAccount) => void;
  initialMode?: 'login' | 'register' | 'admin_manage';
}

const AVATAR_OPTIONS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80',
];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  activeUser,
  onUserChanged,
  initialMode = 'login',
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'admin_manage'>(initialMode);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Login Form State
  const [loginEmailOrName, setLoginEmailOrName] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Register Form State
  const [regName, setRegName] = useState('');
  const [regStoreName, setRegStoreName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regRole, setRegRole] = useState<UserRole>('Cashier');
  const [regPhone, setRegPhone] = useState('');
  const [regPin, setRegPin] = useState('1234');
  const [regAvatar, setRegAvatar] = useState(AVATAR_OPTIONS[0]);

  // Admin Editing Credentials Modal State
  const [editingTargetUser, setEditingTargetUser] = useState<UserAccount | null>(null);
  const [adminEditEmail, setAdminEditEmail] = useState('');
  const [adminEditPassword, setAdminEditPassword] = useState('');
  const [adminEditName, setAdminEditName] = useState('');
  const [adminEditStoreName, setAdminEditStoreName] = useState('');
  const [adminEditPin, setAdminEditPin] = useState('');
  const [adminEditRole, setAdminEditRole] = useState<UserRole>('Cashier');
  const [adminEditPhone, setAdminEditPhone] = useState('');

  const accounts = getAccounts();

  if (!isOpen) return null;

  // Handle Login
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!loginEmailOrName.trim()) {
      setErrorMsg('Pakilagay ang iyong Gmail/Email o Pangalan.');
      return;
    }
    if (!loginPassword.trim()) {
      setErrorMsg('Pakilagay ang iyong Password o 4-Digit PIN.');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      const res = loginUserWithCredentials(loginEmailOrName, loginPassword);
      setLoading(false);

      if (res.success && res.user) {
        playSuccessChime();
        setSuccessMsg(`Welcome, ${res.user.name}! Matagumpay kang nakapag-login.`);
        onUserChanged(res.user);
        setTimeout(() => {
          onClose();
        }, 800);
      } else {
        playWarningBeep();
        setErrorMsg(res.error || 'Maling credentials. Pakisuri ang email o password.');
      }
    }, 250);
  };

  // Quick 1-Tap Select User from list
  const handleQuickSelectUser = (user: UserAccount) => {
    setLoginEmailOrName(user.email || user.name);
    if (user.password) {
      setLoginPassword(user.password);
    }
  };

  // Handle Register New Account
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!regName.trim()) {
      setErrorMsg('Pakilagay ang iyong Buong Pangalan o Owner Name.');
      return;
    }
    if (!regEmail.trim() || !regEmail.includes('@')) {
      setErrorMsg('Pakilagay ang wastong Gmail o Email Address (e.g. name@gmail.com).');
      return;
    }
    if (!regPassword.trim() || regPassword.length < 4) {
      setErrorMsg('Ang password ay dapat hindi bababa sa 4 characters.');
      return;
    }
    if (regPassword !== regConfirmPassword) {
      setErrorMsg('Hindi magkatugma ang Password at Confirm Password.');
      return;
    }

    setLoading(true);
    try {
      const created = await registerNewAccount({
        name: regName,
        email: regEmail,
        password: regPassword,
        role: regRole,
        storeName: regStoreName || `${regName}'s Store`,
        phone: regPhone,
        pin: regPin || '1234',
        avatar: regAvatar,
      });

      playSuccessChime();
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });

      setSuccessMsg(`Matagumpay na nagawa ang account ni ${created.name}! Handa na ang sariling Firebase Database.`);
      onUserChanged(created);

      setTimeout(() => {
        setLoading(false);
        onClose();
      }, 1200);
    } catch (err: any) {
      setLoading(false);
      playWarningBeep();
      setErrorMsg(err.message || 'May error sa paggawa ng account. Pakisubukan muli.');
    }
  };

  // Open Admin Credentials Editor
  const handleOpenAdminEdit = (user: UserAccount) => {
    setEditingTargetUser(user);
    setAdminEditName(user.name);
    setAdminEditEmail(user.email || '');
    setAdminEditPassword(user.password || '');
    setAdminEditStoreName(user.storeName || '');
    setAdminEditPin(user.pin || '1234');
    setAdminEditRole(user.role);
    setAdminEditPhone(user.phone || '');
  };

  // Save Admin Credentials Updates
  const handleSaveAdminEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTargetUser) return;

    try {
      setLoading(true);
      const updated = await adminUpdateUserCredentials(editingTargetUser.id, {
        name: adminEditName,
        email: adminEditEmail,
        password: adminEditPassword,
        pin: adminEditPin,
        role: adminEditRole,
        storeName: adminEditStoreName,
        phone: adminEditPhone,
      });

      playSuccessChime();
      setSuccessMsg(`Na-update ng Admin ang Gmail at Password para kay ${updated.name}!`);
      setEditingTargetUser(null);
      setLoading(false);

      if (activeUser.id === updated.id) {
        onUserChanged(updated);
      }
    } catch (err: any) {
      setLoading(false);
      playWarningBeep();
      setErrorMsg(err.message || 'May error sa pag-update ng credentials.');
    }
  };

  // Direct login as user by Admin
  const handleAdminDirectLogin = (user: UserAccount) => {
    setActiveUser(user.id);
    onUserChanged(user);
    playSuccessChime();
    setSuccessMsg(`Binuksan ang account ni ${user.name}`);
    setTimeout(() => onClose(), 600);
  };

  // Admin delete user
  const handleDeleteUser = async (user: UserAccount) => {
    if (user.id === 'user-admin') {
      alert('Hindi maaaring burahin ang Primary Admin Account.');
      return;
    }
    if (confirm(`Sigurado ka bang nais mong burahin ang account ni "${user.name}"?`)) {
      try {
        await deleteUserAccount(user.id);
        playSuccessChime();
        setSuccessMsg(`Nabura ang account ni ${user.name}`);
      } catch (err: any) {
        alert(err.message);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto select-none animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.8)] overflow-hidden text-white relative my-6 animate-in zoom-in-95 duration-200 flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="px-6 pt-6 pb-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 p-0.5 shadow-lg flex items-center justify-center">
              <div className="w-full h-full bg-slate-900 rounded-[10px] flex items-center justify-center">
                {mode === 'login' ? <LogIn className="w-5 h-5 text-cyan-400" /> : <UserPlus className="w-5 h-5 text-emerald-400" />}
              </div>
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                <span>{mode === 'login' ? 'ACCOUNT LOGIN PAGE' : 'GUMAWA NG BAGONG ACCOUNT'}</span>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Firebase Sync
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                {mode === 'login'
                  ? 'I-enter ang iyong Gmail / Email o Pangalan para mag-login'
                  : 'Magrehistro ng bagong account na may sariling isolated Firebase Database'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-full hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feedback Alert Banners */}
        {errorMsg && (
          <div className="mx-6 mt-4 p-3 rounded-2xl bg-rose-950/80 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mx-6 mt-4 p-3 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Scrollable Modal Body Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          {/* ========================================================= */}
          {/* MODE 1: LOGIN VIEW */}
          {/* ========================================================= */}
          {mode === 'login' && (
            <div className="space-y-5">
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Gmail / Email Address o Pangalan:</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="hal. jeromellames7@gmail.com o Juan"
                    value={loginEmailOrName}
                    onChange={(e) => setLoginEmailOrName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Password o 4-Digit Security PIN:</span>
                    </label>
                  </div>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="I-type ang password o PIN"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 pr-10 transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      onTouchEnd={(e) => {
                        e.preventDefault();
                        setShowPassword(!showPassword);
                      }}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-slate-400 hover:text-white active:text-cyan-400 touch-manipulation cursor-pointer"
                      title={showPassword ? 'Itago ang password' : 'Ipakita ang password'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-extrabold text-sm shadow-lg shadow-cyan-500/25 active:scale-98 transition-all flex items-center justify-center gap-2"
                >
                  <LogIn className="w-4 h-4 text-slate-950" />
                  <span>{loading ? 'Sinisuri ang Account...' : 'Mag-Login sa Account'}</span>
                </button>
              </form>

              {/* Register Prompt */}
              <div className="p-3 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 flex items-center justify-between text-xs">
                <div>
                  <p className="font-bold text-indigo-300">Wala ka pang sariling account?</p>
                  <p className="text-[10px] text-indigo-200/70">Gumawa ng account para sa iyong sariling tindahan.</p>
                </div>
                <button
                  onClick={() => setMode('register')}
                  className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1 shadow"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Mag-Register</span>
                </button>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* MODE 2: REGISTER NEW ACCOUNT VIEW */}
          {/* ========================================================= */}
          {mode === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              <div className="p-3 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 text-cyan-200 text-xs flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400 shrink-0 animate-pulse" />
                <span>
                  <strong>Awtomatikong Database Isolation:</strong> Bawat account na magagawa ay magkakaroon ng sariling
                  Firebase dataset para sa mga produkto, benta, utang, at reports.
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Buong Pangalan / Account Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="hal. Jerome Llames"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Pangalan ng Tindahan / Store</label>
                  <input
                    type="text"
                    placeholder="hal. Jerome's Mini Store"
                    value={regStoreName}
                    onChange={(e) => setRegStoreName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Gmail / Email Address * (Gagamitin sa Login at Firebase Sync)</span>
                </label>
                <input
                  type="email"
                  required
                  placeholder="hal. jeromellames7@gmail.com"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Password *</label>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="Minimum 4 characters"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Kumpirmahin ang Password *</label>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="I-type muli ang password"
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">4-Digit Security PIN *</label>
                  <input
                    type="text"
                    maxLength={4}
                    placeholder="hal. 1234"
                    value={regPin}
                    onChange={(e) => setRegPin(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs font-mono focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Contact Phone Number (Optional)</label>
                  <input
                    type="text"
                    placeholder="hal. 0917-123-4567"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              {/* Avatar Picker */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-2">Pumili ng Profile Avatar:</label>
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {AVATAR_OPTIONS.map((url, i) => (
                    <img
                      key={i}
                      src={url || undefined}
                      alt="Avatar"
                      onClick={() => setRegAvatar(url)}
                      className={`w-10 h-10 rounded-full object-cover cursor-pointer transition-transform ${
                        regAvatar === url
                          ? 'ring-3 ring-cyan-400 scale-110 shadow-lg'
                          : 'opacity-70 hover:opacity-100 hover:scale-105'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-extrabold text-sm shadow-lg shadow-emerald-500/25 active:scale-98 transition-all flex items-center justify-center gap-2 mt-2"
              >
                <UserPlus className="w-4 h-4 text-slate-950" />
                <span>{loading ? 'Gumagawa ng Account...' : 'I-rehistro at Gumawa ng Account'}</span>
              </button>

              {/* Login Prompt for Users with Account */}
              <div className="p-3 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-between text-xs mt-4">
                <div>
                  <p className="font-bold text-cyan-300">Mayroon ka nang account?</p>
                  <p className="text-[10px] text-cyan-200/70">Mag-login para mabuksan ang iyong tindahan.</p>
                </div>
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-extrabold text-xs flex items-center gap-1 shadow"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Mag-Login</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
