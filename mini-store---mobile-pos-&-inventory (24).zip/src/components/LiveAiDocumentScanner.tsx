import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Camera,
  X,
  Sparkles,
  CheckCircle2,
  RefreshCw,
  Zap,
  ChevronDown,
  Volume2,
  VolumeX,
  Play,
  Pause,
  ArrowRight,
  FileSpreadsheet,
  Check,
  ScanLine,
  Lightbulb,
  HelpCircle,
  Scissors,
  Eye,
  CheckCircle,
  Smartphone,
  Package,
  Plus,
  Grid,
  Layers,
  Table,
  ArrowUpRight,
  AlertTriangle,
  Clock,
  Timer
} from 'lucide-react';
import { extractDocumentClientSide, getClientGeminiApiKey } from '../lib/geminiDocExtractor';
import { GalleryBoxItem } from '../types';

interface LiveAiDocumentScannerProps {
  isOpen: boolean;
  onClose: () => void;
  headers: string[];
  templateName?: string;
  onRowExtracted: (row: Record<string, string>, rawImageBase64?: string) => void;
  apiKeyModalTrigger?: () => void;
  galleryBoxes?: GalleryBoxItem[];
  onAssignToGalleryBox?: (imageSrc: string, boxNumber: number) => void;
  onAddNew4BoxesAndAssign?: (imageSrc: string) => void;
  onOpenGallery?: () => void;
}

interface DetectedFieldNotification {
  id: string;
  header: string;
  value: string;
  timestamp: number;
}

export const LiveAiDocumentScanner: React.FC<LiveAiDocumentScannerProps> = ({
  isOpen,
  onClose,
  headers,
  templateName = 'Personal Data Sheet (PDS / 19 Columns)',
  onRowExtracted,
  apiKeyModalTrigger,
  galleryBoxes = [],
  onAssignToGalleryBox,
  onAddNew4BoxesAndAssign,
  onOpenGallery,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // States
  const [isCameraReady, setIsCameraReady] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [torchOn, setTorchOn] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [isAutoScanActive, setIsAutoScanActive] = useState<boolean>(true);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('I-tutok ang camera sa buong PDS o Form document...');
  
  // Real-time detection state
  const [detectedFields, setDetectedFields] = useState<Record<string, string>>({});
  const detectedFieldsRef = useRef<Record<string, string>>({});
  const [fieldPopups, setFieldPopups] = useState<DetectedFieldNotification[]>([]);
  const [scannedRowCount, setScannedRowCount] = useState<number>(0);
  const [showLiveTablePreview, setShowLiveTablePreview] = useState<boolean>(false);
  const [lastCapturedImage, setLastCapturedImage] = useState<string | null>(null);

  // 5-Minute Inactivity Watchdog Auto-Close State & Warning Modal
  const [isTimeoutWarningOpen, setIsTimeoutWarningOpen] = useState<boolean>(false);
  const [inactivitySecondsLeft, setInactivitySecondsLeft] = useState<number>(300);
  const lastDataFoundTimestampRef = useRef<number>(Date.now());
  const scannerOpenedTimestampRef = useRef<number>(Date.now());

  // Gallery Box Destination Picker Modal State
  const [isBoxSelectorOpen, setIsBoxSelectorOpen] = useState<boolean>(false);
  const [pendingCroppedForBox, setPendingCroppedForBox] = useState<string | null>(null);

  // Auto-Cropped PDS Inspection Modal State
  const [isCroppedModalOpen, setIsCroppedModalOpen] = useState<boolean>(false);
  const [rawPhotoSrc, setRawPhotoSrc] = useState<string | null>(null);
  const [croppedImageSrc, setCroppedImageSrc] = useState<string | null>(null);
  const [cropPhase, setCropPhase] = useState<'idle' | 'detecting_bounds' | 'cropped_ready'>('idle');
  const [isCroppedAnalyzing, setIsCroppedAnalyzing] = useState<boolean>(false);
  const [croppedSuccessCount, setCroppedSuccessCount] = useState<number>(0);
  const [croppedErrorMessage, setCroppedErrorMessage] = useState<string | null>(null);

  // Side Controls Placement (Nasa gilid ng screen tulad ng hiniling sa picture 2)
  const [sidePosition, setSidePosition] = useState<'right' | 'left'>('right');


  // Sync ref with state
  useEffect(() => {
    detectedFieldsRef.current = detectedFields;
  }, [detectedFields]);

  // Camera shutter snap sound synthesizer
  const playShutterSound = useCallback(() => {
    if (!soundEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(300, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.09);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.09);
    } catch {}
  }, [soundEnabled]);

  // Pleasant audio synthesizer feedback for detected headers
  const playSuccessChime = useCallback(() => {
    if (!soundEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'sine';
      osc2.type = 'triangle';
      osc1.frequency.setValueAtTime(880, ctx.currentTime);
      osc2.frequency.setValueAtTime(1320, ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(ctx.currentTime);
      osc2.start(ctx.currentTime + 0.08);
      osc1.stop(ctx.currentTime + 0.35);
      osc2.stop(ctx.currentTime + 0.35);
    } catch {
      // Browser audio restriction handling
    }
  }, [soundEnabled]);

  // Major match fanfare chime
  const playAllMatchFanfare = useCallback(() => {
    if (!soundEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      [523.25, 659.25, 783.99, 1046.50].forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + i * 0.07);
        gain.gain.setValueAtTime(0.15, ctx.currentTime + i * 0.07);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.07 + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + i * 0.07);
        osc.stop(ctx.currentTime + i * 0.07 + 0.25);
      });
    } catch {}
  }, [soundEnabled]);

  // Start Camera Stream
  const startCamera = useCallback(async () => {
    try {
      setCameraError(null);
      setIsCameraReady(false);

      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }

      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: { ideal: facingMode },
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        },
        audio: false
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play().then(() => {
            setIsCameraReady(true);
            setStatusMessage('AI Line Detector Aktibo! I-tutok sa Form / PDS...');
          }).catch(err => {
            console.error('Video play error:', err);
          });
        };
      }
    } catch (err: any) {
      console.error('Camera stream error:', err);
      setCameraError(err.message || 'Hindi ma-access ang Camera. Pakipahintulutan ang Camera Permission sa browser.');
    }
  }, [facingMode]);

  // Stop camera stream
  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    setIsCameraReady(false);
  }, []);

  // Initialize and cleanup camera and 5-minute inactivity watchdog on modal open/close
  useEffect(() => {
    if (isOpen) {
      setIsTimeoutWarningOpen(false);
      lastDataFoundTimestampRef.current = Date.now();
      scannerOpenedTimestampRef.current = Date.now();
      setInactivitySecondsLeft(300);
      startCamera();
    } else {
      stopCamera();
      setFieldPopups([]);
      setDetectedFields({});
      setIsTimeoutWarningOpen(false);
    }

    return () => {
      stopCamera();
    };
  }, [isOpen, startCamera, stopCamera]);

  // 5-Minute Inactivity Watchdog: Auto-close scanner if no required data is detected within 5 minutes (300 seconds)
  useEffect(() => {
    if (!isOpen || isTimeoutWarningOpen) return;

    const watchdogInterval = setInterval(() => {
      const elapsedSinceData = Date.now() - lastDataFoundTimestampRef.current;
      const secondsRemaining = Math.max(0, Math.ceil((300000 - elapsedSinceData) / 1000));
      setInactivitySecondsLeft(secondsRemaining);

      // If 5 minutes have elapsed without finding genuine required data
      if (elapsedSinceData >= 300000) {
        stopCamera();
        setIsTimeoutWarningOpen(true);
        setStatusMessage('⚠️ Pansamantalang isinara: 5 minuto nang walang nakikitang kailangang datos.');
      }
    }, 1000);

    return () => clearInterval(watchdogInterval);
  }, [isOpen, isTimeoutWarningOpen, stopCamera]);

  // High-Precision Smart Bondpaper Boundary Edge Cropper
  const extractBondpaperBoundingBox = (stageCanvas: HTMLCanvasElement): string => {
    const w = stageCanvas.width;
    const h = stageCanvas.height;

    try {
      // 1. Create downsampled fast analysis canvas (180px width)
      const sampleW = 180;
      const sampleH = Math.max(120, Math.round((h / w) * sampleW));
      const sampleCanvas = document.createElement('canvas');
      sampleCanvas.width = sampleW;
      sampleCanvas.height = sampleH;
      const sCtx = sampleCanvas.getContext('2d');
      if (!sCtx) return stageCanvas.toDataURL('image/jpeg', 0.92);

      sCtx.drawImage(stageCanvas, 0, 0, sampleW, sampleH);
      const imgData = sCtx.getImageData(0, 0, sampleW, sampleH);
      const data = imgData.data;

      // 2. Scan luminance & saturation to identify paper pixels
      let totalLum = 0;
      for (let i = 0; i < data.length; i += 4) {
        const lum = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
        totalLum += lum;
      }
      const avgLum = totalLum / (sampleW * sampleH);
      const paperLumThreshold = Math.max(105, avgLum * 1.08);

      let minX = sampleW;
      let maxX = 0;
      let minY = sampleH;
      let maxY = 0;
      let paperCount = 0;

      for (let y = 0; y < sampleH; y++) {
        for (let x = 0; x < sampleW; x++) {
          const idx = (y * sampleW + x) * 4;
          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];
          const lum = 0.299 * r + 0.587 * g + 0.114 * b;
          const maxC = Math.max(r, g, b);
          const minC = Math.min(r, g, b);
          const sat = maxC === 0 ? 0 : (maxC - minC) / maxC;

          // White paper has high luminance and low to moderate saturation
          const isPaperPixel = (lum > paperLumThreshold && sat < 0.48) || lum > 165;
          if (isPaperPixel) {
            paperCount++;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
          }
        }
      }

      // If a distinct paper region was identified (covers at least 15% of frame)
      const totalPixels = sampleW * sampleH;
      if (paperCount > totalPixels * 0.12 && maxX > minX + 25 && maxY > minY + 25) {
        const scaleX = w / sampleW;
        const scaleY = h / sampleH;

        // Add 1.5% safety inward/outward margin
        const realMinX = Math.max(0, Math.floor((minX - 1) * scaleX));
        const realMaxX = Math.min(w, Math.ceil((maxX + 1) * scaleX));
        const realMinY = Math.max(0, Math.floor((minY - 1) * scaleY));
        const realMaxY = Math.min(h, Math.ceil((maxY + 1) * scaleY));

        const cropW = realMaxX - realMinX;
        const cropH = realMaxY - realMinY;

        if (cropW >= w * 0.35 && cropH >= h * 0.35) {
          const outCanvas = document.createElement('canvas');
          outCanvas.width = cropW;
          outCanvas.height = cropH;
          const outCtx = outCanvas.getContext('2d');
          if (outCtx) {
            outCtx.drawImage(stageCanvas, realMinX, realMinY, cropW, cropH, 0, 0, cropW, cropH);
            return outCanvas.toDataURL('image/jpeg', 0.94);
          }
        }
      }
    } catch (e) {
      console.warn('Paper boundary detection fallback:', e);
    }

    // High quality center-crop fallback for portrait bondpaper
    const targetRatio = 3 / 4;
    let defCropW = Math.round(w * 0.82);
    let defCropH = Math.round(defCropW / targetRatio);
    if (defCropH > h * 0.88) {
      defCropH = Math.round(h * 0.88);
      defCropW = Math.round(defCropH * targetRatio);
    }
    const startX = Math.max(0, Math.round((w - defCropW) / 2));
    const startY = Math.max(0, Math.round((h - defCropH) / 2));

    const fallbackCanvas = document.createElement('canvas');
    fallbackCanvas.width = defCropW;
    fallbackCanvas.height = defCropH;
    const fCtx = fallbackCanvas.getContext('2d');
    if (fCtx) {
      fCtx.drawImage(stageCanvas, startX, startY, defCropW, defCropH, 0, 0, defCropW, defCropH);
      return fallbackCanvas.toDataURL('image/jpeg', 0.92);
    }

    return stageCanvas.toDataURL('image/jpeg', 0.9);
  };

  // Capture high-res frame and automatically crop the outer sides, keeping strictly the bondpaper box of the PDS picture
  const captureRawAndCroppedPDS = useCallback((): { raw: string; cropped: string } | null => {
    if (!videoRef.current || !isCameraReady) return null;
    const video = videoRef.current;
    
    // Create high-res staging canvas
    const width = video.videoWidth || 1920;
    const height = video.videoHeight || 1080;
    
    const stageCanvas = document.createElement('canvas');
    stageCanvas.width = width;
    stageCanvas.height = height;
    const stageCtx = stageCanvas.getContext('2d');
    if (!stageCtx) return null;
    stageCtx.drawImage(video, 0, 0, width, height);

    const rawData = stageCanvas.toDataURL('image/jpeg', 0.85);
    const croppedData = extractBondpaperBoundingBox(stageCanvas);

    return { raw: rawData, cropped: croppedData };
  }, [isCameraReady]);

  // Capture frame as Base64 Image
  const captureFrameBase64 = useCallback((): string | null => {
    if (!videoRef.current || !canvasRef.current || !isCameraReady) return null;
    const video = videoRef.current;
    const canvas = canvasRef.current;

    const width = video.videoWidth || 1280;
    const height = video.videoHeight || 720;
    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0, width, height);
    return canvas.toDataURL('image/jpeg', 0.82);
  }, [isCameraReady]);

  // Handle Snap, Fast Auto-Crop Bondpaper Box, and Prompt for Gallery Box Destination
  const handleSnapAndAutoCrop = async () => {
    if (!isCameraReady) return;
    
    playShutterSound();
    setCroppedErrorMessage(null);

    const snapResult = captureRawAndCroppedPDS();
    if (!snapResult) {
      alert('Hindi nakuha ang larawan. Pakisubukang muli.');
      return;
    }

    setRawPhotoSrc(snapResult.raw);
    setCroppedImageSrc(snapResult.cropped);
    setPendingCroppedForBox(snapResult.cropped);
    setIsBoxSelectorOpen(true);
    setStatusMessage('📸 Nakuha ang PDS! Pumili ng Box sa Gallery Table para simulan ang AI scan...');
  };

  const handleSelectBoxDestination = (boxNum: number) => {
    if (!pendingCroppedForBox) return;
    if (onAssignToGalleryBox) {
      onAssignToGalleryBox(pendingCroppedForBox, boxNum);
    }
    setIsBoxSelectorOpen(false);
    setPendingCroppedForBox(null);
    onClose();
  };

  const handleSelectAddNew4Boxes = () => {
    if (!pendingCroppedForBox) return;
    if (onAddNew4BoxesAndAssign) {
      onAddNew4BoxesAndAssign(pendingCroppedForBox);
    }
    setIsBoxSelectorOpen(false);
    setPendingCroppedForBox(null);
    onClose();
  };

  // Perform AI Frame Analysis and Automatic Extraction
  const performAiScan = useCallback(async () => {
    if (isAnalyzing || !isCameraReady) return;

    const imageBase64 = captureFrameBase64();
    if (!imageBase64) return;

    setLastCapturedImage(imageBase64);
    setIsAnalyzing(true);
    setStatusMessage('Binabasa ng AI Line Detector ang bawat header at datos...');

    try {
      // Run AI Extraction against target headers
      const result = await extractDocumentClientSide(
        [imageBase64],
        'AI Mobile Live Frame Scan',
        undefined,
        headers
      );

      if (result && result.data && result.data.sections && result.data.sections.length > 0) {
        const extractedRow = result.data.sections[0]?.rows?.[0] || {};
        
        // Single-pass lock-in: Accumulate into detected fields memory
        const currentMemory = { ...detectedFieldsRef.current };
        const newPopups: DetectedFieldNotification[] = [];
        let newlyFoundCount = 0;

        headers.forEach(h => {
          // Check direct key or fuzzy matching
          let val = (extractedRow[h] || '').trim();
          if (!val) {
            const cleanH = h.toLowerCase().replace(/[^a-z0-9]/g, '');
            const matchingKey = Object.keys(extractedRow).find(k => {
              const cleanK = k.toLowerCase().replace(/[^a-z0-9]/g, '');
              return cleanH.includes(cleanK) || cleanK.includes(cleanH);
            });
            if (matchingKey) {
              val = (extractedRow[matchingKey] || '').trim();
            }
          }

          // Strict Zero-Hallucination Filter: Accept ONLY genuine, verified non-placeholder data
          const isPlaceholderOrInvalid = (v: string) => {
            const c = v.trim().toLowerCase();
            return (
              !c ||
              c === 'n/a' ||
              c === 'na' ||
              c === '-' ||
              c === '--' ||
              c === '---' ||
              c === 'none' ||
              c === 'unknown' ||
              c === 'hindi matukoy' ||
              c === 'bagong aplikante' ||
              c === 'aplikante' ||
              c === 'null' ||
              c === 'undefined'
            );
          };

          if (val && !isPlaceholderOrInvalid(val)) {
            // If field is newly detected or has more complete information, lock it in permanently!
            if (!currentMemory[h] || (currentMemory[h] !== val && val.length >= (currentMemory[h]?.length || 0))) {
              currentMemory[h] = val;
              newlyFoundCount++;
              newPopups.push({
                id: `${h}-${Date.now()}-${Math.random()}`,
                header: h,
                value: val,
                timestamp: Date.now()
              });
            }
          }
        });

        if (newlyFoundCount > 0) {
          // Reset 5-minute inactivity watchdog because genuine data was discovered!
          lastDataFoundTimestampRef.current = Date.now();
          setInactivitySecondsLeft(300);

          detectedFieldsRef.current = currentMemory;
          setDetectedFields({ ...currentMemory });
          
          // Trigger popups sequentially with pleasant sound feedback
          playSuccessChime();
          setFieldPopups(prev => [...newPopups, ...prev].slice(0, 8));

          // Automatically send accumulated data row to parent table!
          onRowExtracted(currentMemory, imageBase64);

          setStatusMessage(`🎯 1-Pass Locked! Na-detect ang ${newlyFoundCount} bagong field at pasok agad sa table.`);

          // Check if majority of headers are filled
          const filledCount = headers.filter(h => !!(currentMemory[h] && currentMemory[h].trim())).length;
          if (filledCount >= headers.length * 0.7) {
            playAllMatchFanfare();
          }
        } else {
          const currentCount = Object.keys(currentMemory).length;
          setStatusMessage(currentCount > 0 
            ? `May ${currentCount} headers nang naka-lock sa table. Naka-abang sa iba pang fields...`
            : 'Naka-tutok ang AI line detector... Ilapit o i-scan ang mga linya ng PDS/form');
        }
      } else {
        setStatusMessage('Ina-align ang lines at teksto sa form...');
      }
    } catch (err: any) {
      console.warn('AI live scan warning:', err);
      setStatusMessage('Naghahanap ng mababasang form o PDS...');
    } finally {
      setIsAnalyzing(false);
    }
  }, [
    isAnalyzing,
    isCameraReady,
    captureFrameBase64,
    headers,
    detectedFields,
    playSuccessChime,
    playAllMatchFanfare,
    onRowExtracted,
    apiKeyModalTrigger
  ]);

  // Interval loop for Auto Scan every 1.8 seconds for ultra-rapid data capture
  useEffect(() => {
    if (!isOpen || !isAutoScanActive || !isCameraReady) return;

    const timer = setInterval(() => {
      if (!isAnalyzing) {
        performAiScan();
      }
    }, 1800);

    return () => clearInterval(timer);
  }, [isOpen, isAutoScanActive, isCameraReady, isAnalyzing, performAiScan]);

  // Clean old popups after 3.5 seconds
  useEffect(() => {
    if (fieldPopups.length === 0) return;
    const interval = setInterval(() => {
      const now = Date.now();
      setFieldPopups(prev => prev.filter(p => now - p.timestamp < 3500));
    }, 500);
    return () => clearInterval(interval);
  }, [fieldPopups]);

  // Toggle Torch/Flash
  const toggleTorch = async () => {
    if (!streamRef.current) return;
    const track = streamRef.current.getVideoTracks()[0];
    if (!track) return;
    try {
      const capabilities = track.getCapabilities() as any;
      if (capabilities && capabilities.torch) {
        await (track as any).applyConstraints({
          advanced: [{ torch: !torchOn }]
        });
        setTorchOn(!torchOn);
      } else {
        alert('Walang Torch / Flashlight ang camera na ito.');
      }
    } catch (e) {
      console.warn('Torch toggle error', e);
    }
  };

  // Flip Front/Back Camera
  const toggleFacingMode = () => {
    setFacingMode(prev => (prev === 'environment' ? 'user' : 'environment'));
  };

  // Save current record and start scanning next document
  const handleSaveAndScanNext = () => {
    if (Object.keys(detectedFields).length === 0) {
      alert('Wala pang na-detect na datos. Mangyaring itutok muna ang camera sa dokumento.');
      return;
    }
    
    // Notify parent
    onRowExtracted(detectedFields, lastCapturedImage || undefined);
    setScannedRowCount(prev => prev + 1);
    
    // Reset scanner for next document/page
    setDetectedFields({});
    setFieldPopups([]);
    playAllMatchFanfare();
    setStatusMessage('Na-save na sa Table! Handa nang i-scan ang susunod na form o aplikante...');
  };

  if (!isOpen) return null;

  const matchedHeadersCount = headers.filter(h => !!(detectedFields[h] && detectedFields[h].trim())).length;
  const matchPercentage = headers.length > 0 ? Math.round((matchedHeadersCount / headers.length) * 100) : 0;

  const inactivityMinutes = Math.floor(inactivitySecondsLeft / 60);
  const inactivitySeconds = (inactivitySecondsLeft % 60).toString().padStart(2, '0');
  const formattedInactivityTime = `${inactivityMinutes}:${inactivitySeconds}`;

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col select-none overflow-hidden touch-auto font-sans">
      {/* Hidden offscreen canvas for snapshot extraction */}
      <canvas ref={canvasRef} className="hidden" />

      {/* TOP HUD BAR - Horizontally scrollable papahiga para hindi maipit o maitago ang mga button sa kanan */}
      <div className="absolute top-0 inset-x-0 z-30 bg-gradient-to-b from-black/95 via-black/75 to-transparent pt-3 pb-2 px-2.5 sm:px-4 pointer-events-auto">
        <div
          className="w-full overflow-x-auto scroll-smooth no-scrollbar touch-pan-x flex items-center justify-between gap-3 min-w-0"
          style={{ WebkitOverflowScrolling: 'touch' }}
          onWheel={(e) => {
            if (e.deltaY !== 0) {
              e.currentTarget.scrollLeft += e.deltaY;
            }
          }}
        >
          {/* Left: App & Status */}
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/50 backdrop-blur-md flex items-center justify-center text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)] shrink-0">
              <ScanLine className="w-6 h-6 animate-pulse" />
            </div>
            <div className="shrink-0">
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-black text-white tracking-wide">AI LIVE SCANNER</h2>
                <span className="px-1.5 py-0.5 text-[9px] font-black uppercase rounded bg-emerald-400 text-black shadow">
                  GEMINI AI
                </span>
              </div>
              <p className="text-[11px] text-emerald-300 font-bold truncate max-w-[170px] sm:max-w-xs">
                {templateName}
              </p>
            </div>
          </div>

          {/* Right Action Icons (Horizontally scrollable with the bar, never cut off!) */}
          <div className="flex items-center gap-2 shrink-0 pl-1">
            {/* 5-Minute Inactivity Watchdog Timer Badge */}
            <div
              className={`px-2.5 py-1 rounded-xl backdrop-blur-md border text-[11px] font-black flex items-center gap-1.5 transition-all shrink-0 ${
                inactivitySecondsLeft <= 60
                  ? 'bg-rose-500/30 border-rose-500 text-rose-200 animate-pulse'
                  : inactivitySecondsLeft <= 120
                  ? 'bg-amber-500/20 border-amber-400/40 text-amber-300'
                  : 'bg-slate-900/70 border-slate-700/60 text-slate-300'
              }`}
              title="Awtomatikong magsasara kapag 5 minuto nang walang nakikitang kailangang datos"
            >
              <Clock className={`w-3.5 h-3.5 ${inactivitySecondsLeft <= 60 ? 'text-rose-400 animate-spin' : 'text-amber-400'}`} />
              <span className="hidden sm:inline">5m Inactivity:</span>
              <span className="font-mono">{formattedInactivityTime}</span>
            </div>

            {/* Sound Toggle */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-2.5 rounded-xl backdrop-blur-md border transition-all shrink-0 active:scale-95 ${
                soundEnabled
                  ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-300'
                  : 'bg-white/10 border-white/20 text-white/60'
              }`}
              title="Toggle Sound Effects"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Torch Toggle */}
            <button
              onClick={toggleTorch}
              className={`p-2.5 rounded-xl backdrop-blur-md border transition-all shrink-0 active:scale-95 ${
                torchOn
                  ? 'bg-amber-400 text-black border-amber-300 font-bold shadow-lg shadow-amber-400/40'
                  : 'bg-white/10 border-white/20 text-white/80'
              }`}
              title="Buksan ang Flashlight"
            >
              <Zap className="w-4 h-4" />
            </button>

            {/* Switch Front/Back Camera */}
            <button
              onClick={toggleFacingMode}
              className="p-2.5 rounded-xl bg-white/10 border border-white/20 text-white/90 backdrop-blur-md active:scale-95 transition-all shrink-0"
              title="Palitan ang Camera (Harap/Likod)"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            {/* Close Scanner Button */}
            <button
              onClick={onClose}
              className="p-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 border border-rose-400/60 text-white backdrop-blur-md active:scale-95 transition-all shadow-lg shadow-rose-900/40 shrink-0"
              title="Isara ang AI Scanner"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* FULLSCREEN CAMERA VIEWFINDER & LASER LINE DETECTOR OVERLAY */}
      <div className="relative flex-1 w-full h-full bg-black flex items-center justify-center overflow-hidden">
        {/* Live Video Feed (Filling entire screen of mobile device) */}
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="absolute inset-0 w-full h-full object-cover"
        />

        {/* Camera Error Message fallback */}
        {cameraError && (
          <div className="absolute inset-0 z-20 bg-slate-950/95 flex flex-col items-center justify-center p-6 text-center text-white gap-4">
            <div className="w-16 h-16 rounded-2xl bg-rose-500/20 border border-rose-500 text-rose-400 flex items-center justify-center">
              <Camera className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold">Kailangan ng Access sa Camera</h3>
            <p className="text-xs text-slate-300 max-w-sm">{cameraError}</p>
            <button
              onClick={startCamera}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-lg transition-all"
            >
              Subukan Muli
            </button>
          </div>
        )}

        {/* DOCUMENT TARGETING FRAME & LASER SCANNER LINE DETECTOR */}
        {isCameraReady && !cameraError && (
          <div className={`relative z-10 w-[82%] sm:w-[86%] max-w-sm sm:max-w-md ${sidePosition === 'left' ? 'ml-16 sm:ml-20 mr-2' : 'mr-16 sm:mr-20 ml-2'} aspect-[3/4] sm:aspect-[4/5] border border-white/30 rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.8)] backdrop-contrast-105 pointer-events-none transition-all`}>
            {/* Viewfinder Corner Brackets */}
            <div className="absolute top-0 left-0 w-9 h-9 border-t-4 border-l-4 border-emerald-400 rounded-tl-2xl shadow-[0_0_15px_#10b981]" />
            <div className="absolute top-0 right-0 w-9 h-9 border-t-4 border-r-4 border-emerald-400 rounded-tr-2xl shadow-[0_0_15px_#10b981]" />
            <div className="absolute bottom-0 left-0 w-9 h-9 border-b-4 border-l-4 border-emerald-400 rounded-bl-2xl shadow-[0_0_15px_#10b981]" />
            <div className="absolute bottom-0 right-0 w-9 h-9 border-b-4 border-r-4 border-emerald-400 rounded-br-2xl shadow-[0_0_15px_#10b981]" />

            {/* Matrix Radar Grid Background */}
            <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:18px_18px]" />

            {/* ✨ GLOWING AI LASER LINE DETECTOR (Moving Up & Down) */}
            <div className="absolute inset-x-0 h-1.5 bg-gradient-to-r from-transparent via-emerald-300 to-transparent shadow-[0_0_25px_#10b981,0_0_50px_#34d399] animate-laser-scan">
              {/* Laser glow follower beam */}
              <div className="absolute -top-14 inset-x-0 h-14 bg-gradient-to-b from-transparent to-emerald-400/25 pointer-events-none" />
              <div className="absolute top-1.5 inset-x-0 h-10 bg-gradient-to-t from-transparent to-emerald-300/20 pointer-events-none" />
            </div>

            {/* Center Target Crosshair */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-14 h-14 border border-emerald-400/40 rounded-full flex items-center justify-center">
              <div className="w-2 h-2 bg-emerald-400 rounded-full shadow-[0_0_10px_#10b981] animate-ping" />
            </div>

            {/* Floating Live Detection Status inside Frame */}
            <div className="absolute top-3 inset-x-3 flex items-center justify-between text-[11px] font-black text-white">
              <div className="px-2.5 py-1 bg-black/70 backdrop-blur-md rounded-xl border border-emerald-500/50 text-emerald-300 flex items-center gap-1.5 shadow-lg">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span>AI LINE DETECTOR</span>
              </div>
              <div className="px-2.5 py-1 bg-black/70 backdrop-blur-md rounded-xl border border-white/20 text-white/90 shadow-lg">
                {matchedHeadersCount}/{headers.length} Headers
              </div>
            </div>

            {/* Bottom Progress Bar inside frame */}
            <div className="absolute bottom-3 inset-x-3">
              <div className="bg-black/80 backdrop-blur-md rounded-xl p-2.5 border border-white/10 flex flex-col gap-1.5 shadow-lg">
                <div className="flex items-center justify-between text-[10px] text-slate-300">
                  <span className="font-bold">AI Field Match:</span>
                  <span className="font-extrabold text-emerald-400 text-xs">{matchPercentage}%</span>
                </div>
                <div className="w-full h-2 bg-white/20 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-300 transition-all duration-500 rounded-full shadow-[0_0_12px_#10b981]"
                    style={{ width: `${Math.max(matchPercentage, 5)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 🌟 REAL-TIME POPUP CHIPS WITH CHECKMARK & HEADER NAME (Nalalagay agad sa table) */}
        <div className="absolute inset-x-4 top-20 z-30 pointer-events-none flex flex-col items-center gap-2 max-w-md mx-auto">
          {fieldPopups.map((item, idx) => (
            <div
              key={item.id}
              className="w-full transform animate-in slide-in-from-top-4 fade-in duration-300"
              style={{ animationDelay: `${idx * 40}ms` }}
            >
              <div className="bg-slate-950/95 backdrop-blur-xl border-2 border-emerald-400 rounded-2xl p-3 shadow-[0_10px_35px_rgba(0,0,0,0.9),0_0_20px_rgba(16,185,129,0.4)] flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  {/* POP-UP CHECKMARK ICON */}
                  <div className="w-7 h-7 rounded-full bg-emerald-400 text-slate-950 flex items-center justify-center flex-shrink-0 shadow-[0_0_12px_#10b981] font-black">
                    <Check className="w-4 h-4 stroke-[3.5]" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-[10px] font-black uppercase text-emerald-300 tracking-wider block truncate">
                      {item.header}
                    </span>
                    <span className="text-xs font-extrabold text-white truncate block">
                      {item.value}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col items-end shrink-0">
                  <span className="px-2 py-0.5 text-[9px] font-black rounded-md bg-emerald-500 text-slate-950 shadow flex items-center gap-1">
                    <Sparkles className="w-2.5 h-2.5" />
                    Pasok sa Table
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 📱 SIDE ACTION CONTROLS DOCK (Nasa gilid ng screen tulad ng hiniling sa Picture 2) */}
      <div
        className={`absolute ${
          sidePosition === 'left' ? 'left-2 sm:left-3.5' : 'right-2 sm:right-3.5'
        } top-1/2 -translate-y-1/2 z-40 flex flex-col items-center gap-2 sm:gap-2.5 p-1.5 sm:p-2 bg-slate-950/85 backdrop-blur-md rounded-2xl border border-white/20 shadow-[0_0_30px_rgba(0,0,0,0.85)] pointer-events-auto`}
      >
        {/* 1. Toggle Auto Scan */}
        <button
          onClick={() => setIsAutoScanActive(!isAutoScanActive)}
          className={`w-14 sm:w-16 h-12 sm:h-13 flex flex-col items-center justify-center rounded-xl text-[10px] font-bold border transition-all active:scale-95 ${
            isAutoScanActive
              ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
              : 'bg-white/10 border-white/15 text-slate-400'
          }`}
          title="Auto Continuous Scanning: I-on o I-off"
        >
          {isAutoScanActive ? (
            <Pause className="w-4 h-4 mb-0.5 text-emerald-300" />
          ) : (
            <Play className="w-4 h-4 mb-0.5 text-slate-300" />
          )}
          <span className="text-[9px] font-mono leading-tight">
            {isAutoScanActive ? 'Auto: ON' : 'Auto: OFF'}
          </span>
        </button>

        {/* 2. Live Frame Scan button */}
        <button
          onClick={performAiScan}
          disabled={isAnalyzing || !isCameraReady}
          className={`w-14 sm:w-16 h-12 sm:h-13 flex flex-col items-center justify-center rounded-xl text-[10px] font-bold transition-all shadow-md active:scale-95 ${
            isAnalyzing
              ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
              : 'bg-slate-800/90 hover:bg-slate-700 text-slate-100 border border-white/20 active:scale-95'
          }`}
          title="Manual na i-scan ang frame gamit ang AI"
        >
          {isAnalyzing ? (
            <RefreshCw className="w-4 h-4 animate-spin mb-0.5 text-amber-400" />
          ) : (
            <Sparkles className="w-4 h-4 mb-0.5 text-emerald-400" />
          )}
          <span className="text-[9px] font-medium leading-tight">
            {isAnalyzing ? 'Scan...' : 'Live Scan'}
          </span>
        </button>

        {/* 3. 📸 Primary Camera Shutter: Snap & Auto-Crop Bondpaper Button (Bright Golden Shutter Button) */}
        <button
          onClick={handleSnapAndAutoCrop}
          disabled={!isCameraReady || isCroppedAnalyzing}
          className={`w-14 sm:w-16 h-14 sm:h-16 flex flex-col items-center justify-center rounded-xl text-[10px] font-black transition-all shadow-xl active:scale-95 ${
            isCroppedAnalyzing
              ? 'bg-amber-600 text-white animate-pulse'
              : 'bg-gradient-to-br from-amber-300 via-amber-400 to-yellow-500 text-slate-950 hover:brightness-110 shadow-amber-500/30 border-2 border-amber-200'
          }`}
          title="Picturan at i-crop ang buong PDS bondpaper"
        >
          {isCroppedAnalyzing ? (
            <RefreshCw className="w-5 h-5 animate-spin mb-0.5 text-slate-950" />
          ) : (
            <Camera className="w-5 h-5 mb-0.5 text-slate-950" />
          )}
          <span className="text-[8.5px] sm:text-[9px] font-black uppercase tracking-tight leading-none text-center">
            {isCroppedAnalyzing ? (
              'Crop...'
            ) : (
              <>
                <span className="block">CROP &</span>
                <span className="block mt-0.5">SCAN</span>
              </>
            )}
          </span>
        </button>

        {/* 4. Save & Scan Next Document */}
        <button
          onClick={handleSaveAndScanNext}
          className="w-14 sm:w-16 h-12 sm:h-13 flex flex-col items-center justify-center rounded-xl text-[10px] font-bold bg-indigo-600 hover:bg-indigo-500 text-white border border-indigo-400/50 shadow-md active:scale-95 transition-all"
          title="I-save sa table at i-scan ang susunod na form o aplikante"
        >
          <ArrowRight className="w-4 h-4 mb-0.5 text-white" />
          <span className="text-[9px] font-semibold leading-tight text-center">Next Form</span>
        </button>

        {/* Subtle Dock Flip Button (Right ⇄ Left side) */}
        <button
          onClick={() => setSidePosition((prev) => (prev === 'right' ? 'left' : 'right'))}
          className="w-full py-1 text-slate-400 hover:text-white text-[9px] font-bold flex items-center justify-center gap-1 rounded hover:bg-white/10 transition-all opacity-60 hover:opacity-100 mt-0.5"
          title={sidePosition === 'right' ? 'Ilipat sa kaliwang gilid ang mga button' : 'Ilipat sa kanang gilid ang mga button'}
        >
          <span>⇄ Gilid</span>
        </button>
      </div>

      {/* BOTTOM COMPACT STATUS RIBBON & REAL-TIME DATA DRAWER */}
      <div className="relative z-30 bg-slate-950/95 border-t border-white/10 p-2 sm:p-2.5 flex flex-col gap-2 pointer-events-auto">
        {/* Status ticker */}
        <div className="flex items-center justify-between gap-2 text-[11px]">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className={`w-2 h-2 rounded-full flex-shrink-0 ${isAnalyzing ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`} />
            <span className="text-slate-200 truncate font-semibold text-[10px] sm:text-xs">
              {statusMessage}
            </span>
          </div>

          <button
            onClick={() => setShowLiveTablePreview(!showLiveTablePreview)}
            className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[10px] font-bold border border-white/15 flex items-center gap-1 flex-shrink-0 active:scale-95 transition-all"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>{showLiveTablePreview ? 'Itago' : `Tingnan (${matchedHeadersCount})`}</span>
            <ChevronDown className={`w-2.5 h-2.5 transition-transform ${showLiveTablePreview ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {/* Live Detected Fields Drawer */}
        {showLiveTablePreview && (
          <div className="max-h-48 overflow-y-auto bg-slate-900/95 rounded-xl p-2.5 border border-white/15 divide-y divide-white/5 text-xs text-slate-200 shadow-2xl">
            <div className="font-black text-emerald-400 text-[10px] uppercase tracking-wider pb-1.5 flex items-center justify-between">
              <span>Mga Na-detect na Header ({matchedHeadersCount}/{headers.length})</span>
              <span className="text-[9px] text-slate-400 font-mono">100% Synced sa Table</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 pt-1.5">
              {headers.map(h => {
                const val = detectedFields[h];
                const isFound = !!(val && val.trim());
                return (
                  <div
                    key={h}
                    className={`flex items-start justify-between gap-1.5 p-1.5 rounded-lg border text-[10px] transition-all ${
                      isFound
                        ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-200'
                        : 'bg-black/30 border-white/5 text-slate-500'
                    }`}
                  >
                    <span className="font-bold truncate max-w-[120px]">{h}:</span>
                    <span className="font-bold text-right truncate flex-1 text-white">
                      {isFound ? val : 'Hinahanap...'}
                    </span>
                    {isFound ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                    ) : (
                      <div className="w-3.5 h-3.5 rounded-full border border-dashed border-slate-600 flex-shrink-0" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* 📄 AUTOMATIC POP-UP MODAL: FAST AUTO-CROP THEN AI LASER DETECTOR */}
      {isCroppedModalOpen && (rawPhotoSrc || croppedImageSrc) && (
        <div className="fixed inset-0 z-[70] bg-black/92 backdrop-blur-md flex flex-col items-center justify-between p-3 sm:p-4 animate-in fade-in zoom-in-95 duration-200">
          {/* Header Bar */}
          <div className="w-full max-w-lg flex items-center justify-between gap-3 bg-slate-900/95 border border-amber-400/50 rounded-xl px-3.5 py-2 shadow-2xl">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-amber-400/20 border border-amber-400/50 flex items-center justify-center text-amber-300">
                <Scissors className="w-3.5 h-3.5" />
              </div>
              <div>
                <h3 className="text-xs font-black text-white flex items-center gap-1.5">
                  <span>
                    {cropPhase === 'detecting_bounds' ? 'Pinuputol ang Paligid...' : 'Buong PDS Bondpaper'}
                  </span>
                  <span
                    className={`px-1.5 py-0.5 font-black text-[9px] uppercase rounded ${
                      cropPhase === 'detecting_bounds'
                        ? 'bg-amber-400 text-slate-950 animate-pulse'
                        : 'bg-emerald-400 text-slate-950'
                    }`}
                  >
                    {cropPhase === 'detecting_bounds' ? 'Auto-Cropping' : 'AI Line Detector'}
                  </span>
                </h3>
                <p className="text-[9px] text-slate-300">
                  {cropPhase === 'detecting_bounds'
                    ? '⚡ Inaalis ang mga kalat sa background...'
                    : isCroppedAnalyzing
                    ? '⚡ Binabasa ng AI Line Detector ang bawat linya...'
                    : `✓ Nahanap at naka-sync: ${Object.keys(detectedFields).length} headers`}
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsCroppedModalOpen(false)}
              className="p-1 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white border border-white/10"
              title="Isara"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Central Frame: Transitions from Raw Photo -> Pure Cropped Bondpaper + Laser Scan */}
          <div className="relative my-auto w-full max-w-sm sm:max-w-md max-h-[62vh] rounded-2xl overflow-hidden border-2 border-emerald-400/80 shadow-[0_0_40px_rgba(16,185,129,0.35)] bg-slate-950 flex items-center justify-center">
            {/* Step 1: Raw photo showing crop box animation */}
            {cropPhase === 'detecting_bounds' && rawPhotoSrc && (
              <div className="relative w-full h-full flex items-center justify-center animate-pulse">
                <img
                  src={rawPhotoSrc || undefined}
                  alt="Raw Document Snapshot"
                  className="w-full h-full object-contain max-h-[58vh] opacity-70"
                />
                {/* Visual Bounding Box clipping indicator */}
                <div className="absolute inset-4 border-2 border-dashed border-amber-400 bg-amber-400/10 rounded-xl flex items-center justify-center shadow-[0_0_25px_rgba(251,191,36,0.5)]">
                  <div className="px-2.5 py-1 rounded-full bg-slate-950/90 border border-amber-400 text-amber-300 text-[10px] font-black uppercase tracking-wider flex items-center gap-1.5 shadow-xl">
                    <Scissors className="w-3 h-3 animate-spin" />
                    <span>Auto-Cropping Bondpaper...</span>
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Pure Cropped Bondpaper + AI Laser Line Detector */}
            {cropPhase === 'cropped_ready' && croppedImageSrc && (
              <div className="relative w-full h-full flex items-center justify-center animate-in zoom-in-95 duration-200">
                <img
                  src={croppedImageSrc || undefined}
                  alt="Cropped Pure PDS Bondpaper"
                  className="w-full h-full object-contain max-h-[58vh] bg-white rounded-lg shadow-2xl"
                />

                {/* AI Laser Line Detector overlay on the cropped bondpaper */}
                <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-lg">
                  {/* Vertical Laser Scan Beam */}
                  {isCroppedAnalyzing && (
                    <div className="w-full h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_20px_#10b981,0_0_35px_#34d399] animate-laser-scan absolute top-0 left-0" />
                  )}

                  {/* Scan grid effect */}
                  <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:20px_20px] opacity-15" />

                  {/* 4 Precision Corner Guides */}
                  <div className="absolute top-2 left-2 w-5 h-5 border-t-2 border-l-2 border-amber-400" />
                  <div className="absolute top-2 right-2 w-5 h-5 border-t-2 border-r-2 border-amber-400" />
                  <div className="absolute bottom-2 left-2 w-5 h-5 border-b-2 border-l-2 border-amber-400" />
                  <div className="absolute bottom-2 right-2 w-5 h-5 border-b-2 border-r-2 border-amber-400" />

                  {/* Laser Status Pill */}
                  <div className="absolute top-3 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full bg-slate-950/85 border border-emerald-400 text-emerald-300 text-[9px] font-black tracking-wider uppercase flex items-center gap-1.5 shadow-lg">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    <span>
                      {isCroppedAnalyzing ? 'AI Line Detector Scanning...' : 'Scan Complete ✓'}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Action / Confirmation Bar */}
          <div className="w-full max-w-lg bg-slate-900/95 border border-white/10 rounded-xl p-2 sm:p-2.5 flex items-center justify-between gap-2 shadow-2xl">
            <button
              onClick={() => {
                setIsCroppedModalOpen(false);
                setTimeout(() => handleSnapAndAutoCrop(), 300);
              }}
              disabled={isCroppedAnalyzing && cropPhase === 'detecting_bounds'}
              className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 text-[11px] font-bold border border-white/10 flex items-center gap-1.5 flex-shrink-0"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Kumuha Ulit</span>
            </button>

            <button
              onClick={() => setIsCroppedModalOpen(false)}
              className="flex-1 px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-slate-950 text-[11px] font-black shadow-md flex items-center justify-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5 stroke-[3]" />
              <span>I-save sa Table ({Object.keys(detectedFields).length} headers)</span>
            </button>
          </div>
        </div>
      )}

      {/* 📦 MODAL: PUMILI NG BOX SA GALLERY TABLE (BOX 1, 2, 3, 4 O MAG-ADD NG BAGONG 4 BOX) */}
      {isBoxSelectorOpen && pendingCroppedForBox && (
        <div className="fixed inset-0 z-[80] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-slate-900 border-2 border-emerald-500/50 rounded-3xl overflow-hidden shadow-2xl flex flex-col text-white">
            {/* Header */}
            <div className="px-5 py-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center shadow">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white flex items-center gap-1.5">
                    <span>PUMILI NG BOX SA GALLERY TABLE</span>
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Saan ilalagay ang napicturang PDS?
                  </p>
                </div>
              </div>

              <button
                onClick={() => {
                  setIsBoxSelectorOpen(false);
                  setPendingCroppedForBox(null);
                }}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="Kanselahin"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Photo Preview & Selection Grid */}
            <div className="p-4 sm:p-5 space-y-4 max-h-[70vh] overflow-y-auto">
              {/* Cropped Photo Preview Card */}
              <div className="flex items-center gap-3 p-2.5 rounded-2xl bg-slate-950/60 border border-slate-800">
                <div className="w-16 h-20 rounded-xl overflow-hidden bg-slate-800 border border-emerald-500/50 shrink-0 shadow-md">
                  <img
                    src={pendingCroppedForBox}
                    alt="Captured PDS"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="space-y-1">
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Naka-crop at Nakahanda</span>
                  </span>
                  <p className="text-xs font-bold text-white">
                    Napicturang PDS Bondpaper
                  </p>
                  <p className="text-[11px] text-slate-400 leading-snug">
                    Awtomatikong iisa-isahin ng AI ang bawat box simula sa una, kukunin ang data sa table, at ililipat ang picture sa PDS Pictures.
                  </p>
                </div>
              </div>

              {/* Box Slots List */}
              <div className="space-y-2">
                <label className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                  <Table className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Pumili ng Box Slot sa Table:</span>
                </label>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(() => {
                    // Ensure at least 4 boxes are rendered
                    const effectiveBoxes: { boxNumber: number; label: string; isOccupied: boolean }[] = [];
                    const maxBoxNum = Math.max(4, ...(galleryBoxes.map(b => b.boxNumber) || [4]));
                    
                    for (let i = 1; i <= maxBoxNum; i++) {
                      const found = galleryBoxes.find(b => b.boxNumber === i);
                      const isOccupied = !!(found && found.imageSrc);
                      let label = `Box ${i}`;
                      if (i === 1) label = 'Pang-una (Box 1)';
                      else if (i === 2) label = 'Pangalawa (Box 2)';
                      else if (i === 3) label = 'Pangatlo (Box 3)';
                      else if (i === 4) label = 'Pang-apat (Box 4)';
                      else label = `Box ${i}`;

                      effectiveBoxes.push({ boxNumber: i, label, isOccupied });
                    }

                    return effectiveBoxes.map(slot => (
                      <button
                        key={slot.boxNumber}
                        onClick={() => handleSelectBoxDestination(slot.boxNumber)}
                        className={`p-2.5 rounded-xl border text-left transition-all active:scale-95 flex flex-col justify-between gap-1.5 shadow-sm ${
                          slot.isOccupied
                            ? 'bg-amber-950/30 border-amber-500/40 hover:bg-amber-900/40 text-amber-200'
                            : 'bg-slate-800/80 border-slate-700 hover:border-emerald-500 hover:bg-emerald-950/30 text-white'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="w-5 h-5 rounded bg-emerald-500/20 text-emerald-300 font-mono font-black text-[11px] flex items-center justify-center border border-emerald-500/30">
                            {slot.boxNumber}
                          </span>
                          <span
                            className={`text-[8px] font-bold px-1.5 py-0.2 rounded-full ${
                              slot.isOccupied
                                ? 'bg-amber-500/30 text-amber-300 border border-amber-500/40'
                                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            }`}
                          >
                            {slot.isOccupied ? 'Laman' : 'Bakante'}
                          </span>
                        </div>
                        <div>
                          <div className="text-[11px] font-black truncate">{slot.label}</div>
                          <div className="text-[9px] text-slate-400 truncate">
                            {slot.isOccupied ? 'Papalitan' : 'Piliin'}
                          </div>
                        </div>
                      </button>
                    ));
                  })()}
                </div>
              </div>

              {/* Add New 4 Box Button */}
              <div className="pt-2 border-t border-slate-800">
                <button
                  onClick={handleSelectAddNew4Boxes}
                  className="w-full p-3 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 hover:brightness-110 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 border border-indigo-400/40 active:scale-98 transition-all"
                >
                  <Plus className="w-4 h-4 text-indigo-200" />
                  <span>➕ Mag-add ng Bagong 4 Box (New 4-Box Row)</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-indigo-200" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ⚠️ 5-MINUTE INACTIVITY AUTO-CLOSE WARNING MODAL */}
      {isTimeoutWarningOpen && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
        >
          <div className="w-full max-w-md bg-slate-900 border-2 border-amber-500/80 rounded-3xl overflow-hidden shadow-2xl p-6 text-center space-y-5 animate-in zoom-in-95 duration-200">
            <div className="relative w-20 h-20 mx-auto flex items-center justify-center">
              <div className="absolute inset-0 bg-amber-500/20 rounded-full animate-ping opacity-75" />
              <div className="relative w-16 h-16 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center shadow-xl shadow-amber-500/30 font-black">
                <AlertTriangle className="w-9 h-9 animate-bounce text-slate-950" />
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-lg sm:text-xl font-black text-white tracking-tight">
                Pansamantalang Isinara ang Scanner
              </h3>
              <div className="p-3.5 rounded-2xl bg-amber-950/50 border border-amber-500/40 text-amber-200 text-xs sm:text-sm font-bold leading-relaxed">
                "Pansamantala ko muna itong isasara dahil 5 minuto nang walang nakikitang kailangang datos. Pakibuksan na lamang ulit kapag handa na ang PDS o dokumento."
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Mahigpit na sumusunod ang AI sa patakarang bawal mag-imbento o maglagay ng hindi totoong datos. Hanggat walang totoong nakikitang kailangang impormasyon sa dokumento, hindi ito magpapasok ng maling data.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-2.5 pt-2">
              <button
                onClick={() => {
                  setIsTimeoutWarningOpen(false);
                  lastDataFoundTimestampRef.current = Date.now();
                  scannerOpenedTimestampRef.current = Date.now();
                  setInactivitySecondsLeft(300);
                  startCamera();
                }}
                className="w-full sm:flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black shadow-lg shadow-emerald-900/40 transition-all active:scale-95 flex items-center justify-center gap-2 border border-emerald-400/40"
              >
                <RefreshCw className="w-4 h-4 text-emerald-200" />
                <span>Buksan Muli ang Scanner</span>
              </button>

              <button
                onClick={() => {
                  setIsTimeoutWarningOpen(false);
                  onClose();
                }}
                className="w-full sm:w-auto py-3 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all border border-slate-700 active:scale-95"
              >
                Isara / Naintindihan
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

