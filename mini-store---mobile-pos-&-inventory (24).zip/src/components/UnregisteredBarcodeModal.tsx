import React, { useState, useEffect } from 'react';
import { getLanguage, t, LANG_CHANGE_EVENT } from '../utils/language';
import { Barcode, PlusCircle, Sparkles } from 'lucide-react';

interface UnregisteredBarcodeModalProps {
  barcode: string | null;
  isOpen: boolean;
  onClose: () => void;
  onRegisterProduct: (barcode: string) => void;
}

export const UnregisteredBarcodeModal: React.FC<UnregisteredBarcodeModalProps> = ({
  barcode,
  isOpen,
  onClose,
  onRegisterProduct,
}) => {
  const [, setLangState] = useState(getLanguage());

  useEffect(() => {
    const handleLangChange = () => setLangState(getLanguage());
    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
  }, []);

  if (!isOpen || !barcode) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-white border border-slate-200/80 rounded-3xl p-6 shadow-2xl text-center space-y-4 animate-in zoom-in-95 duration-200">
        <div className="w-12 h-12 rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center mx-auto text-amber-600">
          <Barcode className="w-6 h-6" />
        </div>

        <div>
          <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider bg-amber-50 text-amber-700 px-2.5 py-0.5 rounded-full border border-amber-200 mb-1">
            <Sparkles className="w-3 h-3" /> {t('unregisteredBadge')}
          </span>
          <h3 className="text-base font-bold text-slate-900 mt-1">{t('unregisteredTitle')}</h3>
          <p className="text-xs text-slate-500 mt-1">{t('unregisteredSub')}</p>
          <div className="my-2 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 font-mono text-indigo-700 font-bold text-sm inline-block">
            {barcode}
          </div>
        </div>

        <p className="text-xs text-slate-500">
          {t('unregisteredPrompt')}
        </p>

        <div className="flex gap-2 pt-2">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs border border-slate-200"
          >
            {t('cancel')}
          </button>
          <button
            onClick={() => {
              onRegisterProduct(barcode);
              onClose();
            }}
            className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-100 flex items-center justify-center gap-1"
          >
            <PlusCircle className="w-4 h-4" /> {t('registerNowBtn')}
          </button>
        </div>
      </div>
    </div>
  );
};
