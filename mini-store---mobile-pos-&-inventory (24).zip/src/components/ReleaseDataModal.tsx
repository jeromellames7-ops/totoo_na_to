import React, { useState } from 'react';
import {
  Smartphone,
  Monitor,
  Send,
  CheckCircle2,
  RefreshCw,
  X,
  ShoppingBag,
  Printer,
  Home,
  FileText,
  Zap,
  ArrowRight,
  ArrowLeftRight,
} from 'lucide-react';
import {
  triggerReleaseData,
  ReleaseSummary,
  getDeviceTypeDescription,
  isCurrentDeviceMobile,
} from '../utils/desktopReleaseSync';
import { getEffectiveAccountId } from '../utils/storage';
import { playSuccessChime } from '../utils/sound';

interface ReleaseDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  accountId?: string;
  defaultTarget?: 'desktop' | 'mobile';
}

export const ReleaseDataModal: React.FC<ReleaseDataModalProps> = ({
  isOpen,
  onClose,
  accountId,
  defaultTarget,
}) => {
  const isMobile = isCurrentDeviceMobile();
  const initialTarget: 'desktop' | 'mobile' = defaultTarget || (isMobile ? 'desktop' : 'mobile');

  const [targetDevice, setTargetDevice] = useState<'desktop' | 'mobile'>(initialTarget);
  const [isReleasing, setIsReleasing] = useState(false);
  const [stepStatus, setStepStatus] = useState<string>('');
  const [releasedSummary, setReleasedSummary] = useState<ReleaseSummary | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentAccountId = accountId || getEffectiveAccountId();
  const deviceType = getDeviceTypeDescription();

  const handleRelease = async (overrideTarget?: 'desktop' | 'mobile') => {
    const target = overrideTarget || targetDevice;
    setIsReleasing(true);
    setErrorMessage(null);
    setStepStatus(
      target === 'mobile'
        ? 'Kinokolekta ang data mula sa desktop computer...'
        : 'Kinokolekta ang data mula sa mobile phone...'
    );

    try {
      setStepStatus('Nagpapadala ng POS, Print Studio, AI Tables at Home Bills sa Cloud DB...');
      const result = await triggerReleaseData(target, currentAccountId);

      if (result.success) {
        setStepStatus(
          target === 'mobile'
            ? 'Ipinapadala ang instant Mobile Device Sync signal...'
            : 'Ipinapadala ang instant Desktop Computer Sync signal...'
        );
        setReleasedSummary(result.summary);
        playSuccessChime();
      } else {
        setErrorMessage(result.error || 'Nagka-problema sa pag-release ng data.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error releasing data.');
    } finally {
      setIsReleasing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border-2 border-indigo-500/40 rounded-3xl shadow-2xl text-white overflow-hidden flex flex-col max-h-[92vh]">
        {/* Glow Header */}
        <div className="relative px-5 py-4 bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-950 border-b border-indigo-500/30 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-500 to-cyan-400 p-0.5 shadow-lg shadow-indigo-500/30 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <Send className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight text-white flex items-center gap-1.5">
                <span>Release Data Synchronizer</span>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Cross-Device Beam
                </span>
              </h2>
              <p className="text-[11px] text-slate-300">
                {targetDevice === 'mobile'
                  ? 'Ipadala ang data mula sa Computer patungo sa Mobile Phone'
                  : 'Ipadala ang data mula sa Mobile Phone patungo sa Desktop Computer'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Target Direction Selector Tabs */}
          <div className="p-1 rounded-2xl bg-slate-950/80 border border-slate-800 grid grid-cols-2 gap-1">
            <button
              type="button"
              onClick={() => {
                setTargetDevice('mobile');
                setReleasedSummary(null);
              }}
              className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                targetDevice === 'mobile'
                  ? 'bg-gradient-to-r from-cyan-600 to-teal-500 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>For Mobile Device</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setTargetDevice('desktop');
                setReleasedSummary(null);
              }}
              className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                targetDevice === 'desktop'
                  ? 'bg-gradient-to-r from-indigo-600 to-cyan-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Monitor className="w-4 h-4" />
              <span>For Desktop Computer</span>
            </button>
          </div>

          {/* Animated Device Transfer Illustration */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-950/70 via-slate-950 to-indigo-950/70 border border-indigo-500/30 flex items-center justify-between">
            {targetDevice === 'mobile' ? (
              <>
                {/* SOURCE: DESKTOP */}
                <div className="flex flex-col items-center text-center gap-1">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-300">
                    <Monitor className="w-6 h-6 animate-pulse" />
                  </div>
                  <span className="text-[11px] font-bold text-slate-200">Desktop Computer</span>
                  <span className="text-[9px] text-slate-400 max-w-[90px] truncate">{deviceType}</span>
                </div>

                {/* TRANSFER ARROW */}
                <div className="flex-1 flex flex-col items-center px-3">
                  <div className="flex items-center gap-1 text-cyan-300 text-xs font-mono font-bold animate-pulse">
                    <span>Release to Mobile</span>
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                  <div className="w-full h-1 bg-gradient-to-r from-indigo-500 via-cyan-400 to-emerald-400 rounded-full my-1.5 relative overflow-hidden">
                    <div className="absolute inset-0 bg-white/60 animate-[shimmer_1.5s_infinite]" />
                  </div>
                  <span className="text-[10px] text-slate-400 text-center">Cloud Realtime Bus</span>
                </div>

                {/* TARGET: MOBILE */}
                <div className="flex flex-col items-center text-center gap-1">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-600/30 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                    <Smartphone className="w-6 h-6" />
                  </div>
                  <span className="text-[11px] font-bold text-slate-200">Mobile Phone</span>
                  <span className="text-[9px] text-emerald-400 font-bold">Auto-Loads Data</span>
                </div>
              </>
            ) : (
              <>
                {/* SOURCE: MOBILE */}
                <div className="flex flex-col items-center text-center gap-1">
                  <div className="w-12 h-12 rounded-2xl bg-cyan-600/30 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
                    <Smartphone className="w-6 h-6 animate-pulse" />
                  </div>
                  <span className="text-[11px] font-bold text-slate-200">Mobile Phone</span>
                  <span className="text-[9px] text-slate-400 max-w-[90px] truncate">{deviceType}</span>
                </div>

                {/* TRANSFER ARROW */}
                <div className="flex-1 flex flex-col items-center px-3">
                  <div className="flex items-center gap-1 text-indigo-300 text-xs font-mono font-bold animate-pulse">
                    <span>Release to Desktop</span>
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                  </div>
                  <div className="w-full h-1 bg-gradient-to-r from-cyan-500 via-indigo-400 to-emerald-400 rounded-full my-1.5 relative overflow-hidden">
                    <div className="absolute inset-0 bg-white/60 animate-[shimmer_1.5s_infinite]" />
                  </div>
                  <span className="text-[10px] text-slate-400 text-center">Cloud Realtime Bus</span>
                </div>

                {/* TARGET: DESKTOP */}
                <div className="flex flex-col items-center text-center gap-1">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-600/30 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                    <Monitor className="w-6 h-6" />
                  </div>
                  <span className="text-[11px] font-bold text-slate-200">Desktop Computer</span>
                  <span className="text-[9px] text-emerald-400 font-bold">Auto-Loads Data</span>
                </div>
              </>
            )}
          </div>

          {/* Success Box */}
          {releasedSummary && (
            <div className="p-4 rounded-2xl bg-emerald-950/60 border-2 border-emerald-500/60 animate-in zoom-in-95 duration-200 space-y-3">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-black text-emerald-200">
                    {targetDevice === 'mobile'
                      ? 'Matagumpay na Na-release ang Data sa Mobile Device!'
                      : 'Matagumpay na Na-release ang Data sa Desktop Computer!'}
                  </h4>
                  <p className="text-xs text-emerald-300/90 leading-relaxed mt-0.5">
                    Awtomatiko nang na-detect ng system ang iyong sign. Ang target na device ay maglo-load at mag-a-update ng mga sumusunod na datos:
                  </p>
                </div>
              </div>

              {/* Summary Badges Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-center">
                <div className="p-2 rounded-xl bg-slate-900/80 border border-emerald-500/30">
                  <ShoppingBag className="w-4 h-4 text-indigo-400 mx-auto mb-1" />
                  <span className="text-xs font-black text-white">{releasedSummary.productsCount}</span>
                  <p className="text-[9px] text-slate-400">POS Products</p>
                </div>
                <div className="p-2 rounded-xl bg-slate-900/80 border border-emerald-500/30">
                  <FileText className="w-4 h-4 text-amber-400 mx-auto mb-1" />
                  <span className="text-xs font-black text-white">{releasedSummary.extractedDocsCount}</span>
                  <p className="text-[9px] text-slate-400">AI Doc Tables</p>
                </div>
                <div className="p-2 rounded-xl bg-slate-900/80 border border-emerald-500/30">
                  <Printer className="w-4 h-4 text-cyan-400 mx-auto mb-1" />
                  <span className="text-xs font-black text-white">{releasedSummary.printProjectsCount}</span>
                  <p className="text-[9px] text-slate-400">Print Jobs</p>
                </div>
                <div className="p-2 rounded-xl bg-slate-900/80 border border-emerald-500/30">
                  <Home className="w-4 h-4 text-emerald-400 mx-auto mb-1" />
                  <span className="text-xs font-black text-white">{releasedSummary.billsCount}</span>
                  <p className="text-[9px] text-slate-400">Home Bills</p>
                </div>
              </div>
            </div>
          )}

          {/* Explanation Notes */}
          {!releasedSummary && (
            <div className="space-y-2.5">
              <p className="text-xs text-slate-300 leading-relaxed">
                {targetDevice === 'mobile' ? (
                  <span>
                    Kapag pinindot mo ang <strong>"I-Release ang Data sa Mobile Device"</strong>, ang lahat ng binago o binuksan mong table sheets, products, print drafts, at household bills sa Computer ay agad na magre-reflect sa iyong Mobile Phone.
                  </span>
                ) : (
                  <span>
                    Kapag pinindot mo ang <strong>"I-Release ang Data sa Desktop Computer"</strong>, ang lahat ng binago o binuksan mong data sa Mobile Phone ay agad na magre-reflect sa iyong Computer screen.
                  </span>
                )}
              </p>

              <div className="space-y-1.5 text-[11px] text-slate-300 bg-slate-950/60 p-3 rounded-2xl border border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                  <span><strong>AI Form Extractor:</strong> Pinakabagong na-scan na tables, cell edits, at PDS photos.</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                  <span><strong>Mini Store POS:</strong> Lahat ng bagong items, sales transaction history, at utang records.</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                  <span><strong>Print Studio:</strong> Layout drafts, resize coordinates, at sales logs.</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  <span><strong>Home Monitoring:</strong> Kuryente, Tubig, Gasul LPG countdown, at Menstrual logs.</span>
                </div>
              </div>
            </div>
          )}

          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500 text-rose-200 text-xs">
              {errorMessage}
            </div>
          )}

          {/* In Progress Status Banner */}
          {isReleasing && (
            <div className="p-3 rounded-xl bg-indigo-950/80 border border-indigo-500/40 flex items-center gap-3 text-cyan-300 text-xs">
              <RefreshCw className="w-4 h-4 animate-spin shrink-0 text-cyan-400" />
              <span>{stepStatus}</span>
            </div>
          )}
        </div>

        {/* Footer Action Button */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-end gap-2.5">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
          >
            {releasedSummary ? 'Tapusin' : 'Kanselahin'}
          </button>

          <button
            onClick={() => handleRelease()}
            disabled={isReleasing}
            className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 px-6 py-2.5 rounded-2xl font-black text-xs shadow-lg transition-all active:scale-95 disabled:opacity-50 cursor-pointer text-white ${
              targetDevice === 'mobile'
                ? 'bg-gradient-to-r from-cyan-600 via-teal-600 to-emerald-500 hover:from-cyan-500 hover:to-emerald-400 shadow-teal-600/30'
                : 'bg-gradient-to-r from-indigo-600 via-cyan-600 to-teal-500 hover:from-indigo-500 hover:to-teal-400 shadow-indigo-600/30'
            }`}
          >
            {isReleasing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>NAG-RE-RELEASE...</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>
                  {releasedSummary
                    ? 'I-RELEASE ULI ANG DATA'
                    : targetDevice === 'mobile'
                    ? 'I-RELEASE ANG DATA SA MOBILE DEVICE'
                    : 'I-RELEASE ANG DATA SA DESKTOP'}
                </span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
