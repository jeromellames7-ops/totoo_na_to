import React, { useEffect, useState } from 'react';
import { PrintSaleTransaction, loadPrintSalesFromFirestore, getLocalPrintSales, saveLocalPrintSales } from '../utils/printSalesStorage';
import { Printer, Calendar, DollarSign, TrendingUp, Search, X, Trash2, Shield, Clock, Database, Code, CheckCircle2, AlertTriangle, Save } from 'lucide-react';

interface BusinessHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang?: 'tl' | 'en';
}

export const BusinessHistoryModal: React.FC<BusinessHistoryModalProps> = ({
  isOpen,
  onClose,
  lang = 'tl',
}) => {
  const [sales, setSales] = useState<PrintSaleTransaction[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPeriod, setFilterPeriod] = useState<'all' | 'today' | 'week' | 'month'>('all');

  // Database Editor State
  const [viewMode, setViewMode] = useState<'list' | 'database'>('list');
  const [rawJsonText, setRawJsonText] = useState('');
  const [jsonError, setJsonError] = useState('');
  const [saveSuccess, setSaveSuccess] = useState('');

  useEffect(() => {
    if (isOpen) {
      loadSales();
    }
  }, [isOpen]);

  const loadSales = async () => {
    setLoading(true);
    try {
      const data = await loadPrintSalesFromFirestore();
      // Auto-purge items older than 3 months (90 days)
      const threeMonthsAgo = Date.now() - 90 * 24 * 60 * 60 * 1000;
      const filtered = data.filter((item) => new Date(item.timestamp).getTime() > threeMonthsAgo);
      setSales(filtered);
    } catch (e) {
      console.error('Error loading print business history:', e);
      setSales(getLocalPrintSales());
    } finally {
      setLoading(false);
    }
  };

  const handleClearAllSales = () => {
    if (confirm(lang === 'tl' ? 'Sigurado ka bang gusto mong burahin ang lahat ng print history at sales data?' : 'Are you sure you want to clear all print history and sales data?')) {
      saveLocalPrintSales([]);
      setSales([]);
      setRawJsonText('[]');
    }
  };

  const handleFormatAll = () => {
    if (confirm(lang === 'tl' ? '⚠️ FORMAT ALL: Sigurado ka bang gusto mong i-format at burahin ang LAHAT ng print audio/sales database records? Hindi na ito maibabalik.' : '⚠️ FORMAT ALL: Are you sure you want to format and wipe ALL print audio/sales database records? This cannot be undone.')) {
      saveLocalPrintSales([]);
      setSales([]);
      setRawJsonText('[]');
      alert(lang === 'tl' ? 'Na-format at nabura na ang buong print database!' : 'Print database successfully formatted and wiped!');
    }
  };

  const handleOpenDatabaseEditor = () => {
    setRawJsonText(JSON.stringify(sales, null, 2));
    setJsonError('');
    setSaveSuccess('');
    setViewMode('database');
  };

  const handleSaveRawDatabase = () => {
    try {
      setJsonError('');
      const parsed = JSON.parse(rawJsonText);
      if (!Array.isArray(parsed)) {
        throw new Error(lang === 'tl' ? 'Dapat ay isang JSON Array of transactions ang database.' : 'Database JSON must be an array of transactions.');
      }
      saveLocalPrintSales(parsed);
      setSales(parsed);
      setSaveSuccess(lang === 'tl' ? 'Matagumpay na nai-save ang database!' : 'Database saved successfully!');
      setTimeout(() => setSaveSuccess(''), 3000);
    } catch (e: any) {
      setJsonError(e.message || 'Invalid JSON format');
    }
  };

  if (!isOpen) return null;

  // Filter sales based on period and search
  const now = new Date();
  const todayStr = now.toDateString();

  const getWeekStart = (d: Date) => {
    const date = new Date(d);
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1); // Monday start
    return new Date(date.setDate(diff)).setHours(0, 0, 0, 0);
  };
  const weekStart = getWeekStart(now);

  const filteredSales = sales.filter((item) => {
    const itemDate = new Date(item.timestamp);
    
    // Period check
    if (filterPeriod === 'today') {
      if (itemDate.toDateString() !== todayStr) return false;
    } else if (filterPeriod === 'week') {
      if (itemDate.getTime() < weekStart) return false;
    } else if (filterPeriod === 'month') {
      if (itemDate.getMonth() !== now.getMonth() || itemDate.getFullYear() !== now.getFullYear()) return false;
    }

    // Search query
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      const matchId = item.id.toLowerCase().includes(term);
      const matchSize = item.paperSize.toLowerCase().includes(term);
      const matchMode = item.colorMode.toLowerCase().includes(term);
      if (!matchId && !matchSize && !matchMode) return false;
    }

    return true;
  });

  // Calculate earnings summaries
  const todaySales = sales
    .filter((s) => new Date(s.timestamp).toDateString() === todayStr)
    .reduce((sum, s) => sum + (s.totalAmount || 0), 0);

  const weekSales = sales
    .filter((s) => new Date(s.timestamp).getTime() >= weekStart)
    .reduce((sum, s) => sum + (s.totalAmount || 0), 0);

  const monthSales = sales
    .filter((s) => {
      const d = new Date(s.timestamp);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    })
    .reduce((sum, s) => sum + (s.totalAmount || 0), 0);

  const todayProfit = sales
    .filter((s) => new Date(s.timestamp).toDateString() === todayStr)
    .reduce((sum, s) => sum + (s.profitAmount || 0), 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-cyan-500/40 w-full max-w-5xl rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-white">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-white flex items-center gap-2">
                <span>{lang === 'tl' ? 'Print Database & Sales History' : 'Print Database & Sales History'}</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  {sales.length} {lang === 'tl' ? 'Rekord' : 'Records'}
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {lang === 'tl'
                  ? 'Tingnan ang transaksyon at i-edit ang raw database.'
                  : 'View transactions and edit raw database.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* View Mode Toggle Buttons */}
            <div className="flex bg-slate-900 border border-slate-700 rounded-xl p-1">
              <button
                onClick={() => setViewMode('list')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                  viewMode === 'list' ? 'bg-cyan-500 text-slate-950 shadow' : 'text-slate-300 hover:text-white'
                }`}
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{lang === 'tl' ? 'Talaan' : 'List'}</span>
              </button>
              <button
                onClick={handleOpenDatabaseEditor}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                  viewMode === 'database' ? 'bg-cyan-500 text-slate-950 shadow' : 'text-slate-300 hover:text-white'
                }`}
                title="Tingnan at i-edit ang Raw Database ng Print"
              >
                <Code className="w-3.5 h-3.5" />
                <span>{lang === 'tl' ? 'Raw DB (Edit)' : 'Raw DB'}</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

         {/* View Mode Content Switcher */}
         {viewMode === 'database' ? (
           <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
             <div className="flex flex-wrap items-center justify-between gap-3">
               <div>
                 <h3 className="text-sm font-extrabold text-cyan-400 flex items-center gap-1.5">
                   <Database className="w-4 h-4" />
                   <span>{lang === 'tl' ? 'Raw Database Editor (JSON)' : 'Raw Database JSON Editor'}</span>
                 </h3>
                 <p className="text-xs text-slate-400">
                   {lang === 'tl'
                     ? 'Dito mo makikita at tuwirang ma-e-edit ang mga rekord ng database sa format na JSON.'
                     : 'Inspect and directly edit the raw print database records in JSON format.'}
                 </p>
               </div>
               <button
                 type="button"
                 onClick={handleFormatAll}
                 className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md shadow-rose-900/40 flex items-center gap-1.5 transition-all active:scale-95"
                 title="Format All Database Records"
               >
                 <Trash2 className="w-3.5 h-3.5" />
                 <span>{lang === 'tl' ? 'FORMAT ALL (Burahin Lahat)' : 'FORMAT ALL'}</span>
               </button>
             </div>

             {saveSuccess && (
               <div className="bg-emerald-500/20 border border-emerald-500/40 rounded-2xl p-3 text-emerald-300 text-xs font-bold flex items-center gap-2">
                 <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                 <span>{saveSuccess}</span>
               </div>
             )}

             {jsonError && (
               <div className="bg-rose-500/20 border border-rose-500/40 rounded-2xl p-3 text-rose-300 text-xs font-bold flex items-center gap-2">
                 <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                 <span>{jsonError}</span>
               </div>
             )}

             <div className="relative">
               <textarea
                 value={rawJsonText}
                 onChange={(e) => setRawJsonText(e.target.value)}
                 rows={16}
                 className="w-full bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-2xl p-4 font-mono text-xs text-cyan-300 leading-relaxed focus:outline-none shadow-inner"
                 placeholder="[...]"
               />
             </div>

             <div className="flex justify-end gap-2">
               <button
                 type="button"
                 onClick={handleSaveRawDatabase}
                 className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold text-xs shadow-lg flex items-center gap-2 transition-all active:scale-95"
               >
                 <Save className="w-4 h-4" />
                 <span>{lang === 'tl' ? 'I-save ang Binagong Database' : 'Save Database Changes'}</span>
               </button>
             </div>
           </div>
         ) : (
           <>
             {/* Earnings Summary Cards Grid */}
             <div className="p-4 sm:p-6 grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-950/30 border-b border-slate-800">
               {/* Today */}
               <div className="bg-slate-900/90 border border-cyan-500/30 rounded-2xl p-4 shadow-md flex items-center justify-between">
                 <div>
                   <p className="text-xs font-semibold text-cyan-400 uppercase tracking-wide">
                     {lang === 'tl' ? 'Kita Ngayong Araw (Today)' : "Today's Earnings"}
                   </p>
                   <h3 className="text-2xl font-extrabold text-white mt-1">₱{todaySales.toFixed(2)}</h3>
                   <p className="text-[11px] text-emerald-400 mt-0.5 flex items-center gap-1">
                     <TrendingUp className="w-3 h-3" /> Tubo: ₱{todayProfit.toFixed(2)}
                   </p>
                 </div>
                 <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                   <DollarSign className="w-6 h-6" />
                 </div>
               </div>

               {/* This Week */}
               <div className="bg-slate-900/90 border border-indigo-500/30 rounded-2xl p-4 shadow-md flex items-center justify-between">
                 <div>
                   <p className="text-xs font-semibold text-indigo-400 uppercase tracking-wide">
                     {lang === 'tl' ? 'Kita Kada Linggo (This Week)' : 'Weekly Earnings'}
                   </p>
                   <h3 className="text-2xl font-extrabold text-white mt-1">₱{weekSales.toFixed(2)}</h3>
                   <p className="text-[11px] text-slate-400 mt-0.5">
                     {lang === 'tl' ? 'Mula Lunes hanggang ngayon' : 'Current week total'}
                   </p>
                 </div>
                 <div className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                   <Calendar className="w-6 h-6" />
                 </div>
               </div>

               {/* This Month */}
               <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-4 shadow-md flex items-center justify-between">
                 <div>
                   <p className="text-xs font-semibold text-emerald-400 uppercase tracking-wide">
                     {lang === 'tl' ? 'Kita Buong Buwan (This Month)' : 'Monthly Earnings'}
                   </p>
                   <h3 className="text-2xl font-extrabold text-white mt-1">₱{monthSales.toFixed(2)}</h3>
                   <p className="text-[11px] text-slate-400 mt-0.5">
                     {lang === 'tl' ? 'Kabuuan ngayong buwan' : 'Current month total'}
                   </p>
                 </div>
                 <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                   <TrendingUp className="w-6 h-6" />
                 </div>
               </div>
             </div>

             {/* Filters and Search Bar */}
             <div className="px-6 py-3 bg-slate-950/50 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
               <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700 rounded-xl p-1">
                 <button
                   onClick={() => setFilterPeriod('all')}
                   className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                     filterPeriod === 'all' ? 'bg-cyan-500 text-slate-950 shadow' : 'text-slate-300 hover:text-white'
                   }`}
                 >
                   {lang === 'tl' ? 'Lahat (All)' : 'All'}
                 </button>
                 <button
                   onClick={() => setFilterPeriod('today')}
                   className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                     filterPeriod === 'today' ? 'bg-cyan-500 text-slate-950 shadow' : 'text-slate-300 hover:text-white'
                   }`}
                 >
                   {lang === 'tl' ? 'Ngayon' : 'Today'}
                 </button>
                 <button
                   onClick={() => setFilterPeriod('week')}
                   className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                     filterPeriod === 'week' ? 'bg-cyan-500 text-slate-950 shadow' : 'text-slate-300 hover:text-white'
                   }`}
                 >
                   {lang === 'tl' ? 'Linggo' : 'Week'}
                 </button>
                 <button
                   onClick={() => setFilterPeriod('month')}
                   className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                     filterPeriod === 'month' ? 'bg-cyan-500 text-slate-950 shadow' : 'text-slate-300 hover:text-white'
                   }`}
                 >
                   {lang === 'tl' ? 'Buwan' : 'Month'}
                 </button>
               </div>

               <div className="relative w-full sm:w-64">
                 <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                 <input
                   type="text"
                   value={searchTerm}
                   onChange={(e) => setSearchTerm(e.target.value)}
                   placeholder={lang === 'tl' ? 'Maghanap sa history...' : 'Search history...'}
                   className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                 />
               </div>
             </div>

             {/* Transactions List Table */}
             <div className="flex-1 overflow-y-auto p-4 sm:p-6">
               {loading ? (
                 <div className="text-center py-12 text-slate-400 text-sm">
                   {lang === 'tl' ? 'Naglo-load ng print history...' : 'Loading print history...'}
                 </div>
               ) : filteredSales.length === 0 ? (
                 <div className="text-center py-16 text-slate-500">
                   <Printer className="w-12 h-12 mx-auto mb-3 opacity-30 text-cyan-400" />
                   <p className="text-sm font-bold text-slate-400">
                     {lang === 'tl' ? 'Walang natagpuang print transaction' : 'No print transactions found'}
                   </p>
                   <p className="text-xs text-slate-500 mt-1">
                     {lang === 'tl'
                       ? 'Ang mga bagong print job sa Print Studio ay awtomatikong mave-save dito.'
                       : 'New print jobs in Print Studio will be saved here automatically.'}
                   </p>
                 </div>
               ) : (
                 <div className="space-y-3">
                   {filteredSales.map((item) => (
                     <div
                       key={item.id}
                       className="bg-slate-950/60 border border-slate-800 hover:border-cyan-500/40 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4 transition-all"
                     >
                       <div className="flex items-center gap-3">
                         <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
                           <Printer className="w-5 h-5" />
                         </div>
                         <div>
                           <div className="flex items-center gap-2">
                             <span className="text-xs font-extrabold text-white">
                               {item.paperSize.toUpperCase()} • {item.colorMode === 'colored' ? 'Colored' : 'B & W'}
                             </span>
                             <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                               {item.copies} {lang === 'tl' ? 'kopya' : 'copies'} ({item.pages} {lang === 'tl' ? 'pahina' : 'pages'})
                             </span>
                           </div>
                           <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
                             <Clock className="w-3 h-3 text-slate-500" />
                             {new Date(item.timestamp).toLocaleString()}
                           </p>
                         </div>
                       </div>

                       <div className="flex items-center gap-4">
                         <div className="text-right">
                           <p className="text-sm font-extrabold text-cyan-400">₱{item.totalAmount.toFixed(2)}</p>
                           <p className="text-[11px] text-emerald-400">
                             {lang === 'tl' ? 'Tubo' : 'Profit'}: ₱{item.profitAmount.toFixed(2)}
                           </p>
                         </div>
                       </div>
                     </div>
                   ))}
                 </div>
               )}
             </div>
           </>
         )}

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-950/80 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleClearAllSales}
              className="px-3 py-1.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40 font-bold flex items-center gap-1.5 transition-all active:scale-95"
              title="Burahin ang lahat ng nakaimbak na sales history"
            >
              <Trash2 className="w-3.5 h-3.5 text-red-400" />
              <span>{lang === 'tl' ? 'Burahin ang Lahat ng History' : 'Clear All History'}</span>
            </button>
            <div className="hidden sm:flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-cyan-400" />
              <span>
                {lang === 'tl'
                  ? 'Auto-delete pagkalipas ng 3 buwan.'
                  : 'Auto-purged after 3 months.'}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl transition-all"
          >
            {lang === 'tl' ? 'Isara' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
