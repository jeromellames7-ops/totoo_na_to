import React, { useState, useEffect } from 'react';
import { Sale, Product, UserAccount } from '../types';
import { getProducts, getAccounts } from '../utils/storage';
import { Database, Search, Receipt, Package, Users, ArrowUpDown, Filter, Download, ChevronLeft, ChevronRight, FileText } from 'lucide-react';

interface AdminDatabaseTableProps {
  sales: Sale[];
}

type DbTab = 'sales' | 'products' | 'accounts';

export const AdminDatabaseTable: React.FC<AdminDatabaseTableProps> = ({ sales }) => {
  const [activeTab, setActiveTab] = useState<DbTab>('sales');
  const [searchQuery, setSearchQuery] = useState('');
  const [paymentFilter, setPaymentFilter] = useState<string>('All');

  // Pagination state (50 items per sheet)
  const ITEMS_PER_PAGE = 50;
  const [currentPage, setCurrentPage] = useState<number>(1);

  useEffect(() => {
    setCurrentPage(1);
  }, [activeTab, searchQuery, paymentFilter]);

  const products: Product[] = getProducts();
  const accounts: UserAccount[] = getAccounts();

  // Filtered Sales Data
  const filteredSales = (sales || []).filter((sale) => {
    if (!sale) return false;
    const matchesPayment = paymentFilter === 'All' || sale.paymentMethod === paymentFilter;
    const matchesSearch =
      (sale.receiptNo || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (sale.cashierName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (Array.isArray(sale.items) &&
        sale.items.some((item) =>
          (item?.product?.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
          (item?.product?.barcode || '').toLowerCase().includes(searchQuery.toLowerCase())
        ));
    return matchesPayment && matchesSearch;
  });

  // Filtered Products Data
  const filteredProducts = (products || []).filter((prod) =>
    (prod?.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (prod?.barcode || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (prod?.category || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Filtered Accounts Data
  const filteredAccounts = (accounts || []).filter((acc) =>
    (acc?.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (acc?.role || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (acc?.phone && acc.phone.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const totalItems =
    activeTab === 'sales'
      ? filteredSales.length
      : activeTab === 'products'
      ? filteredProducts.length
      : filteredAccounts.length;
  const totalPages = Math.max(1, Math.ceil(totalItems / ITEMS_PER_PAGE));
  const safeCurrentPage = Math.min(currentPage, totalPages);
  const startIndex = (safeCurrentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

  const displayedSales = filteredSales.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  const displayedProducts = filteredProducts.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  const displayedAccounts = filteredAccounts.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  // Export Table Data to CSV
  const handleExportDb = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';

    if (activeTab === 'sales') {
      csvContent += 'Receipt No,Date,Cashier,Payment Method,Items,Total Amount,Profit\n';
      filteredSales.forEach((s) => {
        const itemsStr = (s.items || [])
          .map((i) => `${i?.product?.name || 'Item'} (x${i?.quantity || 1})`)
          .join('; ');
        csvContent += `"${s.receiptNo || ''}","${new Date(s.timestamp || Date.now()).toLocaleString()}","${s.cashierName || ''}","${s.paymentMethod || 'Cash'}","${itemsStr}",${s.totalAmount || 0},${s.profit || 0}\n`;
      });
    } else if (activeTab === 'products') {
      csvContent += 'Barcode,Name,Category,Cost Price,Price,Profit Margin,Stock\n';
      filteredProducts.forEach((p) => {
        const cost = p.costPrice || 0;
        const price = p.price || 0;
        const profitMargin = price > 0 ? (((price - cost) / price) * 100).toFixed(1) : '0.0';
        csvContent += `"${p.barcode || ''}","${p.name || ''}","${p.category || ''}",${cost},${price},${profitMargin}%,${p.stock || 0}\n`;
      });
    } else {
      csvContent += 'ID,Name,Role,Phone,Info,Status\n';
      filteredAccounts.forEach((a) => {
        csvContent += `"${a.id}","${a.name}","${a.role}","${a.phone || ''}","${a.info || ''}","${a.isLoggedIn ? 'Active' : 'Offline'}"\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `AdminDB_${activeTab}_export_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white border border-slate-200/80 rounded-3xl p-4 sm:p-5 shadow-xs space-y-4 max-w-full overflow-visible">
      {/* DB Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2.5 bg-indigo-50 border border-indigo-100 rounded-2xl text-indigo-600 shrink-0">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-extrabold text-slate-900 tracking-tight">
              Admin Database & Collected Data Table
            </h3>
            <p className="text-[11px] text-slate-500 font-medium">
              Talaan ng lahat ng naitagong transaksyon, kagamitan, at rekord ng tindahan
            </p>
          </div>
        </div>

        {/* Tab Controls & Export Button */}
        <div className="flex items-center justify-between sm:justify-end gap-2 shrink-0">
          <button
            onClick={handleExportDb}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 flex items-center gap-1.5 transition-colors shadow-xs shrink-0"
            title="Download DB Records CSV"
          >
            <Download className="w-3.5 h-3.5 text-indigo-600" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Tabs and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center justify-between">
        {/* Category Tabs */}
        <div className="flex bg-slate-100/80 p-1 rounded-2xl border border-slate-200/80 gap-1 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('sales')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap shrink-0 ${
              activeTab === 'sales'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Receipt className="w-3.5 h-3.5" />
            <span>Sales DB ({sales.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap shrink-0 ${
              activeTab === 'products'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Products DB ({products.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('accounts')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap shrink-0 ${
              activeTab === 'accounts'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Accounts DB ({accounts.length})</span>
          </button>
        </div>

        {/* Search & Filters */}
        <div className="flex items-center gap-2">
          {activeTab === 'sales' && (
            <div className="relative shrink-0">
              <select
                value={paymentFilter}
                onChange={(e) => setPaymentFilter(e.target.value)}
                className="pl-2 pr-6 py-1.5 text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl text-slate-700 appearance-none focus:outline-none cursor-pointer"
              >
                <option value="All">All Payments</option>
                <option value="Cash">Cash</option>
                <option value="GCash">GCash</option>
                <option value="Maya">Maya</option>
              </select>
              <Filter className="w-3 h-3 text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          )}

          <div className="relative flex-1 sm:w-60">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Hanapin sa database..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>
        </div>
      </div>

      {/* Database Table Container */}
      <div className="border border-slate-200/90 rounded-2xl overflow-x-auto max-w-full bg-white shadow-2xs">
        {activeTab === 'sales' && (
          <table className="w-full text-left border-collapse text-xs min-w-[650px]">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200/80">
                <th className="p-3">Receipt #</th>
                <th className="p-3">Petsa & Oras</th>
                <th className="p-3">Cashier</th>
                <th className="p-3">Mga Produkto</th>
                <th className="p-3 text-center">Bayad</th>
                <th className="p-3 text-right">Puhunan</th>
                <th className="p-3 text-right">Kita (Profit)</th>
                <th className="p-3 text-right font-black text-slate-900">Total Benta</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredSales.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400 font-medium">
                    Walang nahanap na sales record sa database.
                  </td>
                </tr>
              ) : (
                displayedSales.map((s) => {
                  const total = s.totalAmount || 0;
                  const profit = s.profit || 0;
                  const costTotal = total - profit;
                  const itemsList = Array.isArray(s.items) ? s.items : [];
                  const timeDate = s.timestamp ? new Date(s.timestamp) : new Date();
                  return (
                    <tr key={s.id || Math.random().toString()} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-mono font-bold text-indigo-700">{s.receiptNo || 'N/A'}</td>
                      <td className="p-3 text-slate-600 whitespace-nowrap">
                        {timeDate.toLocaleDateString([], {
                          month: 'short',
                          day: 'numeric',
                        })}{' '}
                        {timeDate.toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="p-3 font-medium text-slate-800">{s.cashierName || 'Cashier'}</td>
                      <td className="p-3 text-slate-600 max-w-[200px]">
                        <p className="truncate font-semibold text-slate-800">
                          {itemsList.map((i) => i?.product?.name || 'Item').join(', ')}
                        </p>
                        <p className="text-[10px] text-slate-400">
                          {itemsList.reduce((sum, i) => sum + (i?.quantity || 0), 0)} pcs total
                        </p>
                      </td>
                      <td className="p-3 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                            s.paymentMethod === 'Cash'
                              ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                              : s.paymentMethod === 'GCash'
                              ? 'bg-cyan-50 text-cyan-700 border border-cyan-200'
                              : 'bg-pink-50 text-pink-700 border border-pink-200'
                          }`}
                        >
                          {s.paymentMethod || 'Cash'}
                        </span>
                      </td>
                      <td className="p-3 text-right text-slate-500 font-mono">
                        ₱{costTotal.toFixed(2)}
                      </td>
                      <td className="p-3 text-right font-mono font-extrabold text-emerald-600">
                        +₱{profit.toFixed(2)}
                      </td>
                      <td className="p-3 text-right font-mono font-black text-indigo-600">
                        ₱{total.toFixed(2)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        )}

        {activeTab === 'products' && (
          <table className="w-full text-left border-collapse text-xs min-w-[650px]">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200/80">
                <th className="p-3">Barcode</th>
                <th className="p-3">Item Details</th>
                <th className="p-3">Kategorya</th>
                <th className="p-3 text-right">Puhunan</th>
                <th className="p-3 text-right">Presyo (Benta)</th>
                <th className="p-3 text-right">Tubo %</th>
                <th className="p-3 text-center">Stock Level</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400 font-medium">
                    Walang nahanap na produkto sa database.
                  </td>
                </tr>
              ) : (
                displayedProducts.map((p) => {
                  const cost = p.costPrice || 0;
                  const price = p.price || 0;
                  const marginPct = price > 0 ? (((price - cost) / price) * 100).toFixed(1) : '0.0';
                  return (
                    <tr key={p.id || Math.random().toString()} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-mono font-bold text-slate-700">{p.barcode || '-'}</td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <img
                            src={p.imageUrl || undefined}
                            alt={p.name || 'Product'}
                            className="w-8 h-8 rounded-lg object-cover border border-slate-200 shrink-0"
                          />
                          <span className="bg-amber-200/90 text-slate-950 font-black tracking-wide uppercase text-xs px-2.5 py-1 rounded-lg border border-amber-300/80 shadow-2xs line-clamp-1">
                            {p.name || 'Unnamed Product'}
                          </span>
                        </div>
                      </td>
                      <td className="p-3 text-slate-600">
                        <span className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded-md font-semibold text-[11px]">
                          {p.category || 'General'}
                        </span>
                      </td>
                      <td className="p-3 text-right font-mono text-slate-500">
                        ₱{cost.toFixed(2)}
                      </td>
                      <td className="p-3 text-right font-mono font-bold text-indigo-600">
                        ₱{price.toFixed(2)}
                      </td>
                      <td className="p-3 text-right font-mono font-extrabold text-emerald-600">
                        {marginPct}%
                      </td>
                      <td className="p-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                            (p.stock || 0) === 0
                              ? 'bg-rose-100 text-rose-700 border border-rose-200'
                              : (p.stock || 0) <= 5
                              ? 'bg-orange-100 text-orange-700 border border-orange-200'
                              : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                          }`}
                        >
                          {p.stock || 0} pcs
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        )}

        {activeTab === 'accounts' && (
          <table className="w-full text-left border-collapse text-xs min-w-[550px]">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200/80">
                <th className="p-3">User ID</th>
                <th className="p-3">Akaunt & Pangalan</th>
                <th className="p-3">Role</th>
                <th className="p-3">Email / Contact</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAccounts.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-400 font-medium">
                    Walang nahanap na user account.
                  </td>
                </tr>
              ) : (
                displayedAccounts.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3 font-mono text-slate-400 font-semibold">{a.id}</td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <img
                          src={a.avatar || undefined}
                          alt={a.name}
                          className="w-7 h-7 rounded-full object-cover ring-1 ring-slate-200"
                        />
                        <span className="font-bold text-slate-900">{a.name}</span>
                      </div>
                    </td>
                    <td className="p-3">
                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase ${
                          a.role === 'Admin'
                            ? 'bg-amber-100 text-amber-800 border border-amber-200'
                            : 'bg-slate-100 text-slate-700 border border-slate-200'
                        }`}
                      >
                        {a.role}
                      </span>
                    </td>
                    <td className="p-3 text-slate-600 font-medium">
                      {a.phone || a.info || 'Standard Staff Account'}
                    </td>
                    <td className="p-3 text-center">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          a.isLoggedIn
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-slate-100 text-slate-500 border border-slate-200'
                        }`}
                      >
                        {a.isLoggedIn ? 'Active Now' : 'Offline'}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        )}
      </div>

      {/* Sheet Pagination Controls (50 items per sheet) */}
      <div className="bg-slate-50/80 p-3 border border-slate-200/90 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-2xs">
        <div className="flex items-center gap-2 text-xs text-slate-600 font-bold">
          <FileText className="w-4 h-4 text-indigo-600" />
          <span>
            Sheet {safeCurrentPage} ng {totalPages} ({totalItems === 0 ? 0 : startIndex + 1} - {endIndex} sa {totalItems} kabuuang datos)
          </span>
          <span className="bg-indigo-100 text-indigo-800 text-[10px] px-2 py-0.5 rounded-full font-black">
            50 datos / sheet
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
            disabled={safeCurrentPage === 1}
            className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 transition-colors shadow-2xs"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Nakaraang Sheet</span>
          </button>

          {/* Quick Sheet Selector Pills */}
          <div className="flex items-center gap-1 max-w-[180px] overflow-x-auto no-scrollbar py-0.5">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
              <button
                key={pageNum}
                onClick={() => setCurrentPage(pageNum)}
                className={`w-7 h-7 shrink-0 rounded-lg text-xs font-black transition-all ${
                  pageNum === safeCurrentPage
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                {pageNum}
              </button>
            ))}
          </div>

          <button
            onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
            disabled={safeCurrentPage >= totalPages}
            className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 transition-colors shadow-2xs"
          >
            <span>Susunod na Sheet</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
