import React, { useState, useEffect } from 'react';
import { Product, Sale, UserAccount, PaymentMethod } from '../types';
import {
  getAccounts,
  getProducts,
  getSales,
  saveProduct,
  deleteProduct,
  updateSale,
  deleteSale,
  DATA_CHANGE_EVENT,
} from '../utils/storage';
import {
  X,
  Database,
  Search,
  Receipt,
  Package,
  Users,
  Edit,
  Trash2,
  Plus,
  Save,
  Download,
  Filter,
  CheckCircle,
  AlertCircle,
  Layers,
  ChevronLeft,
  ChevronRight,
  FileText,
} from 'lucide-react';
import { FormatDataModal } from './FormatDataModal';

interface AdminDatabaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialAccountId?: string | null;
}

type ModalTab = 'products' | 'sales';

export const AdminDatabaseModal: React.FC<AdminDatabaseModalProps> = ({
  isOpen,
  onClose,
  initialAccountId = null,
}) => {
  const accounts: UserAccount[] = getAccounts();
  const [selectedAccountId, setSelectedAccountId] = useState<string>(
    initialAccountId || accounts[0]?.id || 'user-admin'
  );

  const [activeTab, setActiveTab] = useState<ModalTab>('products');
  const [searchQuery, setSearchQuery] = useState('');
  const [paymentFilter, setPaymentFilter] = useState('All');
  const [successMsg, setSuccessMsg] = useState('');
  const [isFormatModalOpen, setIsFormatModalOpen] = useState(false);

  // Loaded Data for Selected Account
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);

  // Editing state for Product
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [prodForm, setProdForm] = useState({
    name: '',
    barcode: '',
    category: 'Grocery',
    costPrice: 0,
    price: 0,
    stock: 0,
    lowStockThreshold: 5,
  });

  // Editing state for Sale
  const [editingSale, setEditingSale] = useState<Sale | null>(null);
  const [saleForm, setSaleForm] = useState<{
    paymentMethod: PaymentMethod;
    cashierName: string;
    totalAmount: number;
    profit: number;
  }>({
    paymentMethod: 'Cash',
    cashierName: '',
    totalAmount: 0,
    profit: 0,
  });

  // Load account data function
  const loadData = () => {
    const accId = selectedAccountId;
    setProducts(getProducts(accId));
    setSales(getSales(accId));
  };

  useEffect(() => {
    if (initialAccountId) {
      setSelectedAccountId(initialAccountId);
    }
  }, [initialAccountId]);

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
    const handleDataChange = () => {
      if (isOpen) loadData();
    };
    window.addEventListener(DATA_CHANGE_EVENT, handleDataChange);
    return () => window.removeEventListener(DATA_CHANGE_EVENT, handleDataChange);
  }, [isOpen, selectedAccountId]);

  if (!isOpen) return null;

  const currentAccount = accounts.find((a) => a.id === selectedAccountId) || accounts[0];

  const showNotification = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  // Pagination state (50 items per sheet)
  const ITEMS_PER_PAGE = 50;
  const [currentPage, setCurrentPage] = useState<number>(1);

  useEffect(() => {
    setCurrentPage(1);
  }, [activeTab, selectedAccountId, searchQuery, paymentFilter]);

  // Filtered Products
  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.barcode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Filtered Sales
  const filteredSales = sales.filter((s) => {
    const matchesPayment = paymentFilter === 'All' || s.paymentMethod === paymentFilter;
    const matchesSearch =
      s.receiptNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.cashierName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.items.some((i) =>
        i.product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        i.product.barcode.toLowerCase().includes(searchQuery.toLowerCase())
      );
    return matchesPayment && matchesSearch;
  });

  const totalItems = activeTab === 'products' ? filteredProducts.length : filteredSales.length;
  const totalPages = Math.max(1, Math.ceil(totalItems / ITEMS_PER_PAGE));
  const safeCurrentPage = Math.min(currentPage, totalPages);
  const startIndex = (safeCurrentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, totalItems);

  const displayedProducts = filteredProducts.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  const displayedSales = filteredSales.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  // Product Actions
  const handleOpenAddProduct = () => {
    setEditingProduct({
      id: '',
      barcode: '',
      name: '',
      category: 'Grocery',
      costPrice: 0,
      price: 0,
      stock: 10,
      lowStockThreshold: 5,
      imageUrl: '',
      details: '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    setProdForm({
      name: '',
      barcode: Date.now().toString().slice(-6),
      category: 'Grocery',
      costPrice: 10,
      price: 15,
      stock: 10,
      lowStockThreshold: 5,
    });
  };

  const handleOpenEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setProdForm({
      name: prod.name,
      barcode: prod.barcode,
      category: prod.category,
      costPrice: prod.costPrice,
      price: prod.price,
      stock: prod.stock,
      lowStockThreshold: prod.lowStockThreshold || 5,
    });
  };

  const handleSaveProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    saveProduct(
      {
        ...(editingProduct.id ? { id: editingProduct.id } : {}),
        name: prodForm.name.trim() || 'Bagong Produkto',
        barcode: prodForm.barcode.trim(),
        category: prodForm.category.trim() || 'Grocery',
        costPrice: Number(prodForm.costPrice) || 0,
        price: Number(prodForm.price) || 0,
        stock: Number(prodForm.stock) || 0,
        lowStockThreshold: Number(prodForm.lowStockThreshold) || 5,
        imageUrl: editingProduct.imageUrl || '',
        details: editingProduct.details || '',
      },
      selectedAccountId
    );

    showNotification(`Matagumpay na na-save ang produkto sa ${currentAccount.name} Database!`);
    setEditingProduct(null);
    loadData();
  };

  const handleDeleteProductClick = (prod: Product) => {
    if (confirm(`Sigurado ka bang gusto mong burahin ang "${prod.name}" sa database?`)) {
      deleteProduct(prod.id, selectedAccountId);
      showNotification(`Nabura na ang "${prod.name}" sa database.`);
      loadData();
    }
  };

  // Sale Actions
  const handleOpenEditSale = (sale: Sale) => {
    setEditingSale(sale);
    setSaleForm({
      paymentMethod: sale.paymentMethod,
      cashierName: sale.cashierName,
      totalAmount: sale.totalAmount,
      profit: sale.profit,
    });
  };

  const handleSaveSaleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSale) return;

    updateSale(
      {
        ...editingSale,
        paymentMethod: saleForm.paymentMethod,
        cashierName: saleForm.cashierName.trim() || editingSale.cashierName,
        totalAmount: Number(saleForm.totalAmount) || editingSale.totalAmount,
        profit: Number(saleForm.profit) || editingSale.profit,
      },
      selectedAccountId
    );

    showNotification(`Matagumpay na nabago ang Resibo ${editingSale.receiptNo}!`);
    setEditingSale(null);
    loadData();
  };

  const handleDeleteSaleClick = (sale: Sale) => {
    if (confirm(`Burahin ang resibo ${sale.receiptNo} sa database?`)) {
      deleteSale(sale.id, selectedAccountId);
      showNotification(`Nabura na ang resibo ${sale.receiptNo}.`);
      loadData();
    }
  };

  // CSV Export
  const handleExportCsv = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';
    if (activeTab === 'products') {
      csvContent += 'Barcode,Name,Category,Cost Price,Price,Stock\n';
      filteredProducts.forEach((p) => {
        csvContent += `"${p.barcode}","${p.name}","${p.category}",${p.costPrice},${p.price},${p.stock}\n`;
      });
    } else {
      csvContent += 'Receipt No,Timestamp,Cashier,Payment Method,Total Amount,Profit\n';
      filteredSales.forEach((s) => {
        csvContent += `"${s.receiptNo}","${new Date(s.timestamp).toLocaleString()}","${s.cashierName}","${s.paymentMethod}",${s.totalAmount},${s.profit}\n`;
      });
    }
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `DB_${currentAccount.name}_${activeTab}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/70 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-5xl h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-600 via-indigo-700 to-indigo-900 text-white p-4 sm:p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-xs border border-white/20">
              <Database className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-extrabold text-white">
                  Admin Database Pop-up Table & Data Editor
                </h3>
                <span className="bg-amber-400 text-amber-950 font-black text-[10px] px-2 py-0.5 rounded-full uppercase">
                  Interactive DB
                </span>
              </div>
              <p className="text-xs text-amber-100">
                Tingnan, i-edit, magdagdag, o magbura ng mga produkto, barcodes, at benta sa database.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Account Selector Bar */}
        <div className="bg-slate-100 border-b border-slate-200 p-2.5 flex items-center justify-between gap-2 overflow-x-auto no-scrollbar shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider px-2 flex items-center gap-1 shrink-0">
              <Layers className="w-3.5 h-3.5 text-amber-600" /> Select Account DB:
            </span>
            {accounts.map((acc) => {
              const isSelected = selectedAccountId === acc.id;
              return (
                <button
                  key={acc.id}
                  onClick={() => setSelectedAccountId(acc.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 ${
                    isSelected
                      ? 'bg-amber-600 text-white shadow-xs ring-2 ring-amber-500/30'
                      : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
                  }`}
                >
                  <img src={acc.avatar || undefined} alt={acc.name} className="w-4 h-4 rounded-full object-cover" />
                  <span>{acc.name} DB</span>
                </button>
              );
            })}
          </div>

          <div className="hidden md:flex items-center gap-2 px-3 py-1 bg-indigo-50 border border-indigo-200 rounded-xl text-[11px] font-bold text-indigo-900 shrink-0">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>IndexedDB Capacity: <strong>100,000+ Records Ready</strong></span>
          </div>
        </div>

        {/* Action Controls & Search Bar */}
        <div className="p-3 sm:p-4 border-b border-slate-200 flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between shrink-0 bg-white">
          {/* Data Type Tabs */}
          <div className="flex bg-slate-100 p-1 rounded-2xl border border-slate-200 shrink-0">
            <button
              onClick={() => setActiveTab('products')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                activeTab === 'products'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Package className="w-3.5 h-3.5" />
              <span>Mga Produkto & Barcodes ({products.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('sales')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                activeTab === 'sales'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Receipt className="w-3.5 h-3.5" />
              <span>Mga Transaksyon & Benta ({sales.length})</span>
            </button>
          </div>

          {/* Search, Filter & Add Button */}
          <div className="flex items-center gap-2 flex-1 sm:justify-end min-w-0">
            {activeTab === 'sales' && (
              <div className="relative shrink-0">
                <select
                  value={paymentFilter}
                  onChange={(e) => setPaymentFilter(e.target.value)}
                  className="pl-2 pr-6 py-1.5 text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl text-slate-700 appearance-none focus:outline-none cursor-pointer"
                >
                  <option value="All">All Payments</option>
                  <option value="Cash">Cash</option>
                  <option value="GCash">GCash</option>
                  <option value="Maya">Maya</option>
                </select>
                <Filter className="w-3 h-3 text-slate-400 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            )}

            <div className="relative flex-1 sm:w-56">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Hanapin sa database table..."
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>

            {activeTab === 'products' && (
              <button
                onClick={handleOpenAddProduct}
                className="py-1.5 px-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1 shrink-0 transition-transform active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden sm:inline">Dagdag Produkto</span>
              </button>
            )}

            <button
              onClick={handleExportCsv}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-200 flex items-center gap-1 transition-colors shadow-xs shrink-0"
              title="Export CSV"
            >
              <Download className="w-4 h-4 text-indigo-600" />
            </button>

            <button
              onClick={() => setIsFormatModalOpen(true)}
              className="py-1.5 px-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold border border-rose-200 flex items-center gap-1 transition-colors shadow-xs shrink-0"
              title="Format DB (PIN 1234 Required)"
            >
              <Trash2 className="w-4 h-4 text-rose-600" />
              <span className="hidden xs:inline">Format DB</span>
            </button>
          </div>
        </div>

        {/* Notifications */}
        {successMsg && (
          <div className="bg-emerald-50 border-b border-emerald-200 p-2.5 px-4 text-emerald-800 text-xs font-bold flex items-center gap-2 shrink-0 animate-fade-in">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Database Pop-up Table Body */}
        <div className="flex-1 overflow-auto p-3 sm:p-4 bg-slate-50">
          {activeTab === 'products' ? (
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <table className="w-full text-left border-collapse text-xs min-w-[700px]">
                <thead>
                  <tr className="bg-slate-100/90 text-slate-700 font-extrabold border-b border-slate-200">
                    <th className="p-3">Barcode</th>
                    <th className="p-3">Product Name</th>
                    <th className="p-3">Category</th>
                    <th className="p-3 text-right">Cost Price</th>
                    <th className="p-3 text-right">Selling Price</th>
                    <th className="p-3 text-center">Stock</th>
                    <th className="p-3 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredProducts.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-slate-400 font-medium">
                        No products found in {currentAccount.name} Database.
                      </td>
                    </tr>
                  ) : (
                    displayedProducts.map((prod) => (
                      <tr key={prod.id} className="hover:bg-amber-50/40 transition-colors">
                        <td className="p-3 font-mono font-bold text-indigo-700">{prod.barcode}</td>
                        <td className="p-3">
                          <span className="inline-block bg-amber-200/90 text-slate-950 px-2.5 py-1 rounded-lg border border-amber-300/80 font-black tracking-wide uppercase text-xs shadow-2xs">
                            {prod.name}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded-md text-[11px] text-slate-600 font-semibold">
                            {prod.category}
                          </span>
                        </td>
                        <td className="p-3 text-right font-mono text-slate-500">
                          ₱{prod.costPrice.toFixed(2)}
                        </td>
                        <td className="p-3 text-right font-mono font-black text-indigo-600">
                          ₱{prod.price.toFixed(2)}
                        </td>
                        <td className="p-3 text-center">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                              prod.stock === 0
                                ? 'bg-rose-100 text-rose-700 border border-rose-200'
                                : prod.stock <= 5
                                ? 'bg-orange-100 text-orange-700 border border-orange-200'
                                : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                            }`}
                          >
                            {prod.stock} pcs
                          </span>
                        </td>
                        <td className="p-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => handleOpenEditProduct(prod)}
                              className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-lg border border-indigo-200 text-[11px] flex items-center gap-1 transition-colors"
                            >
                              <Edit className="w-3 h-3" />
                              <span>Edit</span>
                            </button>
                            <button
                              onClick={() => handleDeleteProductClick(prod)}
                              className="p-1 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg border border-rose-200 transition-colors"
                              title="Delete"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
              <table className="w-full text-left border-collapse text-xs min-w-[700px]">
                <thead>
                  <tr className="bg-slate-100/90 text-slate-700 font-extrabold border-b border-slate-200">
                    <th className="p-3">Receipt No</th>
                    <th className="p-3">Time</th>
                    <th className="p-3">Cashier</th>
                    <th className="p-3">Items</th>
                    <th className="p-3 text-center">Payment</th>
                    <th className="p-3 text-right">Profit</th>
                    <th className="p-3 text-right font-black">Total</th>
                    <th className="p-3 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredSales.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-400 font-medium">
                        No receipt records found in {currentAccount.name} Database.
                      </td>
                    </tr>
                  ) : (
                    displayedSales.map((sale) => (
                      <tr key={sale.id} className="hover:bg-amber-50/40 transition-colors">
                        <td className="p-3 font-mono font-bold text-indigo-700">{sale.receiptNo}</td>
                        <td className="p-3 text-slate-500 whitespace-nowrap">
                          {new Date(sale.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' })}{' '}
                          {new Date(sale.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </td>
                        <td className="p-3 font-bold text-slate-800">{sale.cashierName}</td>
                        <td className="p-3 text-slate-600 max-w-[220px]">
                          <p className="truncate font-black text-slate-900 uppercase">
                            {sale.items.map((i) => `${i.product.name.toUpperCase()} (x${i.quantity})`).join(', ')}
                          </p>
                        </td>
                        <td className="p-3 text-center">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-indigo-50 text-indigo-700 border border-indigo-200">
                            {sale.paymentMethod}
                          </span>
                        </td>
                        <td className="p-3 text-right font-mono font-extrabold text-emerald-600">
                          +₱{sale.profit.toFixed(2)}
                        </td>
                        <td className="p-3 text-right font-mono font-black text-indigo-600">
                          ₱{sale.totalAmount.toFixed(2)}
                        </td>
                        <td className="p-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => handleOpenEditSale(sale)}
                              className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-lg border border-indigo-200 text-[11px] flex items-center gap-1 transition-colors"
                            >
                              <Edit className="w-3 h-3" />
                              <span>Edit</span>
                            </button>
                            <button
                              onClick={() => handleDeleteSaleClick(sale)}
                              className="p-1 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg border border-rose-200 transition-colors"
                              title="Delete"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {/* Sheet Pagination Controls (50 items per sheet) */}
          <div className="bg-white p-3 border border-slate-200 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-2xs">
            <div className="flex items-center gap-2 text-xs text-slate-600 font-bold">
              <FileText className="w-4 h-4 text-indigo-600" />
              <span>
                Sheet {safeCurrentPage} ng {totalPages} ({totalItems === 0 ? 0 : startIndex + 1} - {endIndex} sa {totalItems} kabuuang datos)
              </span>
              <span className="bg-indigo-100 text-indigo-800 text-[10px] px-2 py-0.5 rounded-full font-black">
                50 datos / sheet
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                disabled={safeCurrentPage === 1}
                className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 bg-slate-50 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 transition-colors shadow-2xs"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Nakaraang Sheet</span>
              </button>

              {/* Quick Sheet Selector Pills */}
              <div className="flex items-center gap-1 max-w-[180px] overflow-x-auto no-scrollbar py-0.5">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
                  <button
                    key={pageNum}
                    onClick={() => setCurrentPage(pageNum)}
                    className={`w-7 h-7 shrink-0 rounded-lg text-xs font-black transition-all ${
                      pageNum === safeCurrentPage
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {pageNum}
                  </button>
                ))}
              </div>

              <button
                onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
                disabled={safeCurrentPage >= totalPages}
                className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 bg-slate-50 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 transition-colors shadow-2xs"
              >
                <span>Susunod na Sheet</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between shrink-0">
          <p className="text-xs text-slate-500 font-medium">
            Active Database: <strong className="text-slate-900">{currentAccount.name}</strong> ({products.length} products, {sales.length} sales)
          </p>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-colors"
          >
            Close Table Modal
          </button>
        </div>
      </div>

      {/* Product Edit Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-60 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-2xl w-full max-w-md space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                <Edit className="w-4 h-4 text-indigo-600" />
                <span>{editingProduct.id ? 'Edit Product' : 'Add Product'}</span>
              </h4>
              <button
                onClick={() => setEditingProduct(null)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveProductSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Product Name *</label>
                <input
                  type="text"
                  required
                  value={prodForm.name}
                  onChange={(e) => setProdForm({ ...prodForm, name: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-bold focus:outline-none focus:border-indigo-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Barcode *</label>
                  <input
                    type="text"
                    required
                    value={prodForm.barcode}
                    onChange={(e) => setProdForm({ ...prodForm, barcode: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-mono font-bold focus:outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Category</label>
                  <input
                    type="text"
                    value={prodForm.category}
                    onChange={(e) => setProdForm({ ...prodForm, category: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Cost Price (₱)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={prodForm.costPrice}
                    onChange={(e) => setProdForm({ ...prodForm, costPrice: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-xs text-slate-900 font-mono focus:outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Selling Price (₱)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={prodForm.price}
                    onChange={(e) => setProdForm({ ...prodForm, price: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-xs text-indigo-700 font-mono font-bold focus:outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Stock (Pcs)</label>
                  <input
                    type="number"
                    required
                    value={prodForm.stock}
                    onChange={(e) => setProdForm({ ...prodForm, stock: parseInt(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-xs text-slate-900 font-mono font-bold focus:outline-none focus:border-indigo-600"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold border border-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-100 flex items-center justify-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>Save to Database</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Sale Edit Modal */}
      {editingSale && (
        <div className="fixed inset-0 z-60 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-2xl w-full max-w-md space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                <Edit className="w-4 h-4 text-indigo-600" />
                <span>Edit Receipt {editingSale.receiptNo}</span>
              </h4>
              <button onClick={() => setEditingSale(null)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSaleSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Payment Method</label>
                <select
                  value={saleForm.paymentMethod}
                  onChange={(e) => setSaleForm({ ...saleForm, paymentMethod: e.target.value as any })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 font-bold focus:outline-none focus:border-indigo-600"
                >
                  <option value="Cash">Cash</option>
                  <option value="GCash">GCash</option>
                  <option value="Maya">Maya</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">Cashier Name</label>
                <input
                  type="text"
                  value={saleForm.cashierName}
                  onChange={(e) => setSaleForm({ ...saleForm, cashierName: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Total Amount (₱)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={saleForm.totalAmount}
                    onChange={(e) => setSaleForm({ ...saleForm, totalAmount: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-indigo-700 font-mono font-bold focus:outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Profit (₱)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={saleForm.profit}
                    onChange={(e) => setSaleForm({ ...saleForm, profit: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-emerald-700 font-mono font-bold focus:outline-none focus:border-indigo-600"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingSale(null)}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold border border-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-100 flex items-center justify-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Receipt</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Format Data PIN Modal */}
      <FormatDataModal
        isOpen={isFormatModalOpen}
        onClose={() => {
          setIsFormatModalOpen(false);
          loadData();
        }}
        targetAccountId={selectedAccountId}
        accountName={accounts.find((a) => a.id === selectedAccountId)?.name || 'Account'}
      />
    </div>
  );
};
