import React, { useState, useEffect } from 'react';
import {
  getSyncStatus,
  pushCloudSync,
  pullCloudSync,
  clearOfflineQueue,
  SYNC_STATUS_EVENT,
  SyncStatus,
} from '../utils/syncEngine';
import {
  Wifi,
  WifiOff,
  RefreshCw,
  Server,
  Smartphone,
  CheckCircle2,
  Clock,
  Trash2,
  X,
  Layers,
  Sparkles,
  ArrowDownCircle,
  ArrowUpCircle,
  Database,
} from 'lucide-react';

interface DataSyncStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DataSyncStatusModal: React.FC<DataSyncStatusModalProps> = ({ isOpen, onClose }) => {
  const [syncStatus, setSyncStatus] = useState<SyncStatus>(getSyncStatus());
  const [isActionLoading, setIsActionLoading] = useState(false);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  useEffect(() => {
    const handleStatusChange = (e: any) => {
      if (e.detail) {
        setSyncStatus(e.detail);
      } else {
        setSyncStatus(getSyncStatus());
      }
    };

    window.addEventListener(SYNC_STATUS_EVENT, handleStatusChange);
    return () => window.removeEventListener(SYNC_STATUS_EVENT, handleStatusChange);
  }, []);

  if (!isOpen) return null;

  const handleManualPushSync = async () => {
    setIsActionLoading(true);
    setActionMessage('Inililipat ang offline data sa Firebase Firestore Cloud...');
    const success = await pushCloudSync();
    setIsActionLoading(false);
    if (success) {
      setActionMessage('✓ Tagumpay! Naka-sync na sa Firebase Firestore ang lahat ng data.');
    } else {
      setActionMessage('⚠️ Hindi maikonekta sa Firebase. Naka-save pa rin sa local storage.');
    }
    setTimeout(() => setActionMessage(null), 4000);
  };

  const handleManualPullSync = async () => {
    setIsActionLoading(true);
    setActionMessage('Kinukuha ang pinakabagong data mula sa Firebase Cloud Database...');
    const success = await pullCloudSync();
    setIsActionLoading(false);
    if (success) {
      setActionMessage('✓ Na-update na ang system gamit ang pinakabagong data mula sa Firebase!');
    } else {
      setActionMessage('⚠️ Hindi makuha ang data mula sa Firebase. Subukan muli maya-maya.');
    }
    setTimeout(() => setActionMessage(null), 4000);
  };

  const handleClearQueue = () => {
    if (window.confirm('Sigurado ka bang gusto mong burahin ang naka-queue na offline updates?')) {
      clearOfflineQueue();
      setActionMessage('Na-clear na ang offline queue.');
      setTimeout(() => setActionMessage(null), 3000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto animate-fade-in">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-100 overflow-hidden text-slate-800">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between relative overflow-hidden">
          <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-indigo-500/20 rounded-full blur-xl pointer-events-none" />
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-2xl ${syncStatus.isOnline ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'}`}>
              {syncStatus.isOnline ? <Wifi className="w-6 h-6 animate-pulse" /> : <WifiOff className="w-6 h-6" />}
            </div>
            <div>
              <h3 className="font-extrabold text-lg leading-tight flex items-center gap-2">
                Firebase Realtime Database
                <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded-full bg-emerald-600 text-white">
                  Online Sync
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                {syncStatus.isOnline ? '🟢 Connected sa Firebase Firestore Cloud' : '🟠 Offline Mode - Local Storage'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Action Notification Alert */}
          {actionMessage && (
            <div className="p-3.5 rounded-2xl bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs font-bold flex items-center gap-2 animate-shake">
              <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>{actionMessage}</span>
            </div>
          )}

          {/* Sync Status Banner */}
          <div className={`p-4 rounded-2xl border ${syncStatus.isOnline ? 'bg-emerald-50/80 border-emerald-200' : 'bg-amber-50/90 border-amber-200'}`}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-black uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                <Server className="w-4 h-4 text-indigo-600" /> Status ng Firebase Cloud
              </span>
              <span className={`px-2.5 py-1 rounded-full text-xs font-black flex items-center gap-1.5 ${
                syncStatus.syncState === 'synced'
                  ? 'bg-emerald-600 text-white'
                  : syncStatus.syncState === 'syncing'
                  ? 'bg-indigo-600 text-white animate-pulse'
                  : 'bg-amber-600 text-white'
              }`}>
                {syncStatus.syncState === 'synced' && <CheckCircle2 className="w-3.5 h-3.5" />}
                {syncStatus.syncState === 'syncing' && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                {syncStatus.syncState === 'offline_queued' && <Clock className="w-3.5 h-3.5" />}
                {syncStatus.syncState === 'synced' && 'Naka-sync na (Online Firebase)'}
                {syncStatus.syncState === 'syncing' && 'Nagsi-sync sa Firebase...'}
                {syncStatus.syncState === 'offline_queued' && `Naka-queue (${syncStatus.pendingCount} update)`}
              </span>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed font-medium">
              {syncStatus.isOnline
                ? 'Lahat ng ginawa mong dagdag o edit sa mga produkto, benta, at utang ay automatic na naka-sync at makikita agad kahit saang device mo i-open!'
                : 'Nakaantabay ang iyong mga bagong data. Sa oras na maging online ka, AUTOMATIC itong ita-transfer sa Firebase Firestore cloud at sa ibang device!'}
            </p>
          </div>

          {/* Offline Pending Items Queue List */}
          {syncStatus.pendingCount > 0 && (
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-amber-600" />
                  Naka-queue na Offline Updates ({syncStatus.pendingCount})
                </span>
                <button
                  onClick={handleClearQueue}
                  className="text-[11px] font-bold text-rose-600 hover:text-rose-700 flex items-center gap-1 hover:underline"
                >
                  <Trash2 className="w-3 h-3" /> Clear Queue
                </button>
              </div>

              <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                {syncStatus.queueSummary.map((item, idx) => (
                  <div
                    key={idx}
                    className="text-xs p-2 rounded-xl bg-white border border-slate-200/80 text-slate-700 font-medium flex items-center gap-2"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                    <span className="truncate">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Device & Sync Info Card */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-2xl bg-slate-100 border border-slate-200/80">
              <span className="text-slate-500 font-semibold block text-[10px] uppercase">Device Identifier</span>
              <div className="font-extrabold text-slate-900 flex items-center gap-1.5 mt-0.5">
                <Smartphone className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                <span className="truncate">{syncStatus.deviceId}</span>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-100 border border-slate-200/80">
              <span className="text-slate-500 font-semibold block text-[10px] uppercase">Huling Naka-sync</span>
              <div className="font-extrabold text-slate-900 flex items-center gap-1.5 mt-0.5">
                <Clock className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>
                  {syncStatus.lastSyncedTime
                    ? new Date(syncStatus.lastSyncedTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                    : 'Wala pa'}
                </span>
              </div>
            </div>
          </div>

          {/* Firebase Online Firestore Status Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-indigo-950 text-white border border-indigo-700/50 shadow-md space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-600/30 rounded-xl border border-emerald-400/30 text-emerald-400">
                  <Database className="w-4 h-4 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-xs font-black tracking-wide flex items-center gap-1.5">
                    Firebase Firestore Online Database
                    <span className="text-[9px] bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-400/30 font-bold">
                      Live Cloud Sync
                    </span>
                  </h4>
                  <p className="text-[10px] text-slate-300">
                    Awtomatikong naka-sync sa cloud. Kahit saang cellphone o computer mo buksan, pareho ang mga makikitang datos!
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* How Automatic Sync Works Explanation Box */}
          <div className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-100 space-y-2 text-xs">
            <h4 className="font-bold text-indigo-950 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              Paano Gumagana ang Firebase Cloud Sync?
            </h4>
            <ul className="space-y-1 text-slate-600 leading-normal font-medium list-disc pl-4">
              <li>
                <strong>Kapag Online:</strong> Anumang i-add, i-edit, o i-delete mong produkto o benta ay agad na naitatala sa Firebase Firestore.
              </li>
              <li>
                <strong>Kahit Saang Device:</strong> Pag-open mo ng app sa ibang cellphone o PC, agad na magi-import at mag-uupdate ang mga datos gamit ang online Firebase database.
              </li>
            </ul>
          </div>

          {/* Manual Control Buttons */}
          <div className="pt-2 grid grid-cols-2 gap-3">
            <button
              onClick={handleManualPullSync}
              disabled={isActionLoading}
              className="py-3 px-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-extrabold text-xs flex items-center justify-center gap-1.5 border border-slate-200 transition-all active:scale-95 disabled:opacity-50"
            >
              <ArrowDownCircle className="w-4 h-4 text-indigo-600" />
              <span>Pull Mula sa Firebase</span>
            </button>

            <button
              onClick={handleManualPushSync}
              disabled={isActionLoading}
              className="py-3 px-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-indigo-600/20 transition-all active:scale-95 disabled:opacity-50"
            >
              <ArrowUpCircle className="w-4 h-4 text-amber-300" />
              <span>I-push Sa Firebase</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

