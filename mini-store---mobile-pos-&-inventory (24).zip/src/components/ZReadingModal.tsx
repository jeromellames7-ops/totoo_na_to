import React, { useState, useEffect } from 'react';
import { Sale, ShiftReport } from '../types';
import { getSales, getActiveUser, saveShiftReport, getUtangRecords } from '../utils/storage';
import { X, Calculator, Printer, CheckCircle, AlertTriangle, FileText, DollarSign, Coins, ArrowRight } from 'lucide-react';

interface ZReadingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ZReadingModal: React.FC<ZReadingModalProps> = ({ isOpen, onClose }) => {
  const [sales, setSales] = useState<Sale[]>([]);
  const [openingCash, setOpeningCash] = useState<number>(1000); // default opening float

  // Cash Denomination Breakdown Count
  const [bills, setBills] = useState({
    c1000: 0,
    c500: 0,
    c200: 0,
    c100: 0,
    c50: 0,
    c20: 0,
    coins: 0,
  });

  const [notes, setNotes] = useState('');
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setSales(getSales());
      setIsSaved(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Filter today's sales
  const todayStr = new Date().toISOString().split('T')[0];
  const todaySales = sales.filter((s) => s.timestamp.startsWith(todayStr));

  const totalCashSales = todaySales
    .filter((s) => s.paymentMethod === 'Cash')
    .reduce((sum, s) => sum + s.totalAmount, 0);

  const totalDigitalSales = todaySales
    .filter((s) => s.paymentMethod === 'GCash' || s.paymentMethod === 'Maya')
    .reduce((sum, s) => sum + s.totalAmount, 0);

  const totalUtangAdded = todaySales
    .filter((s) => s.paymentMethod === 'Utang')
    .reduce((sum, s) => sum + s.totalAmount, 0);

  const expectedCashInDrawer = openingCash + totalCashSales;

  // Physical cash calculated from denomination counts
  const actualCashCount =
    bills.c1000 * 1000 +
    bills.c500 * 500 +
    bills.c200 * 200 +
    bills.c100 * 100 +
    bills.c50 * 50 +
    bills.c20 * 20 +
    (parseFloat(bills.coins.toString()) || 0);

  const variance = actualCashCount - expectedCashInDrawer; // negative = shortage, positive = overage

  const handleSaveShift = () => {
    const activeUser = getActiveUser();
    const report: ShiftReport = {
      id: `shift-${Date.now()}`,
      shiftDate: new Date().toLocaleDateString(),
      cashierName: activeUser.name,
      openingCash,
      totalCashSales,
      totalDigitalSales,
      totalUtangAdded,
      totalUtangCollected: 0,
      expectedCash: expectedCashInDrawer,
      actualCashCount,
      variance,
      notes: notes.trim() || undefined,
      timestamp: new Date().toISOString(),
    };

    saveShiftReport(report);
    setIsSaved(true);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/65 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-slate-900 text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500 text-slate-900 flex items-center justify-center font-bold shadow-lg shadow-amber-500/20">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight flex items-center gap-2">
                <span>Z-Reading Shift Turnover Audit</span>
                <span className="bg-amber-400 text-slate-900 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                  End of Day
                </span>
              </h3>
              <p className="text-xs text-slate-300">
                Pagsusuri ng benta at pagkuwenta ng perang nasa cash drawer
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50">
          {/* Shift System Calculated Overview */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs space-y-3">
            <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
              Awtomatikong Benta Ngayong Araw
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                <span className="text-slate-500 text-[10px] font-bold block">Cash Sales</span>
                <span className="font-extrabold text-slate-900 text-sm">₱{totalCashSales.toFixed(2)}</span>
              </div>

              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                <span className="text-slate-500 text-[10px] font-bold block">GCash / Maya</span>
                <span className="font-extrabold text-indigo-600 text-sm">₱{totalDigitalSales.toFixed(2)}</span>
              </div>

              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                <span className="text-slate-500 text-[10px] font-bold block">Bagong Utang</span>
                <span className="font-extrabold text-amber-600 text-sm">₱{totalUtangAdded.toFixed(2)}</span>
              </div>
            </div>

            {/* Opening Float Input */}
            <div className="pt-2 flex items-center justify-between border-t border-slate-100 text-xs">
              <span className="font-bold text-slate-700">Simulang Pondo (Opening Float):</span>
              <div className="flex items-center gap-1 font-bold">
                <span>₱</span>
                <input
                  type="number"
                  value={openingCash}
                  onChange={(e) => setOpeningCash(parseFloat(e.target.value) || 0)}
                  className="w-24 px-2 py-1 bg-slate-100 border border-slate-300 rounded-lg text-right text-xs font-black"
                />
              </div>
            </div>

            <div className="bg-amber-50 border border-amber-200/80 rounded-xl p-3 flex items-center justify-between text-xs font-bold text-amber-900">
              <span>Inaasahang Cash sa Drawer:</span>
              <span className="text-base font-black">₱{expectedCashInDrawer.toFixed(2)}</span>
            </div>
          </div>

          {/* Physical Cash Bill Denomination Calculator */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs space-y-3">
            <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
              <Coins className="w-4 h-4 text-amber-600" />
              <span>Bilang ng Perang Papel at Barya (Physical Count)</span>
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div>
                <label className="text-[10px] font-bold text-slate-500 block">₱1,000 Bills</label>
                <input
                  type="number"
                  min="0"
                  value={bills.c1000 || ''}
                  onChange={(e) => setBills({ ...bills, c1000: parseInt(e.target.value) || 0 })}
                  placeholder="0"
                  className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 block">₱500 Bills</label>
                <input
                  type="number"
                  min="0"
                  value={bills.c500 || ''}
                  onChange={(e) => setBills({ ...bills, c500: parseInt(e.target.value) || 0 })}
                  placeholder="0"
                  className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 block">₱200 Bills</label>
                <input
                  type="number"
                  min="0"
                  value={bills.c200 || ''}
                  onChange={(e) => setBills({ ...bills, c200: parseInt(e.target.value) || 0 })}
                  placeholder="0"
                  className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 block">₱100 Bills</label>
                <input
                  type="number"
                  min="0"
                  value={bills.c100 || ''}
                  onChange={(e) => setBills({ ...bills, c100: parseInt(e.target.value) || 0 })}
                  placeholder="0"
                  className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 block">₱50 Bills</label>
                <input
                  type="number"
                  min="0"
                  value={bills.c50 || ''}
                  onChange={(e) => setBills({ ...bills, c50: parseInt(e.target.value) || 0 })}
                  placeholder="0"
                  className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-500 block">₱20 Bills</label>
                <input
                  type="number"
                  min="0"
                  value={bills.c20 || ''}
                  onChange={(e) => setBills({ ...bills, c20: parseInt(e.target.value) || 0 })}
                  placeholder="0"
                  className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900"
                />
              </div>

              <div className="col-span-2">
                <label className="text-[10px] font-bold text-slate-500 block">Kabuuan ng mga Barya (Coins Total ₱)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={bills.coins || ''}
                  onChange={(e) => setBills({ ...bills, coins: parseFloat(e.target.value) || 0 })}
                  placeholder="0.00"
                  className="w-full px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900"
                />
              </div>
            </div>
          </div>

          {/* Variance Audit Card */}
          <div
            className={`border rounded-2xl p-4 space-y-2 ${
              variance === 0
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : variance < 0
                ? 'bg-rose-50 border-rose-200 text-rose-900'
                : 'bg-indigo-50 border-indigo-200 text-indigo-900'
            }`}
          >
            <div className="flex items-center justify-between text-xs font-bold">
              <span>Nabilang na Perang Hawak:</span>
              <span className="text-base font-black">₱{actualCashCount.toFixed(2)}</span>
            </div>

            <div className="flex items-center justify-between text-xs pt-1 border-t border-current/10 font-bold">
              <span>Variance (Sobra / Kulang):</span>
              <span
                className={`text-sm font-black px-2 py-0.5 rounded-lg ${
                  variance === 0
                    ? 'bg-emerald-200 text-emerald-900'
                    : variance < 0
                    ? 'bg-rose-200 text-rose-900'
                    : 'bg-indigo-200 text-indigo-900'
                }`}
              >
                {variance === 0
                  ? 'TUMEPTEP (Exact)'
                  : variance < 0
                  ? `KULANG: -₱${Math.abs(variance).toFixed(2)}`
                  : `SOBRA: +₱${variance.toFixed(2)}`}
              </span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-slate-100 border-t border-slate-200 flex items-center justify-between gap-2">
          <button
            onClick={handlePrint}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>I-Print Z-Report</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-white border border-slate-200 text-slate-700 text-xs font-bold rounded-xl"
            >
              Isara
            </button>

            <button
              onClick={handleSaveShift}
              disabled={isSaved}
              className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-1.5 disabled:opacity-50"
            >
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>{isSaved ? 'Nai-Save Na!' : 'I-Save Z-Report'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
