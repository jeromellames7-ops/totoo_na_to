import React, { useState, useEffect } from 'react';
import { UserAccount, LowStockAlert } from '../types';
import { getLanguage, setLanguage, t, LANG_CHANGE_EVENT, Language } from '../utils/language';
import { getAdminTargetAccountId, getAccounts } from '../utils/storage';
import { getSyncStatus, SYNC_STATUS_EVENT, SyncStatus } from '../utils/syncEngine';
import {
  Store,
  Shield,
  Bell,
  Smartphone,
  Monitor,
  Globe,
  Layers,
  Download,
  BookOpen,
  Sparkles,
  Calculator,
  RefreshCw,
  WifiOff,
  Database,
  ShieldAlert,
  Lock,
  Menu,
  X,
  ChevronRight,
  Home,
  LogOut,
} from 'lucide-react';

interface HeaderProps {
  activeUser: UserAccount;
  onOpenAccountsModal: () => void;
  onOpenAccountSettingsModal?: () => void;
  lowStockAlerts: LowStockAlert[];
  onOpenLowStockDrawer: () => void;
  isMobileFrame: boolean;
  onToggleMobileFrame: () => void;
  onNavigateToPortal?: () => void;
  onNavigateToPrintStudio?: () => void;
  onNavigateToHomeMonitoring?: () => void;
  onNavigateToDocScanner?: () => void;
  onOpenInstallApkModal?: () => void;
  onOpenUtangModal?: () => void;
  onOpenAiModal?: () => void;
  onOpenZReadingModal?: () => void;
  onOpenDataSyncModal?: () => void;
  onOpenSecurityModal?: () => void;
  onLockTerminalNow?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeUser,
  onOpenAccountsModal,
  onOpenAccountSettingsModal,
  lowStockAlerts,
  onOpenLowStockDrawer,
  isMobileFrame,
  onToggleMobileFrame,
  onNavigateToPortal,
  onNavigateToPrintStudio,
  onNavigateToHomeMonitoring,
  onNavigateToDocScanner,
  onOpenInstallApkModal,
  onOpenUtangModal,
  onOpenAiModal,
  onOpenZReadingModal,
  onOpenDataSyncModal,
  onOpenSecurityModal,
  onLockTerminalNow,
}) => {
  const [currentLang, setCurrentLangState] = useState<Language>(getLanguage());
  const [syncStatus, setSyncStatus] = useState<SyncStatus>(getSyncStatus());
  const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);

  const unreadCount = lowStockAlerts.filter((a) => !a.isRead).length;

  const adminTargetId = activeUser.role === 'Admin' ? getAdminTargetAccountId() : null;
  const allAccounts = getAccounts();
  const targetAccountObj = adminTargetId ? allAccounts.find((a) => a.id === adminTargetId) : null;

  useEffect(() => {
    const handleLangChange = () => {
      setCurrentLangState(getLanguage());
    };
    const handleSyncStatusChange = (e: any) => {
      if (e.detail) {
        setSyncStatus(e.detail);
      } else {
        setSyncStatus(getSyncStatus());
      }
    };

    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    window.addEventListener(SYNC_STATUS_EVENT, handleSyncStatusChange);

    return () => {
      window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
      window.removeEventListener(SYNC_STATUS_EVENT, handleSyncStatusChange);
    };
  }, []);

  const handleToggleLang = () => {
    const nextLang: Language = currentLang === 'tl' ? 'en' : 'tl';
    setLanguage(nextLang);
  };

  const handleMenuAction = (actionFn?: () => void) => {
    setIsMenuOpen(false);
    if (actionFn) {
      actionFn();
    }
  };

  return (
    <header className="bg-white text-slate-900 sticky top-0 z-30 shadow-xs border-b border-slate-200/80">
      {/* Professional Top Branding Bar */}
      <div className="bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-950 text-slate-200 py-1.5 px-2.5 sm:px-4 border-b border-indigo-900/40 text-[11px] font-bold flex items-center justify-between shadow-xs overflow-hidden max-w-full">
        <div className="flex items-center gap-2 max-w-7xl mx-auto w-full justify-between min-w-0">
          <div className="flex items-center gap-1.5 text-indigo-300 min-w-0 truncate">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse shrink-0" />
            <span className="tracking-wide truncate text-[10px] sm:text-[11px]">
              Dev: <strong className="text-white font-black hover:text-amber-300 transition-colors">Jerome U. Llames</strong>
            </span>
            <span className="hidden md:inline-block bg-indigo-500/20 text-indigo-300 text-[9px] px-2 py-0.5 rounded-full border border-indigo-500/30 uppercase font-black tracking-wider shrink-0">
              Lead System Developer
            </span>
          </div>
          <div className="flex items-center gap-2 text-[10px] text-slate-400 font-medium shrink-0">
            <span className="hidden md:inline-flex items-center gap-1.5 text-emerald-400 font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              Operational
            </span>
            <span className="text-slate-300 font-mono text-[9px] sm:text-[10px] bg-slate-800/80 px-1.5 py-0.5 rounded border border-slate-700">v2.5 PRO</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-2.5 sm:px-4 py-2 flex items-center justify-between w-full min-w-0 gap-2">
        {/* App Branding */}
        <div className="flex items-center space-x-2 min-w-0">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-indigo-600 flex items-center justify-center shadow-md shadow-indigo-100 shrink-0">
            <Store className="w-4 h-4 sm:w-5 sm:h-5 text-white font-bold" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap sm:flex-nowrap">
              <h1 className="font-extrabold text-sm sm:text-lg tracking-tight leading-none text-slate-900 uppercase shrink-0">
                MINI <span className="text-indigo-600">STORE</span>
              </h1>

              {/* Automatic Data Sync Status Badge */}
              <button
                onClick={onOpenDataSyncModal}
                className={`inline-flex items-center gap-1 px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-full text-[9px] sm:text-[10px] font-extrabold border transition-all cursor-pointer hover:opacity-90 active:scale-95 shrink-0 ${
                  syncStatus.syncState === 'synced'
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                    : syncStatus.syncState === 'syncing'
                    ? 'bg-indigo-50 text-indigo-700 border-indigo-300'
                    : 'bg-amber-50 text-amber-800 border-amber-300'
                }`}
                title="Click para i-manage ang Automatic Cloud Sync"
              >
                {syncStatus.syncState === 'synced' && (
                  <>
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="hidden sm:inline">Cloud Synced</span>
                  </>
                )}
                {syncStatus.syncState === 'syncing' && (
                  <>
                    <RefreshCw className="w-3 h-3 text-indigo-600 animate-spin" />
                    <span className="hidden sm:inline">Syncing...</span>
                  </>
                )}
                {syncStatus.syncState === 'offline_queued' && (
                  <>
                    <WifiOff className="w-3 h-3 text-amber-600" />
                    <span className="text-[9px]">Offline ({syncStatus.pendingCount})</span>
                  </>
                )}
              </button>

              {/* IndexedDB Offline Database Badge */}
              <button
                onClick={onOpenDataSyncModal}
                className="hidden md:inline-flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-extrabold border bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100/80 transition-all cursor-pointer active:scale-95 shadow-2xs shrink-0"
                title="TindahanOfflineDB - Naka-save sa IndexedDB Offline Database"
              >
                <Database className="w-3 h-3 text-indigo-600 animate-pulse" />
                <span>IndexedDB</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-500 hidden sm:block font-medium truncate">{t('appSubtitle')}</p>
          </div>
        </div>

        {/* Right Navigation: Exit & Unified Menu Button */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Automatic Return to Front Page Exit Button */}
          {onNavigateToPortal && (
            <button
              onClick={onNavigateToPortal}
              className="flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-[11px] sm:text-xs shadow-md shadow-rose-600/20 transition-all active:scale-95 cursor-pointer border border-rose-500 shrink-0 group"
              title="EXIT: Bumalik sa Front Page (Main Hub)"
            >
              <LogOut className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white group-hover:-translate-x-0.5 transition-transform" />
              <span className="uppercase tracking-wider">EXIT</span>
            </button>
          )}

          <button
            onClick={() => setIsMenuOpen(true)}
            className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-black text-xs shadow-md shadow-slate-900/20 transition-all active:scale-95 cursor-pointer border border-slate-700 shrink-0"
            title="Buksan ang System Menu"
          >
            <div className="relative flex items-center shrink-0">
              <img
                src={activeUser.avatar || undefined}
                alt={activeUser.name}
                className="w-5 h-5 sm:w-6 sm:h-6 rounded-full object-cover ring-2 ring-amber-400"
              />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-orange-500 text-[9px] font-black text-white ring-2 ring-slate-900 animate-pulse">
                  {unreadCount}
                </span>
              )}
            </div>
            <span className="tracking-wider text-amber-400 uppercase font-black text-[11px] sm:text-xs">MENU</span>
            <Menu className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>

      {/* Slide-over Menu Drawer & Modal */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex justify-end transition-all">
          {/* Backdrop Click */}
          <div className="absolute inset-0" onClick={() => setIsMenuOpen(false)} />

          {/* Drawer Body */}
          <div className="relative w-full max-w-sm bg-white h-full shadow-2xl flex flex-col z-10 border-l border-slate-200 overflow-y-auto animate-in slide-in-from-right duration-200">
            {/* Drawer Header */}
            <div className="p-4 bg-slate-950 text-white flex items-center justify-between sticky top-0 z-20 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-amber-300 font-bold">
                  <Menu className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-sm font-black tracking-wide uppercase text-white">System Menu</h2>
                  <p className="text-[10px] text-slate-400 font-medium">MINI STORE Controls & Settings</p>
                </div>
              </div>
              <button
                onClick={() => setIsMenuOpen(false)}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                title="Isara ang Menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 space-y-4">
              {/* Active User Card & Switcher */}
              <div className="bg-slate-900 text-white rounded-2xl p-3.5 flex items-center justify-between shadow-md">
                <div className="flex items-center gap-3">
                  <div className="relative shrink-0">
                    <img
                      src={activeUser.avatar || undefined}
                      alt={activeUser.name}
                      className="w-10 h-10 rounded-full object-cover ring-2 ring-amber-400"
                    />
                    {activeUser.role === 'Admin' && (
                      <Shield className="w-3.5 h-3.5 text-amber-500 absolute -bottom-0.5 -right-0.5 bg-slate-900 rounded-full p-0.5" />
                    )}
                  </div>
                  <div>
                    <p className="text-xs font-black text-white">{activeUser.name}</p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 uppercase">
                        {activeUser.role}
                      </span>
                      {targetAccountObj && (
                        <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          Store: {targetAccountObj.name.split(' ')[0]}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  {onOpenAccountSettingsModal && (
                    <button
                      onClick={() => handleMenuAction(onOpenAccountSettingsModal)}
                      className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-bold transition-all border border-cyan-500/30 cursor-pointer"
                      title="Account Settings"
                    >
                      Settings
                    </button>
                  )}
                  <button
                    onClick={() => handleMenuAction(onOpenAccountsModal)}
                    className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black transition-all cursor-pointer shadow-xs"
                  >
                    Switch
                  </button>
                </div>
              </div>

              {/* Section 1: Quick Actions & Operational Tools */}
              <div>
                <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-2 px-1">
                  Main System Portals
                </h3>
                <div className="grid grid-cols-1 gap-2">
                  {/* Front Page Hub */}
                  {onNavigateToPortal && (
                    <button
                      onClick={() => handleMenuAction(onNavigateToPortal)}
                      className="w-full flex items-center justify-between p-3 rounded-xl bg-cyan-950 text-cyan-200 hover:bg-cyan-900 border border-cyan-500/40 transition-all text-left group shadow-xs cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-cyan-500/20 flex items-center justify-center shrink-0">
                          <Layers className="w-5 h-5 text-cyan-400" />
                        </div>
                        <div>
                          <span className="text-xs font-black block text-white">Front Page Hub (Main Portal)</span>
                          <span className="text-[10px] text-cyan-300 font-medium">Bumalik sa 4-Button Main Screen</span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  )}

                  {/* Print Studio */}
                  {onNavigateToPrintStudio && (
                    <button
                      onClick={() => handleMenuAction(onNavigateToPrintStudio)}
                      className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-900 text-white hover:bg-slate-800 border border-slate-700 transition-all text-left group shadow-xs cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-cyan-500/20 flex items-center justify-center shrink-0">
                          <Store className="w-5 h-5 text-cyan-400" />
                        </div>
                        <div>
                          <span className="text-xs font-black block">Print Studio (HP Smart Tank 580)</span>
                          <span className="text-[10px] text-slate-300 font-medium">Bondpaper Editor & Photo Resizer</span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  )}

                  {/* Home Monitoring */}
                  {onNavigateToHomeMonitoring && (
                    <button
                      onClick={() => handleMenuAction(onNavigateToHomeMonitoring)}
                      className="w-full flex items-center justify-between p-3 rounded-xl bg-emerald-950/60 text-emerald-200 hover:bg-emerald-900 border border-emerald-500/40 transition-all text-left group shadow-xs cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-emerald-500/20 flex items-center justify-center shrink-0">
                          <Home className="w-5 h-5 text-emerald-400" />
                        </div>
                        <div>
                          <span className="text-xs font-black block text-white">Home Monitoring System</span>
                          <span className="text-[10px] text-emerald-300 font-medium">Electric, Water, LPG & Menstruation</span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-emerald-400 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  )}

                  {/* Utang Ledger */}
                  {onOpenUtangModal && (
                    <button
                      onClick={() => handleMenuAction(onOpenUtangModal)}
                      className="w-full flex items-center justify-between p-3 rounded-xl bg-amber-50/80 hover:bg-amber-100 border border-amber-200 text-amber-950 transition-all text-left group cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-amber-500/20 flex items-center justify-center shrink-0">
                          <BookOpen className="w-5 h-5 text-amber-700" />
                        </div>
                        <div>
                          <span className="text-xs font-black block">Utang Ledger</span>
                          <span className="text-[10px] text-amber-800/80 font-medium">Talaan ng Utang at Singilin</span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-amber-500 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  )}

                  {/* Z-Reading */}
                  {onOpenZReadingModal && (
                    <button
                      onClick={() => handleMenuAction(onOpenZReadingModal)}
                      className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white transition-all text-left group shadow-xs cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-amber-400/20 flex items-center justify-center shrink-0">
                          <Calculator className="w-5 h-5 text-amber-400" />
                        </div>
                        <div>
                          <span className="text-xs font-black block">Z-Reading Shift Turnover</span>
                          <span className="text-[10px] text-slate-300 font-medium">Shift Summary & Cash Count</span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  )}

                  {/* AI Assistant */}
                  {onOpenAiModal && (
                    <button
                      onClick={() => handleMenuAction(onOpenAiModal)}
                      className="w-full flex items-center justify-between p-3 rounded-xl bg-indigo-50 hover:bg-indigo-100/80 border border-indigo-200 text-indigo-950 transition-all text-left group cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-indigo-500/20 flex items-center justify-center shrink-0">
                          <Sparkles className="w-5 h-5 text-indigo-600 animate-pulse" />
                        </div>
                        <div>
                          <span className="text-xs font-black block">AI Business Assistant</span>
                          <span className="text-[10px] text-indigo-800/80 font-medium">Suriin ang benta gamit ang AI</span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-indigo-400 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  )}

                  {/* Download APK / Mobile App */}
                  {onOpenInstallApkModal && (
                    <button
                      onClick={() => handleMenuAction(onOpenInstallApkModal)}
                      className="w-full flex items-center justify-between p-3 rounded-xl bg-emerald-50 hover:bg-emerald-100/80 border border-emerald-200 text-emerald-950 transition-all text-left group cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-emerald-500/20 flex items-center justify-center shrink-0">
                          <Download className="w-5 h-5 text-emerald-700" />
                        </div>
                        <div>
                          <span className="text-xs font-black block">Download APK / App</span>
                          <span className="text-[10px] text-emerald-800/80 font-medium">I-download ang Mobile App</span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-emerald-500 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  )}

                  {/* System Security Audit */}
                  {onOpenSecurityModal && (
                    <button
                      onClick={() => handleMenuAction(onOpenSecurityModal)}
                      className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-900 transition-all text-left group cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-rose-500/10 flex items-center justify-center shrink-0">
                          <ShieldAlert className="w-5 h-5 text-rose-600" />
                        </div>
                        <div>
                          <span className="text-xs font-black block">System Security Center</span>
                          <span className="text-[10px] text-slate-500 font-medium">Audit Trail Logs & Settings</span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  )}

                  {/* Quick Lock Terminal */}
                  {onLockTerminalNow && (
                    <button
                      onClick={() => handleMenuAction(onLockTerminalNow)}
                      className="w-full flex items-center justify-between p-3 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-950 transition-all text-left group cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-rose-500/20 flex items-center justify-center shrink-0">
                          <Lock className="w-5 h-5 text-rose-600" />
                        </div>
                        <div>
                          <span className="text-xs font-black block">Lock Terminal Screen</span>
                          <span className="text-[10px] text-rose-800/80 font-medium">I-lock agad ang screen</span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-rose-400 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  )}
                </div>
              </div>

              {/* Section 2: Notifications & Settings */}
              <div>
                <h3 className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-2 px-1">
                  Mga Setting & Notipikasyon
                </h3>
                <div className="grid grid-cols-1 gap-2">
                  {/* Low Stock Notifications */}
                  <button
                    onClick={() => handleMenuAction(onOpenLowStockDrawer)}
                    className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-900 transition-all text-left cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-orange-500/10 flex items-center justify-center shrink-0 relative">
                        <Bell className="w-5 h-5 text-orange-600" />
                        {unreadCount > 0 && (
                          <span className="absolute -top-1 -right-1 flex h-4 min-w-4 px-1 items-center justify-center rounded-full bg-orange-500 text-[10px] font-black text-white shadow-xs">
                            {unreadCount}
                          </span>
                        )}
                      </div>
                      <div>
                        <span className="text-xs font-black block">Low Stock Alerts</span>
                        <span className="text-[10px] text-slate-500 font-medium">
                          {unreadCount > 0 ? `${unreadCount} na produkto ang kakaunti na` : 'Walang low stock warning'}
                        </span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>

                  {/* Language Switcher */}
                  <button
                    onClick={handleToggleLang}
                    className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-900 transition-all text-left cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-indigo-500/10 flex items-center justify-center shrink-0">
                        <Globe className="w-5 h-5 text-indigo-600" />
                      </div>
                      <div>
                        <span className="text-xs font-black block">Wika / Language</span>
                        <span className="text-[10px] text-slate-500 font-medium">
                          Kasalukuyan: {currentLang === 'tl' ? '🇵🇭 Tagalog' : '🇺🇸 English'}
                        </span>
                      </div>
                    </div>
                    <span className="text-xs font-extrabold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-lg border border-indigo-200">
                      Palitan
                    </span>
                  </button>

                  {/* Mobile App View Frame Toggle */}
                  <button
                    onClick={onToggleMobileFrame}
                    className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-900 transition-all text-left cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-slate-200 flex items-center justify-center shrink-0">
                        {isMobileFrame ? (
                          <Monitor className="w-5 h-5 text-slate-700" />
                        ) : (
                          <Smartphone className="w-5 h-5 text-indigo-600" />
                        )}
                      </div>
                      <div>
                        <span className="text-xs font-black block">Display View Mode</span>
                        <span className="text-[10px] text-slate-500 font-medium">
                          {isMobileFrame ? 'Naka-Mobile View' : 'Naka-Full Screen'}
                        </span>
                      </div>
                    </div>
                    <span className="text-xs font-extrabold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-lg border border-indigo-200">
                      {isMobileFrame ? 'Full Screen' : 'Mobile View'}
                    </span>
                  </button>

                  {/* IndexedDB & Cloud Data Sync */}
                  {onOpenDataSyncModal && (
                    <button
                      onClick={() => handleMenuAction(onOpenDataSyncModal)}
                      className="w-full flex items-center justify-between p-3 rounded-xl bg-indigo-50/50 hover:bg-indigo-50 border border-indigo-200 text-indigo-950 transition-all text-left cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-indigo-500/10 flex items-center justify-center shrink-0">
                          <Database className="w-5 h-5 text-indigo-600" />
                        </div>
                        <div>
                          <span className="text-xs font-black block">IndexedDB & Cloud Sync</span>
                          <span className="text-[10px] text-slate-500 font-medium">
                            {syncStatus.syncState === 'synced'
                              ? 'IndexedDB Active • Cloud Synced'
                              : syncStatus.syncState === 'syncing'
                              ? 'Naglilipat ng data...'
                              : `Offline (${syncStatus.pendingCount} nakapila)`}
                          </span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-indigo-400" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

