import React, { useState } from 'react';
import { Sale } from '../types';
import { Search, Receipt, Calendar, User, CreditCard, ChevronRight, Eye } from 'lucide-react';

interface SalesHistoryProps {
  sales: Sale[];
  onSelectSale: (sale: Sale) => void;
}

export const SalesHistory: React.FC<SalesHistoryProps> = ({ sales, onSelectSale }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSales = (sales || []).filter((s) => {
    if (!s) return false;
    const items = Array.isArray(s.items) ? s.items : [];
    return (
      (s.receiptNo || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (s.cashierName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (s.paymentMethod || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      items.some((i) => (i?.product?.name || '').toLowerCase().includes(searchTerm.toLowerCase()))
    );
  });

  return (
    <div className="space-y-4 pb-40 sm:pb-44 max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-white border border-slate-200/80 p-4 rounded-3xl shadow-xs flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <Receipt className="w-5 h-5 text-indigo-600 shrink-0" />
            <span>Sales History</span>
          </h2>
          <p className="text-xs text-slate-500">Complete record of all store sales transactions and receipts</p>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search receipt no., cashier, item..."
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-indigo-600 focus:bg-white"
          />
        </div>
      </div>

      {/* Sales List */}
      <div className="space-y-2.5">
        {filteredSales.length === 0 ? (
          <div className="bg-white border border-slate-200/80 rounded-3xl p-8 text-center text-slate-500 shadow-xs">
            <Receipt className="w-12 h-12 stroke-1 mx-auto mb-2 text-slate-300" />
            <p className="text-sm font-bold text-slate-800">No transaction records found</p>
            <p className="text-xs text-slate-400 mt-1">Sales receipts will appear here automatically when transactions occur.</p>
          </div>
        ) : (
          filteredSales.map((sale) => (
            <div
              key={sale.id}
              onClick={() => onSelectSale(sale)}
              className="bg-white border border-slate-200/80 hover:border-indigo-300 p-3.5 rounded-2xl shadow-xs hover:shadow-md cursor-pointer transition-all flex items-center justify-between group"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-xs shrink-0">
                  <Receipt className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs font-bold text-slate-900">{sale.receiptNo || 'INV-0000'}</span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                        sale.paymentMethod === 'Cash'
                          ? 'bg-indigo-50 text-indigo-700 border-indigo-100'
                          : sale.paymentMethod === 'GCash'
                          ? 'bg-cyan-50 text-cyan-700 border-cyan-100'
                          : 'bg-pink-50 text-pink-700 border-pink-100'
                      }`}
                    >
                      {sale.paymentMethod || 'Cash'}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-600 mt-0.5 line-clamp-1">
                    {(sale.items || []).map((i) => `${i?.quantity || 1}x ${i?.product?.name || 'Item'}`).join(', ')}
                  </p>

                  <div className="flex items-center gap-3 text-[10px] text-slate-400 mt-1 flex-wrap">
                    <span>{new Date(sale.timestamp || Date.now()).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}</span>
                    <span>• Cashier: {(sale.cashierName || 'Cashier').split(' ')[0]}</span>
                  </div>
                </div>
              </div>

              <div className="text-right flex items-center gap-2 pl-2 shrink-0">
                <div>
                  <p className="text-sm font-black text-indigo-600">₱{(sale.totalAmount || 0).toFixed(2)}</p>
                  <p className="text-[10px] text-slate-400 font-medium">{(sale.items || []).length} items</p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 transition-colors" />
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
