import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Download,
  X,
  CheckCircle2,
  Share,
  PlusSquare,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';

interface InstallApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallApkModal: React.FC<InstallApkModalProps> = ({ isOpen, onClose }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'android' | 'ios' | 'pc'>('android');

  useEffect(() => {
    // Check if app is already running in standalone (installed APK/PWA) mode
    if (
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone === true
    ) {
      setIsInstalled(true);
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    }
  };

  return (
    <div className="fixed inset-0 z-70 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fade-in">
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-2xl w-full max-w-lg space-y-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-3">
            <img
              src="/shop-icon.svg"
              alt="MINI STORE Icon"
              className="w-14 h-14 rounded-2xl object-cover border-2 border-red-500 shadow-lg shadow-red-500/20 shrink-0"
            />
            <div>
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <span>Install Mobile App (APK / PWA)</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 font-bold border border-emerald-200">
                  Standalone Native
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                Installs as a real application with custom red S H O P launcher icon.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Highlighted Banner */}
        <div className="bg-gradient-to-br from-indigo-900 via-indigo-800 to-slate-900 text-white rounded-2xl p-4 shadow-md space-y-2">
          <div className="flex items-center gap-2 font-black text-amber-300 text-xs uppercase tracking-wider">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Play Store Quality Application</span>
          </div>
          <p className="text-xs text-indigo-100 leading-relaxed font-medium">
            Once installed, MINI STORE operates directly from your phone app drawer without needing a web browser header. Supports full offline barcode scanning, instant load speeds, and local storage!
          </p>
          <div className="pt-1 flex flex-wrap gap-2 text-[10px] font-bold text-indigo-200">
            <span className="bg-white/10 px-2 py-1 rounded-md flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-emerald-400" /> Fast Offline Support
            </span>
            <span className="bg-white/10 px-2 py-1 rounded-md flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-400" /> Instant Camera Scanner
            </span>
          </div>
        </div>

        {/* ALWAYS-VISIBLE PRIMARY ACTION BUTTONS: 1-Tap Install & Download Offline Launcher */}
        <div className="space-y-2.5">
          <button
            onClick={() => {
              if (deferredPrompt) {
                handleInstallClick();
              } else {
                setActiveTab('android');
                alert(
                  "📲 PARA MAI-INSTALL SA IYONG CELLPHONE (Kasama ang bagong red S H O P Icon):\n\n1. I-tap ang tatlong tuldok (⋮) sa upper-right corner ng iyong Chrome browser.\n2. Piliin ang 'Install app' o 'Add to Home screen'.\n\nAwtomatikong gagawa ang Android system ng MINI STORE Application sa iyong phone home screen!"
                );
              }
            }}
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-sm rounded-2xl shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
          >
            <Download className="w-5 h-5 shrink-0" />
            <span>📲 I-INSTALL SA CELLPHONE NOW (1-TAP SYSTEM APP)</span>
          </button>

          <a
            href="/MINI_STORE_Offline_App.html"
            download="MINI_STORE_Application.html"
            className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-2xl shadow-md flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer no-underline text-center"
          >
            <Download className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>📥 DOWNLOAD OFFLINE APP PACKAGE (.HTML LAUNCHER)</span>
          </a>
        </div>

        {isInstalled && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3 text-emerald-800 text-xs font-bold flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>App is already installed and active on this device!</span>
          </div>
        )}

        {/* Tab Selection for Manual Install Guides */}
        <div className="space-y-3">
          <div className="flex bg-slate-100 p-1 rounded-2xl gap-1">
            <button
              onClick={() => setActiveTab('android')}
              className={`flex-1 py-1.5 text-xs font-extrabold rounded-xl transition-all ${
                activeTab === 'android'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              🤖 Android Phone
            </button>
            <button
              onClick={() => setActiveTab('ios')}
              className={`flex-1 py-1.5 text-xs font-extrabold rounded-xl transition-all ${
                activeTab === 'ios'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              🍎 iPhone / iOS
            </button>
            <button
              onClick={() => setActiveTab('pc')}
              className={`flex-1 py-1.5 text-xs font-extrabold rounded-xl transition-all ${
                activeTab === 'pc'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              💻 Laptop / Desktop
            </button>
          </div>

          {/* Android Step Guide */}
          {activeTab === 'android' && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 text-xs text-slate-700">
              <h4 className="font-extrabold text-slate-900 text-xs flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-emerald-600" />
                <span>How to Install on Android Phone (w/ New Red SHOP Icon):</span>
              </h4>
              <ol className="space-y-2 font-medium">
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </span>
                  <span>
                    I-tap ang <strong>Three Dots (⋮)</strong> menu button sa top right ng iyong Chrome browser sa cellphone.
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    2
                  </span>
                  <span>
                    Piliin ang <strong>"Install app"</strong> o <strong>"Add to Home screen"</strong>.
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    3
                  </span>
                  <span>
                    I-click ang <strong>"Install"</strong>. Awtomatikong gagawin ng Android OS ang system application kasama ang bagong <strong>red S H O P Icon</strong> sa iyong Home Screen!
                  </span>
                </li>
              </ol>
            </div>
          )}

          {/* iOS Step Guide */}
          {activeTab === 'ios' && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 text-xs text-slate-700">
              <h4 className="font-extrabold text-slate-900 text-xs flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-indigo-600" />
                <span>How to Install on iPhone (Safari):</span>
              </h4>
              <ol className="space-y-2 font-medium">
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </span>
                  <span className="flex items-center gap-1">
                    Tap the <strong>Share</strong> button <Share className="w-3.5 h-3.5 text-indigo-600 inline" /> at the bottom of Safari.
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    2
                  </span>
                  <span className="flex items-center gap-1">
                    Scroll down and tap <strong>"Add to Home Screen"</strong> <PlusSquare className="w-3.5 h-3.5 text-indigo-600 inline" />.
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    3
                  </span>
                  <span>Tap <strong>"Add"</strong> on the top right corner.</span>
                </li>
              </ol>
            </div>
          )}

          {/* Desktop Step Guide */}
          {activeTab === 'pc' && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 text-xs text-slate-700">
              <h4 className="font-extrabold text-slate-900 text-xs flex items-center gap-2">
                <Download className="w-4 h-4 text-indigo-600" />
                <span>How to Install on Desktop / Laptop:</span>
              </h4>
              <ol className="space-y-2 font-medium">
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </span>
                  <span>Look for the <strong>Install Icon (⊕)</strong> on the right side of the browser URL bar.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                    2
                  </span>
                  <span>Click <strong>"Install MINI STORE"</strong>.</span>
                </li>
              </ol>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-all"
          >
            Close & Continue
          </button>
        </div>
      </div>
    </div>
  );
};
