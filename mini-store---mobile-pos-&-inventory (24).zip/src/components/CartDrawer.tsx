import React, { useState, useEffect } from 'react';
import { CartItem, PaymentMethod, Product, UserAccount, Sale } from '../types';
import { recordSale, addUtangRecord, isReferenceNoUsed, addSecurityLog } from '../utils/storage';
import { playSuccessChime } from '../utils/sound';
import { getLanguage, t, LANG_CHANGE_EVENT, Language } from '../utils/language';
import confetti from 'canvas-confetti';
import { ShoppingBag, Trash2, Plus, Minus, CreditCard, DollarSign, ArrowRight, Tag, X, CheckCircle, Calculator, BookOpen, User, QrCode, AlertTriangle, ShieldCheck } from 'lucide-react';
import { EWalletQrModal } from './EWalletQrModal';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  activeUser: UserAccount;
  onSaleCompleted: (sale: Sale) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  activeUser,
  onSaleCompleted,
}) => {
  const [discountAmount, setDiscountAmount] = useState<string>('0');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash');
  const [cashReceived, setCashReceived] = useState<string>('');
  const [referenceNo, setReferenceNo] = useState<string>('');
  const [utangCustomerName, setUtangCustomerName] = useState<string>('');
  const [utangPhone, setUtangPhone] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [isQrModalOpen, setIsQrModalOpen] = useState<boolean>(false);
  const [lang, setLang] = useState<Language>(getLanguage());

  useEffect(() => {
    const handleLangChange = () => setLang(getLanguage());
    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
  }, []);

  if (!isOpen) return null;

  const isTl = lang === 'tl';

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discount = Math.min(subtotal, Math.max(0, parseFloat(discountAmount) || 0));
  const finalTotal = Math.max(0, subtotal - discount);

  const parsedCash = parseFloat(cashReceived) || 0;
  const change = Math.max(0, parsedCash - finalTotal);
  const isCashInsufficient = paymentMethod === 'Cash' && parsedCash < finalTotal;
  const isUtangInvalid = paymentMethod === 'Utang' && !utangCustomerName.trim();
  const isEWalletMethod = paymentMethod === 'GCash' || paymentMethod === 'Maya';
  const isReferenceDuplicate = isEWalletMethod && referenceNo.trim() ? isReferenceNoUsed(referenceNo.trim()) : false;

  const handleCheckout = () => {
    if (cart.length === 0) return;
    if (paymentMethod === 'Cash' && isCashInsufficient) return;
    if (paymentMethod === 'Utang' && isUtangInvalid) return;
    if (isEWalletMethod && isReferenceDuplicate) return;

    setIsProcessing(true);

    setTimeout(() => {
      const sale = recordSale({
        items: cart,
        subtotal,
        discount,
        totalAmount: finalTotal,
        paymentMethod,
        cashReceived: paymentMethod === 'Cash' ? parsedCash : undefined,
        change: paymentMethod === 'Cash' ? change : undefined,
        referenceNo: paymentMethod === 'Utang' ? `UTANG-${utangCustomerName.trim()}` : referenceNo.trim() || undefined,
        cashierId: activeUser.id,
        cashierName: activeUser.name,
      });

      // Audit Log for Security
      addSecurityLog(
        'SALE_RECORDED',
        `Kinompleto ang benta (Receipt #${sale.receiptNo}) - ₱${finalTotal.toFixed(2)} via ${paymentMethod}${referenceNo ? ` [Ref: ${referenceNo}]` : ''}`,
        'INFO'
      );

      // If payment is Utang, create corresponding record in Utang Ledger
      if (paymentMethod === 'Utang') {
        const itemSummaryStr = cart.map((c) => `${c.quantity}x ${c.product.name}`).join(', ');
        addUtangRecord({
          customerName: utangCustomerName.trim(),
          customerPhone: utangPhone.trim() || undefined,
          itemsSummary: itemSummaryStr,
          totalAmount: finalTotal,
          saleReceiptNo: sale.receiptNo,
        });
      }

      playSuccessChime();

      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (e) {
        // ignore
      }

      setIsProcessing(false);
      onClearCart();
      onClose();
      onSaleCompleted(sale);
    }, 300);
  };


  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex justify-end">
      <div className="w-full max-w-md bg-white border-l border-slate-200/80 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="bg-slate-50 px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">{t('cartTitle')}</h3>
              <p className="text-[11px] text-slate-500">{cart.length} {t('itemsInCart')}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <ShoppingBag className="w-12 h-12 stroke-1 mb-2 opacity-50 text-slate-300" />
              <p className="text-sm font-bold text-slate-800">{t('emptyCart')}</p>
              <p className="text-xs text-slate-500 mt-1 max-w-xs">
                {t('emptyCartSub')}
              </p>
            </div>
          ) : (
            cart.map((item) => (
              <div
                key={item.product.id}
                className="bg-slate-50 border border-slate-200 rounded-2xl p-3 flex items-center gap-3"
              >
                <img
                  src={item.product.imageUrl || undefined}
                  alt={item.product.name}
                  className="w-12 h-12 rounded-xl object-cover bg-slate-200 border border-slate-200 flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold text-slate-900 truncate">{item.product.name}</h4>
                  <p className="text-[11px] text-indigo-600 font-bold">
                    ₱{item.product.price.toFixed(2)} x {item.quantity} = ₱
                    {(item.product.price * item.quantity).toFixed(2)}
                  </p>
                </div>

                {/* Quantity Controls */}
                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => onUpdateQuantity(item.product.id, -1)}
                    className="w-6 h-6 rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 flex items-center justify-center font-bold text-xs"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="w-6 text-center text-xs font-bold text-slate-900">{item.quantity}</span>
                  <button
                    onClick={() => onUpdateQuantity(item.product.id, 1)}
                    disabled={item.quantity >= item.product.stock}
                    className="w-6 h-6 rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 disabled:opacity-40 flex items-center justify-center font-bold text-xs"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => onRemoveItem(item.product.id)}
                    className="w-6 h-6 ml-1 text-slate-400 hover:text-rose-600 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Checkout Form & Summary Footer */}
        {cart.length > 0 && (
          <div className="bg-slate-50 border-t border-slate-200 p-4 space-y-3">
            {/* Payment Method Selector */}
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1.5">{t('paymentMethod')}</label>
              <div className="grid grid-cols-4 gap-1.5">
                {(['Cash', 'GCash', 'Maya', 'Utang'] as PaymentMethod[]).map((method) => (
                  <button
                    key={method}
                    type="button"
                    onClick={() => setPaymentMethod(method)}
                    className={`py-2 px-1 rounded-xl text-[11px] font-extrabold border transition-all ${
                      paymentMethod === method
                        ? method === 'Utang'
                          ? 'bg-amber-500 text-slate-900 border-amber-500 shadow-xs'
                          : 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {method}
                  </button>
                ))}
              </div>
            </div>

            {/* Cash Calculator / Utang Customer Input / E-Wallet Reference */}
            {paymentMethod === 'Cash' ? (
              <div className="grid grid-cols-2 gap-2 bg-white p-2.5 rounded-2xl border border-slate-200">
                <div>
                  <label className="text-[11px] font-semibold text-slate-500 block mb-1">
                    {t('cashReceived')}
                  </label>
                  <input
                    type="number"
                    step="1"
                    value={cashReceived}
                    onChange={(e) => setCashReceived(e.target.value)}
                    placeholder={finalTotal.toFixed(0)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-indigo-600 font-bold focus:outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-500 block mb-1">{t('changeAmount')}</label>
                  <div className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-black text-emerald-600 flex items-center h-[34px]">
                    ₱{change.toFixed(2)}
                  </div>
                </div>
              </div>
            ) : paymentMethod === 'Utang' ? (
              <div className="bg-amber-50/80 p-2.5 rounded-2xl border border-amber-200 space-y-2 text-xs">
                <div>
                  <label className="font-extrabold text-amber-900 block mb-1">
                    {isTl ? 'Pangalan ng Nag-utang (Suki Name) *' : 'Customer Credit Name *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={utangCustomerName}
                    onChange={(e) => setUtangCustomerName(e.target.value)}
                    placeholder={isTl ? 'e.g. Mareng Lisa' : 'e.g. John Doe'}
                    className="w-full bg-white border border-amber-300 rounded-lg px-2.5 py-1.5 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="font-semibold text-amber-800 block mb-1">
                    {isTl ? 'Cellphone No. (Optional)' : 'Mobile Phone No. (Optional)'}
                  </label>
                  <input
                    type="text"
                    value={utangPhone}
                    onChange={(e) => setUtangPhone(e.target.value)}
                    placeholder="0917XXXXXXX"
                    className="w-full bg-white border border-amber-200 rounded-lg px-2.5 py-1.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>
            ) : (
              <div className="bg-white p-3 rounded-2xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                    {paymentMethod} {t('refNo')}
                  </label>
                  <button
                    type="button"
                    onClick={() => setIsQrModalOpen(true)}
                    className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-extrabold text-[10px] flex items-center gap-1 border border-indigo-200 shadow-2xs"
                  >
                    <QrCode className="w-3 h-3 text-indigo-600" />
                    <span>{isTl ? 'I-scan QR / Info' : 'Scan QR Code'}</span>
                  </button>
                </div>
                <input
                  type="text"
                  value={referenceNo}
                  onChange={(e) => setReferenceNo(e.target.value)}
                  placeholder="e.g. 1029 3847 5612"
                  className={`w-full border rounded-xl px-2.5 py-1.5 text-xs font-mono font-bold focus:outline-none ${
                    isReferenceDuplicate
                      ? 'bg-rose-50 border-rose-500 text-rose-800'
                      : 'bg-slate-50 border-slate-200 text-slate-900 focus:border-indigo-600'
                  }`}
                />
                {isReferenceDuplicate && (
                  <p className="text-[10px] text-rose-600 font-extrabold flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 text-rose-600 shrink-0" />
                    {isTl ? 'Ginamit na ang Ref No. na ito sa nakaraang benta!' : 'This Ref No. has already been used!'}
                  </p>
                )}
              </div>
            )}

            {/* E-Wallet QR Modal */}
            <EWalletQrModal
              isOpen={isQrModalOpen}
              onClose={() => setIsQrModalOpen(false)}
              paymentMethod={paymentMethod}
              amount={finalTotal}
              onConfirmRefNo={(ref) => setReferenceNo(ref)}
            />

            {/* Discount Option */}
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-600 flex items-center gap-1 font-semibold">
                <Tag className="w-3.5 h-3.5 text-amber-500" /> {t('discount')} (₱):
              </span>
              <input
                type="number"
                min="0"
                value={discountAmount}
                onChange={(e) => setDiscountAmount(e.target.value)}
                className="w-20 bg-white border border-slate-200 rounded-lg px-2 py-1 text-right text-xs text-amber-600 font-bold focus:outline-none focus:border-indigo-600"
              />
            </div>

            {/* Calculation Breakdown */}
            <div className="space-y-1 text-xs pt-2 border-t border-slate-200">
              <div className="flex justify-between text-slate-500">
                <span>{t('subtotal')}:</span>
                <span>₱{subtotal.toFixed(2)}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-amber-600 font-medium">
                  <span>{t('discount')}:</span>
                  <span>-₱{discount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-base font-black text-slate-900 pt-1">
                <span>{t('total')}:</span>
                <span className="text-indigo-600">₱{finalTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* Complete Sale Button */}
            <button
              onClick={handleCheckout}
              disabled={isProcessing || (paymentMethod === 'Cash' && isCashInsufficient) || isReferenceDuplicate}
              className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md shadow-indigo-100 active:scale-98 transition-all"
            >
              {isProcessing ? (
                <span>{isTl ? 'Kino-kompleto ang Benta...' : 'Completing Sale...'}</span>
              ) : (
                <>
                  <CheckCircle className="w-5 h-5 text-white" />
                  <span>{t('completeSale')} (₱{finalTotal.toFixed(2)})</span>
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

