import React, { useState } from 'react';
import { Send, Smartphone, Monitor, ArrowUpRight, Zap, RefreshCw } from 'lucide-react';
import { ReleaseDataModal } from './ReleaseDataModal';

interface ReleaseDataButtonProps {
  variant?: 'header' | 'portal' | 'toolbar' | 'compact' | 'pair';
  target?: 'to-mobile' | 'to-desktop' | 'auto';
  accountId?: string;
  className?: string;
}

export const ReleaseDataButton: React.FC<ReleaseDataButtonProps> = ({
  variant = 'header',
  target = 'auto',
  accountId,
  className = '',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTarget, setSelectedTarget] = useState<'desktop' | 'mobile'>(
    target === 'to-mobile' ? 'mobile' : target === 'to-desktop' ? 'desktop' : 'mobile'
  );

  const openWithTarget = (t: 'desktop' | 'mobile') => {
    setSelectedTarget(t);
    setIsOpen(true);
  };

  // Pair variant: Renders two clean buttons side by side
  if (variant === 'pair') {
    return (
      <div className={`flex items-center gap-1.5 ${className}`}>
        <button
          type="button"
          onClick={() => openWithTarget('mobile')}
          className="flex items-center gap-1.5 px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-full text-[10px] sm:text-[11px] font-black tracking-wide bg-gradient-to-r from-teal-600 to-emerald-600 text-white hover:opacity-95 transition-all shadow-sm active:scale-95 cursor-pointer border border-emerald-400/30 shrink-0"
          title="Release Data for Mobile Device: Ipadala ang data mula computer sa mobile phone"
        >
          <Smartphone className="w-3.5 h-3.5 text-emerald-200 animate-pulse" />
          <span className="hidden md:inline">Release for Mobile</span>
          <span className="md:hidden">For Mobile</span>
        </button>

        <button
          type="button"
          onClick={() => openWithTarget('desktop')}
          className="flex items-center gap-1.5 px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-full text-[10px] sm:text-[11px] font-black tracking-wide bg-gradient-to-r from-indigo-600 to-cyan-600 text-white hover:opacity-95 transition-all shadow-sm active:scale-95 cursor-pointer border border-cyan-400/30 shrink-0"
          title="Release Data to Desktop: Ipadala ang mobile data sa desktop computer"
        >
          <Monitor className="w-3.5 h-3.5 text-cyan-200" />
          <span className="hidden md:inline">Release to Desktop</span>
          <span className="md:hidden">To PC</span>
        </button>

        <ReleaseDataModal
          isOpen={isOpen}
          onClose={() => setIsOpen(false)}
          accountId={accountId}
          defaultTarget={selectedTarget}
        />
      </div>
    );
  }

  if (variant === 'portal') {
    return (
      <>
        <div className={`flex items-center gap-2 ${className}`}>
          {/* Release for Mobile Device Button */}
          <button
            type="button"
            onClick={() => openWithTarget('mobile')}
            className="group flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-2xl bg-gradient-to-r from-teal-600 via-emerald-600 to-cyan-600 hover:from-teal-500 hover:to-emerald-500 text-white font-black text-xs shadow-lg shadow-teal-500/25 transition-all active:scale-95 cursor-pointer border border-emerald-400/40 relative overflow-hidden"
            title="Release Data for Mobile Device: I-load ang desktop data sa Mobile Phone"
          >
            <div className="flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-emerald-200 group-hover:scale-110 transition-transform" />
              <span className="tracking-wide">Release for Mobile</span>
            </div>
            <span className="px-1.5 py-0.5 rounded-full bg-white/20 text-[9px] font-mono uppercase">
              PC &rarr; Phone
            </span>
          </button>

          {/* Release to Desktop Computer Button */}
          <button
            type="button"
            onClick={() => openWithTarget('desktop')}
            className="group flex items-center gap-2 px-3 sm:px-3.5 py-2 rounded-2xl bg-gradient-to-r from-indigo-600 via-cyan-600 to-teal-600 hover:from-indigo-500 hover:to-teal-500 text-white font-black text-xs shadow-lg shadow-indigo-500/25 transition-all active:scale-95 cursor-pointer border border-cyan-400/40 relative overflow-hidden"
            title="Release Data to Desktop: I-load ang mobile data sa Desktop Computer"
          >
            <div className="flex items-center gap-1.5">
              <Monitor className="w-4 h-4 text-cyan-200 group-hover:scale-110 transition-transform" />
              <span className="tracking-wide">Release to PC</span>
            </div>
            <span className="px-1.5 py-0.5 rounded-full bg-white/20 text-[9px] font-mono uppercase">
              Phone &rarr; PC
            </span>
          </button>
        </div>

        <ReleaseDataModal
          isOpen={isOpen}
          onClose={() => setIsOpen(false)}
          accountId={accountId}
          defaultTarget={selectedTarget}
        />
      </>
    );
  }

  if (variant === 'toolbar') {
    return (
      <>
        <div className={`flex items-center gap-1.5 ${className}`}>
          <button
            type="button"
            onClick={() => openWithTarget('mobile')}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-xs shadow-sm transition-all active:scale-95 cursor-pointer border border-emerald-400/30"
            title="Release Data for Mobile Device: I-load ang data sa mobile phone"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-200" />
            <span>Release for Mobile</span>
          </button>

          <button
            type="button"
            onClick={() => openWithTarget('desktop')}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-bold text-xs shadow-sm transition-all active:scale-95 cursor-pointer border border-cyan-400/30"
            title="Release Data to Desktop Computer"
          >
            <Monitor className="w-3.5 h-3.5 text-cyan-200" />
            <span>Release to PC</span>
          </button>
        </div>

        <ReleaseDataModal
          isOpen={isOpen}
          onClose={() => setIsOpen(false)}
          accountId={accountId}
          defaultTarget={selectedTarget}
        />
      </>
    );
  }

  if (variant === 'compact') {
    return (
      <>
        <button
          type="button"
          onClick={() => openWithTarget(target === 'to-mobile' ? 'mobile' : 'desktop')}
          className={`p-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 border border-indigo-500/30 transition-all active:scale-95 cursor-pointer ${className}`}
          title={target === 'to-mobile' ? 'Release Data for Mobile Device' : 'Release Data to Desktop'}
        >
          {target === 'to-mobile' ? (
            <Smartphone className="w-4 h-4 text-emerald-400" />
          ) : (
            <Send className="w-4 h-4 text-cyan-400" />
          )}
        </button>

        <ReleaseDataModal
          isOpen={isOpen}
          onClose={() => setIsOpen(false)}
          accountId={accountId}
          defaultTarget={selectedTarget}
        />
      </>
    );
  }

  // Default: Header pill button
  return (
    <>
      <div className={`flex items-center gap-1.5 shrink-0 ${className}`}>
        {/* Release for Mobile Button */}
        <button
          type="button"
          onClick={() => openWithTarget('mobile')}
          className="inline-flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-full text-[10px] sm:text-[11px] font-black tracking-wide bg-gradient-to-r from-teal-600 to-emerald-600 text-white hover:opacity-95 transition-all shadow-sm active:scale-95 cursor-pointer border border-emerald-400/30 shrink-0"
          title="Release Data for Mobile Device: I-load ang computer data sa iyong mobile phone"
        >
          <Smartphone className="w-3 h-3 text-emerald-200 animate-pulse" />
          <span className="hidden sm:inline">Release for Mobile</span>
          <span className="sm:hidden">For Mobile</span>
        </button>

        {/* Release to Desktop Button */}
        <button
          type="button"
          onClick={() => openWithTarget('desktop')}
          className="inline-flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-full text-[10px] sm:text-[11px] font-black tracking-wide bg-gradient-to-r from-indigo-600 via-cyan-600 to-teal-500 text-white hover:opacity-95 transition-all shadow-sm active:scale-95 cursor-pointer border border-cyan-400/30 shrink-0"
          title="Release Data to Desktop: I-load ang mobile data sa desktop computer"
        >
          <Monitor className="w-3 h-3 text-cyan-200" />
          <span className="hidden sm:inline">Release to PC</span>
          <span className="sm:hidden">To PC</span>
        </button>
      </div>

      <ReleaseDataModal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        accountId={accountId}
        defaultTarget={selectedTarget}
      />
    </>
  );
};
