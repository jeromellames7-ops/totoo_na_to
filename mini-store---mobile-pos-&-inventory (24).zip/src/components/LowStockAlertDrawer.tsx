import React from 'react';
import { LowStockAlert, Product } from '../types';
import { markAlertAsRead } from '../utils/storage';
import { AlertTriangle, X, RefreshCw, Bell, ArrowRight, Package } from 'lucide-react';

interface LowStockAlertDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  alerts: LowStockAlert[];
  products: Product[];
  onRestockProduct: (product: Product) => void;
}

export const LowStockAlertDrawer: React.FC<LowStockAlertDrawerProps> = ({
  isOpen,
  onClose,
  alerts,
  products,
  onRestockProduct,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex justify-end">
      <div className="w-full max-w-sm bg-white border-l border-slate-200/80 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="bg-amber-50 px-5 py-4 border-b border-amber-200/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Low Stock Reminders</h3>
              <p className="text-[11px] text-amber-700 font-semibold">
                {alerts.length} mga paninda na kailangang i-reorder
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-amber-100/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Alerts List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {alerts.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <Package className="w-12 h-12 stroke-1 mb-2 text-indigo-600 opacity-60" />
              <p className="text-sm font-bold text-slate-800">Sapat ang Lahat ng Stock!</p>
              <p className="text-xs text-slate-500 mt-1">Walang mga paninda na mababa ang stock ngayon.</p>
            </div>
          ) : (
            alerts.map((alert) => {
              const product = products.find((p) => p.id === alert.productId);
              return (
                <div
                  key={alert.id}
                  className="bg-amber-50/50 border border-amber-200 rounded-2xl p-3 flex flex-col justify-between space-y-2 shadow-xs"
                >
                  <div className="flex items-start gap-3">
                    {product && (
                      <img
                        src={product.imageUrl || undefined}
                        alt={product.name}
                        className="w-10 h-10 rounded-xl object-cover bg-white border border-slate-200 flex-shrink-0"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-slate-900 truncate">{alert.productName}</h4>
                      <div className="flex items-center gap-2 mt-0.5 text-[11px]">
                        <span className="text-amber-700 font-bold">
                          {alert.currentStock === 0 ? 'Out of Stock (0 pcs)' : `${alert.currentStock} pcs nalang natira`}
                        </span>
                        <span className="text-slate-400">• Limit: {alert.threshold} pcs</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-amber-200/60">
                    <span className="text-[10px] text-slate-400">
                      Reminded {new Date(alert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>

                    {product && (
                      <button
                        onClick={() => {
                          markAlertAsRead(alert.productId);
                          onRestockProduct(product);
                          onClose();
                        }}
                        className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg shadow-xs flex items-center gap-1 active:scale-95 transition-all"
                      >
                        <RefreshCw className="w-3 h-3" /> Restock Now
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
