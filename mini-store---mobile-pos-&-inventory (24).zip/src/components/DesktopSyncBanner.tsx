import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  CheckCircle2,
  X,
  ShoppingBag,
  FileText,
  Printer,
  Home,
  Monitor,
} from 'lucide-react';
import {
  DesktopReleaseSignal,
  initDesktopReleaseListener,
  DESKTOP_DATA_RECEIVED_EVENT,
  MOBILE_DATA_RECEIVED_EVENT,
  CROSS_DEVICE_DATA_RECEIVED_EVENT,
} from '../utils/desktopReleaseSync';

export const DesktopSyncBanner: React.FC = () => {
  const [activeSignal, setActiveSignal] = useState<DesktopReleaseSignal | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // 1. Initialize global listener
    initDesktopReleaseListener((signal) => {
      setActiveSignal(signal);
      setIsVisible(true);
    });

    // 2. Listen to custom window events
    const handleReceived = (e: any) => {
      if (e.detail) {
        setActiveSignal(e.detail);
        setIsVisible(true);
      }
    };

    window.addEventListener(DESKTOP_DATA_RECEIVED_EVENT, handleReceived);
    window.addEventListener(MOBILE_DATA_RECEIVED_EVENT, handleReceived);
    window.addEventListener(CROSS_DEVICE_DATA_RECEIVED_EVENT, handleReceived);

    return () => {
      window.removeEventListener(DESKTOP_DATA_RECEIVED_EVENT, handleReceived);
      window.removeEventListener(MOBILE_DATA_RECEIVED_EVENT, handleReceived);
      window.removeEventListener(CROSS_DEVICE_DATA_RECEIVED_EVENT, handleReceived);
    };
  }, []);

  // Auto-dismiss after 9 seconds
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        setIsVisible(false);
      }, 9000);
      return () => clearTimeout(timer);
    }
  }, [isVisible]);

  if (!isVisible || !activeSignal) return null;

  const summary = activeSignal.summary;
  const isMobileTarget = activeSignal.targetDevice === 'mobile';

  return (
    <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 w-full max-w-xl px-3 animate-in slide-in-from-top duration-300">
      <div className={`bg-gradient-to-r ${
        isMobileTarget
          ? 'from-slate-950 via-teal-950 to-slate-950 border-teal-400/60'
          : 'from-slate-950 via-indigo-950 to-slate-950 border-cyan-400/60'
      } border-2 rounded-2xl shadow-2xl p-3.5 text-white flex items-center justify-between gap-3 backdrop-blur-xl`}>
        <div className="flex items-center gap-3 min-w-0">
          <div className={`w-10 h-10 rounded-xl ${
            isMobileTarget ? 'bg-teal-500/20 border-teal-400/40 text-teal-300' : 'bg-cyan-500/20 border-cyan-400/40 text-cyan-300'
          } border flex items-center justify-center shrink-0`}>
            {isMobileTarget ? (
              <Smartphone className="w-5 h-5 animate-bounce text-emerald-300" />
            ) : (
              <Monitor className="w-5 h-5 animate-pulse text-cyan-300" />
            )}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`text-xs font-black ${isMobileTarget ? 'text-teal-300' : 'text-cyan-300'} flex items-center gap-1`}>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 inline" />
                {isMobileTarget
                  ? 'Natanggap ang Data mula sa Desktop Computer!'
                  : 'Natanggap ang Data mula sa Mobile Device!'}
              </span>
              <span className={`text-[9px] font-mono font-bold px-2 py-0.2 rounded-full ${
                isMobileTarget ? 'bg-teal-500/20 text-teal-300 border-teal-500/30' : 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
              } border`}>
                {activeSignal.deviceName || (isMobileTarget ? 'Desktop Computer' : 'Mobile Phone')}
              </span>
            </div>

            <p className="text-[11px] text-slate-300 truncate mt-0.5">
              {isMobileTarget
                ? 'Awtomatikong na-load at na-update ang mga table sheets, products, at records sa iyong Mobile Device.'
                : 'Awtomatikong na-load at na-update ang mga table sheets, products, at records sa Desktop Computer.'}
            </p>

            {/* Quick mini metrics */}
            {summary && (
              <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-400 flex-wrap">
                {summary.extractedDocsCount > 0 && (
                  <span className="flex items-center gap-1 text-amber-300">
                    <FileText className="w-3 h-3" /> {summary.extractedDocsCount} Docs
                  </span>
                )}
                {summary.productsCount > 0 && (
                  <span className="flex items-center gap-1 text-indigo-300">
                    <ShoppingBag className="w-3 h-3" /> {summary.productsCount} POS
                  </span>
                )}
                {summary.printProjectsCount > 0 && (
                  <span className="flex items-center gap-1 text-cyan-300">
                    <Printer className="w-3 h-3" /> {summary.printProjectsCount} Prints
                  </span>
                )}
                {summary.billsCount > 0 && (
                  <span className="flex items-center gap-1 text-emerald-300">
                    <Home className="w-3 h-3" /> {summary.billsCount} Bills
                  </span>
                )}
              </div>
            )}
          </div>
        </div>

        <button
          onClick={() => setIsVisible(false)}
          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors shrink-0 cursor-pointer"
          title="Isara"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
