import React from 'react';
import { Sale } from '../types';
import { X, Printer, CheckCircle2, Share2, Store, Barcode } from 'lucide-react';

interface ReceiptModalProps {
  sale: Sale | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ sale, isOpen, onClose }) => {
  if (!isOpen || !sale) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-sm bg-white border border-slate-200/80 rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-indigo-600 px-4 py-3 text-white flex items-center justify-between font-bold text-sm">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-white fill-indigo-400" />
            <span>Sales Receipt</span>
          </div>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-white/10 transition-colors">
            <X className="w-4 h-4 text-white" />
          </button>
        </div>

        {/* Receipt Visual Body (Thermal Receipt Look) */}
        <div className="p-5 bg-white text-slate-900 font-mono text-xs space-y-3 print:p-0 select-text">
          {/* Store Logo & Info */}
          <div className="text-center pb-2 border-b border-dashed border-slate-300">
            <h2 className="font-extrabold text-base tracking-tight uppercase text-indigo-950">TindahanPOS</h2>
            <p className="text-[10px] text-slate-600 font-sans">Official Store Sales Receipt</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Receipt #: {sale.receiptNo}</p>
            <p className="text-[10px] text-slate-500">
              Date: {new Date(sale.timestamp).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })}
            </p>
            <p className="text-[10px] text-slate-500">Cashier: {sale.cashierName}</p>
          </div>

          {/* Items Table */}
          <div className="space-y-1.5 py-1">
            <div className="grid grid-cols-6 font-bold text-[10px] border-b border-slate-300 pb-1">
              <span className="col-span-3">ITEM</span>
              <span className="col-span-1 text-center font-bold">QTY</span>
              <span className="col-span-2 text-right">TOTAL</span>
            </div>

            {sale.items.map((item, idx) => (
              <div key={idx} className="grid grid-cols-6 text-[10px]">
                <span className="col-span-3 font-sans font-semibold text-slate-800 truncate">
                  {item.product.name}
                </span>
                <span className="col-span-1 text-center font-bold">{item.quantity}</span>
                <span className="col-span-2 text-right font-bold">
                  ₱{(item.product.price * item.quantity).toFixed(2)}
                </span>
              </div>
            ))}
          </div>

          {/* Calculations */}
          <div className="pt-2 border-t border-dashed border-slate-300 space-y-1 text-[11px]">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span>₱{sale.subtotal.toFixed(2)}</span>
            </div>
            {sale.discount > 0 && (
              <div className="flex justify-between text-rose-600">
                <span>Discount:</span>
                <span>-₱{sale.discount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between font-black text-sm pt-1 border-t border-slate-300">
              <span>TOTAL AMOUNT:</span>
              <span className="text-indigo-600">₱{sale.totalAmount.toFixed(2)}</span>
            </div>

            {/* Payment Details */}
            <div className="pt-1 text-[10px] text-slate-600 space-y-0.5">
              <div className="flex justify-between">
                <span>Payment Method:</span>
                <span className="font-bold">{sale.paymentMethod}</span>
              </div>

              {sale.paymentMethod === 'Cash' && (
                <>
                  <div className="flex justify-between">
                    <span>Cash Received:</span>
                    <span>₱{(sale.cashReceived || sale.totalAmount).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-slate-900">
                    <span>Change:</span>
                    <span>₱{(sale.change || 0).toFixed(2)}</span>
                  </div>
                </>
              )}

              {sale.referenceNo && (
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span>Ref No:</span>
                    <span className="font-mono font-bold">{sale.referenceNo}</span>
                  </div>
                  {(sale.paymentMethod === 'GCash' || sale.paymentMethod === 'Maya') && (
                    <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-1.5 rounded-lg text-[9px] font-sans font-bold text-center flex items-center justify-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>VERIFIED ONLINE E-WALLET PAYMENT</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Footer Barcode */}
          <div className="text-center pt-3 border-t border-dashed border-slate-300">
            <div className="w-36 h-8 mx-auto bg-slate-900 flex items-center justify-center text-white rounded">
              <span className="font-mono text-[10px] tracking-widest">||| | |||| | |||||</span>
            </div>
            <p className="text-[9px] text-slate-500 mt-1 font-sans">
              Thank you for your purchase! Please come again!
            </p>
          </div>
        </div>

        {/* Buttons */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex gap-2">
          <button
            onClick={handlePrint}
            className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 border border-slate-200 transition-colors"
          >
            <Printer className="w-4 h-4 text-indigo-600" /> Print Receipt
          </button>
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-indigo-100 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
