import React, { useState, useEffect } from 'react';
import { Product, UserAccount } from '../types';
import { deleteProduct, restockProduct } from '../utils/storage';
import { getLanguage, t, LANG_CHANGE_EVENT } from '../utils/language';
import { Search, Plus, Filter, Edit, Trash2, PackageCheck, RefreshCw, Barcode, QrCode, Printer, AlertTriangle, FileSpreadsheet, Database } from 'lucide-react';
import { FormatDataModal } from './FormatDataModal';
import { BackupRestoreModal } from './BackupRestoreModal';

interface InventoryListProps {
  products: Product[];
  activeUser: UserAccount;
  onOpenAddProduct: () => void;
  onEditProduct: (product: Product) => void;
  onRequestAdminPin: (onSuccess: () => void) => void;
  onSelectProductForCheckout: (product: Product) => void;
  onOpenPrintQrSheet: () => void;
  onOpenCsvModal?: () => void;
  targetAccountId?: string;
}

export const InventoryList: React.FC<InventoryListProps> = ({
  products,
  activeUser,
  onOpenAddProduct,
  onEditProduct,
  onRequestAdminPin,
  onSelectProductForCheckout,
  onOpenPrintQrSheet,
  onOpenCsvModal,
  targetAccountId,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [stockFilter, setStockFilter] = useState<'ALL' | 'LOW' | 'OUT'>('ALL');
  const [restockModalProduct, setRestockModalProduct] = useState<Product | null>(null);
  const [restockAmount, setRestockAmount] = useState<string>('10');
  const [isFormatModalOpen, setIsFormatModalOpen] = useState(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [, setLangState] = useState(getLanguage());

  useEffect(() => {
    const handleLangChange = () => setLangState(getLanguage());
    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
  }, []);

  const categories = ['ALL', ...Array.from(new Set(products.map((p) => p.category)))];

  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.barcode.includes(searchTerm) ||
      p.category.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory = selectedCategory === 'ALL' || p.category === selectedCategory;

    let matchesStock = true;
    if (stockFilter === 'LOW') {
      matchesStock = p.stock > 0 && p.stock <= p.lowStockThreshold;
    } else if (stockFilter === 'OUT') {
      matchesStock = p.stock <= 0;
    }

    return matchesSearch && matchesCategory && matchesStock;
  });

  const handleDelete = (productId: string) => {
    if (activeUser.role !== 'Admin') {
      onRequestAdminPin(() => {
        if (confirm('Sigurado ka bang gusto mong idelete ang produktong ito?')) {
          deleteProduct(productId, targetAccountId);
        }
      });
    } else {
      if (confirm('Sigurado ka bang gusto mong idelete ang produktong ito?')) {
        deleteProduct(productId, targetAccountId);
      }
    }
  };

  const handleRestockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (restockModalProduct && restockAmount) {
      const qty = parseInt(restockAmount, 10);
      if (qty > 0) {
        restockProduct(restockModalProduct.id, qty, targetAccountId);
        setRestockModalProduct(null);
      }
    }
  };

  return (
    <div className="space-y-4 pb-40 sm:pb-44 max-w-4xl mx-auto">
      {/* Top Action Header */}
      <div className="flex flex-col lg:flex-row gap-3 items-start lg:items-center justify-between bg-white border border-slate-200/80 p-3.5 sm:p-4 rounded-3xl shadow-xs overflow-visible">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <PackageCheck className="w-5 h-5 text-indigo-600 shrink-0" />
            <span>{t('inventoryTitle')}</span>
          </h2>
          <p className="text-xs text-slate-500">{t('inventorySubtitle')}</p>
        </div>

        <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2 w-full lg:w-auto">
          {/* Format Database Button (PIN 1234 Protection) */}
          <button
            onClick={() => setIsFormatModalOpen(true)}
            className="py-2.5 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-all active:scale-95 w-full sm:w-auto"
            title="Format database & delete all products (PIN 1234 required)"
          >
            <Trash2 className="w-4 h-4 text-rose-600 shrink-0" />
            <span className="whitespace-nowrap">Format Data</span>
          </button>

          {/* Backup & Restore Data Button */}
          <button
            onClick={() => setIsBackupModalOpen(true)}
            className="py-2.5 px-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-all active:scale-95 w-full sm:w-auto"
            title="Tingnan at i-restore ang mga na-delete/na-format na data"
          >
            <Database className="w-4 h-4 text-indigo-600 shrink-0" />
            <span className="whitespace-nowrap">Backup / Restore</span>
          </button>

          {/* CSV/Excel Import/Export Button */}
          {onOpenCsvModal && (
            <button
              onClick={onOpenCsvModal}
              className="py-2.5 px-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-all active:scale-95 w-full sm:w-auto"
              title="Bulk Import / Export products via Excel/CSV"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="whitespace-nowrap">Excel / CSV</span>
            </button>
          )}

          {/* Add New Product Button */}
          <button
            onClick={onOpenAddProduct}
            className="py-2.5 px-3.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md shadow-indigo-100 flex items-center justify-center gap-1.5 active:scale-95 transition-all w-full sm:w-auto col-span-2 sm:col-span-1"
          >
            <Plus className="w-4 h-4 stroke-[3px] shrink-0" />
            <span className="whitespace-nowrap">{t('addProduct')}</span>
          </button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white border border-slate-200/80 p-3.5 rounded-3xl shadow-xs space-y-3">
        <div className="flex flex-col xs:flex-row gap-2">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t('searchProduct')}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-indigo-600 focus:bg-white"
            />
          </div>

          {/* Low Stock quick toggle */}
          <div className="flex bg-slate-100 border border-slate-200 rounded-xl p-1 gap-1 shrink-0">
            <button
              onClick={() => setStockFilter('ALL')}
              className={`flex-1 xs:flex-initial px-3 py-1 text-[11px] font-bold rounded-lg transition-colors ${
                stockFilter === 'ALL' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setStockFilter('LOW')}
              className={`flex-1 xs:flex-initial px-3 py-1 text-[11px] font-bold rounded-lg transition-colors ${
                stockFilter === 'LOW' ? 'bg-orange-500 text-white shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              Low Stock
            </button>
          </div>
        </div>

        {/* Categories Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1 pr-1 shrink-0">
            <Filter className="w-3 h-3" /> Cat:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 text-[11px] font-semibold rounded-full whitespace-nowrap border transition-all ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {filteredProducts.length === 0 ? (
          <div className="col-span-full bg-white border border-slate-200/80 rounded-3xl p-8 text-center text-slate-500 shadow-xs">
            <PackageCheck className="w-12 h-12 stroke-1 mx-auto mb-2 text-slate-300" />
            <p className="text-sm font-bold text-slate-800">Walang nahanap na produkto</p>
            <p className="text-xs text-slate-500 mt-1">
              Subukang baguhin ang search term o i-click ang &quot;{t('addProduct')}&quot;.
            </p>
          </div>
        ) : (
          filteredProducts.map((product) => {
            const isOutOfStock = product.stock <= 0;
            const isLowStock = product.stock > 0 && product.stock <= product.lowStockThreshold;

            const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(
              product.barcode
            )}`;

            return (
              <div
                key={product.id}
                className={`bg-white border ${
                  isOutOfStock
                    ? 'border-rose-200 bg-rose-50/40'
                    : isLowStock
                    ? 'border-orange-200 bg-orange-50/40'
                    : 'border-slate-200/80'
                } rounded-2xl p-3 flex flex-col justify-between gap-3 hover:border-indigo-200 transition-all shadow-xs group min-w-0 overflow-hidden relative`}
              >
                {/* Top Main Section: Image + Barcode, Title & Price */}
                <div className="flex gap-3 items-start min-w-0">
                  {/* Product Image */}
                  <div
                    onClick={() => onSelectProductForCheckout(product)}
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0 cursor-pointer relative group-hover:scale-105 transition-transform"
                  >
                    <img
                      src={product.imageUrl || undefined}
                      alt={product.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src =
                          'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&auto=format&fit=crop&q=80';
                      }}
                    />
                    {isOutOfStock ? (
                      <span className="absolute inset-0 bg-slate-900/80 text-rose-300 text-[8px] sm:text-[9px] font-black uppercase flex items-center justify-center p-0.5 text-center leading-tight">
                        OUT OF STOCK
                      </span>
                    ) : isLowStock ? (
                      <span className="absolute bottom-0 inset-x-0 bg-orange-500 text-white text-[8px] font-bold text-center py-0.5">
                        LOW STOCK
                      </span>
                    ) : null}
                  </div>

                  {/* Right Info Box */}
                  <div className="flex-1 min-w-0">
                    {/* Barcode & Price Header */}
                    <div className="flex items-center justify-between gap-1 min-w-0">
                      <span className="text-[10px] text-indigo-700 font-mono bg-indigo-50 px-1.5 py-0.5 rounded-md border border-indigo-100 flex items-center gap-1 font-bold truncate max-w-[100px] sm:max-w-[140px]">
                        <Barcode className="w-2.5 h-2.5 text-indigo-600 shrink-0" />
                        <span className="truncate">{product.barcode}</span>
                      </span>
                      <span className="text-xs sm:text-sm font-black text-indigo-600 shrink-0 whitespace-nowrap ml-auto">
                        ₱{product.price.toFixed(2)}
                      </span>
                    </div>

                    {/* Title */}
                    <div className="mt-1">
                      <span
                        onClick={() => onSelectProductForCheckout(product)}
                        className="inline-block bg-amber-200/90 text-slate-950 font-black tracking-wide uppercase text-xs sm:text-xs px-2 py-0.5 rounded-md border border-amber-300/80 shadow-2xs leading-snug cursor-pointer hover:bg-amber-300 transition-colors line-clamp-2"
                      >
                        {product.name}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Bottom Action Footer Bar inside Card */}
                <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 min-w-0 bg-slate-50/70 -mx-3 -mb-3 p-2.5 rounded-b-2xl">
                  {/* Left: Stock Qty & QR preview */}
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="text-[10px] sm:text-[11px] whitespace-nowrap">
                      <span className="text-slate-500">Stock: </span>
                      <span
                        className={`font-black ${
                          isOutOfStock
                            ? 'text-rose-600'
                            : isLowStock
                            ? 'text-orange-600'
                            : 'text-slate-800'
                        }`}
                      >
                        {product.stock} pcs
                      </span>
                    </div>

                    {/* QR Badge & Hover Preview */}
                    <div className="group/qr relative flex items-center gap-1 px-1.5 py-0.5 bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 rounded-lg cursor-pointer transition-colors shrink-0">
                      <img src={qrUrl || undefined} alt="QR" className="w-3.5 h-3.5 rounded bg-white shrink-0" />
                      <span className="text-[9px] font-bold text-slate-600 group-hover/qr:text-indigo-600 font-mono">QR</span>
                      
                      {/* Hover QR Popover */}
                      <div className="absolute bottom-full left-0 mb-1.5 hidden group-hover/qr:block bg-slate-900 text-white p-2.5 rounded-2xl shadow-2xl z-50 w-32 text-center border border-slate-700 pointer-events-none">
                        <img src={qrUrl || undefined} alt="QR Code" className="w-24 h-24 mx-auto rounded-xl bg-white p-1" />
                        <p className="text-[10px] font-mono mt-1 font-bold text-slate-200 truncate">{product.barcode}</p>
                        <p className="text-[8px] text-indigo-300 uppercase tracking-wide font-bold">Scan Barcode</p>
                      </div>
                    </div>
                  </div>

                  {/* Right: Action Buttons (+Stock, Edit, Delete) */}
                  <div className="flex items-center gap-1.5 shrink-0 ml-auto">
                    <button
                      onClick={() => setRestockModalProduct(product)}
                      className="px-2 py-1 bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] sm:text-[11px] font-bold rounded-lg shadow-xs flex items-center gap-1 transition-colors shrink-0"
                      title="Add Stock"
                    >
                      <RefreshCw className="w-3 h-3 shrink-0" />
                      <span>+Stock</span>
                    </button>

                    <button
                      onClick={() => onEditProduct(product)}
                      className="p-1.5 rounded-lg bg-white hover:bg-slate-100 text-slate-700 transition-colors border border-slate-200 shadow-xs shrink-0"
                      title="Edit Item"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => handleDelete(product.id)}
                      className="p-1.5 rounded-lg bg-white hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition-colors border border-slate-200 hover:border-rose-200 shadow-xs shrink-0"
                      title="Delete Item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Quick Restock Modal */}
      {restockModalProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-xs bg-white border border-slate-200/80 rounded-3xl p-5 shadow-2xl">
            <h3 className="text-sm font-bold text-slate-900 mb-1">Dagdagan ang Stock (Restock)</h3>
            <p className="text-xs text-slate-500 mb-3 truncate">{restockModalProduct.name}</p>

            <form onSubmit={handleRestockSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Kasalukuyang Stock: <span className="text-indigo-600 font-bold">{restockModalProduct.stock} pcs</span>
                </label>
                <input
                  type="number"
                  min="1"
                  value={restockAmount}
                  onChange={(e) => setRestockAmount(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm text-indigo-600 font-bold focus:outline-none focus:border-indigo-600"
                  placeholder="10"
                />
              </div>

              {/* Preset Addition Buttons */}
              <div className="flex gap-2">
                {[5, 10, 24, 50].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setRestockAmount(num.toString())}
                    className="flex-1 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold border border-slate-200"
                  >
                    +{num}
                  </button>
                ))}
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRestockModalProduct(null)}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold border border-slate-200"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-100"
                >
                  I-update Stock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Format Database PIN Modal */}
      <FormatDataModal
        isOpen={isFormatModalOpen}
        onClose={() => setIsFormatModalOpen(false)}
        targetAccountId={targetAccountId}
        accountName={activeUser.storeName || activeUser.name}
      />

      {/* Backup & Restore Data Modal */}
      <BackupRestoreModal
        isOpen={isBackupModalOpen}
        onClose={() => setIsBackupModalOpen(false)}
      />
    </div>
  );
};
