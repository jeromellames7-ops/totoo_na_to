import React, { useState, useEffect } from 'react';
import { Sale } from '../types';
import { getLanguage, t, LANG_CHANGE_EVENT } from '../utils/language';
import { AdminDatabaseTable } from './AdminDatabaseTable';
import { InstallApkModal } from './InstallApkModal';
import {
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
  AreaChart,
  Area,
} from 'recharts';
import { LayoutDashboard, TrendingUp, DollarSign, ShoppingBag, Award, Download, Smartphone } from 'lucide-react';

interface SalesDashboardProps {
  sales: Sale[];
  onRequestAdminPin?: (onSuccess: () => void) => void;
}

type DateRange = 'today' | 'week' | 'month' | 'all';

export const SalesDashboard: React.FC<SalesDashboardProps> = ({ sales }) => {
  const [range, setRange] = useState<DateRange>('today');
  const [, setLangState] = useState(getLanguage());
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  useEffect(() => {
    const handleLangChange = () => setLangState(getLanguage());
    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
  }, []);

  const safeSales = Array.isArray(sales) ? sales.filter(Boolean) : [];
  const now = new Date();

  // Profit Breakdown per Day, Week, and Month
  const todaySalesList = safeSales.filter((s) => {
    try {
      return s.timestamp && new Date(s.timestamp).toDateString() === now.toDateString();
    } catch {
      return false;
    }
  });
  const todayGross = todaySalesList.reduce((sum, s) => sum + (Number(s.totalAmount) || 0), 0);
  const todayProfit = todaySalesList.reduce((sum, s) => sum + (Number(s.profit) || 0), 0);

  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
  const weekSalesList = safeSales.filter((s) => {
    try {
      return s.timestamp && new Date(s.timestamp) >= oneWeekAgo;
    } catch {
      return false;
    }
  });
  const weekGross = weekSalesList.reduce((sum, s) => sum + (Number(s.totalAmount) || 0), 0);
  const weekProfit = weekSalesList.reduce((sum, s) => sum + (Number(s.profit) || 0), 0);

  const monthSalesList = safeSales.filter((s) => {
    try {
      const d = new Date(s.timestamp);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    } catch {
      return false;
    }
  });
  const monthGross = monthSalesList.reduce((sum, s) => sum + (Number(s.totalAmount) || 0), 0);
  const monthProfit = monthSalesList.reduce((sum, s) => sum + (Number(s.profit) || 0), 0);

  const filteredSales = safeSales.filter((sale) => {
    if (!sale) return false;
    try {
      const saleDate = new Date(sale.timestamp);
      if (range === 'today') {
        return saleDate.toDateString() === now.toDateString();
      } else if (range === 'week') {
        return saleDate >= oneWeekAgo;
      } else if (range === 'month') {
        return (
          saleDate.getMonth() === now.getMonth() && saleDate.getFullYear() === now.getFullYear()
        );
      }
      return true; // 'all'
    } catch {
      return true;
    }
  });

  const totalGrossSales = filteredSales.reduce((sum, s) => sum + (Number(s.totalAmount) || 0), 0);
  const totalProfit = filteredSales.reduce((sum, s) => sum + (Number(s.profit) || 0), 0);
  const totalTransactions = filteredSales.length;
  const totalItemsSold = filteredSales.reduce(
    (sum, s) =>
      sum +
      (Array.isArray(s.items)
        ? s.items.reduce((iSum, item) => iSum + (Number(item?.quantity) || 0), 0)
        : 0),
    0
  );

  const salesByDateMap: { [key: string]: number } = {};
  filteredSales.forEach((sale) => {
    try {
      const d = new Date(sale.timestamp || Date.now());
      const label =
        range === 'today'
          ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          : d.toLocaleDateString([], { month: 'short', day: 'numeric' });
      salesByDateMap[label] = (salesByDateMap[label] || 0) + (Number(sale.totalAmount) || 0);
    } catch {
      // fallback
    }
  });

  const chartData = Object.keys(salesByDateMap).map((key) => ({
    name: key,
    Sales: salesByDateMap[key],
  }));

  const paymentMap: { [key: string]: number } = { Cash: 0, GCash: 0, Maya: 0 };
  filteredSales.forEach((s) => {
    const method = s.paymentMethod || 'Cash';
    paymentMap[method] = (paymentMap[method] || 0) + (Number(s.totalAmount) || 0);
  });

  const pieData = Object.keys(paymentMap).map((key) => ({
    name: key,
    value: paymentMap[key],
  }));

  const PIE_COLORS = ['#4f46e5', '#06b6d4', '#ec4899'];

  const productSalesCount: { [name: string]: { qty: number; total: number; img: string } } = {};
  filteredSales.forEach((s) => {
    (s.items || []).forEach((item) => {
      if (!item || !item.product) return;
      const pName = item.product.name || 'Unnamed Product';
      if (!productSalesCount[pName]) {
        productSalesCount[pName] = {
          qty: 0,
          total: 0,
          img: item.product.imageUrl || '',
        };
      }
      const qty = Number(item.quantity) || 0;
      const price = Number(item.product.price) || 0;
      productSalesCount[pName].qty += qty;
      productSalesCount[pName].total += price * qty;
    });
  });

  const topProducts = Object.entries(productSalesCount)
    .map(([name, data]) => ({ name, ...data }))
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 5);

  const handleExportCSV = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += 'Receipt No,Date,Cashier,Payment Method,Subtotal,Discount,Total,Profit\n';

    filteredSales.forEach((s) => {
      csvContent += `"${s.receiptNo || ''}","${new Date(s.timestamp || Date.now()).toLocaleString()}","${s.cashierName || ''}","${s.paymentMethod || 'Cash'}",${s.subtotal || 0},${s.discount || 0},${s.totalAmount || 0},${s.profit || 0}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `MINI_STORE_SalesReport_${range}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 pb-40 sm:pb-44 max-w-4xl mx-auto">
      {/* Top Header & Range Controls */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between bg-white border border-slate-200/80 p-4 rounded-3xl shadow-xs">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
            <LayoutDashboard className="w-5 h-5 text-indigo-600" />
            <span>{t('dashboardTitle')}</span>
          </h2>
          <p className="text-xs text-slate-500">{t('dashboardSub')}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2 justify-between sm:justify-end min-w-0">
          {/* Date Selector */}
          <div className="flex bg-slate-100 border border-slate-200 rounded-xl p-1 gap-1 overflow-x-auto max-w-full min-w-0 no-scrollbar">
            {(['today', 'week', 'month', 'all'] as DateRange[]).map((r) => (
              <button
                key={r}
                onClick={() => setRange(r)}
                className={`px-2 sm:px-2.5 py-1 text-[11px] font-bold rounded-lg transition-colors capitalize whitespace-nowrap shrink-0 ${
                  range === r
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {r === 'today' ? t('rangeToday') : r === 'week' ? t('rangeWeek') : r === 'month' ? t('rangeMonth') : t('rangeAll')}
              </button>
            ))}
          </div>

          <button
            onClick={() => setIsApkModalOpen(true)}
            className="py-1.5 px-2.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold border border-indigo-200 flex items-center gap-1.5 transition-colors shadow-xs shrink-0"
            title="I-install ang Mobile App / APK"
          >
            <Smartphone className="w-4 h-4 text-indigo-600 shrink-0" />
            <span className="hidden xs:inline">App / APK</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs border border-slate-200 flex items-center gap-1 transition-colors shadow-xs shrink-0"
            title="Download CSV Report"
          >
            <Download className="w-4 h-4 text-indigo-600" />
          </button>
        </div>
      </div>

      {/* 4 Key Stat Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-indigo-600 border border-indigo-500 p-4 rounded-3xl shadow-md text-white">
          <div className="flex items-center justify-between text-indigo-100 mb-1">
            <span className="text-xs font-semibold">{t('totalGrossSales')}</span>
            <DollarSign className="w-4 h-4 text-white" />
          </div>
          <p className="text-lg sm:text-xl font-black text-white">₱{totalGrossSales.toFixed(2)}</p>
          <span className="text-[10px] text-indigo-200">Gross Sales ({range})</span>
        </div>

        <div className="bg-white border border-slate-200/80 p-4 rounded-3xl shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium text-slate-500">{t('totalNetProfit')}</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-lg sm:text-xl font-black text-emerald-600">₱{totalProfit.toFixed(2)}</p>
          <span className="text-[10px] text-slate-400">Selected Filter Net Profit</span>
        </div>

        <div className="bg-white border border-slate-200/80 p-4 rounded-3xl shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium text-slate-500">{t('totalTransactions')}</span>
            <ShoppingBag className="w-4 h-4 text-indigo-600" />
          </div>
          <p className="text-lg sm:text-xl font-black text-slate-900">{totalTransactions}</p>
          <span className="text-[10px] text-slate-400">Transactions</span>
        </div>

        <div className="bg-white border border-slate-200/80 p-4 rounded-3xl shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-medium text-slate-500">{t('totalItemsSold')}</span>
            <Award className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-lg sm:text-xl font-black text-amber-600">{totalItemsSold}</p>
          <span className="text-[10px] text-slate-400">Products sold</span>
        </div>
      </div>

      {/* Net Profit Summary (Daily, Weekly & Monthly) Breakdown */}
      <div className="bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-900 border border-emerald-700 p-4 sm:p-5 rounded-3xl shadow-lg text-white space-y-3 overflow-hidden">
        <div className="flex items-center justify-between border-b border-emerald-700/80 pb-3 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 shrink-0">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide">Net Profit Summary</h3>
              <p className="text-[11px] text-emerald-200">Real-time net earnings breakdown</p>
            </div>
          </div>
          <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-emerald-400/20 text-emerald-300 border border-emerald-400/30 uppercase tracking-wider shrink-0">
            Net Earnings
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Today Profit */}
          <div className="bg-emerald-950/60 border border-emerald-700/60 p-3.5 rounded-2xl flex flex-col justify-between space-y-2 backdrop-blur-xs overflow-hidden">
            <div className="flex items-start justify-between gap-1 text-emerald-300 text-xs font-bold min-w-0">
              <span className="truncate">Today&apos;s Profit</span>
              <span className="text-[10px] bg-emerald-500/20 px-1.5 py-0.5 rounded text-emerald-300 shrink-0 border border-emerald-500/30">
                Today
              </span>
            </div>
            <p className="text-xl sm:text-2xl font-black text-white">₱{todayProfit.toFixed(2)}</p>
            <div className="flex items-center justify-between text-[10px] text-emerald-200/80 pt-1.5 border-t border-emerald-800/60 min-w-0">
              <span className="truncate">Gross: ₱{todayGross.toFixed(2)}</span>
              <span className="shrink-0">{todaySalesList.length} txns</span>
            </div>
          </div>

          {/* Week Profit */}
          <div className="bg-emerald-950/60 border border-emerald-700/60 p-3.5 rounded-2xl flex flex-col justify-between space-y-2 backdrop-blur-xs overflow-hidden">
            <div className="flex items-start justify-between gap-1 text-teal-300 text-xs font-bold min-w-0">
              <span className="truncate">Weekly Profit</span>
              <span className="text-[10px] bg-teal-500/20 px-1.5 py-0.5 rounded text-teal-300 shrink-0 border border-teal-500/30">
                7 Days
              </span>
            </div>
            <p className="text-xl sm:text-2xl font-black text-white">₱{weekProfit.toFixed(2)}</p>
            <div className="flex items-center justify-between text-[10px] text-emerald-200/80 pt-1.5 border-t border-emerald-800/60 min-w-0">
              <span className="truncate">Gross: ₱{weekGross.toFixed(2)}</span>
              <span className="shrink-0">{weekSalesList.length} txns</span>
            </div>
          </div>

          {/* Month Profit */}
          <div className="bg-emerald-950/60 border border-emerald-700/60 p-3.5 rounded-2xl flex flex-col justify-between space-y-2 backdrop-blur-xs overflow-hidden">
            <div className="flex items-start justify-between gap-1 text-emerald-300 text-xs font-bold min-w-0">
              <span className="truncate">Monthly Profit</span>
              <span className="text-[10px] bg-emerald-500/20 px-1.5 py-0.5 rounded text-emerald-300 shrink-0 border border-emerald-500/30">
                This Month
              </span>
            </div>
            <p className="text-xl sm:text-2xl font-black text-white">₱{monthProfit.toFixed(2)}</p>
            <div className="flex items-center justify-between text-[10px] text-emerald-200/80 pt-1.5 border-t border-emerald-800/60 min-w-0">
              <span className="truncate">Gross: ₱{monthGross.toFixed(2)}</span>
              <span className="shrink-0">{monthSalesList.length} txns</span>
            </div>
          </div>
        </div>
      </div>

      {/* Sales Trend Chart */}
      <div className="bg-white border border-slate-200/80 p-4 rounded-3xl shadow-xs">
        <h3 className="text-xs font-bold text-slate-800 mb-3 flex items-center gap-1.5">
          <TrendingUp className="w-4 h-4 text-indigo-600" />
          <span>{t('salesTrendChart')} (₱)</span>
        </h3>

        <div className="h-56 w-full">
          {chartData.length === 0 ? (
            <div className="h-full flex items-center justify-center text-xs text-slate-400">
              Walang benta sa napiling time period.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} />
                <YAxis stroke="#94a3b8" fontSize={10} tickFormatter={(v) => `₱${v}`} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '0.75rem',
                    color: '#0f172a',
                    fontSize: '12px',
                    boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                  }}
                  formatter={(value: number) => [`₱${value.toFixed(2)}`, 'Sales']}
                />
                <Area type="monotone" dataKey="Sales" stroke="#4f46e5" strokeWidth={2.5} fillOpacity={1} fill="url(#colorSales)" />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Bottom Grid: Top Products & Payment breakdown */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Top Products Leaderboard */}
        <div className="bg-white border border-slate-200/80 p-4 rounded-3xl shadow-xs">
          <h3 className="text-xs font-bold text-slate-800 mb-3 flex items-center gap-1.5">
            <Award className="w-4 h-4 text-amber-500" />
            <span>{t('topProductsTitle')}</span>
          </h3>

          <div className="space-y-2.5">
            {topProducts.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-4">Walang data ng benta.</p>
            ) : (
              topProducts.map((prod, idx) => (
                <div key={idx} className="flex items-center gap-2.5 p-2 bg-slate-50 rounded-2xl border border-slate-200">
                  <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-700 font-black text-[10px] flex items-center justify-center">
                    {idx + 1}
                  </span>
                  <img src={prod.img || undefined} alt={prod.name} className="w-8 h-8 rounded-lg object-cover bg-slate-200" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-800 truncate">{prod.name}</p>
                    <p className="text-[10px] text-slate-500">{prod.qty} pcs naibenta</p>
                  </div>
                  <span className="text-xs font-bold text-indigo-600">₱{prod.total.toFixed(2)}</span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Payment Methods Chart */}
        <div className="bg-white border border-slate-200/80 p-4 rounded-3xl shadow-xs flex flex-col justify-between">
          <h3 className="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
            <DollarSign className="w-4 h-4 text-indigo-600" />
            <span>{t('paymentBreakdownTitle')}</span>
          </h3>

          <div className="h-40 w-full flex items-center justify-center">
            {totalGrossSales === 0 ? (
              <p className="text-xs text-slate-400">Walang data.</p>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={65}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderColor: '#e2e8f0',
                      borderRadius: '0.75rem',
                      color: '#0f172a',
                      fontSize: '11px',
                      boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                    }}
                    formatter={(v: number) => `₱${v.toFixed(2)}`}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>

          <div className="flex justify-around text-[11px] pt-2 border-t border-slate-100">
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-600" />
              <span className="text-slate-700 font-semibold">Cash: ₱{paymentMap.Cash.toFixed(0)}</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-500" />
              <span className="text-slate-700 font-semibold">GCash: ₱{paymentMap.GCash.toFixed(0)}</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-pink-500" />
              <span className="text-slate-700 font-semibold">Maya: ₱{paymentMap.Maya.toFixed(0)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Comprehensive Admin Database & Data Table Section */}
      <AdminDatabaseTable sales={sales} />

      {/* APK / PWA Mobile App Install Modal */}
      <InstallApkModal isOpen={isApkModalOpen} onClose={() => setIsApkModalOpen(false)} />
    </div>
  );
};
