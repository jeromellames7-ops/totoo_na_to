import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { UserAccount, ExtractedDocumentResult, ExtractedTableSection, GalleryBoxItem } from '../types';
import {
  ArrowLeft,
  Upload,
  FileText,
  Sparkles,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Copy,
  Download,
  Printer,
  Trash2,
  Plus,
  Search,
  Check,
  RefreshCw,
  ShieldCheck,
  Eye,
  FileCheck,
  Layers,
  Edit3,
  History,
  Lock,
  User,
  ZoomIn,
  ZoomOut,
  RotateCw,
  X,
  Image as ImageIcon,
  Grid,
  Table,
  FileSpreadsheet,
  Maximize2,
  ChevronRight,
  ChevronDown,
  Database,
  Cloud,
  HardDrive,
  Save,
  ExternalLink,
  Folder,
  FolderPlus,
  Key,
  ScanLine,
  Camera,
  ChevronLeft,
  Sliders,
  Wand2,
  Filter,
  Zap,
  Rocket,
  Gauge,
  ZapOff,
  Package,
  Clock,
  ArrowUpRight,
  Share2,
  Briefcase,
  GraduationCap,
  Calendar,
  Tag,
  HelpCircle,
} from 'lucide-react';
import { LiveAiDocumentScanner } from './LiveAiDocumentScanner';
import {
  extractDocumentClientSide,
  extractPdsApplicantName,
  createOptimizedPdsThumbnailForOcr,
  getClientGeminiApiKey,
  setClientGeminiApiKey,
} from '../lib/geminiDocExtractor';
import { compressImageForAi } from '../lib/imageCompressor';
import {
  calculateImagePerceptualHash,
  detectAndRemoveDuplicatePictures,
  getAiFilterCss,
  enhanceImageClarityWithCanvas,
  AiFilterMode,
} from '../lib/aiImageOrganizer';
import * as XLSX from 'xlsx';
import {
  collection,
  doc,
  setDoc,
  getDocs,
  deleteDoc,
  writeBatch,
  onSnapshot,
  enableNetwork,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { handleFirestoreError, isFirestoreQuotaExhausted, resetQuotaExhausted } from '../utils/firebaseSync';
import {
  savePdsImagesToIndexedDB,
  getAllPdsImagesFromIndexedDB,
  deletePdsImageFromIndexedDB,
  clearAllPdsImagesFromIndexedDB,
  savePdsImagesToFirebaseAndIndexedDB,
  updatePdsImageMetadataInFirebaseAndIndexedDB,
  deletePdsImageFromFirebaseAndIndexedDB,
  deletePdsImagesByApplicantNameFromFirebaseAndIndexedDB,
  clearAllPdsImagesFromFirebaseAndIndexedDB,
  PdsStoredImage,
} from '../utils/pdsImageStorage';
import { getEffectiveAccountId } from '../utils/storage';

interface DocExtractorProps {
  activeUser: UserAccount;
  onBackToPortal: () => void;
}

export const TARGET_REQUESTED_HEADERS = [
  'NAME (SURNAME, FIRST NAME, MIDDLE NAME)',
  'SUFFIX',
  'DATE OF BIRTH (MM, DD, YYYY)',
  'SEX',
  'CIVIL STATUS',
  'ADDRESS (PUROK, BRGY, MUNICIPALITY, PROVINCE)',
  'HEIGHT (Kg)',
  'WEIGHT (Kg)',
  'BLOOD TYPE',
  'RELIGION',
  'PHILHEALTH NO.',
  'SSS NO.',
  'PAG IBIG NO.',
  'TIN NO.',
  'PhilSys Number (PSN)',
  "Voter's Identification Number :",
  'CP NO.',
  'EMAIL ADDRESS',
  'EMPLOYMENT STATUS',
  'HOW LONG HAVE YOU BEEN LOOKING FOR WORK (MONTHS)',
  'PREFERRED OCCUPATION',
  'EDUCATIONAL BACKROUND (SCHOOL, COURSE, YEAR GRAD.)',
  'CERTIFICATION/VOCATIONAL TRAINING',
  'ELIGIBILITY/LICENSE (DATE TAKEN, VALID UNTIL)',
  'WORK EXPERIENCE (EMPLOYER NAME, ADDRESS, POSITION HELD, INCLUSIVE DATES, STATUS)',
  'OTHER SKILLS',
];

// Helper to check if a value is empty, hyphen, placeholder, or N/A
export const isValuePlaceholderOrNA = (val: any): boolean => {
  if (val === undefined || val === null) return true;
  const s = String(val).trim().toLowerCase();
  return (
    s === '' ||
    s === '-' ||
    s === '--' ||
    s === '---' ||
    s === 'n/a' ||
    s === 'na' ||
    s === 'none' ||
    s === 'unknown' ||
    s === 'hindi matukoy' ||
    s === 'bagong aplikante' ||
    s === 'aplikante' ||
    s === 'null' ||
    s === 'undefined'
  );
};

// Preset Standard Templates for Text Generated Tables & Form Extraction
export interface PresetFormTemplate {
  id: string;
  name: string;
  category: string;
  description: string;
  headers: string[];
}

export const TARGET_PRESET_TEMPLATES: PresetFormTemplate[] = [
  {
    id: 'pds_26_columns',
    name: 'Personal Data Sheet (PDS & Official Form)',
    category: 'Government & HR',
    description: 'Kumpletong 26 columns kasama ang PhilHealth, SSS, Pag-IBIG, Blood Type, Weight, Height, PhilSys PSN, at Voter\'s ID',
    headers: TARGET_REQUESTED_HEADERS,
  },
  {
    id: 'biodata_applicant',
    name: 'Bio-Data / Applicant Registration',
    category: 'Job Applications',
    description: 'Karaniwang impormasyon ng nag-aaplay: Pangalan, Edad, Tirahan, Edukasyon, at Trabaho',
    headers: [
      'SURNAME',
      'FIRST NAME',
      'MIDDLE NAME',
      'AGE',
      'SEX',
      'CIVIL STATUS',
      'DATE OF BIRTH',
      'CITIZENSHIP',
      'RESIDENTIAL ADDRESS',
      'CONTACT NUMBER',
      'EMAIL ADDRESS',
      'EDUCATIONAL ATTAINMENT',
      'SPECIAL SKILLS',
      'WORK EXPERIENCE',
    ],
  },
  {
    id: 'employee_payroll',
    name: 'Employee Record & Payroll Matrix',
    category: 'Company & Staff',
    description: 'Para sa listahan ng empleyado, sahod, posisyon, at mga bawas/kontribusyon',
    headers: [
      'EMPLOYEE ID',
      'FULL NAME',
      'POSITION / DESIGNATION',
      'DEPARTMENT',
      'EMPLOYMENT STATUS',
      'BASIC SALARY',
      'ALLOWANCE',
      'DEDUCTIONS',
      'NET PAY',
      'DATE HIRED',
      'SSS / GSIS NO',
      'TIN',
      'PHILHEALTH NO',
      'PAG-IBIG NO',
    ],
  },
  {
    id: 'sales_inventory',
    name: 'Sales & Inventory Management Table',
    category: 'Business & Store',
    description: 'Pag-scan ng listahan ng produkto, stock count, presyo ng bili at tinda',
    headers: [
      'ITEM CODE / SKU',
      'PRODUCT NAME',
      'CATEGORY',
      'UNIT',
      'STOCK QUANTITY',
      'UNIT PRICE (BUY)',
      'SELLING PRICE',
      'TOTAL VALUE',
      'SUPPLIER',
      'EXPIRY DATE',
      'REMARKS / STATUS',
    ],
  },
  {
    id: 'student_masterlist',
    name: 'Student Masterlist / School Enrollment',
    category: 'Schools & Education',
    description: 'Listahan ng mag-aaral, LRN, baitang, seksyon, magulang, at kontak',
    headers: [
      'LRN / STUDENT ID',
      'FULL NAME (SURNAME, FIRST, MI)',
      'GRADE LEVEL / YEAR',
      'SECTION',
      'SEX',
      'AGE',
      'DATE OF BIRTH',
      'PARENT / GUARDIAN',
      'CONTACT NUMBER',
      'HOME ADDRESS',
      'ENROLLMENT STATUS',
    ],
  },
  {
    id: 'logbook_attendance',
    name: 'Daily Logbook & Attendance Sheet',
    category: 'Daily Office Operations',
    description: 'Talaan ng oras ng pagpasok/labas ng bisita o empleyado at kanilang layunin',
    headers: [
      'DATE',
      'TIME IN',
      'TIME OUT',
      'FULL NAME',
      'DEPARTMENT / OFFICE',
      'PURPOSE / ACTIVITY',
      'CONTACT NO',
      'TEMPERATURE / HEALTH',
      'SIGNATURE / REMARKS',
    ],
  },
];

// Helper to parse multiple headers from raw text input (handles newlines, commas, semicolons, tabs, pipes)
export const parseCustomHeadersString = (rawText: string): string[] => {
  if (!rawText || !rawText.trim()) return [];
  const items = rawText
    .split(/[\n,;|\t]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0 && !s.startsWith('#') && !s.startsWith('//'));
  // De-duplicate while preserving original order
  return Array.from(new Set(items));
};


// Helper function to pivot key-value tables so all field descriptors become top column headers under ABCD
const normalizeSectionTable = (sec: ExtractedTableSection): ExtractedTableSection => {
  if (!sec.headers || sec.headers.length === 0 || !sec.rows || sec.rows.length === 0) {
    return sec;
  }

  // Detect if this is a key-value format (e.g. 'Field / Descriptor', 'Nakasulat na Datos / Sagot')
  const firstHeader = (sec.headers[0] || '').toLowerCase();
  const secondHeader = (sec.headers[1] || '').toLowerCase();
  const isKeyValueTable =
    (firstHeader.includes('field') || firstHeader.includes('descriptor') || firstHeader.includes('label') || firstHeader.includes('item') || firstHeader.includes('pangalan ng field')) &&
    (secondHeader.includes('datos') || secondHeader.includes('sagot') || secondHeader.includes('output') || secondHeader.includes('value') || secondHeader.includes('answer') || secondHeader.includes('impormasyon'));

  if (isKeyValueTable && sec.rows.length > 1) {
    const keyCol = sec.headers[0];
    const valCol = sec.headers[1];
    const newHeaders: string[] = [];
    const newRow: Record<string, string> = {};

    sec.rows.forEach((r) => {
      const fieldKey = (r[keyCol] || '').trim();
      const fieldVal = (r[valCol] || '').trim();
      if (fieldKey) {
        newHeaders.push(fieldKey);
        newRow[fieldKey] = fieldVal;
      }
    });

    if (newHeaders.length > 0) {
      return {
        ...sec,
        headers: newHeaders,
        rows: [newRow],
      };
    }
  }

  return sec;
};

// Helper to compute exact age from a Date of Birth string or numeric age
export const calculateAgeFromDob = (val: string | number | undefined | null): number | null => {
  if (val === undefined || val === null) return null;
  const str = String(val).trim();
  if (!str || str.toLowerCase().includes('n/a') || str.toLowerCase().includes('hindi')) return null;

  // Check if string is directly a number like "22" or "24 yrs old"
  const directNumMatch = str.match(/^(\d{1,3})\s*(years|yrs|taong|y\/o|yo|edad)?$/i);
  if (directNumMatch) {
    const num = parseInt(directNumMatch[1]);
    if (num >= 0 && num <= 120) return num;
  }

  // Parse date patterns (MM/DD/YYYY, DD/MM/YYYY, YYYY-MM-DD, Month DD YYYY)
  let birthDate: Date | null = null;
  const match = str.match(/\b(\d{1,4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,4})\b/);
  if (match) {
    const p1 = parseInt(match[1]);
    const p2 = parseInt(match[2]);
    const p3 = parseInt(match[3]);

    if (p1 > 1900 && p1 <= new Date().getFullYear()) {
      // YYYY-MM-DD
      birthDate = new Date(p1, p2 - 1, p3);
    } else if (p3 > 1900 && p3 <= new Date().getFullYear()) {
      // MM/DD/YYYY or DD/MM/YYYY
      const month = p1 > 12 ? p2 - 1 : p1 - 1;
      const day = p1 > 12 ? p1 : p2;
      birthDate = new Date(p3, month, day);
    }
  } else {
    const parsed = new Date(str);
    if (!isNaN(parsed.getTime()) && parsed.getFullYear() > 1900 && parsed.getFullYear() <= new Date().getFullYear()) {
      birthDate = parsed;
    }
  }

  if (birthDate && !isNaN(birthDate.getTime())) {
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    if (age >= 0 && age <= 120) return age;
  }

  return null;
};

// Helper to extract calculated age from any table row object
export const getRowAge = (row: Record<string, string>): number | null => {
  if (!row) return null;

  // 1. Check DOB header specifically
  for (const [key, val] of Object.entries(row)) {
    const kLower = key.toLowerCase();
    if (
      kLower.includes('date of birth') ||
      kLower.includes('birth') ||
      kLower.includes('dob') ||
      kLower.includes('birtdey') ||
      kLower.includes('kaarawan') ||
      kLower.includes('kapanganakan')
    ) {
      const age = calculateAgeFromDob(val);
      if (age !== null) return age;
    }
  }

  // 2. Check explicit age / edad headers
  for (const [key, val] of Object.entries(row)) {
    const kLower = key.toLowerCase();
    if (kLower === 'age' || kLower === 'edad' || kLower.includes('age') || kLower.includes('edad')) {
      const age = calculateAgeFromDob(val);
      if (age !== null) return age;
    }
  }

  return null;
};

// Universal applicant name normalizer for strict duplicate prevention
export const normalizeApplicantName = (name: string): string => {
  if (!name) return '';
  return name
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
};

// Helper to extract clean person name from image filenames (e.g. "01 - PABILLO, MELANIE M.jpg" -> "PABILLO MELANIE M")
export const extractNameCandidateFromFilename = (fileName: string): string => {
  if (!fileName) return '';
  return fileName
    .replace(/\.[^/.]+$/, '') // alisin ang file extension
    .replace(/^\d+[\.\-_,\s]*/, '') // alisin ang leading numbers (hal. "01 - ", "1. ", "02_")
    .replace(/[\(\)\[\]\{\}]/g, ' ') // alisin ang panaklong
    .replace(/[_\-]+/g, ' ') // palitan ang underscore at gitling ng space
    .replace(/\b(pds|page|pahina|copy|scan|picture|photo|larawan|form|cs212|img|image|file|pic|doc)\b/gi, ' ') // alisin ang generic tags
    .replace(/\s+/g, ' ')
    .trim();
};

// Helper to detect if a string is a raw UUID, camera hash or meaningless timestamp instead of a real person's full name
export const isLikelyFilenameOrHash = (name: string): boolean => {
  if (!name) return false;
  const clean = name.trim();
  if (clean.length < 2) return true;
  // Pure UUID with dashes or spaces (e.g. "A23DBD0B-158D-4F97-86D6-FBDB730ACC11")
  if (/^[0-9a-fA-F]{8}[-\s][0-9a-fA-F]{4}[-\s][0-9a-fA-F]{4}[-\s][0-9a-fA-F]{4}[-\s][0-9a-fA-F]{12}$/i.test(clean)) return true;
  // Consecutive pure hex string of 16+ chars
  if (/^[0-9a-fA-F]{16,}$/i.test(clean.replace(/[\s\-_()]/g, ''))) return true;
  // Pure camera prefix without actual name (IMG_001, DSC_1234, PHOTO_999)
  if (/^(IMG|DSC|PHOTO|PIC|SCAN|WP|DOC|CAPTURE|IMAGE|FILE|TEMP|SCREENSHOT)[_\-\s0-9()]+$/i.test(clean)) return true;
  // High digit ratio: strings with 6+ numbers and >40% numbers without letters
  const letters = (clean.match(/[a-zA-Z]/g) || []).length;
  if (letters < 2 && clean.length >= 4) return true;
  return false;
};

// Helper to determine if a string is a real applicant name (and not a placeholder/generic label)
export const isRealApplicantName = (name: string): boolean => {
  if (!name) return false;
  const clean = extractNameCandidateFromFilename(name);
  const norm = normalizeApplicantName(clean || name);
  if (!norm || norm.length < 2) return false;
  if (
    norm === 'hindi matukoy' ||
    norm === 'n a' ||
    norm === 'na' ||
    norm === 'unknown' ||
    norm === 'none' ||
    norm === 'maramihang rekord aplikante' ||
    norm === 'walang nakasalang' ||
    norm === 'pds' ||
    norm === 'form' ||
    norm.startsWith('aplikante') ||
    norm.startsWith('rekord aplikante') ||
    norm.startsWith('pds aplikante') ||
    norm.startsWith('box ') ||
    norm.startsWith('row ')
  ) {
    return false;
  }
  return true;
};

// Helper to accurately compare two applicant names for duplicates and matching
export const checkApplicantNamesMatch = (nameA: string, nameB: string): boolean => {
  if (!nameA || !nameB) return false;
  const rawA = nameA.trim();
  const rawB = nameB.trim();
  if (rawA.toLowerCase() === rawB.toLowerCase()) return true;

  const cleanA = extractNameCandidateFromFilename(nameA);
  const cleanB = extractNameCandidateFromFilename(nameB);

  const normA = normalizeApplicantName(cleanA || nameA);
  const normB = normalizeApplicantName(cleanB || nameB);

  if (!normA || !normB) return false;
  if (normA === normB) return true;

  // Filter out noise keywords for word analysis
  const noiseRegex = /^(pds|form|cs212|bio|data|sheet|page|pahina|copy|scan|photo|pic|picture|larawan|image|img|applicant|aplikante|record|rekord|doc|file)$/i;
  const wordsA = normA.split(' ').filter((w) => w.length > 1 && !noiseRegex.test(w));
  const wordsB = normB.split(' ').filter((w) => w.length > 1 && !noiseRegex.test(w));

  if (wordsA.length === 0 || wordsB.length === 0) return false;

  // 1. Exact sorted words equality (e.g. "MELANIE MARIANO PABILLO" vs "PABILLO, MELANIE MARIANO")
  if (wordsA.slice().sort().join(' ') === wordsB.slice().sort().join(' ')) {
    return true;
  }

  // 2. Subset matching: If all significant words of one name (at least 2 words) are in the other name
  // e.g. ["pabillo", "melanie"] are both in ["pabillo", "melanie", "mariano"]
  const aInB = wordsA.length >= 2 && wordsA.every((w) => wordsB.includes(w));
  const bInA = wordsB.length >= 2 && wordsB.every((w) => wordsA.includes(w));
  if (aInB || bInA) return true;

  // 3. Significant word overlap (at least 2 matching words of length >= 3)
  const sharedWords = wordsA.filter((w) => w.length >= 3 && wordsB.includes(w));
  if (sharedWords.length >= 2) {
    return true;
  }

  // 4. Substring check if minimum length is at least 6 characters
  if ((normA.includes(normB) || normB.includes(normA)) && Math.min(normA.length, normB.length) >= 6) {
    return true;
  }

  return false;
};

// Helper to format clean, reliable PDS image download filenames matching exact applicant name
export const getPdsPictureFileName = (name?: string): string => {
  const clean = (name || 'PDS_DOCUMENT')
    .trim()
    .replace(/[\\/:*?"<>|]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  return clean ? `${clean}.png` : 'PDS_DOCUMENT.png';
};

// Universal search matcher for Rows, Headers, Sheets, Calculated Age, and Cell Data
export const checkRowMatchesSearch = (
  sec: ExtractedTableSection,
  secIdx: number,
  row: Record<string, string>,
  searchTerm: string
): boolean => {
  if (!searchTerm || !searchTerm.trim()) return true;
  const q = searchTerm.toLowerCase().trim();

  // 1. Match Sheet Name or Section Title ("Sheet 1", "Sheet 2", "Sheet", "Seksyon 1", etc.)
  const sheetName = `sheet ${secIdx + 1}`;
  const sectionLabel = `seksyon ${secIdx + 1}`;
  const sectionTitle = (sec.sectionTitle || '').toLowerCase();
  if (
    sheetName.includes(q) ||
    sectionLabel.includes(q) ||
    sectionTitle.includes(q)
  ) {
    return true;
  }

  // 2. Match Column Headers (e.g. "CIVIL STATUS", "DATE OF BIRTH", "TIN", "CP NO", "WORK EXPERIENCE", "SEX", etc.)
  if (sec.headers && sec.headers.some((h) => String(h || '').toLowerCase().includes(q))) {
    return true;
  }

  // 3. Match Cell Values in row
  const hasCellMatch = Object.entries(row || {}).some(([k, v]) => {
    return String(k || '').toLowerCase().includes(q) || String(v || '').toLowerCase().includes(q);
  });
  if (hasCellMatch) return true;

  // 4. Match Calculated Age or Youth / Non-Youth status
  const age = getRowAge(row);
  if (age !== null) {
    const ageStr = `${age} yrs old ${age <= 24 ? 'youth (24 pababa)' : 'non-youth (25 pataas)'}`;
    if (ageStr.toLowerCase().includes(q)) return true;
  }

  return false;
};

export const ROWS_PER_SHEET = 20;

// Helper to partition rows strictly into 20 rows per sheet (Sheet 1, Sheet 2, Sheet 3, etc.)
export const chunkRowsIntoSections = (
  allRows: Record<string, string>[],
  baseCheckboxes: any[] = [],
  customHeaders?: string[]
): ExtractedTableSection[] => {
  const activeHeaders =
    customHeaders && customHeaders.length > 0 ? customHeaders : TARGET_REQUESTED_HEADERS;

  if (!allRows || allRows.length === 0) {
    const emptyRow: Record<string, string> = {};
    activeHeaders.forEach((h) => (emptyRow[h] = ''));
    return [
      {
        sectionTitle: 'Sheet 1 (Rows 1 - 20)',
        headers: activeHeaders,
        rows: [emptyRow],
        checkboxes: baseCheckboxes,
        notes: `Unang 20 rekord (Sheet 1 • ${activeHeaders.length} Columns)`,
      },
    ];
  }

  const sections: ExtractedTableSection[] = [];
  const totalSheets = Math.ceil(allRows.length / ROWS_PER_SHEET) || 1;

  for (let i = 0; i < totalSheets; i++) {
    const start = i * ROWS_PER_SHEET;
    const end = start + ROWS_PER_SHEET;
    const sheetRows = allRows.slice(start, end);

    sections.push({
      sectionTitle: `Sheet ${i + 1} (Rows ${start + 1} - ${Math.min(end, allRows.length)})`,
      headers: activeHeaders,
      rows: sheetRows,
      checkboxes: i === 0 ? baseCheckboxes : [],
      notes: `Sheet ${i + 1} • ${sheetRows.length} rows (Kabuuan: ${allRows.length})`,
    });
  }

  return sections;
};

// Helper to normalize any existing document to 20 rows per sheet
export const ensure20RowsPerSheet = (
  doc: ExtractedDocumentResult | null,
  fallbackHeaders?: string[]
): ExtractedDocumentResult | null => {
  if (!doc || !doc.sections || doc.sections.length === 0) return doc;
  const existingHeaders =
    doc.sections[0]?.headers && doc.sections[0].headers.length > 0
      ? doc.sections[0].headers
      : fallbackHeaders;
  const allRows = doc.sections.flatMap((s) => s.rows || []);
  const allCheckboxes = doc.sections.flatMap((s) => s.checkboxes || []);
  const chunked = chunkRowsIntoSections(allRows, allCheckboxes, existingHeaders);
  return {
    ...doc,
    sections: chunked,
  };
};

export const SHARED_MASTER_TABLE_ID = 'DOC-PRIMARY-SHARED-MASTER-TABLE';

// Helper to unify and deduplicate all records into a single shared Master Table across mobile & desktop
export const combineAndDeduplicateAllRows = (
  docsList: ExtractedDocumentResult[],
  fallbackDoc?: ExtractedDocumentResult | null,
  pdsImages?: PdsStoredImage[] | null
): ExtractedDocumentResult | null => {
  const allRows: Record<string, string>[] = [];
  const headersSet = new Set<string>(TARGET_REQUESTED_HEADERS);

  const masterDocInList = docsList.find((d) => d.id === SHARED_MASTER_TABLE_ID);

  if (masterDocInList?.sections?.[0]?.headers) {
    masterDocInList.sections[0].headers.forEach((h) => headersSet.add(h));
  }
  if (fallbackDoc?.sections?.[0]?.headers) {
    fallbackDoc.sections[0].headers.forEach((h) => headersSet.add(h));
  }

  const docsToProcess: ExtractedDocumentResult[] = [];
  if (masterDocInList) {
    docsToProcess.push(masterDocInList);
  }
  docsList.filter((d) => d.id !== SHARED_MASTER_TABLE_ID).forEach((d) => docsToProcess.push(d));
  if (fallbackDoc) {
    docsToProcess.push(fallbackDoc);
  }

  docsToProcess.forEach((docItem) => {
    (docItem.sections || []).forEach((sec) => {
      (sec.headers || []).forEach((h) => headersSet.add(h));
      (sec.rows || []).forEach((row) => {
        const hasValue = Object.values(row).some((v) => !isValuePlaceholderOrNA(v));
        if (!hasValue) return;

        const name =
          row['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
          row['FULL NAME'] ||
          row['PANGALAN'] ||
          row['SURNAME'] ||
          '';

        let matchIdx = -1;
        if (name && isRealApplicantName(name)) {
          matchIdx = allRows.findIndex((existing) => {
            const exName =
              existing['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
              existing['FULL NAME'] ||
              existing['PANGALAN'] ||
              existing['SURNAME'] ||
              '';
            return checkApplicantNamesMatch(name, exName);
          });
        }

        if (matchIdx >= 0) {
          const existing = allRows[matchIdx];
          Object.keys(row).forEach((k) => {
            const newVal = row[k];
            if (!isValuePlaceholderOrNA(newVal)) {
              existing[k] = String(newVal);
            }
          });
        } else {
          allRows.push({ ...row });
        }
      });
    });
  });

  // Also guarantee every applicant from PDS Pictures exists as a row in the Table & Database!
  if (pdsImages && pdsImages.length > 0) {
    pdsImages.forEach((pds) => {
      const pdsName = (pds.applicantName || '').trim();
      if (!pdsName) return;

      const matchIdx = allRows.findIndex((existing) => {
        const exName =
          existing['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
          existing['FULL NAME'] ||
          existing['PANGALAN'] ||
          existing['SURNAME'] ||
          '';
        return checkApplicantNamesMatch(pdsName, exName);
      });

      if (matchIdx === -1) {
        const newRow: Record<string, string> = {
          'NAME (SURNAME, FIRST NAME, MIDDLE NAME)': pdsName.toUpperCase(),
        };
        TARGET_REQUESTED_HEADERS.forEach((h) => {
          if (newRow[h] === undefined) newRow[h] = '';
        });
        allRows.push(newRow);
      }
    });
  }

  if (allRows.length === 0) {
    return null;
  }

  const finalHeaders = Array.from(headersSet);
  const chunked = chunkRowsIntoSections(allRows, [], finalHeaders);

  const mdHeaders = finalHeaders.join(' | ');
  const mdDividers = finalHeaders.map(() => '---').join(' | ');
  const mdRows = allRows
    .map((r) => finalHeaders.map((h) => String(r[h] || '-')).join(' | '))
    .join('\n');

  return {
    id: SHARED_MASTER_TABLE_ID,
    title: masterDocInList?.title || fallbackDoc?.title || 'Personal Data Sheet Master Table',
    detectedPersonName: allRows[0]?.['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || 'Master Applicant List',
    documentType: `Master Form Table (${finalHeaders.length} Columns)`,
    totalPages: chunked.length,
    detectedPageNumbers: chunked.map((_, i) => `Sheet ${i + 1}`),
    sections: chunked,
    consolidatedMarkdownTable: `| ${mdHeaders} |\n| ${mdDividers} |\n${mdRows}`,
    signaturesAndDates: masterDocInList?.signaturesAndDates || [],
    unreadableSummary: '',
    privacyNoticeAcknowledged: true,
    scannedAt: masterDocInList?.scannedAt || new Date().toISOString(),
    imagesBase64: masterDocInList?.imagesBase64 || [],
  };
};

// Robust parser that handles full JSON serialized docs (Home Monitoring pattern), sectionsJson, and legacy schemas
export const parseFirestoreDocToResult = (id: string, data: any): ExtractedDocumentResult => {
  if (data?.data && typeof data.data === 'string') {
    try {
      const parsed = JSON.parse(data.data);
      if (parsed && typeof parsed === 'object') {
        const sections = Array.isArray(parsed.sections) ? parsed.sections : [];
        return {
          ...parsed,
          id,
          sections,
          imagesBase64: Array.isArray(parsed.imagesBase64) ? parsed.imagesBase64 : [],
        };
      }
    } catch (e) {}
  }

  let sections: ExtractedTableSection[] = [];
  if (data?.sectionsJson && typeof data.sectionsJson === 'string') {
    try {
      sections = JSON.parse(data.sectionsJson);
    } catch (e) {}
  } else if (Array.isArray(data?.sections)) {
    sections = data.sections;
  }

  return {
    id,
    title: data?.title || 'Form Document',
    detectedPersonName: data?.detectedPersonName || 'Aplikante',
    documentType: data?.documentType || 'Official Form',
    totalPages: data?.totalPages || 1,
    detectedPageNumbers: typeof data?.detectedPageNumbers === 'string'
      ? data.detectedPageNumbers.split(', ')
      : Array.isArray(data?.detectedPageNumbers)
      ? data.detectedPageNumbers
      : ['Sheet 1'],
    sections,
    consolidatedMarkdownTable: data?.consolidatedMarkdownTable || '',
    signaturesAndDates: Array.isArray(data?.signaturesAndDates) ? data.signaturesAndDates : [],
    unreadableSummary: data?.unreadableSummary || '',
    privacyNoticeAcknowledged: true,
    scannedAt: data?.scannedAt || new Date().toISOString(),
    imagesBase64: Array.isArray(data?.imagesBase64) ? data.imagesBase64 : [],
  };
};

export const DocExtractor: React.FC<DocExtractorProps> = ({ activeUser, onBackToPortal }) => {
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [titleHint, setTitleHint] = useState<string>('');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanStep, setScanStep] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const currentAccountId = getEffectiveAccountId();

  // Active document result - initialized from persistent active storage or scan history (strictly 20 rows per sheet)
  const [result, setResult] = useState<ExtractedDocumentResult | null>(() => {
    try {
      const activeStored =
        localStorage.getItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`) ||
        (currentAccountId === 'user-admin1' ? localStorage.getItem('tindahan_doc_extracted_active_table') : null);
      if (activeStored) {
        return ensure20RowsPerSheet(JSON.parse(activeStored));
      }
      const stored =
        localStorage.getItem(`tindahan_doc_extracted_history_acc_${currentAccountId}`) ||
        (currentAccountId === 'user-admin1' ? localStorage.getItem('tindahan_doc_extracted_history') : null);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return ensure20RowsPerSheet(parsed[0]);
        }
      }
      return null;
    } catch {
      return null;
    }
  });
  const [activeTab, setActiveTab] = useState<'tables' | 'markdown' | 'checkboxes' | 'signatures'>('tables');
  const [isInitialLoading, setIsInitialLoading] = useState<boolean>(() => {
    try {
      return !(
        localStorage.getItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`) ||
        localStorage.getItem('tindahan_doc_extracted_active_table')
      );
    } catch {
      return true;
    }
  });
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [ageFilter, setAgeFilter] = useState<'all' | 'youth' | 'non-youth'>('all');
  const [copied, setCopied] = useState<boolean>(false);
  const [selectedSheetTab, setSelectedSheetTab] = useState<number | 'all'>(0);
  const [activeCell, setActiveCell] = useState<{
    secIdx: number;
    rowIdx: number;
    colIdx: number;
    colLetter: string;
    colName: string;
    value: string;
    cellCoord: string;
  } | null>(null);
  const [showExcelGridlines, setShowExcelGridlines] = useState<boolean>(true);
  const [historySearchQuery, setHistorySearchQuery] = useState<string>('');
  const [previewModalImage, setPreviewModalImage] = useState<{ src: string; title: string; pageNum?: number } | null>(null);
  const [savedHistory, setSavedHistory] = useState<ExtractedDocumentResult[]>(() => {
    try {
      const stored =
        localStorage.getItem(`tindahan_doc_extracted_history_acc_${currentAccountId}`) ||
        (currentAccountId === 'user-admin1' ? localStorage.getItem('tindahan_doc_extracted_history') : null);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);

  // PDS Pictures Gallery & 100% Fullscreen PC View State
  const [storedPdsImages, setStoredPdsImages] = useState<PdsStoredImage[]>([]);
  const [isPdsGalleryOpen, setIsPdsGalleryOpen] = useState<boolean>(false);

  // Synchronize local states whenever switching active user account
  useEffect(() => {
    try {
      const activeStored =
        localStorage.getItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`) ||
        (currentAccountId === 'user-admin1' ? localStorage.getItem('tindahan_doc_extracted_active_table') : null);
      if (activeStored) {
        setResult(ensure20RowsPerSheet(JSON.parse(activeStored)));
      } else {
        setResult(null);
      }

      const historyStored =
        localStorage.getItem(`tindahan_doc_extracted_history_acc_${currentAccountId}`) ||
        (currentAccountId === 'user-admin1' ? localStorage.getItem('tindahan_doc_extracted_history') : null);
      if (historyStored) {
        const parsed = JSON.parse(historyStored);
        setSavedHistory(parsed);
        setFirestoreDocs(parsed);
      } else {
        setSavedHistory([]);
        setFirestoreDocs([]);
      }
    } catch (e) {}

    getAllPdsImagesFromIndexedDB(currentAccountId)
      .then((imgs) => {
        setStoredPdsImages(imgs || []);
      })
      .catch((err) => console.warn('[PDS Storage] Error loading IndexedDB photos:', err));
  }, [currentAccountId]);

  // Load persistent full-resolution PDS images from IndexedDB on component mount
  useEffect(() => {
    getAllPdsImagesFromIndexedDB(currentAccountId)
      .then((imgs) => {
        if (imgs && imgs.length > 0) {
          setStoredPdsImages(imgs);
        }
      })
      .catch((err) => console.warn('[PDS Storage] Error loading IndexedDB photos:', err));
  }, [currentAccountId]);

  // Real-time Firestore Listener for PDS Pictures across all devices
  useEffect(() => {
    try {
      const unsubscribePictures = onSnapshot(
        collection(db, 'pds_pictures'),
        (snapshot) => {
          const cloudList: PdsStoredImage[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            const docAcc = data?.accountId || 'user-admin1';
            const isMatch = docAcc === currentAccountId || (currentAccountId === 'user-admin1' && docAcc === 'user-admin');
            if (data && data.src && isMatch) {
              cloudList.push({
                id: docSnap.id,
                src: data.src,
                accountId: docAcc,
                applicantName: data.applicantName || '',
                pageTitle: data.pageTitle || '',
                pageNumber: data.pageNumber || 1,
                searchKey: data.searchKey || '',
                createdAt: data.createdAt || '',
                uploadedAt: data.uploadedAt || '',
                docId: data.docId || '',
                order: data.order ?? 0,
              });
            }
          });

          if (cloudList.length > 0) {
            cloudList.sort(
              (a, b) =>
                (a.order ?? 0) - (b.order ?? 0) ||
                new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime()
            );
            setStoredPdsImages(cloudList);
            savePdsImagesToIndexedDB(cloudList, currentAccountId).catch(() => {});
          } else {
            // NEVER wipe local IndexedDB if cloud returns 0 temporarily or during reload/offline!
            // Only Delete All button is allowed to permanently wipe pictures.
            getAllPdsImagesFromIndexedDB(currentAccountId).then((cached) => {
              if (cached && cached.length > 0) {
                setStoredPdsImages(cached);
                // Also re-sync cached pictures to Firestore so other devices will have them!
                savePdsImagesToFirebaseAndIndexedDB(cached, currentAccountId).catch(() => {});
              }
            }).catch(() => {});
          }
        },
        (err) => {
          console.warn('[Firestore] pds_pictures onSnapshot error:', err);
        }
      );

      return () => unsubscribePictures();
    } catch (err) {
      console.warn('[Firestore] pds_pictures init error:', err);
    }
  }, [currentAccountId]);
  const [pdsSearchQuery, setPdsSearchQuery] = useState<string>('');
  const [galleryCurrentPage, setGalleryCurrentPage] = useState<number>(1);
  const [pdsGalleryViewMode, setPdsGalleryViewMode] = useState<'table' | 'grid'>('table');
  const GALLERY_PAGE_SIZE = 10;
  const [aiFilterMode, setAiFilterMode] = useState<AiFilterMode>('ai_ultra_clear');
  const [isHdClarityMode, setIsHdClarityMode] = useState<boolean>(true);
  const [isAiOrganizing, setIsAiOrganizing] = useState<boolean>(false);
  const [aiOrganizerToast, setAiOrganizerToast] = useState<string | null>(null);
  const [isAutoClarifyingAll, setIsAutoClarifyingAll] = useState<boolean>(false);
  const [autoDeduplicateEnabled, setAutoDeduplicateEnabled] = useState<boolean>(true);
  // AI Boost State: Accelerates image pre-processing, parallel OCR extraction, and instant deep indexed searching
  const [isAiBoostEnabled, setIsAiBoostEnabled] = useState<boolean>(true);
  const [showAiBoostModal, setShowAiBoostModal] = useState<boolean>(false);
  const [customPhotoNames, setCustomPhotoNames] = useState<Record<string, string>>({});
  const [editingPhotoId, setEditingPhotoId] = useState<string | null>(null);
  const [editingPhotoNameInput, setEditingPhotoNameInput] = useState<string>('');
  const [showDeleteAllConfirmModal, setShowDeleteAllConfirmModal] = useState<boolean>(false);
  const [isDeletingAll, setIsDeletingAll] = useState<boolean>(false);
  const [fullScreenPdsImage, setFullScreenPdsImage] = useState<{
    id: string;
    src: string;
    applicantName: string;
    pageTitle?: string;
    zoom: number;
    rotation: number;
  } | null>(null);
  const [isAiScanningFullScreen, setIsAiScanningFullScreen] = useState<boolean>(false);
  const [isEditingFullScreenName, setIsEditingFullScreenName] = useState<boolean>(false);
  const [editingFullScreenNameInput, setEditingFullScreenNameInput] = useState<string>('');
  const [isDragging, setIsDragging] = useState<boolean>(false);

  // Dynamic Custom Table Headers (Text Generated Table Feature)
  const [activeTargetHeaders, setActiveTargetHeaders] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('tindahan_custom_table_headers');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return TARGET_REQUESTED_HEADERS;
  });

  const [activeTemplateName, setActiveTemplateName] = useState<string>(() => {
    return localStorage.getItem('tindahan_custom_table_template_name') || 'Personal Data Sheet (19 Columns)';
  });

  const [isTextGeneratedModalOpen, setIsTextGeneratedModalOpen] = useState<boolean>(false);
  const [customHeadersInputText, setCustomHeadersInputText] = useState<string>('');
  const [customNewSingleHeader, setCustomNewSingleHeader] = useState<string>('');
  const textGeneratedFileInputRef = useRef<HTMLInputElement | null>(null);

  // Excel File Upload & Conditional PDS Picture Upload State & Refs
  const excelUploadFileInputRef = useRef<HTMLInputElement | null>(null);
  const excelPdsPictureFileInputRef = useRef<HTMLInputElement | null>(null);
  const [isVerifyingExcelPdsMatch, setIsVerifyingExcelPdsMatch] = useState<boolean>(false);
  const [verifyingPdsStepText, setVerifyingPdsStepText] = useState<string>('');
  const [pdsVerificationProgress, setPdsVerificationProgress] = useState<{
    current: number;
    total: number;
    matchedCount: number;
    unmatchedCount: number;
    activeFileNames: string[];
  }>({
    current: 0,
    total: 0,
    matchedCount: 0,
    unmatchedCount: 0,
    activeFileNames: [],
  });
  const pdsVerificationAbortRef = useRef<boolean>(false);
  const [excelMatchReportModal, setExcelMatchReportModal] = useState<{
    isOpen: boolean;
    matched: {
      fileName: string;
      applicantName: string;
      pdsDetectedName?: string;
      tableMatchedName?: string;
      rowIndex?: number;
    }[];
    unmatched: {
      id: string;
      fileName: string;
      base64?: string;
      candidateName: string;
      reason: string;
      pdsDetectedName?: string;
      selectedApplicantToLink?: string;
    }[];
  } | null>(null);

  // Multi-Table Management & Interactive Table List Modal State
  const [isTableListModalOpen, setIsTableListModalOpen] = useState<boolean>(false);
  const [tableListSearch, setTableListSearch] = useState<string>('');
  const [isDownloadTableModalOpen, setIsDownloadTableModalOpen] = useState<boolean>(false);
  const [selectedTableIdForDownload, setSelectedTableIdForDownload] = useState<string>('active');
  const [tableToDeleteConfirm, setTableToDeleteConfirm] = useState<{ id: string; title: string } | null>(null);

  // Real-Time Fullscreen Mobile AI Camera Scanner State
  const [isLiveScannerOpen, setIsLiveScannerOpen] = useState<boolean>(false);

  // Gallery Table (4-Box Scanner Queue System) - Persisted across reloads/exits
  const [galleryBoxes, setGalleryBoxes] = useState<GalleryBoxItem[]>(() => {
    try {
      const saved = localStorage.getItem('tindahan_gallery_boxes');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('[DocExtractor] Could not parse cached gallery boxes:', e);
    }
    return [
      { id: 'box-1', boxNumber: 1, imageSrc: null, status: 'empty' },
      { id: 'box-2', boxNumber: 2, imageSrc: null, status: 'empty' },
      { id: 'box-3', boxNumber: 3, imageSrc: null, status: 'empty' },
      { id: 'box-4', boxNumber: 4, imageSrc: null, status: 'empty' },
    ];
  });

  // Auto-persist gallery boxes to localStorage
  useEffect(() => {
    try {
      const cleanBoxes = galleryBoxes.map((b) => ({
        ...b,
        imageSrc: b.imageSrc && b.imageSrc.length < 500000 ? b.imageSrc : b.imageSrc ? b.imageSrc.slice(0, 200000) : null,
      }));
      localStorage.setItem('tindahan_gallery_boxes', JSON.stringify(cleanBoxes));
    } catch (e) {
      console.warn('[DocExtractor] Failed to cache gallery boxes:', e);
    }
  }, [galleryBoxes]);
  const [isGalleryQueueOpen, setIsGalleryQueueOpen] = useState<boolean>(false);
  const [isSequentialScanning, setIsSequentialScanning] = useState<boolean>(false);
  const [currentScanningBoxNum, setCurrentScanningBoxNum] = useState<number | null>(null);
  const [detectedRowSummaries, setDetectedRowSummaries] = useState<
    Record<
      number,
      {
        personName: string;
        headersDetected: string[];
        dataPreview: Record<string, string>;
        scannedBoxNumbers: number[];
        lastScannedAt: string;
      }
    >
  >({});
  const [deletedRowPopupInfo, setDeletedRowPopupInfo] = useState<{
    isOpen: boolean;
    rowName?: string;
  } | null>(null);

  // Automatic Duplicate Prevention Alert Modal State
  const [duplicateWarningInfo, setDuplicateWarningInfo] = useState<{
    isOpen: boolean;
    duplicateName: string;
    message?: string;
  } | null>(null);

  const isProcessingQueueRef = useRef<boolean>(false);

  // Helper to ensure 100% accurate 1-to-1 parity between PDS Pictures and Table Rows
  // "kung ilan ang datang nakalagay sa pds picture ganun din ang lalabas na data sa table dapat kaya dapat accurate"
  const reconcilePdsPicturesAndTableRows = useCallback(
    (
      currentTable: ExtractedDocumentResult | null,
      pdsList: PdsStoredImage[],
      headers: string[] = activeTargetHeaders
    ): { updatedTable: ExtractedDocumentResult | null; hasChanged: boolean } => {
      if (!pdsList || pdsList.length === 0) {
        return { updatedTable: currentTable, hasChanged: false };
      }

      const currentHeaders = headers && headers.length > 0 ? headers : TARGET_REQUESTED_HEADERS;
      const primaryHdrKey =
        currentHeaders.find((h) => {
          const hLow = h.toLowerCase();
          return hLow.includes('name') || hLow.includes('pangalan') || hLow.includes('surname') || hLow.includes('item');
        }) || currentHeaders[0] || 'NAME (SURNAME, FIRST NAME, MIDDLE NAME)';

      const currentRows = (currentTable?.sections || []).flatMap((s) => s.rows || []);

      // Filter out pure placeholder empty rows if any
      const meaningfulRows = currentRows.filter((r) =>
        Object.values(r).some((v) => !isValuePlaceholderOrNA(v))
      );

      const workingRows = [...meaningfulRows];
      let changed = false;

      // Ensure every PDS picture has an exact corresponding row in workingRows with matching Full Name
      pdsList.forEach((pds, idx) => {
        let pdsName = (pds.applicantName || '').trim();
        if (!pdsName) return;

        // Check if row already exists for this applicant
        let matchIdx = workingRows.findIndex((row) => {
          const rName = (
            row['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
            row['FULL NAME'] ||
            row['PANGALAN'] ||
            row['SURNAME'] ||
            row[primaryHdrKey] ||
            ''
          ).trim();
          return checkApplicantNamesMatch(pdsName, rName);
        });

        // Fallback: match by index if pdsName is a filename/hash or generic label
        if (matchIdx === -1 && idx < workingRows.length) {
          const rowAtIdx = workingRows[idx];
          const rName = (
            rowAtIdx['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
            rowAtIdx['FULL NAME'] ||
            rowAtIdx['PANGALAN'] ||
            rowAtIdx['SURNAME'] ||
            rowAtIdx[primaryHdrKey] ||
            ''
          ).trim();
          if (rName && isRealApplicantName(rName) && !isLikelyFilenameOrHash(rName)) {
            matchIdx = idx;
            // Also update pds.applicantName so the PDS picture takes the Table's Full Name!
            pds.applicantName = rName.toUpperCase();
            pdsName = rName.toUpperCase();
          }
        }

        if (matchIdx === -1) {
          // If pdsName is a filename/hash, DO NOT add a row with a hash name!
          if (!isLikelyFilenameOrHash(pdsName) && isRealApplicantName(pdsName)) {
            const newRow: Record<string, string> = {
              [primaryHdrKey]: pdsName.toUpperCase(),
              'NAME (SURNAME, FIRST NAME, MIDDLE NAME)': pdsName.toUpperCase(),
            };
            currentHeaders.forEach((h) => {
              if (newRow[h] === undefined) newRow[h] = '';
            });
            workingRows.push(newRow);
            changed = true;
          }
        } else {
          // Row exists - ensure both Table and PDS picture have the exact Full Name
          const ex = workingRows[matchIdx];
          const exName = ex['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || ex[primaryHdrKey] || '';
          if (isValuePlaceholderOrNA(exName) || exName.toLowerCase().startsWith('aplikante') || isLikelyFilenameOrHash(exName)) {
            if (isRealApplicantName(pdsName) && !isLikelyFilenameOrHash(pdsName)) {
              ex['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] = pdsName.toUpperCase();
              ex[primaryHdrKey] = pdsName.toUpperCase();
              changed = true;
            }
          } else if (isRealApplicantName(exName) && !isLikelyFilenameOrHash(exName) && (isLikelyFilenameOrHash(pds.applicantName) || !isRealApplicantName(pds.applicantName))) {
            pds.applicantName = exName.toUpperCase();
          }
        }
      });

      if (!changed && currentTable) {
        return { updatedTable: currentTable, hasChanged: false };
      }

      const rechunked = chunkRowsIntoSections(
        workingRows.length > 0 ? workingRows : [{ [primaryHdrKey]: '' }],
        currentTable?.sections?.[0]?.checkboxes || [],
        currentHeaders
      );

      const updatedTable: ExtractedDocumentResult = {
        id: currentTable?.id || SHARED_MASTER_TABLE_ID,
        title: currentTable?.title || 'Personal Data Sheet Master Table',
        detectedPersonName:
          workingRows[0]?.[primaryHdrKey] ||
          workingRows[0]?.['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
          'Master Applicant List',
        documentType: currentTable?.documentType || `Personal Data Sheet (${currentHeaders.length} Columns)`,
        totalPages: rechunked.length,
        detectedPageNumbers: rechunked.map((_, i) => `Sheet ${i + 1}`),
        sections: rechunked,
        consolidatedMarkdownTable: currentTable?.consolidatedMarkdownTable || '',
        signaturesAndDates: currentTable?.signaturesAndDates || [],
        unreadableSummary: currentTable?.unreadableSummary || '',
        privacyNoticeAcknowledged: true,
        scannedAt: currentTable?.scannedAt || new Date().toISOString(),
        imagesBase64: Array.from(
          new Set([
            ...(currentTable?.imagesBase64 || []),
            ...pdsList.map((p) => p.src).filter(Boolean),
          ])
        ),
      };

      return { updatedTable, hasChanged: true };
    },
    [activeTargetHeaders]
  );

  // Reactive Effect: Continuously reconcile and guarantee 1-to-1 sync whenever PDS pictures are loaded
  useEffect(() => {
    if (!storedPdsImages || storedPdsImages.length === 0) return;
    const { updatedTable, hasChanged } = reconcilePdsPicturesAndTableRows(
      result,
      storedPdsImages,
      activeTargetHeaders
    );
    if (hasChanged && updatedTable) {
      setResult(updatedTable);
      saveUpdatedResult(updatedTable);
    }
  }, [storedPdsImages, activeTargetHeaders, reconcilePdsPicturesAndTableRows]);

  // Manual Trigger for 1:1 PDS & Table Row Synchronization
  const handleManualPdsTableSync = async () => {
    if (!storedPdsImages || storedPdsImages.length === 0) {
      triggerAutoSaveToast('Walang PDS pictures na naka-save sa database.');
      return;
    }

    // Bidirectionally synchronize full names:
    // 1. If table row has full name, update PDS picture applicantName to that exact Full Name!
    // 2. If PDS picture has full name (from OCR), update Table row to that exact Full Name!
    const allRows = (result?.sections || []).flatMap((s) => s.rows || []);
    const updatedPds = [...storedPdsImages];
    let pdsUpdated = false;

    updatedPds.forEach((pds, idx) => {
      const pName = (pds.applicantName || '').trim();
      const rowAtIdx = allRows[idx];
      const rName = (
        rowAtIdx?.['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
        rowAtIdx?.['FULL NAME'] ||
        rowAtIdx?.['PANGALAN'] ||
        rowAtIdx?.['SURNAME'] ||
        ''
      )?.trim();

      if (
        (isLikelyFilenameOrHash(pName) || !isRealApplicantName(pName)) &&
        rName &&
        isRealApplicantName(rName) &&
        !isLikelyFilenameOrHash(rName)
      ) {
        pds.applicantName = rName.toUpperCase();
        pdsUpdated = true;
      }
    });

    if (pdsUpdated) {
      setStoredPdsImages(updatedPds);
      await savePdsImagesToFirebaseAndIndexedDB(updatedPds, currentAccountId);
    }

    const { updatedTable } = reconcilePdsPicturesAndTableRows(
      result,
      updatedPds,
      activeTargetHeaders
    );
    if (updatedTable) {
      setResult(updatedTable);
      saveUpdatedResult(updatedTable);
      const totalRows = (updatedTable.sections || [])
        .flatMap((s) => s.rows || [])
        .filter(
          (r) =>
            !isValuePlaceholderOrNA(
              r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || r['PANGALAN'] || ''
            )
        ).length;
      triggerAutoSaveToast(
        `✅ Matagumpay na nai-sync! Ang Full Name ng lahat ng ${updatedPds.length} PDS Picture(s) ay 100% tugma sa Table Content (${totalRows} rows).`
      );
    }
  };

  // Apply custom headers -> AUTOMATICALLY ADDS ANOTHER TABLE into the system
  const handleApplyCustomHeaders = (
    newHeaders: string[],
    templateName: string = 'Custom Form Table',
    autoAction?: 'scanner' | 'upload' | 'apply_only'
  ) => {
    if (!newHeaders || newHeaders.length === 0) {
      setErrorMessage('Mangyaring maglagay ng kahit isang header para sa table.');
      return;
    }

    const cleanHeaders = Array.from(new Set(newHeaders.map((h) => h.trim()).filter((h) => h.length > 0)));
    if (cleanHeaders.length === 0) {
      setErrorMessage('Walang valid na header ang nakita.');
      return;
    }

    setActiveTargetHeaders(cleanHeaders);
    setActiveTemplateName(templateName);
    try {
      localStorage.setItem('tindahan_custom_table_headers', JSON.stringify(cleanHeaders));
      localStorage.setItem('tindahan_custom_table_template_name', templateName);
    } catch (e) {
      console.warn('[DocExtractor] Failed to cache custom headers in localStorage:', e);
    }

    // Save previous active result to Firestore so it is safely archived
    if (result && result.id) {
      saveDocumentToFirestore(result);
    }

    // Calculate new table index & unique title
    const tableIndex = (combinedDatabaseDocs.length || 0) + 1;
    const finalTableTitle = templateName
      ? `${templateName} (Table ${tableIndex})`
      : `Table ${tableIndex}`;

    // Create a clean empty structure for the NEW TABLE with 1 blank row ready for scanning/editing
    const blankRow: Record<string, string> = {};
    cleanHeaders.forEach((h) => (blankRow[h] = ''));
    const newSecs = chunkRowsIntoSections([blankRow], [], cleanHeaders);

    const mdHeaders = cleanHeaders.join(' | ');
    const mdDividers = cleanHeaders.map(() => '---').join(' | ');
    const mdRows = cleanHeaders.map(() => '-').join(' | ');

    const newDoc: ExtractedDocumentResult = {
      id: `DOC-TABLE-${Date.now()}`,
      title: finalTableTitle,
      detectedPersonName: 'Walang Nakasalang',
      documentType: `${templateName} (${cleanHeaders.length} Columns)`,
      totalPages: 1,
      detectedPageNumbers: ['Sheet 1'],
      sections: newSecs,
      consolidatedMarkdownTable: `| ${mdHeaders} |\n| ${mdDividers} |\n| ${mdRows} |`,
      signaturesAndDates: [],
      unreadableSummary: '',
      privacyNoticeAcknowledged: true,
      scannedAt: new Date().toISOString(),
      imagesBase64: [],
    };

    // Save the new table as the active table and persist to Firestore + localStorage
    setResult(newDoc);
    saveUpdatedResult(newDoc);
    setSelectedSheetTab(0);

    setIsTextGeneratedModalOpen(false);

    if (autoAction === 'scanner') {
      triggerAutoSaveToast(`🎯 Na-add ang bagong table ("${finalTableTitle}") na may ${cleanHeaders.length} Columns! Binubuksan ang AI Camera Scanner...`);
      setTimeout(() => {
        setIsLiveScannerOpen(true);
      }, 200);
    } else if (autoAction === 'upload') {
      triggerAutoSaveToast(`🎯 Na-add ang bagong table ("${finalTableTitle}") na may ${cleanHeaders.length} Columns! Pumili ng larawan o folder na i-scan...`);
      setTimeout(() => {
        if (textGeneratedFileInputRef.current) {
          textGeneratedFileInputRef.current.click();
        }
      }, 250);
    } else {
      triggerAutoSaveToast(`✨ Matagumpay na nag-add ng panibagong Table ("${finalTableTitle}") na may ${cleanHeaders.length} columns!`);
    }
  };

  // Handler to switch active table from Table List
  const handleSwitchActiveTable = (tableDoc: ExtractedDocumentResult) => {
    const normalized = ensure20RowsPerSheet(tableDoc);
    if (!normalized) return;
    setResult(normalized);
    setSelectedSheetTab(0);
    if (normalized.sections?.[0]?.headers && normalized.sections[0].headers.length > 0) {
      setActiveTargetHeaders(normalized.sections[0].headers);
    }
    if (normalized.title) {
      setActiveTemplateName(normalized.title);
    }
    try {
      localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(normalized));
    } catch (e) {
      console.warn('[DocExtractor] Failed to cache active table switch:', e);
    }
    setIsTableListModalOpen(false);
    triggerAutoSaveToast(`📋 Binuksan ang Table: "${normalized.title || 'Table'}"!`);
  };

  // Handler to delete a table completely from Firestore, state, and local storage
  const handleDeleteTable = async (tableId: string, tableTitle?: string) => {
    try {
      await deleteDocumentFromFirestore(tableId);
      setTableToDeleteConfirm(null);
      triggerAutoSaveToast(`🗑️ Permanenteng nabura ang Table "${tableTitle || tableId}"!`);
    } catch (err) {
      console.error('[DocExtractor] Error deleting table:', err);
    }
  };

  // Add 4 more boxes to the Gallery Table (up to 50 sets / 200 boxes capacity)
  const handleAdd4MoreBoxes = (countOfSets: number = 1) => {
    setGalleryBoxes((prev) => {
      const curLen = prev.length;
      const curSets = Math.ceil(curLen / 4);
      if (curSets >= 50) {
        triggerAutoSaveToast('Nasa maximum capacity na ang Gallery Table (50 Sets / 200 Boxes)!');
        return prev;
      }
      
      const setsToAdd = Math.min(countOfSets, 50 - curSets);
      const newItems: GalleryBoxItem[] = [];
      for (let s = 0; s < setsToAdd; s++) {
        const baseNum = curLen + s * 4;
        newItems.push(
          { id: `box-${baseNum + 1}`, boxNumber: baseNum + 1, imageSrc: null, status: 'empty' },
          { id: `box-${baseNum + 2}`, boxNumber: baseNum + 2, imageSrc: null, status: 'empty' },
          { id: `box-${baseNum + 3}`, boxNumber: baseNum + 3, imageSrc: null, status: 'empty' },
          { id: `box-${baseNum + 4}`, boxNumber: baseNum + 4, imageSrc: null, status: 'empty' },
        );
      }
      return [...prev, ...newItems];
    });
    triggerAutoSaveToast(
      countOfSets > 1
        ? `Nagdagdag ng ${countOfSets * 4} na kahon (${countOfSets} sets) sa Gallery Table!`
        : 'Nagdagdag ng 4 na bagong kahon (1 set) sa Gallery Table!'
    );
  };

  // Clear all boxes in gallery
  const handleClearAllGalleryBoxes = () => {
    if (galleryBoxes.every((b) => !b.imageSrc)) return;
    if (window.confirm('Linisin ang lahat ng nakasalang na larawan sa mga kahon ng Gallery Table?')) {
      setGalleryBoxes((prev) =>
        prev.map((b) => ({ ...b, imageSrc: null, status: 'empty', capturedAt: undefined, enqueuedAt: undefined }))
      );
      triggerAutoSaveToast('Nalinis ang lahat ng kahon sa Gallery Table!');
    }
  };

  // Remove single box photo
  const handleRemoveSingleBoxPhoto = (boxNumber: number) => {
    setGalleryBoxes((prev) =>
      prev.map((b) =>
        b.boxNumber === boxNumber
          ? { ...b, imageSrc: null, status: 'empty', capturedAt: undefined, enqueuedAt: undefined, errorMessage: undefined }
          : b
      )
    );
  };

  // Assign captured/uploaded photo to a specific box (strictly FIFO with enqueuedAt timestamp)
  const handleAssignPhotoToBox = (photoSrc: string, boxNumber: number) => {
    const enqueueTime = Date.now();
    setGalleryBoxes((prev) => {
      let updated = [...prev];
      while (updated.length < boxNumber) {
        const cur = updated.length;
        updated.push(
          { id: `box-${cur + 1}`, boxNumber: cur + 1, imageSrc: null, status: 'empty' },
          { id: `box-${cur + 2}`, boxNumber: cur + 2, imageSrc: null, status: 'empty' },
          { id: `box-${cur + 3}`, boxNumber: cur + 3, imageSrc: null, status: 'empty' },
          { id: `box-${cur + 4}`, boxNumber: cur + 4, imageSrc: null, status: 'empty' }
        );
      }
      return updated.map((b) =>
        b.boxNumber === boxNumber
          ? { ...b, imageSrc: photoSrc, status: 'queued', capturedAt: new Date().toLocaleTimeString(), enqueuedAt: enqueueTime, errorMessage: undefined }
          : b
      );
    });

    setIsLiveScannerOpen(false);
    setIsGalleryQueueOpen(true);
    triggerAutoSaveToast(`Nailagay ang PDS sa Box ${boxNumber} ng Gallery Table!`);

    // Awtomatikong mabilis na uunahin ng AI ang unang pumasok na larawan (FIFO 1-by-1)
    setTimeout(() => {
      triggerSequentialAiBoxProcessing();
    }, 250);
  };

  // Add new 4 boxes and assign photo to the first slot of the new set
  const handleAddNew4BoxesAndAssignPhoto = (photoSrc: string) => {
    let targetNum = 1;
    const enqueueTime = Date.now();
    setGalleryBoxes((prev) => {
      const curLen = prev.length;
      targetNum = curLen + 1;
      const newItems: GalleryBoxItem[] = [
        { id: `box-${curLen + 1}`, boxNumber: curLen + 1, imageSrc: photoSrc, status: 'queued', capturedAt: new Date().toLocaleTimeString(), enqueuedAt: enqueueTime },
        { id: `box-${curLen + 2}`, boxNumber: curLen + 2, imageSrc: null, status: 'empty' },
        { id: `box-${curLen + 3}`, boxNumber: curLen + 3, imageSrc: null, status: 'empty' },
        { id: `box-${curLen + 4}`, boxNumber: curLen + 4, imageSrc: null, status: 'empty' },
      ];
      return [...prev, ...newItems];
    });

    setIsLiveScannerOpen(false);
    setIsGalleryQueueOpen(true);
    triggerAutoSaveToast(`Nagdagdag ng 4 bagong boxes at nailagay ang larawan sa Box ${targetNum}!`);

    setTimeout(() => {
      triggerSequentialAiBoxProcessing();
    }, 250);
  };

  // Universal Smart Matcher & Conditional Merger:
  // Kapag na-detect ng AI na nahanap na ang data at inilagay na sa table, pero pina-scan pa rin,
  // awtomatikong pupunan LAMANG ang mga HEADER na naka-N/A (o empty/placeholder) sa row ng parehong aplikante.
  const mergeSingleExtractedRowIntoRows = (
    existingRows: Record<string, string>[],
    normalizedRow: Record<string, string>,
    headers: string[],
    explicitTargetIndex?: number
  ): { updatedRows: Record<string, string>[]; targetIndex: number; isMergedIntoExisting: boolean; filledHeaders: string[] } => {
    const updatedRows = [...existingRows];
    const filledHeaders: string[] = [];

    // Case 1: Explicit target row index provided (e.g. from 4-box gallery set)
    if (typeof explicitTargetIndex === 'number' && explicitTargetIndex >= 0) {
      if (explicitTargetIndex < updatedRows.length) {
        const existing = { ...updatedRows[explicitTargetIndex] };
        headers.forEach((h) => {
          const newVal = normalizedRow[h];
          const oldVal = existing[h];
          if (!isValuePlaceholderOrNA(newVal)) {
            if (isValuePlaceholderOrNA(oldVal) || String(newVal).length > String(oldVal || '').length) {
              existing[h] = String(newVal);
              filledHeaders.push(h);
            }
          }
        });
        updatedRows[explicitTargetIndex] = existing;
        return { updatedRows, targetIndex: explicitTargetIndex, isMergedIntoExisting: true, filledHeaders };
      } else {
        updatedRows.push(normalizedRow);
        return { updatedRows, targetIndex: updatedRows.length - 1, isMergedIntoExisting: false, filledHeaders };
      }
    }

    // Case 2: Auto-match same applicant/data row by ID or Name
    const newName = String(
      normalizedRow['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
      normalizedRow['FULL NAME'] ||
      normalizedRow['PANGALAN'] ||
      normalizedRow['SURNAME'] ||
      ''
    ).trim().toLowerCase();

    const newPhilSys = String(normalizedRow['PhilSys Number (PSN)'] || '').trim();
    const newSSS = String(normalizedRow['SSS NO.'] || normalizedRow['SSS / GSIS NO'] || '').trim();
    const newTIN = String(normalizedRow['TIN NO.'] || normalizedRow['TIN'] || '').trim();
    const newPhilHealth = String(normalizedRow['PHILHEALTH NO.'] || '').trim();
    const newPagIbig = String(normalizedRow['PAG IBIG NO.'] || normalizedRow['PAG-IBIG NO'] || '').trim();
    const newVoters = String(normalizedRow["Voter's Identification Number :"] || '').trim();

    let matchIndex = -1;

    // 2a. Match by Unique Government / National IDs
    if (matchIndex === -1 && (newPhilSys || newSSS || newTIN || newPhilHealth || newPagIbig || newVoters)) {
      matchIndex = updatedRows.findIndex((ex) => {
        if (newPhilSys && !isValuePlaceholderOrNA(newPhilSys) && String(ex['PhilSys Number (PSN)'] || '').trim() === newPhilSys) return true;
        if (newSSS && !isValuePlaceholderOrNA(newSSS) && String(ex['SSS NO.'] || ex['SSS / GSIS NO'] || '').trim() === newSSS) return true;
        if (newTIN && !isValuePlaceholderOrNA(newTIN) && String(ex['TIN NO.'] || ex['TIN'] || '').trim() === newTIN) return true;
        if (newPhilHealth && !isValuePlaceholderOrNA(newPhilHealth) && String(ex['PHILHEALTH NO.'] || '').trim() === newPhilHealth) return true;
        if (newPagIbig && !isValuePlaceholderOrNA(newPagIbig) && String(ex['PAG IBIG NO.'] || ex['PAG-IBIG NO'] || '').trim() === newPagIbig) return true;
        if (newVoters && !isValuePlaceholderOrNA(newVoters) && String(ex["Voter's Identification Number :"] || '').trim() === newVoters) return true;
        return false;
      });
    }

    // 2b. Match by Applicant Name (Exact or Multi-word overlap)
    if (matchIndex === -1 && newName && !isValuePlaceholderOrNA(newName)) {
      matchIndex = updatedRows.findIndex((ex) => {
        const exName = String(
          ex['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
          ex['FULL NAME'] ||
          ex['PANGALAN'] ||
          ex['SURNAME'] ||
          ''
        ).trim().toLowerCase();

        if (!exName || isValuePlaceholderOrNA(exName)) return false;
        if (exName === newName) return true;

        const partsA = exName.split(/[\s,]+/).filter((p) => p.length > 2);
        const partsB = newName.split(/[\s,]+/).filter((p) => p.length > 2);
        const common = partsA.filter((p) => partsB.includes(p));
        return common.length >= 2;
      });
    }

    // 2c. If new scan is a continuation page without name (e.g. Page 2 / 3 with Blood Type, SSS, Weight, Height, etc.)
    if (matchIndex === -1 && isValuePlaceholderOrNA(newName) && updatedRows.length > 0) {
      const lastIdx = updatedRows.length - 1;
      const hasUnfilled = headers.some((h) => isValuePlaceholderOrNA(updatedRows[lastIdx][h]) && !isValuePlaceholderOrNA(normalizedRow[h]));
      if (hasUnfilled) {
        matchIndex = lastIdx;
      }
    }

    // 2d. Perform conditional merge into existing matching row (FILL ONLY N/A or EMPTY HEADERS)
    if (matchIndex !== -1) {
      const existing = { ...updatedRows[matchIndex] };
      headers.forEach((h) => {
        const newVal = normalizedRow[h];
        const oldVal = existing[h];
        if (!isValuePlaceholderOrNA(newVal)) {
          if (isValuePlaceholderOrNA(oldVal) || String(newVal).length > String(oldVal || '').length) {
            existing[h] = String(newVal);
            filledHeaders.push(h);
          }
        }
      });
      updatedRows[matchIndex] = existing;
      return { updatedRows, targetIndex: matchIndex, isMergedIntoExisting: true, filledHeaders };
    } else {
      // Distinct new applicant -> Append new row
      updatedRows.push(normalizedRow);
      return { updatedRows, targetIndex: updatedRows.length - 1, isMergedIntoExisting: false, filledHeaders };
    }
  };

  // Handler for row extracted from live AI camera scanner or gallery boxes
  const handleLiveScannerRowExtracted = (
    extractedRow: Record<string, string>,
    imageSrc?: string,
    targetRowIndex?: number,
    boxNum?: number
  ) => {
    if (!extractedRow || Object.keys(extractedRow).length === 0) return;

    // Check if extracted row has any meaningful content
    const hasData = Object.values(extractedRow).some((v) => !isValuePlaceholderOrNA(v));
    if (!hasData) return;

    const currentHeaders =
      activeTargetHeaders && activeTargetHeaders.length > 0
        ? activeTargetHeaders
        : TARGET_REQUESTED_HEADERS;

    // Normalize row keys to match currentHeaders
    const normalizedRow: Record<string, string> = {};
    currentHeaders.forEach((hdr) => {
      if (extractedRow[hdr] !== undefined) {
        normalizedRow[hdr] = String(extractedRow[hdr] || '');
      } else {
        const cleanHdr = hdr.toLowerCase().replace(/[^a-z0-9]/g, '');
        const foundKey = Object.keys(extractedRow).find((k) => {
          const cleanK = k.toLowerCase().replace(/[^a-z0-9]/g, '');
          return cleanHdr.includes(cleanK) || cleanK.includes(cleanHdr);
        });
        normalizedRow[hdr] = foundKey ? String(extractedRow[foundKey] || '') : '';
      }
    });

    let mergeInfo: { isMergedIntoExisting: boolean; filledHeaders: string[]; targetIndex: number } = {
      isMergedIntoExisting: false,
      filledHeaders: [],
      targetIndex: 0,
    };

    setResult((prevResult) => {
      const allExistingRows = prevResult?.sections?.flatMap((s) => s.rows || []) || [];
      const nonPlaceholderRows = allExistingRows.filter((r) =>
        Object.values(r).some((v) => !isValuePlaceholderOrNA(v))
      );

      const mergeResult = mergeSingleExtractedRowIntoRows(
        nonPlaceholderRows,
        normalizedRow,
        currentHeaders,
        targetRowIndex
      );

      mergeInfo = {
        isMergedIntoExisting: mergeResult.isMergedIntoExisting,
        filledHeaders: mergeResult.filledHeaders,
        targetIndex: mergeResult.targetIndex,
      };

      const updatedRows = mergeResult.updatedRows;

      const updatedSections = chunkRowsIntoSections(
        updatedRows.length > 0 ? updatedRows : [normalizedRow],
        prevResult?.sections?.[0]?.checkboxes || [],
        currentHeaders
      );

      const mdHeaders = currentHeaders.join(' | ');
      const mdDividers = currentHeaders.map(() => '---').join(' | ');
      const mdRows = updatedRows
        .map((r) => currentHeaders.map((h) => String(r[h] || '-')).join(' | '))
        .join('\n');

      const targetRow = updatedRows[mergeResult.targetIndex] || normalizedRow;
      const detectedDocName =
        targetRow['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
        targetRow[currentHeaders[0]] ||
        prevResult?.detectedPersonName ||
        'Aplikante';

      const updatedDoc: ExtractedDocumentResult = {
        id: prevResult?.id || `DOC-AI-${Date.now()}`,
        title: activeTemplateName || prevResult?.title || 'AI Document Extraction',
        detectedPersonName: detectedDocName,
        documentType: `${activeTemplateName} (${currentHeaders.length} Columns)`,
        totalPages: (prevResult?.totalPages || 0) + 1,
        detectedPageNumbers: prevResult?.detectedPageNumbers || ['Page 1'],
        sections: updatedSections,
        consolidatedMarkdownTable: `| ${mdHeaders} |\n| ${mdDividers} |\n${mdRows}`,
        signaturesAndDates: prevResult?.signaturesAndDates || [],
        unreadableSummary: '',
        privacyNoticeAcknowledged: true,
        scannedAt: new Date().toISOString(),
        imagesBase64: imageSrc
          ? Array.from(new Set([...(prevResult?.imagesBase64 || []), imageSrc]))
          : prevResult?.imagesBase64 || [],
      };

      saveUpdatedResult(updatedDoc);
      return updatedDoc;
    });

    const detectedName =
      normalizedRow['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
      normalizedRow[currentHeaders[0]] ||
      (boxNum ? `Box ${boxNum}` : 'Aplikante');

    if (mergeInfo.isMergedIntoExisting && mergeInfo.filledHeaders.length > 0) {
      triggerAutoSaveToast(
        `✨ Awtomatikong pinunan ang N/A para kay "${detectedName}": (${mergeInfo.filledHeaders.slice(0, 3).join(', ')}${mergeInfo.filledHeaders.length > 3 ? ` +${mergeInfo.filledHeaders.length - 3} pa` : ''}) sa Row ${mergeInfo.targetIndex + 1}!`
      );
    } else {
      triggerAutoSaveToast(`🎯 AI Scanner: Matagumpay na naipasok ang datos para kay "${detectedName}"!`);
    }
  };

  // Handler to mark all non-empty gallery boxes as queued and launch AI scan
  const handleStartScanAllGalleryBoxes = async () => {
    if (isSequentialScanning) return;

    // Enqueue all boxes that currently have an image
    setGalleryBoxes((prev) =>
      prev.map((b) =>
        b.imageSrc
          ? { ...b, status: 'queued', enqueuedAt: b.enqueuedAt || Date.now() }
          : b
      )
    );

    await triggerSequentialAiBoxProcessing();
  };

  // Rapid Sequential AI Scanner for Gallery Boxes (STRICT FIFO: Unang Pumasok -> Unang I-scan, 1-by-1 para WALANG LAG)
  const triggerSequentialAiBoxProcessing = async () => {
    if (isProcessingQueueRef.current) return;
    isProcessingQueueRef.current = true;
    setIsSequentialScanning(true);

    let totalScannedThisBatch = 0;

    try {
      let keepRunning = true;
      while (keepRunning) {
        let nextTarget: GalleryBoxItem | undefined;

        setGalleryBoxes((current) => {
          // STRICT FIFO: Sort by earliest enqueued timestamp first; if equal, by box number
          const queued = current
            .filter((b) => (b.status === 'queued' || (!!b.imageSrc && b.status === 'empty')) && !!b.imageSrc)
            .sort((a, b) => {
              const timeA = a.enqueuedAt || 0;
              const timeB = b.enqueuedAt || 0;
              if (timeA !== timeB && timeA > 0 && timeB > 0) {
                return timeA - timeB;
              }
              return a.boxNumber - b.boxNumber;
            });

          if (queued.length > 0) {
            nextTarget = queued[0];
            return current.map((b) =>
              b.id === nextTarget!.id ? { ...b, status: 'scanning' } : b
            );
          }
          return current;
        });

        await new Promise((r) => setTimeout(r, 60));

        if (!nextTarget || !nextTarget.imageSrc) {
          keepRunning = false;
          break;
        }

        const currentBox = nextTarget;
        const boxNum = currentBox.boxNumber;
        const imgData = currentBox.imageSrc;
        setCurrentScanningBoxNum(boxNum);

        // 🎯 4-BOX SET (SERYE) TO SPREADSHEET ROW MAPPING:
        // Serye 1 (Boxes 1, 2, 3, 4)  -> Row 1 (Index 0)
        // Serye 2 (Boxes 5, 6, 7, 8)  -> Row 2 (Index 1)
        // Serye 3 (Boxes 9, 10, 11, 12) -> Row 3 (Index 2)
        const seryeNumber = Math.ceil(boxNum / 4);
        const targetRowIndex = seryeNumber - 1;
        const pageNumberInSet = ((boxNum - 1) % 4) + 1;

        try {
          // AI Extraction (Single instance per iteration to avoid any UI or network lag)
          const aiResult = await extractDocumentClientSide([imgData], `Gallery Box ${boxNum} (Serye ${seryeNumber} - Pahina ${pageNumberInSet}) PDS Snapshot`);
          let extractedRow: Record<string, string> = {};
          if (aiResult && aiResult.data && aiResult.data.sections && aiResult.data.sections.length > 0) {
            extractedRow = aiResult.data.sections[0]?.rows?.[0] || {};
          }

          const rawDetectedName =
            extractedRow['NAME (SURNAME, FIRST NAME, MIDDLE NAME)']?.trim() ||
            extractedRow['PANGALAN']?.trim() ||
            '';

          // 🛑 BAGO I-UPLOAD: CHECK KUNG MAY KAPAREHONG NAME / DUPLICATE DATA
          if (isRealApplicantName(rawDetectedName)) {
            const existingStoredPds = await getAllPdsImagesFromIndexedDB().catch(() => storedPdsImages);
            const foundInPds = existingStoredPds.find((p) => checkApplicantNamesMatch(rawDetectedName, p.applicantName));

            const allExistingRows = (result?.sections || []).flatMap((s) => s.rows || []);
            const foundInTable = allExistingRows.find((r, rIdx) => {
              if (rIdx === targetRowIndex) return false; // Pinapayagan ang pag-merge sa parehong Serye / Row
              const rName = r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || r['PANGALAN'] || '';
              return checkApplicantNamesMatch(rawDetectedName, rName);
            });

            if (foundInPds || foundInTable) {
              // ⚠️ NA-DETECT NA DUPLICATE ANG DATA: HINDI ITO MA-U-UPLOAD!
              setDuplicateWarningInfo({
                isOpen: true,
                duplicateName: rawDetectedName,
                message: `Na-detect na DUPLICATE ang datos para kay "${rawDetectedName}". Hindi ito nai-upload sa PDS Pictures o Table upang maiwasan ang duplicate. Kung nais mong i-upload ang bago o panibagong larawan nito, burahin mo muna ang dating naka-upload na datos o larawan sa PDS Pictures o Table.`
              });
              triggerAutoSaveToast(`⚠️ Duplicate Na-detect: Hindi nai-upload ang Box ${boxNum} dahil may umiiral nang datos para kay "${rawDetectedName}". Burahin muna ang dating naka-upload kung nais palitan.`);

              // Alisin ang larawan sa box upang hindi ito mag-stuck
              setGalleryBoxes((prev) =>
                prev.map((b) =>
                  b.boxNumber === boxNum
                    ? {
                        ...b,
                        imageSrc: null,
                        status: 'empty',
                        capturedAt: undefined,
                        enqueuedAt: undefined,
                        personName: undefined,
                        extractedData: undefined,
                      }
                    : b
                )
              );
              continue;
            }
          }

          // 1. Instantly merge/populate into target Serye row in main spreadsheet table & Firestore
          handleLiveScannerRowExtracted(extractedRow, imgData, targetRowIndex, boxNum);

          // 2. Upload and store picture into PDS Picture content (IndexedDB) with clear Serye, Page, and Row metadata
          const detectedName =
            rawDetectedName ||
            `Aplikante (Row ${seryeNumber} - Box ${boxNum})`;

          const pdsImageItem: PdsStoredImage = {
            id: `pds-box-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            src: imgData,
            applicantName: detectedName,
            pageTitle: `Row ${seryeNumber} (Serye ${seryeNumber}) - Box ${pageNumberInSet} (PDS Pahina ${pageNumberInSet})`,
            pageNumber: pageNumberInSet,
            searchKey: `${detectedName} row ${seryeNumber} serye ${seryeNumber} box ${boxNum} pahina ${pageNumberInSet}`.toLowerCase(),
            createdAt: new Date().toISOString(),
          };

          await savePdsImagesToFirebaseAndIndexedDB([pdsImageItem], activeUser?.id);
          setStoredPdsImages((prev) => [pdsImageItem, ...prev.filter((p) => p.src !== imgData)]);

          // 3. Awtomatikong alisin ang picture sa gallery table box dahil nailipat na ito sa PDS Pictures
          setGalleryBoxes((prev) =>
            prev.map((b) =>
              b.boxNumber === boxNum
                ? {
                    ...b,
                    imageSrc: null,
                    status: 'empty',
                    capturedAt: undefined,
                    enqueuedAt: undefined,
                    personName: undefined,
                    extractedData: undefined,
                  }
                : b
            )
          );

          totalScannedThisBatch++;
          triggerAutoSaveToast(`⚡ Na-scan ang Box ${boxNum} (Pahina ${pageNumberInSet})! Naipasok sa Row ${seryeNumber} ng Table at nailipat sa PDS Pictures!`);
        } catch (err: any) {
          console.warn(`Error scanning box ${boxNum}:`, err);
          setGalleryBoxes((prev) =>
            prev.map((b) =>
              b.boxNumber === boxNum
                ? { ...b, status: 'error', errorMessage: 'Nagka-error sa scan' }
                : b
            )
          );
        }

        // Ultra-low delay between scans so browser UI is 100% fluid with zero lag and maximum speed
        await new Promise((r) => setTimeout(r, 70));
      }

      if (totalScannedThisBatch > 0) {
        triggerAutoSaveToast(`🎉 Matagumpay na naipasok sa Table ang ${totalScannedThisBatch} na larawan at nailipat sa PDS Pictures!`);
      }
    } finally {
      isProcessingQueueRef.current = false;
      setIsSequentialScanning(false);
      setCurrentScanningBoxNum(null);
    }
  };

  // Function to delete a single picture permanently across active session, table rows, history & database (Cloud SQL + Firestore)
  const handleDeleteSinglePicture = async (item: { id: string; src: string; applicantName: string }) => {
    if (!window.confirm(`Sigurado ka bang nais mong burahin ang larawan at kaugnay na data sa table ni "${item.applicantName}"?`)) return;

    const targetName = (item.applicantName || '').trim();
    const cleanSearchName = targetName.toLowerCase();

    // 1. Filter out from storedPdsImages & selectedImages
    const newStoredPics = storedPdsImages.filter((p) => p.id !== item.id && p.src !== item.src);
    setStoredPdsImages(newStoredPics);
    setSelectedImages((prev) => prev.filter((img) => img !== item.src));

    // Delete picture from IndexedDB and Firestore
    deletePdsImageFromFirebaseAndIndexedDB(item.id).catch(() => {});
    if (item.src) deletePdsImageFromFirebaseAndIndexedDB(item.src).catch(() => {});
    if (targetName && isRealApplicantName(targetName)) {
      deletePdsImagesByApplicantNameFromFirebaseAndIndexedDB(targetName).catch(() => {});
    }

    // 2. Filter out corresponding row(s) from active table (result)
    let updatedActiveDoc: ExtractedDocumentResult | null = null;
    if (result && result.sections) {
      const allActiveRows = (result.sections || []).flatMap((s) => s.rows || []);
      const remainingRows = allActiveRows.filter((r) => {
        const rName = (
          r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
          r['FULL NAME'] ||
          r['PANGALAN'] ||
          r['SURNAME'] ||
          r['NAME'] ||
          r['Aplikante'] ||
          ''
        ).trim();

        if (checkApplicantNamesMatch(targetName, rName)) return false;

        const cleanRName = rName.toLowerCase();
        if (cleanSearchName && cleanSearchName.length >= 3 && cleanRName) {
          if (cleanRName.includes(cleanSearchName) || cleanSearchName.includes(cleanRName)) {
            return false;
          }
        }
        return true;
      });

      if (remainingRows.length > 0) {
        const rechunked = chunkRowsIntoSections(remainingRows, result.sections[0]?.checkboxes || []);
        updatedActiveDoc = {
          ...result,
          sections: rechunked,
          imagesBase64: (result.imagesBase64 || []).filter((img) => img !== item.src),
        };
        setResult(updatedActiveDoc);
        try {
          localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(updatedActiveDoc));
        } catch (e) {}
        await saveDocumentToFirestore(updatedActiveDoc);
      } else {
        setResult(null);
        try {
          localStorage.removeItem('tindahan_doc_extracted_active_table');
        } catch (e) {}
        try {
          await deleteDoc(doc(db, 'extracted_documents', result.id));
          await deleteDoc(doc(db, 'extracted_documents', SHARED_MASTER_TABLE_ID));
        } catch (e) {}
      }
    }

    // 3. Filter out from savedHistory and firestoreDocs
    const updatedHistory = savedHistory
      .map((docItem) => {
        const docRows = (docItem.sections || []).flatMap((s) => s.rows || []);
        const remainingDocRows = docRows.filter((r) => {
          const rName = (
            r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
            r['FULL NAME'] ||
            r['PANGALAN'] ||
            r['SURNAME'] ||
            r['NAME'] ||
            r['Aplikante'] ||
            ''
          ).trim();

          if (checkApplicantNamesMatch(targetName, rName)) return false;

          const cleanRName = rName.toLowerCase();
          if (cleanSearchName && cleanSearchName.length >= 3 && cleanRName) {
            if (cleanRName.includes(cleanSearchName) || cleanSearchName.includes(cleanRName)) {
              return false;
            }
          }
          return true;
        });

        if (remainingDocRows.length === 0) return null;

        const newSections = chunkRowsIntoSections(remainingDocRows, docItem.sections?.[0]?.checkboxes || []);
        return {
          ...docItem,
          sections: newSections,
          imagesBase64: (docItem.imagesBase64 || []).filter((img) => img !== item.src),
        };
      })
      .filter(Boolean) as ExtractedDocumentResult[];

    setSavedHistory(updatedHistory);
    setFirestoreDocs(updatedHistory);
    try {
      localStorage.setItem('tindahan_doc_extracted_history', JSON.stringify(updatedHistory));
    } catch (e) {}

    // 4. Synchronize immediately to Cloud SQL PostgreSQL and online cloud DB
    try {
      await pushToCloudServerApi({
        activeTable: updatedActiveDoc,
        pdsPictures: newStoredPics,
        documents: updatedHistory,
      });
    } catch (e) {
      console.error('Cloud SQL sync error during picture delete:', e);
    }

    triggerAutoSaveToast(`🗑️ Awtomatikong nabura ang larawan at row sa table ni "${item.applicantName}" sa Database!`);
  };

  // AI Organizer: Automatically iterates through every PDS picture one-by-one, detects duplicate names & duplicate pictures, and deletes the duplicates across active session, table, and storage
  const handleRunAiOrganizer = async (silent = false) => {
    setIsAiOrganizing(true);
    setAiOrganizerToast(null);

    try {
      // Helper to normalize applicant names for accurate comparison
      const normalizeApplicantName = (name: string): string => {
        if (!name) return '';
        return name
          .toLowerCase()
          .replace(/[^a-z0-9]/g, ' ')
          .replace(/\s+/g, ' ')
          .trim();
      };

      const pdsList = getPdsPictureList();
      const activeImages = Array.from(
        new Set([
          ...(storedPdsImages.map((p) => p.src) || []),
          ...(selectedImages || []),
          ...(result?.imagesBase64 || []),
        ])
      ).filter((img): img is string => Boolean(img && typeof img === 'string' && img.trim() !== ''));

      if (pdsList.length === 0 && activeImages.length === 0) {
        if (!silent) {
          triggerAutoSaveToast('🤖 AI Organizer: Walang nakaimbak na PDS picture sa kasalukuyan.');
        }
        setIsAiOrganizing(false);
        return;
      }

      // Step 1: Iterate through every PDS picture 1-by-1 to detect duplicate names
      const seenNames = new Map<string, { id: string; src: string; name: string; index: number }>();
      const duplicateIdsToDelete = new Set<string>();
      const duplicateSrcsToDelete = new Set<string>();
      const duplicateNamesFound: string[] = [];

      pdsList.forEach((item, idx) => {
        const rawName = (item.applicantName || '').trim();
        const normName = normalizeApplicantName(rawName);

        const isGenericName =
          !normName ||
          normName === 'hindi matukoy' ||
          normName === 'n a' ||
          normName.startsWith('pds aplikante') ||
          normName.startsWith('aplikante') ||
          normName === 'maramihang rekord aplikante';

        if (!isGenericName) {
          if (seenNames.has(normName)) {
            // DUPLICATE DETECTED! Automatically mark 2nd and subsequent instances for deletion
            duplicateIdsToDelete.add(item.id);
            if (item.src) duplicateSrcsToDelete.add(item.src);
            duplicateNamesFound.push(rawName);
          } else {
            seenNames.set(normName, { id: item.id, src: item.src, name: rawName, index: idx });
          }
        }
      });

      // Step 2: Also perform Perceptual Image Hash Deduplication for remaining pictures
      const remainingImageSrcs = activeImages.filter((img) => !duplicateSrcsToDelete.has(img));
      const dedupeImageResult = await detectAndRemoveDuplicatePictures(remainingImageSrcs);

      const additionalDuplicateImages = remainingImageSrcs.filter(
        (img) => !dedupeImageResult.uniqueImages.includes(img)
      );
      additionalDuplicateImages.forEach((src) => duplicateSrcsToDelete.add(src));

      const totalRemovedCount = duplicateIdsToDelete.size + additionalDuplicateImages.length;

      if (totalRemovedCount > 0) {
        // 1. Delete duplicate items from IndexedDB, Firestore, and storedPdsImages
        duplicateIdsToDelete.forEach((id) => deletePdsImageFromFirebaseAndIndexedDB(id).catch(() => {}));
        duplicateSrcsToDelete.forEach((src) => deletePdsImageFromFirebaseAndIndexedDB(src).catch(() => {}));

        const cleanedStoredImages = storedPdsImages.filter(
          (p) => !duplicateIdsToDelete.has(p.id) && !duplicateSrcsToDelete.has(p.src)
        );
        setStoredPdsImages(cleanedStoredImages);

        // 2. Update selectedImages
        const cleanedSelected = (selectedImages || []).filter((img) => !duplicateSrcsToDelete.has(img));
        setSelectedImages(cleanedSelected);

        // 3. Deduplicate table rows in result.sections so no duplicate applicant name or picture is left
        if (result && result.sections) {
          const seenRowNames = new Set<string>();
          const cleanedRows: Record<string, string>[] = [];

          const allCurrentRows = result.sections.flatMap((s) => s.rows || []);
          allCurrentRows.forEach((row) => {
            const rowName = (row['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || '').trim();
            const normRowName = normalizeApplicantName(rowName);

            const isGeneric =
              !normRowName ||
              normRowName === 'hindi matukoy' ||
              normRowName === 'n a' ||
              normRowName.startsWith('pds aplikante');

            if (!isGeneric) {
              if (seenRowNames.has(normRowName)) {
                // Duplicate row detected! Omit duplicate row
                return;
              }
              seenRowNames.add(normRowName);
            }
            cleanedRows.push(row);
          });

          // Re-chunk rows cleanly into sheets (20 rows per sheet)
          const ROWS_PER_SHEET = 20;
          const newTotalSheets = Math.max(1, Math.ceil(cleanedRows.length / ROWS_PER_SHEET));
          const updatedSections: ExtractedTableSection[] = [];

          for (let sIdx = 0; sIdx < newTotalSheets; sIdx++) {
            const startR = sIdx * ROWS_PER_SHEET;
            const sheetRows = cleanedRows.slice(startR, startR + ROWS_PER_SHEET);
            updatedSections.push({
              sectionTitle: `Seksyon / Sheet ${sIdx + 1}: Mga Aplikante (PDS Records)`,
              headers: TARGET_REQUESTED_HEADERS,
              rows: sheetRows,
              checkboxes: [],
            });
          }

          const cleanedImagesBase64 = (result.imagesBase64 || []).filter(
            (img) => !duplicateSrcsToDelete.has(img)
          );

          const updatedResult: ExtractedDocumentResult = {
            ...result,
            sections: updatedSections,
            imagesBase64: cleanedImagesBase64,
            totalPages: newTotalSheets,
          };

          setResult(updatedResult);
          saveUpdatedResult(updatedResult);
        }

        // 4. Update localStorage and Firestore history
        setSavedHistory((prev) => {
          const updated = prev.map((doc) => {
            if (doc.imagesBase64 && doc.imagesBase64.length > 0) {
              const cleaned = doc.imagesBase64.filter((img) => !duplicateSrcsToDelete.has(img));
              return { ...doc, imagesBase64: cleaned };
            }
            return doc;
          });
          try {
            localStorage.setItem('tindahan_doc_extracted_history', JSON.stringify(updated));
          } catch (e) {
            console.error(e);
          }
          return updated;
        });

        const msg = `🤖 AI Organizer: Naisa-isa ang lahat ng PDS picture! Awtomatikong binura ang ${totalRemovedCount} naulit na pangalan/larawan. Napanatili ang mga natatanging rekord.`;
        setAiOrganizerToast(msg);
        triggerAutoSaveToast(msg);
      } else {
        const msg = `🤖 AI Organizer: 100% Malinis! Naisa-isa ang ${pdsList.length || activeImages.length} PDS picture at walang nakitang naulit na pangalan o duplicate na larawan.`;
        setAiOrganizerToast(msg);
        if (!silent) {
          triggerAutoSaveToast(msg);
        }
      }
    } catch (err) {
      console.error('[AI Organizer Error]', err);
      if (!silent) {
        triggerAutoSaveToast('🤖 AI Organizer: Tapos nang suriin ang mga PDS picture.');
      }
    } finally {
      setIsAiOrganizing(false);
    }
  };

  // AI Filter: Automatic clarity booster that sharpens text, enhances contrast, and removes background haze
  const handleAutoClarifyAllPictures = async () => {
    setIsAutoClarifyingAll(true);
    setIsHdClarityMode(true);
    setAiFilterMode('ai_ultra_clear');

    try {
      // Small artificial delay for visual clarity feedback transition
      await new Promise((r) => setTimeout(r, 450));
      triggerAutoSaveToast('✨ AI Filter: Awtomatikong pinalinaw ang lahat ng larawan para mas madaling mabasa ang mga text at sulat-kamay!');
    } finally {
      setIsAutoClarifyingAll(false);
    }
  };

  // Auto-switch sheet tab when sheet number/name is typed into search bar
  useEffect(() => {
    if (!searchTerm || !result?.sections) return;
    const q = searchTerm.trim().toLowerCase();

    // Match patterns like: "sheet 1", "sheet 2", "seksyon 1", "seksyon 2", "sheet1", "sheet2", or exact numbers "1", "2", "3"
    const sheetMatch = q.match(/^(?:sheet|seksyon|pds sheet)?\s*#?\s*(\d+)$/i);
    if (sheetMatch) {
      const sheetNum = parseInt(sheetMatch[1], 10);
      if (sheetNum >= 1 && sheetNum <= result.sections.length) {
        setSelectedSheetTab(sheetNum - 1);
      }
    } else if (q === 'all' || q === 'lahat' || q === 'all sheets') {
      setSelectedSheetTab('all');
    }
  }, [searchTerm, result?.sections]);

  // Helper to compile all uploaded PDS pictures dynamically & 1-to-1 synced with actual uploaded images and table rows (memoized for peak speed)
  const pdsPictureList = useMemo(() => {
    if (!storedPdsImages || storedPdsImages.length === 0) {
      return [];
    }

    const allRows = result?.sections?.flatMap((s) => s.rows || []) || [];

    return storedPdsImages.map((storedObj, iIdx) => {
      const imgId = storedObj.id || `PDS-IMG-${iIdx}`;
      const imgSrc = storedObj.src;

      // Match with corresponding row by applicant name first, or fallback to index
      const pdsName = (storedObj.applicantName || '').trim();
      let matchedRowIdx = -1;

      if (pdsName && isRealApplicantName(pdsName) && !isLikelyFilenameOrHash(pdsName)) {
        matchedRowIdx = allRows.findIndex((r) => {
          const rName = (
            r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
            r['FULL NAME'] ||
            r['PANGALAN'] ||
            r['SURNAME'] ||
            ''
          ).trim();
          return checkApplicantNamesMatch(pdsName, rName);
        });
      }

      if (matchedRowIdx === -1 && iIdx < allRows.length) {
        matchedRowIdx = iIdx;
      }

      const rowForImage = matchedRowIdx >= 0 ? allRows[matchedRowIdx] : undefined;
      const rawRowName = (
        rowForImage?.['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
        rowForImage?.['FULL NAME'] ||
        rowForImage?.['PANGALAN'] ||
        rowForImage?.['SURNAME'] ||
        ''
      )?.trim();

      const isStoredNameReal = isRealApplicantName(pdsName) && !isLikelyFilenameOrHash(pdsName);
      const isRowNameReal = Boolean(
        rawRowName &&
        isRealApplicantName(rawRowName) &&
        !isValuePlaceholderOrNA(rawRowName) &&
        !isLikelyFilenameOrHash(rawRowName)
      );

      let applicantName = '';
      if (customPhotoNames[imgId]) {
        applicantName = customPhotoNames[imgId];
      } else if (customPhotoNames[imgSrc]) {
        applicantName = customPhotoNames[imgSrc];
      } else if (isRowNameReal && rawRowName) {
        // ALWAYS use the applicant's real FULL NAME from the Table Content!
        applicantName = rawRowName;
      } else if (isStoredNameReal) {
        applicantName = pdsName;
      } else if (
        result?.detectedPersonName &&
        result.detectedPersonName !== 'Maramihang Rekord / Aplikante' &&
        isRealApplicantName(result.detectedPersonName) &&
        !isLikelyFilenameOrHash(result.detectedPersonName)
      ) {
        applicantName = result.detectedPersonName;
      } else {
        applicantName = `PDS Aplikante ${iIdx + 1}`;
      }

      const pageTitle = storedObj.pageTitle || `PDS CS Form 212 • Pahina ${iIdx + 1}`;
      const searchIndex = `${applicantName} Pahina ${iIdx + 1} ${
        rowForImage ? Object.values(rowForImage).join(' ') : ''
      }`.toLowerCase();

      return {
        id: imgId,
        src: imgSrc,
        applicantName,
        pageTitle,
        uploadedAt: storedObj.uploadedAt
          ? new Date(storedObj.uploadedAt).toLocaleDateString()
          : result?.scannedAt
          ? new Date(result.scannedAt).toLocaleDateString()
          : 'Kasalukuyang Session',
        searchKey: searchIndex,
        rowIdx: matchedRowIdx >= 0 ? matchedRowIdx : undefined,
      };
    });
  }, [result?.sections, storedPdsImages, customPhotoNames, result?.scannedAt, result?.detectedPersonName]);

  // Reactive Effect: Auto-resolve and heal real applicant Full Name for any PDS picture whose name is a hash or filename
  useEffect(() => {
    if (!storedPdsImages || storedPdsImages.length === 0) return;

    let hasUnresolved = false;
    for (const p of storedPdsImages) {
      const name = (p.applicantName || '').trim();
      if (!name || isLikelyFilenameOrHash(name) || !isRealApplicantName(name)) {
        hasUnresolved = true;
        break;
      }
    }
    if (!hasUnresolved) return;

    const allRows = (result?.sections || []).flatMap((s) => s.rows || []);
    const candidateNames: string[] = [];
    allRows.forEach((r) => {
      const rName = (
        r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
        r['FULL NAME'] ||
        r['PANGALAN'] ||
        r['SURNAME'] ||
        ''
      )?.trim();
      if (rName && isRealApplicantName(rName) && !isLikelyFilenameOrHash(rName)) {
        candidateNames.push(rName);
      }
    });

    let isCancelled = false;

    const resolveNames = async () => {
      let anyUpdated = false;
      const updatedImages = [...storedPdsImages];

      for (let i = 0; i < updatedImages.length; i++) {
        const item = updatedImages[i];
        const currentName = (item.applicantName || '').trim();
        if (currentName && isRealApplicantName(currentName) && !isLikelyFilenameOrHash(currentName)) {
          continue;
        }

        // Extract the Full Name strictly from the PDS picture (Block I: SURNAME, FIRST NAME, MIDDLE NAME, NAME EXTENSION)
        if (item.src && item.src.length > 50) {
          try {
            const thumb = await createOptimizedPdsThumbnailForOcr(item.src);
            const aiRes = await extractPdsApplicantName(thumb, candidateNames);
            let resolvedName = (aiRes.applicantName || '').trim();
            if (aiRes.matchedCandidate && checkApplicantNamesMatch(resolvedName, aiRes.matchedCandidate)) {
              resolvedName = aiRes.matchedCandidate.trim();
            }
            if (resolvedName && isRealApplicantName(resolvedName) && !isLikelyFilenameOrHash(resolvedName)) {
              updatedImages[i] = {
                ...item,
                applicantName: resolvedName.toUpperCase(),
              };
              anyUpdated = true;
            }
          } catch (e) {
            console.warn('[PDS Name Auto-Resolve] Error extracting applicant name:', e);
          }
        }
      }

      if (anyUpdated && !isCancelled) {
        setStoredPdsImages(updatedImages);
        await savePdsImagesToFirebaseAndIndexedDB(updatedImages, currentAccountId);
      }
    };

    resolveNames();

    return () => {
      isCancelled = true;
    };
  }, [storedPdsImages, result?.sections, activeTargetHeaders, currentAccountId]);

  const getPdsPictureList = () => pdsPictureList;

  // Helper to save photo name edit and synchronize with table row
  const handleSavePhotoName = (
    item: { id: string; src: string; applicantName?: string; rowIdx?: number },
    newName: string
  ) => {
    const trimmed = newName.trim();
    if (!trimmed) return;
    setCustomPhotoNames((prev) => ({
      ...prev,
      [item.id]: trimmed,
      ...(item.src ? { [item.src]: trimmed } : {}),
    }));

    // Update applicant name in IndexedDB and Firebase Firestore storedPdsImages
    if (item.src || item.id) {
      setStoredPdsImages((prev) => {
        const updated = prev.map((p) =>
          p.id === item.id || (item.src && p.src === item.src) ? { ...p, applicantName: trimmed } : p
        );
        updatePdsImageMetadataInFirebaseAndIndexedDB(item.id, { applicantName: trimmed }).catch(() => {});
        return updated;
      });
    }

    // Synchronize name directly into matching table row
    if (result && result.sections && result.sections.length > 0) {
      let matched = false;
      let targetRowCounter = 0;
      const targetHeaders =
        activeTargetHeaders && activeTargetHeaders.length > 0 ? activeTargetHeaders : TARGET_REQUESTED_HEADERS;
      const primaryHdrKey =
        targetHeaders.find((h) => {
          const hLow = h.toLowerCase();
          return hLow.includes('name') || hLow.includes('pangalan') || hLow.includes('surname') || hLow.includes('item');
        }) || targetHeaders[0] || 'NAME (SURNAME, FIRST NAME, MIDDLE NAME)';

      const updatedSections = result.sections.map((sec) => {
        if (!sec.rows) return sec;
        const updatedRows = sec.rows.map((row) => {
          const rName = (
            row['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
            row['FULL NAME'] ||
            row['PANGALAN'] ||
            row['SURNAME'] ||
            row[primaryHdrKey] ||
            ''
          ).trim();

          const isMatch =
            (item.applicantName && checkApplicantNamesMatch(item.applicantName, rName)) ||
            (item.rowIdx !== undefined && targetRowCounter === item.rowIdx);

          targetRowCounter++;

          if (isMatch && !matched) {
            matched = true;
            return {
              ...row,
              'NAME (SURNAME, FIRST NAME, MIDDLE NAME)': trimmed.toUpperCase(),
              [primaryHdrKey]: trimmed.toUpperCase(),
            };
          }
          return row;
        });
        return { ...sec, rows: updatedRows };
      });

      if (matched) {
        const updatedResult = { ...result, sections: updatedSections };
        saveUpdatedResult(updatedResult);
      }
    }

    // Also update fullScreenPdsImage if currently open so the UI immediately reflects the change
    setFullScreenPdsImage((prev) => {
      if (prev && (prev.id === item.id || (item.src && prev.src === item.src))) {
        return { ...prev, applicantName: trimmed };
      }
      return prev;
    });
  };

  // Helper to re-scan applicant name directly from PDS image using AI OCR
  const handleRescanSinglePicture = async (item: { id: string; src: string; applicantName?: string }) => {
    if (!item.src) return;
    try {
      triggerAutoSaveToast('🔍 Sinusuri ang pangalan sa loob ng PDS picture (Block I)...');
      const thumb = await createOptimizedPdsThumbnailForOcr(item.src);
      const allRows = (result?.sections || []).flatMap((s) => s.rows || []);
      const candidateNames = allRows
        .map((r) => r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || r['FULL NAME'] || r['PANGALAN'] || '')
        .filter(Boolean);
      const aiRes = await extractPdsApplicantName(thumb, candidateNames);
      let detectedName = (aiRes.applicantName || '').trim();
      if (aiRes.matchedCandidate && checkApplicantNamesMatch(detectedName, aiRes.matchedCandidate)) {
        detectedName = aiRes.matchedCandidate.trim();
      }
      if (detectedName && isRealApplicantName(detectedName) && !isLikelyFilenameOrHash(detectedName)) {
        const upper = detectedName.toUpperCase();
        handleSavePhotoName(item, upper);
        triggerAutoSaveToast(`🎉 Matagumpay na nabasa mula sa PDS Picture: ${upper}`);
      } else {
        triggerAutoSaveToast('⚠️ Walang malinaw na pangalan na nabasa sa larawan. Maaari mo itong i-type gamit ang Edit.');
      }
    } catch (err) {
      console.error('[AI Rescan Single Picture]', err);
      triggerAutoSaveToast('❌ Nagka-error sa pagsusuri ng larawan.');
    }
  };

  // Helper to re-scan applicant name directly in the Fullscreen Modal using AI OCR
  const handleAiRescanFullScreenImage = async () => {
    if (!fullScreenPdsImage || !fullScreenPdsImage.src) return;
    setIsAiScanningFullScreen(true);
    try {
      triggerAutoSaveToast('🔍 Sinusuri ang Block I ng PDS picture gamit ang AI OCR...');
      const thumb = await createOptimizedPdsThumbnailForOcr(fullScreenPdsImage.src);
      const allRows = (result?.sections || []).flatMap((s) => s.rows || []);
      const candidateNames = allRows
        .map((r) => r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || r['FULL NAME'] || r['PANGALAN'] || '')
        .filter(Boolean);
      const aiRes = await extractPdsApplicantName(thumb, candidateNames);
      let detectedName = (aiRes.applicantName || '').trim();
      if (aiRes.matchedCandidate && checkApplicantNamesMatch(detectedName, aiRes.matchedCandidate)) {
        detectedName = aiRes.matchedCandidate.trim();
      }
      if (detectedName && isRealApplicantName(detectedName) && !isLikelyFilenameOrHash(detectedName)) {
        const upper = detectedName.toUpperCase();
        setFullScreenPdsImage((prev) => (prev ? { ...prev, applicantName: upper } : null));
        handleSavePhotoName({ id: fullScreenPdsImage.id, src: fullScreenPdsImage.src }, upper);
        triggerAutoSaveToast(`🎉 Matagumpay na nakuha ang pangalan mula sa PDS: ${upper}`);
      } else {
        triggerAutoSaveToast('⚠️ Hindi awtomatikong nakuha ang pangalan. Gamitin ang Edit button upang i-type.');
      }
    } catch (err) {
      console.error('[AI Rescan FullScreen]', err);
      triggerAutoSaveToast('❌ Nagka-error sa pagsusuri ng larawan.');
    } finally {
      setIsAiScanningFullScreen(false);
    }
  };

  // Automatic sheet jumping when typing in live search bar across different sheets
  useEffect(() => {
    if (!searchTerm.trim() || !result || !result.sections || result.sections.length === 0) {
      return;
    }
    const query = searchTerm.toLowerCase().trim();

    const matchingSheets: number[] = [];
    result.sections.forEach((sec, sheetIdx) => {
      const hasMatch = (sec.rows || []).some((r) =>
        Object.values(r).some((val) => String(val || '').toLowerCase().includes(query))
      );
      if (hasMatch) {
        matchingSheets.push(sheetIdx);
      }
    });

    if (matchingSheets.length > 0) {
      if (selectedSheetTab !== 'all' && !matchingSheets.includes(selectedSheetTab as number)) {
        // Automatically jump to the first sheet containing matching data!
        setSelectedSheetTab(matchingSheets[0]);
      }
    }
  }, [searchTerm, result]);

  // Keyboard Escape listener for closing full screen view or modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (fullScreenPdsImage) setFullScreenPdsImage(null);
        else if (isPdsGalleryOpen) setIsPdsGalleryOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [fullScreenPdsImage, isPdsGalleryOpen]);

  // Firestore Database Modal & Cloud Sync State
  const [isDatabaseModalOpen, setIsDatabaseModalOpen] = useState<boolean>(false);
  const [isSyncCodeModalOpen, setIsSyncCodeModalOpen] = useState<boolean>(false);
  const [syncCodeInput, setSyncCodeInput] = useState<string>('');
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState<boolean>(false);
  const [geminiApiKeyInput, setGeminiApiKeyInput] = useState<string>(getClientGeminiApiKey());
  const [firestoreDocs, setFirestoreDocs] = useState<ExtractedDocumentResult[]>([]);
  const [dbSearchQuery, setDbSearchQuery] = useState<string>('');
  const [isCloudSyncing, setIsCloudSyncing] = useState<boolean>(false);
  const [isCloudConnected, setIsCloudConnected] = useState<boolean>(true);
  const [isManualSyncing, setIsManualSyncing] = useState<boolean>(false);

  const downloadBackupFile = (jsonStr: string) => {
    try {
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `pds_system_data_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      triggerAutoSaveToast('📥 Na-download ang System Data Backup JSON File!');
    } catch (e) {
      triggerAutoSaveToast('Hindi ma-download ang backup file.');
    }
  };

  const handleExportSyncCode = () => {
    try {
      const backupData = {
        activeTable: result,
        history: savedHistory,
        pdsImages: storedPdsImages,
        exportedAt: new Date().toISOString(),
        appName: 'AI FORM EXTRACTOR',
      };
      const jsonStr = JSON.stringify(backupData);
      if (navigator.clipboard) {
        navigator.clipboard
          .writeText(jsonStr)
          .then(() => {
            triggerAutoSaveToast('📋 Kopyado na ang Device Sync Code sa clipboard! Maaari mo na itong i-paste sa kabilang phone/device.');
          })
          .catch(() => {
            downloadBackupFile(jsonStr);
          });
      } else {
        downloadBackupFile(jsonStr);
      }
    } catch (err) {
      triggerAutoSaveToast('May kaunting problema sa pag-export ng Sync Code.');
    }
  };

  const handleImportSyncCode = (rawInput?: string) => {
    const textToImport = (rawInput !== undefined ? rawInput : syncCodeInput).trim();
    if (!textToImport) {
      triggerAutoSaveToast('Pakilagay muna ang Sync Code o i-upload ang Backup File.');
      return;
    }
    try {
      const parsed = JSON.parse(textToImport);
      let rowCount = 0;
      if (parsed.activeTable && parsed.activeTable.sections) {
        setResult(parsed.activeTable);
        localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(parsed.activeTable));
        rowCount = parsed.activeTable.sections.reduce((acc: number, s: any) => acc + (s.rows?.length || 0), 0);
        saveDocumentToFirestore(parsed.activeTable);
      }
      if (Array.isArray(parsed.history) && parsed.history.length > 0) {
        setSavedHistory(parsed.history);
        setFirestoreDocs(parsed.history);
        localStorage.setItem('tindahan_doc_extracted_history', JSON.stringify(parsed.history));
      }
      if (Array.isArray(parsed.pdsImages) && parsed.pdsImages.length > 0) {
        setStoredPdsImages(parsed.pdsImages);
        savePdsImagesToFirebaseAndIndexedDB(parsed.pdsImages).catch(() => {});
      }
      triggerAutoSaveToast(`⚡ Tagumpay! Na-sync at na-load ang ${rowCount} rows at PDS pictures sa device na ito!`);
      setIsSyncCodeModalOpen(false);
      setSyncCodeInput('');
    } catch (err) {
      triggerAutoSaveToast('Mali o hindi valid ang Sync Code / JSON File. Pakisuri uli.');
    }
  };

  // 100% Unified Database Documents (Seamlessly syncs active table data + local history + Firestore cloud docs)
  const combinedDatabaseDocs = useMemo(() => {
    const map = new Map<string, ExtractedDocumentResult>();

    // A. Add Firestore docs first if available
    (firestoreDocs || []).forEach((d) => {
      if (d && d.id) map.set(d.id, d);
    });

    // B. Add local saved history docs
    (savedHistory || []).forEach((d) => {
      if (d && d.id && !map.has(d.id)) {
        map.set(d.id, d);
      }
    });

    // C. Add active table result (if present and has valid content)
    if (result && result.id) {
      const activeRowsCount = result.sections?.reduce((acc, sec) => acc + (sec.rows?.length || 0), 0) || 0;
      if (activeRowsCount > 0 || !map.has(result.id)) {
        map.set(result.id, result);
      }
    }

    return Array.from(map.values()).sort(
      (a, b) => new Date(b.scannedAt || b.id).getTime() - new Date(a.scannedAt || a.id).getTime()
    );
  }, [firestoreDocs, savedHistory, result]);

  // Compute total number of individual records (rows) across the entire database (Cloud + Local Table)
  const totalDatabaseRecords = useMemo(() => {
    return combinedDatabaseDocs.reduce((totalAcc, docItem) => {
      return totalAcc + (docItem.sections?.reduce((secAcc, sec) => secAcc + (sec.rows?.length || 0), 0) || 0);
    }, 0);
  }, [combinedDatabaseDocs]);

  // State for inline double-click editing
  const [editingCell, setEditingCell] = useState<{
    secIdx: number;
    rowIdx: number;
    colKey: string;
    tempValue: string;
  } | null>(null);

  const [editingHeader, setEditingHeader] = useState<{
    secIdx: number;
    colIdx: number;
    oldKey: string;
    tempValue: string;
  } | null>(null);

  const [autoSaveNotification, setAutoSaveNotification] = useState<string | null>(null);

  const triggerAutoSaveToast = (msg: string = 'Awtomatikong na-save!') => {
    setAutoSaveNotification(msg);
    setTimeout(() => {
      setAutoSaveNotification(null);
    }, 2500);
  };

  // Helper to create low-resolution lightweight thumbnail to stay well within Firestore 1MB limit
  const createThumbnailBase64 = async (base64Str: string, maxDim: number = 240, quality: number = 0.45): Promise<string> => {
    return new Promise((resolve) => {
      try {
        if (!base64Str || !base64Str.startsWith('data:image')) {
          return resolve('');
        }
        const img = new Image();
        img.onload = () => {
          try {
            const canvas = document.createElement('canvas');
            let width = img.width;
            let height = img.height;
            if (width > height) {
              if (width > maxDim) {
                height = Math.round((height * maxDim) / width);
                width = maxDim;
              }
            } else {
              if (height > maxDim) {
                width = Math.round((width * maxDim) / height);
                height = maxDim;
              }
            }
            canvas.width = Math.max(width, 1);
            canvas.height = Math.max(height, 1);
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.drawImage(img, 0, 0, width, height);
              const thumb = canvas.toDataURL('image/jpeg', quality);
              resolve(thumb);
            } else {
              resolve('');
            }
          } catch {
            resolve('');
          }
        };
        img.onerror = () => resolve('');
        img.src = base64Str;
      } catch {
        resolve('');
      }
    });
  };

  // Helper to sync state to server-backed online cloud database (accessible anywhere)
  const pushToCloudServerApi = async (params: {
    activeTable?: ExtractedDocumentResult | null;
    pdsPictures?: PdsStoredImage[];
    documents?: ExtractedDocumentResult[];
    customHeaders?: string[];
  }) => {
    try {
      await fetch('/api/doc-extractor/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...params,
          accountId: currentAccountId,
        }),
      });
    } catch (err) {}
  };

  // Helper to save document to Firebase Firestore with safety limits & Online Cloud DB
  const saveDocumentToFirestore = async (docToSave: ExtractedDocumentResult) => {
    try {
      localStorage.removeItem('tindahan_doc_extractor_cleared_at');
    } catch (e) {}

    // Always push to Online Cloud Server DB
    pushToCloudServerApi({
      activeTable: docToSave,
      pdsPictures: storedPdsImages,
      documents: firestoreDocs,
    });

    if (isFirestoreQuotaExhausted()) {
      return;
    }
    try {
      setIsCloudSyncing(true);
      const docRef = doc(db, 'extracted_documents', `${docToSave.id}_${currentAccountId}`);

      // Clean and normalize all sections and rows so NO undefined, null, or non-primitive values exist
      const cleanSections: ExtractedTableSection[] = (docToSave.sections || []).map((sec, sIdx) => ({
        sectionTitle: sec.sectionTitle || `Sheet ${sIdx + 1}`,
        headers: sec.headers || TARGET_REQUESTED_HEADERS,
        rows: (sec.rows || []).map((row) => {
          const cleanRow: Record<string, string> = {};
          Object.entries(row).forEach(([k, v]) => {
            cleanRow[k] = v === undefined || v === null ? '' : String(v);
          });
          return cleanRow;
        }),
        checkboxes: sec.checkboxes || [],
      }));

      const cleanDoc: ExtractedDocumentResult = {
        id: docToSave.id,
        title: docToSave.title || 'Form Document',
        detectedPersonName: docToSave.detectedPersonName || getDocumentPersonName(docToSave) || 'Aplikante',
        documentType: docToSave.documentType || 'Official Form',
        totalPages: docToSave.totalPages || 1,
        detectedPageNumbers: Array.isArray(docToSave.detectedPageNumbers)
          ? docToSave.detectedPageNumbers
          : [String(docToSave.detectedPageNumbers || 'Sheet 1')],
        sections: cleanSections,
        consolidatedMarkdownTable: docToSave.consolidatedMarkdownTable || '',
        signaturesAndDates: docToSave.signaturesAndDates || [],
        unreadableSummary: docToSave.unreadableSummary || '',
        privacyNoticeAcknowledged: true,
        scannedAt: docToSave.scannedAt || new Date().toISOString(),
        imagesBase64: [], // Photos are stored cleanly and separately in pds_pictures collection!
      };

      // Crucial: Use flat primitive payload with JSON-serialized data
      // This follows Home Monitoring's reliable pattern and completely eliminates Firestore's "nested arrays are not supported" error!
      const payload: Record<string, any> = {
        id: cleanDoc.id,
        accountId: currentAccountId,
        title: cleanDoc.title,
        detectedPersonName: cleanDoc.detectedPersonName,
        documentType: cleanDoc.documentType,
        totalPages: cleanDoc.totalPages,
        detectedPageNumbers: Array.isArray(cleanDoc.detectedPageNumbers)
          ? cleanDoc.detectedPageNumbers.join(', ')
          : String(cleanDoc.detectedPageNumbers || ''),
        privacyNoticeAcknowledged: true,
        scannedAt: cleanDoc.scannedAt,
        unreadableSummary: cleanDoc.unreadableSummary || '',
        data: JSON.stringify(cleanDoc),
        sectionsJson: JSON.stringify(cleanSections),
        consolidatedMarkdownTable: cleanDoc.consolidatedMarkdownTable || '',
        updatedAt: new Date().toISOString(),
      };

      await setDoc(docRef, payload, { merge: true });

      // Crucial: Also persist active table state into account-scoped master table so ANY device opens the latest active table immediately!
      const scopedMasterId = `${SHARED_MASTER_TABLE_ID}_${currentAccountId}`;
      if (cleanDoc.id !== SHARED_MASTER_TABLE_ID && cleanDoc.id !== scopedMasterId) {
        const masterPayload = {
          ...payload,
          id: SHARED_MASTER_TABLE_ID,
        };
        await setDoc(doc(db, 'extracted_documents', scopedMasterId), masterPayload, { merge: true }).catch(() => {});
      }

      setIsCloudConnected(true);
    } catch (error) {
      handleFirestoreError(error, 'saveDocumentToFirestore');
      setIsCloudConnected(false);
    } finally {
      setIsCloudSyncing(false);
    }
  };

  // Helper to delete document from Firebase Firestore permanently
  const deleteDocumentFromFirestore = async (docId: string) => {
    try {
      resetQuotaExhausted();
      try {
        await enableNetwork(db);
      } catch (e) {}

      // 1. Delete document from Firestore extracted_documents
      try {
        await deleteDoc(doc(db, 'extracted_documents', `${docId}_${currentAccountId}`));
        await deleteDoc(doc(db, 'extracted_documents', docId));
      } catch (err) {
        console.warn(`[Firestore] deleteDoc notice for ${docId}:`, err);
      }

      // 2. Find target doc to clean up associated pictures
      const targetDoc = firestoreDocs.find((d) => d.id === docId) || savedHistory.find((d) => d.id === docId);
      const personName = targetDoc ? getDocumentPersonName(targetDoc) : '';
      if (personName && personName !== 'Form Document' && personName !== 'Hindi Matukoy ang Pangalan') {
        try {
          await deletePdsImagesByApplicantNameFromFirebaseAndIndexedDB(personName, currentAccountId);
          setStoredPdsImages((prev) =>
            prev.filter((p) => {
              const app = (p.applicantName || '').trim().toLowerCase();
              return !app.includes(personName.toLowerCase());
            })
          );
        } catch (e) {}
      }

      // 3. Update firestoreDocs and savedHistory
      const updated = firestoreDocs.filter((d) => d.id !== docId);
      setFirestoreDocs(updated);
      setSavedHistory(updated);
      try {
        localStorage.setItem(`tindahan_doc_extracted_history_acc_${currentAccountId}`, JSON.stringify(updated));
        localStorage.setItem('tindahan_doc_extracted_history', JSON.stringify(updated));
      } catch (e) {}

      // 4. Update or clear active result
      if (result && (result.id === docId || updated.length === 0)) {
        const nextDoc = updated.length > 0 ? updated[0] : null;
        setResult(nextDoc);
        if (nextDoc) {
          try {
            localStorage.setItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`, JSON.stringify(nextDoc));
            localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(nextDoc));
          } catch (e) {}
        } else {
          try {
            localStorage.removeItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`);
            localStorage.removeItem('tindahan_doc_extracted_active_table');
          } catch (e) {}
          // Also delete master table if no documents left
          try {
            await deleteDoc(doc(db, 'extracted_documents', `${SHARED_MASTER_TABLE_ID}_${currentAccountId}`));
            await deleteDoc(doc(db, 'extracted_documents', SHARED_MASTER_TABLE_ID));
          } catch (e) {}
        }
      }

      triggerAutoSaveToast('🗑️ Permanenteng nabura ang dokumento sa Firestore Cloud Database.');
    } catch (error) {
      handleFirestoreError(error, 'deleteDocumentFromFirestore');
    }
  };

  // Manual Live Cloud Sync Action: Forces instant cloud pull, syncs all devices, respects deletions
  const handleManualSync = async () => {
    setIsManualSyncing(true);
    setIsCloudSyncing(true);
    try {
      // 1. First sync with Online Cloud Server API (100% accessible in Incognito, mobile, all devices)
      try {
        if (result) {
          await pushToCloudServerApi({
            activeTable: result,
            pdsPictures: storedPdsImages,
            documents: firestoreDocs,
          });
        }
        const cloudRes = await fetch(`/api/doc-extractor/pull?accountId=${encodeURIComponent(currentAccountId)}`);
        if (cloudRes.ok) {
          const cloudJson = await cloudRes.json();
          if (cloudJson?.success && cloudJson?.data) {
            const { activeTable: srvTable, pdsPictures: srvPics, documents: srvDocs } = cloudJson.data;
            if (srvTable) {
              const norm = ensure20RowsPerSheet(srvTable) || srvTable;
              setResult(norm);
              try {
                localStorage.setItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`, JSON.stringify(norm));
                localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(norm));
              } catch (e) {}
            }
            if (Array.isArray(srvPics) && srvPics.length > 0) {
              setStoredPdsImages(srvPics);
              await savePdsImagesToIndexedDB(srvPics, currentAccountId);
            }
            if (Array.isArray(srvDocs) && srvDocs.length > 0) {
              setFirestoreDocs(srvDocs);
              setSavedHistory(srvDocs);
            }
            setIsCloudConnected(true);
          }
        }
      } catch (e) {
        console.warn('Online Cloud Server Sync notice:', e);
      }

      // 2. Clear any cached quota block & attempt Firestore sync
      resetQuotaExhausted();
      try {
        await enableNetwork(db);
      } catch (e) {}

      // 3. Fetch all cloud docs from Firestore extracted_documents and pds_pictures
      const [snapshot, picturesSnap] = await Promise.all([
        getDocs(collection(db, 'extracted_documents')).catch(() => null),
        getDocs(collection(db, 'pds_pictures')).catch(() => null),
      ]);

      const docsList: ExtractedDocumentResult[] = [];
      if (snapshot && !snapshot.empty) {
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          const docAcc = data?.accountId || 'user-admin1';
          const isMatch = docAcc === currentAccountId || (currentAccountId === 'user-admin1' && docAcc === 'user-admin');
          if (data && isMatch) {
            docsList.push(parseFirestoreDocToResult(docSnap.id, data));
          }
        });
      }

      if (docsList.length > 0) {
        docsList.sort(
          (a, b) =>
            new Date(b.scannedAt || b.id).getTime() -
            new Date(a.scannedAt || a.id).getTime()
        );
      }

      // 4. Process PDS pictures from Cloud
      const cloudPics: PdsStoredImage[] = [];
      if (picturesSnap && !picturesSnap.empty) {
        picturesSnap.forEach((docSnap) => {
          const data = docSnap.data();
          const docAcc = data?.accountId || 'user-admin1';
          const isMatch = docAcc === currentAccountId || (currentAccountId === 'user-admin1' && docAcc === 'user-admin');
          if (data && data.src && isMatch) {
            cloudPics.push({
              id: docSnap.id,
              src: data.src,
              accountId: docAcc,
              applicantName: data.applicantName || '',
              pageTitle: data.pageTitle || '',
              pageNumber: data.pageNumber || 1,
              searchKey: data.searchKey || '',
              createdAt: data.createdAt || '',
              uploadedAt: data.uploadedAt || '',
              docId: data.docId || '',
              order: data.order ?? 0,
            });
          }
        });
      }

      if (cloudPics.length > 0) {
        cloudPics.sort(
          (a, b) =>
            (a.order ?? 0) - (b.order ?? 0) ||
            new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime()
        );
        setStoredPdsImages(cloudPics);
        await savePdsImagesToIndexedDB(cloudPics, currentAccountId);
      }

      if (docsList.length > 0) {
        const scopedMasterId = `${SHARED_MASTER_TABLE_ID}_${currentAccountId}`;
        const masterDoc = docsList.find((d) => d.id === scopedMasterId || d.id === SHARED_MASTER_TABLE_ID);
        const otherDocs = docsList.filter((d) => d.id !== scopedMasterId && d.id !== SHARED_MASTER_TABLE_ID);
        const unifiedList = masterDoc ? [masterDoc, ...otherDocs] : docsList;

        const bestTable =
          (masterDoc ? ensure20RowsPerSheet(masterDoc) : null) ||
          (docsList[0] ? ensure20RowsPerSheet(docsList[0]) : null);

        if (bestTable) {
          setResult(bestTable);
          try {
            localStorage.setItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`, JSON.stringify(bestTable));
            localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(bestTable));
          } catch {}
        }

        setFirestoreDocs(unifiedList);
        setSavedHistory(unifiedList);
        try {
          localStorage.setItem(`tindahan_doc_extracted_history_acc_${currentAccountId}`, JSON.stringify(unifiedList));
          localStorage.setItem('tindahan_doc_extracted_history', JSON.stringify(unifiedList));
        } catch {}
        setIsCloudConnected(true);
      }

      const totalActiveRows = result?.sections?.reduce((acc, s) => acc + (s.rows?.length || 0), 0) || 0;
      triggerAutoSaveToast(`⚡ Live Online Sync Complete! Na-sync ang ${totalActiveRows} rows at ${storedPdsImages.length} PDS pictures sa Cloud Database!`);
    } catch (err: any) {
      console.error('[Manual Sync Error]', err);
      triggerAutoSaveToast(`⚡ Sync Status: Naka-sync ang data sa Online Database.`);
    } finally {
      setIsManualSyncing(false);
      setIsCloudSyncing(false);
    }
  };

  // Active One-Shot Fetch from Cloud Firestore on Mount & Real-time Sync (identical pattern to Home Monitoring)
  useEffect(() => {
    let isMounted = true;

    // 1. Clear any stale quota flag and enable Firestore network
    resetQuotaExhausted();
    try {
      enableNetwork(db).catch(() => {});
    } catch (e) {}

    // Helper to sync state to server-backed online cloud database
    const syncWithCloudServer = async (
      tableToPush?: ExtractedDocumentResult | null,
      picsToPush?: PdsStoredImage[],
      historyToPush?: ExtractedDocumentResult[]
    ) => {
      try {
        await fetch('/api/doc-extractor/push', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            accountId: currentAccountId,
            activeTable: tableToPush,
            pdsPictures: picsToPush,
            documents: historyToPush,
          }),
        });
      } catch (err) {}
    };

    // 2. Fetch from Online Cloud Server Database & Firestore simultaneously (instant for Incognito / any device)
    const performInitialCloudSync = async () => {
      try {
        // Step A: Instant fetch from Online Cloud Server DB
        try {
          const cloudRes = await fetch(`/api/doc-extractor/pull?accountId=${encodeURIComponent(currentAccountId)}`);
          if (cloudRes.ok) {
            const cloudJson = await cloudRes.json();
            if (cloudJson?.success && cloudJson?.data) {
              const { activeTable: srvTable, pdsPictures: srvPics, documents: srvDocs } = cloudJson.data;

              if (srvTable && Array.isArray(srvTable.sections) && srvTable.sections.length > 0) {
                const normTable = ensure20RowsPerSheet(srvTable) || srvTable;
                setResult(normTable);
                try {
                  localStorage.setItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`, JSON.stringify(normTable));
                  localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(normTable));
                } catch (e) {}
              }

              if (Array.isArray(srvPics) && srvPics.length > 0) {
                setStoredPdsImages(srvPics);
                savePdsImagesToIndexedDB(srvPics, currentAccountId).catch(() => {});
              }

              if (Array.isArray(srvDocs) && srvDocs.length > 0) {
                setFirestoreDocs(srvDocs);
                setSavedHistory(srvDocs);
                try {
                  localStorage.setItem(`tindahan_doc_extracted_history_acc_${currentAccountId}`, JSON.stringify(srvDocs));
                  localStorage.setItem('tindahan_doc_extracted_history', JSON.stringify(srvDocs));
                } catch (e) {}
              }

              setIsCloudConnected(true);
            }
          }
        } catch (e) {
          console.warn('[DocExtractor] Cloud Server API pull warning:', e);
        }

        // Step B: Also attempt Firestore cloud fetch
        const [docsSnap, picturesSnap] = await Promise.all([
          getDocs(collection(db, 'extracted_documents')).catch(() => null),
          getDocs(collection(db, 'pds_pictures')).catch(() => null),
        ]);

        if (!isMounted) return;

        const initialPicturesList: PdsStoredImage[] = [];
        if (picturesSnap && !picturesSnap.empty) {
          picturesSnap.forEach((pSnap) => {
            const pData = pSnap.data();
            const docAcc = pData?.accountId || 'user-admin1';
            const isMatch = docAcc === currentAccountId || (currentAccountId === 'user-admin1' && docAcc === 'user-admin');
            if (pData && pData.applicantName && isMatch) {
              initialPicturesList.push({ id: pSnap.id, ...pData, accountId: docAcc } as PdsStoredImage);
            }
          });
        }

        const docsList: ExtractedDocumentResult[] = [];
        if (docsSnap && !docsSnap.empty) {
          docsSnap.forEach((docSnap) => {
            const data = docSnap.data();
            const docAcc = data?.accountId || 'user-admin1';
            const isMatch = docAcc === currentAccountId || (currentAccountId === 'user-admin1' && docAcc === 'user-admin');
            if (data && isMatch) {
              docsList.push(parseFirestoreDocToResult(docSnap.id, data));
            }
          });
        }

        if (docsList.length > 0) {
          docsList.sort(
            (a, b) =>
              new Date(b.scannedAt || b.id).getTime() -
              new Date(a.scannedAt || a.id).getTime()
          );

          const scopedMasterId = `${SHARED_MASTER_TABLE_ID}_${currentAccountId}`;
          const masterDoc = docsList.find((d) => d.id === scopedMasterId || d.id === SHARED_MASTER_TABLE_ID);
          const otherDocs = docsList.filter((d) => d.id !== scopedMasterId && d.id !== SHARED_MASTER_TABLE_ID);
          const unifiedList = masterDoc ? [masterDoc, ...otherDocs] : docsList;

          setFirestoreDocs(unifiedList);
          setSavedHistory(unifiedList);
          try {
            localStorage.setItem(`tindahan_doc_extracted_history_acc_${currentAccountId}`, JSON.stringify(unifiedList));
            localStorage.setItem('tindahan_doc_extracted_history', JSON.stringify(unifiedList));
          } catch (e) {}

          setResult((prevResult) => {
            if (prevResult && prevResult.id && prevResult.id !== SHARED_MASTER_TABLE_ID && prevResult.id !== scopedMasterId) {
              const matched = docsList.find((d) => d.id === prevResult.id);
              if (matched) {
                const normalized = ensure20RowsPerSheet(matched) || matched;
                try {
                  localStorage.setItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`, JSON.stringify(normalized));
                  localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(normalized));
                } catch (e) {}
                return normalized;
              }
              return prevResult;
            }

            const combinedMaster = combineAndDeduplicateAllRows(
              docsList,
              prevResult,
              initialPicturesList.length > 0 ? initialPicturesList : storedPdsImages
            );
            if (combinedMaster) {
              const normalizedMaster = ensure20RowsPerSheet(combinedMaster) || combinedMaster;
              try {
                localStorage.setItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`, JSON.stringify(normalizedMaster));
                localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(normalizedMaster));
              } catch (e) {}
              return normalizedMaster;
            }

            const firstDoc = ensure20RowsPerSheet(docsList[0]) || docsList[0];
            try {
              localStorage.setItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`, JSON.stringify(firstDoc));
              localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(firstDoc));
            } catch (e) {}
            return firstDoc;
          });

          setIsCloudConnected(true);
        } else {
          // Check local active table or push current active table to server
          const localActive = localStorage.getItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`) || localStorage.getItem('tindahan_doc_extracted_active_table');
          if (localActive) {
            try {
              const parsed = ensure20RowsPerSheet(JSON.parse(localActive));
              if (parsed) {
                setResult(parsed);
                setFirestoreDocs([parsed]);
                setSavedHistory([parsed]);
                syncWithCloudServer(parsed, storedPdsImages, [parsed]);
                saveDocumentToFirestore(parsed);
              }
            } catch (e) {}
          }
        }

        if (initialPicturesList.length > 0) {
          initialPicturesList.sort(
            (a, b) =>
              (a.order ?? 0) - (b.order ?? 0) ||
              new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime()
          );
          setStoredPdsImages(initialPicturesList);
          savePdsImagesToIndexedDB(initialPicturesList, currentAccountId).catch(() => {});
        } else {
          getAllPdsImagesFromIndexedDB(currentAccountId).then((cached) => {
            if (cached && cached.length > 0) {
              setStoredPdsImages(cached);
              syncWithCloudServer(result, cached, firestoreDocs);
              savePdsImagesToFirebaseAndIndexedDB(cached, currentAccountId).catch(() => {});
            }
          }).catch(() => {});
        }
      } catch (err) {
        console.warn('[DocExtractor] Initial cloud sync warning:', err);
      } finally {
        if (isMounted) {
          setIsInitialLoading(false);
        }
      }
    };

    performInitialCloudSync();

    // 3. Setup SSE Real-time listener from online cloud server
    let sseSource: EventSource | null = null;
    try {
      sseSource = new EventSource('/api/doc-extractor/stream');
      sseSource.onmessage = async (event) => {
        try {
          const payload = JSON.parse(event.data);
          if (payload?.type === 'DOC_EXTRACTOR_DATA_MUTATED') {
            if (payload?.accountId && payload.accountId !== currentAccountId && !(currentAccountId === 'user-admin1' && payload.accountId === 'user-admin')) {
              return;
            }
            const res = await fetch(`/api/doc-extractor/pull?accountId=${encodeURIComponent(currentAccountId)}`);
            if (res.ok) {
              const json = await res.json();
              if (json?.success && json?.data) {
                const { activeTable, pdsPictures, documents } = json.data;
                if (activeTable) {
                  const norm = ensure20RowsPerSheet(activeTable) || activeTable;
                  setResult(norm);
                  try {
                    localStorage.setItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`, JSON.stringify(norm));
                    localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(norm));
                  } catch (e) {}
                }
                if (Array.isArray(pdsPictures) && pdsPictures.length > 0) {
                  setStoredPdsImages(pdsPictures);
                  savePdsImagesToIndexedDB(pdsPictures, currentAccountId).catch(() => {});
                }
                if (Array.isArray(documents)) {
                  setFirestoreDocs(documents);
                  setSavedHistory(documents);
                }
                setIsCloudConnected(true);
              }
            }
          }
        } catch (e) {}
      };
    } catch (e) {}

    // 4. Setup Firestore real-time listener
    let unsubscribe: (() => void) | null = null;
    try {
      unsubscribe = onSnapshot(
        collection(db, 'extracted_documents'),
        (snapshot) => {
          const docsList: ExtractedDocumentResult[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            const docAcc = data?.accountId || 'user-admin1';
            const isMatch = docAcc === currentAccountId || (currentAccountId === 'user-admin1' && docAcc === 'user-admin');
            if (data && isMatch) {
              docsList.push(parseFirestoreDocToResult(docSnap.id, data));
            }
          });

          if (docsList.length > 0) {
            docsList.sort(
              (a, b) =>
                new Date(b.scannedAt || b.id).getTime() -
                new Date(a.scannedAt || a.id).getTime()
            );

            const scopedMasterId = `${SHARED_MASTER_TABLE_ID}_${currentAccountId}`;
            const masterDoc = docsList.find((d) => d.id === scopedMasterId || d.id === SHARED_MASTER_TABLE_ID);
            const otherDocs = docsList.filter((d) => d.id !== scopedMasterId && d.id !== SHARED_MASTER_TABLE_ID);
            const unifiedList = masterDoc ? [masterDoc, ...otherDocs] : docsList;

            setFirestoreDocs(unifiedList);
            setSavedHistory(unifiedList);
            try {
              localStorage.setItem(`tindahan_doc_extracted_history_acc_${currentAccountId}`, JSON.stringify(unifiedList));
              localStorage.setItem('tindahan_doc_extracted_history', JSON.stringify(unifiedList));
            } catch (e) {}

            setResult((prevResult) => {
              if (prevResult && prevResult.id && prevResult.id !== SHARED_MASTER_TABLE_ID && prevResult.id !== scopedMasterId) {
                const matched = docsList.find((d) => d.id === prevResult.id);
                if (matched) {
                  const normalizedMatched = ensure20RowsPerSheet(matched) || matched;
                  try {
                    localStorage.setItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`, JSON.stringify(normalizedMatched));
                    localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(normalizedMatched));
                  } catch (e) {}
                  return normalizedMatched;
                }
              }

              const combinedMaster = combineAndDeduplicateAllRows(docsList, prevResult, storedPdsImages);
              if (combinedMaster) {
                const normalizedMaster = ensure20RowsPerSheet(combinedMaster) || combinedMaster;
                try {
                  localStorage.setItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`, JSON.stringify(normalizedMaster));
                  localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(normalizedMaster));
                } catch (e) {}
                return normalizedMaster;
              }

              const firstDoc = ensure20RowsPerSheet(docsList[0]) || docsList[0];
              try {
                localStorage.setItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`, JSON.stringify(firstDoc));
                localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(firstDoc));
              } catch (e) {}
              return firstDoc;
            });
            setIsCloudConnected(true);
          }
        },
        (err) => {
          // If Firestore is rate-limited, we still have Online Cloud Server Sync active!
          console.warn('[Firestore] Live listener warning:', err?.message);
        }
      );
    } catch (err) {}

    return () => {
      isMounted = false;
      if (unsubscribe) unsubscribe();
      if (sseSource) sseSource.close();
    };
  }, [currentAccountId]);

  // Helper to persist updated result to state, localStorage, and Firestore
  const saveUpdatedResult = (updated: ExtractedDocumentResult) => {
    try {
      localStorage.removeItem('tindahan_doc_extractor_cleared_at');
    } catch (e) {}
    setResult(updated);
    // Automatic Firestore Cloud Save
    saveDocumentToFirestore(updated);
    try {
      const cleanToStore = {
        ...updated,
        imagesBase64: (updated.imagesBase64 || []).slice(0, 2).filter((img) => img.length < 60000),
      };
      // Persist active master table across sessions & reloads
      localStorage.setItem(`tindahan_doc_extracted_active_table_acc_${currentAccountId}`, JSON.stringify(cleanToStore));
      localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(cleanToStore));

      const currentHistory = savedHistory.filter((h) => h.id !== updated.id);
      const newHistory = [cleanToStore, ...currentHistory].slice(0, 30);
      setSavedHistory(newHistory);
      setFirestoreDocs(newHistory);
      localStorage.setItem(`tindahan_doc_extracted_history_acc_${currentAccountId}`, JSON.stringify(newHistory));
      localStorage.setItem('tindahan_doc_extracted_history', JSON.stringify(newHistory));
    } catch (e) {
      console.warn('Could not save to localStorage:', e);
    }
  };

  // Function to permanently delete a single table row, update Firebase, and pop up confirmation
  const handleDeleteSingleRow = async (secIdx: number, rIdx: number) => {
    if (!result || !result.sections || !result.sections[secIdx]) return;
    const sec = result.sections[secIdx];
    const targetRow = sec.rows[rIdx];
    if (!targetRow) return;

    const personName =
      targetRow['NAME (SURNAME, FIRST NAME, MIDDLE NAME)']?.trim() ||
      targetRow['NAME']?.trim() ||
      targetRow['Aplikante']?.trim() ||
      targetRow['SURNAME']?.trim() ||
      `Row ${rIdx + 1}`;

    const cleanSearchName = personName.trim().toLowerCase();

    // 1. Filter row out from active result
    const allActiveRows = (result.sections || []).flatMap((s) => s.rows || []);
    const remainingActiveRows = allActiveRows.filter((r) => {
      const rName = (r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || r['NAME'] || r['Aplikante'] || '').trim().toLowerCase();
      if (cleanSearchName && cleanSearchName.length > 2 && rName && (rName.includes(cleanSearchName) || cleanSearchName.includes(rName))) {
        return false;
      }
      return r !== targetRow;
    });

    let updatedDoc: ExtractedDocumentResult | null = null;
    if (remainingActiveRows.length > 0) {
      const rechunked = chunkRowsIntoSections(remainingActiveRows, result.sections[0]?.checkboxes || []);
      updatedDoc = { ...result, sections: rechunked };
      setResult(updatedDoc);
      try {
        localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(updatedDoc));
      } catch (e) {}
      await saveDocumentToFirestore(updatedDoc);
    } else {
      setResult(null);
      try {
        localStorage.removeItem('tindahan_doc_extracted_active_table');
      } catch (e) {}
      try {
        await deleteDoc(doc(db, 'extracted_documents', result.id));
        await deleteDoc(doc(db, 'extracted_documents', SHARED_MASTER_TABLE_ID));
      } catch (e) {}
    }

    // 2. Permanently purge matching row from ALL documents in Firestore and local state
    try {
      resetQuotaExhausted();
      const snapshot = await getDocs(collection(db, 'extracted_documents'));
      for (const docSnap of snapshot.docs) {
        const dData = docSnap.data() as ExtractedDocumentResult;
        if (!dData || !dData.sections) continue;

        const allDocRows = dData.sections.flatMap((s) => s.rows || []);
        const filteredDocRows = allDocRows.filter((r) => {
          const rName = (r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || r['NAME'] || r['Aplikante'] || '').trim().toLowerCase();
          if (cleanSearchName && cleanSearchName.length > 2 && rName && (rName.includes(cleanSearchName) || cleanSearchName.includes(rName))) {
            return false;
          }
          return true;
        });

        if (filteredDocRows.length === 0) {
          // If no rows remain in this document, delete it completely from Firestore
          await deleteDoc(doc(db, 'extracted_documents', docSnap.id));
        } else if (filteredDocRows.length !== allDocRows.length) {
          // Re-chunk and save cleaned document to Firestore
          const cleanedSections = chunkRowsIntoSections(filteredDocRows, dData.sections[0]?.checkboxes || []);
          const cleanedDoc = { ...dData, id: docSnap.id, sections: cleanedSections };
          await saveDocumentToFirestore(cleanedDoc);
        }
      }
    } catch (fsErr) {
      console.warn('[Firestore] Single row purge scan notice:', fsErr);
    }

    // 3. Delete any associated PDS pictures from Firestore and IndexedDB
    if (personName && personName.length > 2) {
      try {
        await deletePdsImagesByApplicantNameFromFirebaseAndIndexedDB(personName, currentAccountId);
        setStoredPdsImages((prev) =>
          prev.filter((p) => {
            const app = (p.applicantName || '').trim().toLowerCase();
            return !app.includes(cleanSearchName) && !cleanSearchName.includes(app);
          })
        );
      } catch (e) {}
    }

    // 4. Update memory & LocalStorage history
    const updatedHistory = savedHistory
      .map((docItem) => {
        const docRows = (docItem.sections || []).flatMap((s) => s.rows || []);
        const validRows = docRows.filter((r) => {
          const rName = (r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || r['NAME'] || r['Aplikante'] || '').trim().toLowerCase();
          return !(cleanSearchName && cleanSearchName.length > 2 && rName && (rName.includes(cleanSearchName) || cleanSearchName.includes(rName)));
        });
        if (validRows.length === 0) return null;
        return {
          ...docItem,
          sections: chunkRowsIntoSections(validRows, docItem.sections?.[0]?.checkboxes || []),
        };
      })
      .filter(Boolean) as ExtractedDocumentResult[];

    setSavedHistory(updatedHistory);
    setFirestoreDocs(updatedHistory);
    try {
      localStorage.setItem('tindahan_doc_extracted_history', JSON.stringify(updatedHistory));
    } catch (e) {}

    const remainingPics = storedPdsImages.filter((p) => {
      const app = (p.applicantName || '').trim().toLowerCase();
      return !app.includes(cleanSearchName) && !cleanSearchName.includes(app);
    });

    try {
      await pushToCloudServerApi({
        activeTable: updatedDoc,
        pdsPictures: remainingPics,
        documents: updatedHistory,
      });
    } catch (e) {}

    // 5. Open DELETED PERMANENTLY Popup Modal & toast
    setDeletedRowPopupInfo({
      isOpen: true,
      rowName: personName,
    });

    triggerAutoSaveToast(`🗑️ DELETED PERMANENTLY: Permanenteng nabura ang data ng row ni "${personName}" sa Table at Database!`);
  };

  // Dedicated function to delete a specific row directly from any document in the Firebase Database Modal
  const handleDeleteDatabaseDocRow = async (
    docItem: ExtractedDocumentResult,
    sIdx: number,
    rIdx: number
  ) => {
    if (!docItem || !docItem.sections || !docItem.sections[sIdx]) return;
    const sec = docItem.sections[sIdx];
    const targetRow = sec.rows ? sec.rows[rIdx] : null;
    if (!targetRow) return;

    const rawName =
      targetRow['NAME (SURNAME, FIRST NAME, MIDDLE NAME)']?.trim() ||
      targetRow['NAME']?.trim() ||
      targetRow['Aplikante']?.trim() ||
      targetRow['SURNAME']?.trim() ||
      docItem.detectedPersonName ||
      `Row #${rIdx + 1}`;

    const cleanSearchName = rawName.trim().toLowerCase();

    // Clone and splice row
    const updatedDoc: ExtractedDocumentResult = JSON.parse(JSON.stringify(docItem));
    if (updatedDoc.sections && updatedDoc.sections[sIdx] && updatedDoc.sections[sIdx].rows) {
      updatedDoc.sections[sIdx].rows.splice(rIdx, 1);
    }

    const totalRowsRemaining = (updatedDoc.sections || []).reduce(
      (acc, s) => acc + (s.rows?.length || 0),
      0
    );

    let activeTableToSync = result;

    if (totalRowsRemaining === 0) {
      // If no rows remain in this document, delete the whole document
      await deleteDocumentFromFirestore(docItem.id);
      if (result && result.id === docItem.id) {
        setResult(null);
        activeTableToSync = null;
        try {
          localStorage.removeItem('tindahan_doc_extracted_active_table');
        } catch (e) {}
      }
    } else {
      // Re-chunk sections if necessary
      const allRemainingRows = (updatedDoc.sections || []).flatMap((s) => s.rows || []);
      const rechunked = chunkRowsIntoSections(allRemainingRows, updatedDoc.sections[0]?.checkboxes || []);
      const finalDoc = { ...updatedDoc, sections: rechunked };

      await saveDocumentToFirestore(finalDoc);

      const nextDocs = firestoreDocs.map((d) => (d.id === docItem.id ? finalDoc : d));
      setFirestoreDocs(nextDocs);
      setSavedHistory(nextDocs);
      try {
        localStorage.setItem('tindahan_doc_extracted_history', JSON.stringify(nextDocs));
      } catch (e) {}

      if (result && result.id === docItem.id) {
        setResult(finalDoc);
        activeTableToSync = finalDoc;
        try {
          localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(finalDoc));
        } catch (e) {}
      }
    }

    // Delete matching PDS images if any
    let remainingPics = storedPdsImages;
    if (cleanSearchName && cleanSearchName.length > 2) {
      try {
        await deletePdsImagesByApplicantNameFromFirebaseAndIndexedDB(cleanSearchName, currentAccountId);
        remainingPics = storedPdsImages.filter((p) => {
          const app = (p.applicantName || '').trim().toLowerCase();
          return !app.includes(cleanSearchName) && !cleanSearchName.includes(app);
        });
        setStoredPdsImages(remainingPics);
      } catch (e) {}
    }

    try {
      await pushToCloudServerApi({
        activeTable: activeTableToSync,
        pdsPictures: remainingPics,
        documents: firestoreDocs,
      });
    } catch (e) {}

    triggerAutoSaveToast(`🗑️ Nabura ang rekord ni "${rawName}" sa Database.`);
  };

  // Function to delete an entire Sheet/Section permanently from Firestore and local state
  const handleDeleteSheet = async (secIdx: number) => {
    if (!result || !result.sections || !result.sections[secIdx]) return;
    const sec = result.sections[secIdx];
    if (!window.confirm(`Burahin ang seksyong "${sec.sectionTitle}" kasama ang lahat ng rows nito?`)) return;

    const rowsInSheet = sec.rows || [];
    const namesToDelete = rowsInSheet
      .map((r) =>
        (
          r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
          r['NAME'] ||
          r['Aplikante'] ||
          r['SURNAME'] ||
          ''
        )
          .trim()
          .toLowerCase()
      )
      .filter((n) => n.length > 2);

    const updatedSections = result.sections.filter((_, i) => i !== secIdx);
    const totalRowsRemaining = updatedSections.reduce((acc, s) => acc + (s.rows?.length || 0), 0);

    let activeTableToSync: ExtractedDocumentResult | null = null;
    if (totalRowsRemaining === 0) {
      setResult(null);
      activeTableToSync = null;
      try {
        localStorage.removeItem('tindahan_doc_extracted_active_table');
      } catch (e) {}
      try {
        await deleteDoc(doc(db, 'extracted_documents', result.id));
        await deleteDoc(doc(db, 'extracted_documents', SHARED_MASTER_TABLE_ID));
      } catch (e) {}
    } else {
      const updatedDoc = { ...result, sections: updatedSections };
      setResult(updatedDoc);
      activeTableToSync = updatedDoc;
      try {
        localStorage.setItem('tindahan_doc_extracted_active_table', JSON.stringify(updatedDoc));
      } catch (e) {}
      await saveDocumentToFirestore(updatedDoc);
    }

    // Purge rows belonging to this sheet from all documents in Firestore
    try {
      resetQuotaExhausted();
      const snapshot = await getDocs(collection(db, 'extracted_documents'));
      for (const docSnap of snapshot.docs) {
        const dData = parseFirestoreDocToResult(docSnap.id, docSnap.data());
        if (!dData || !dData.sections) continue;

        const allDocRows = dData.sections.flatMap((s) => s.rows || []);
        const filteredDocRows = allDocRows.filter((r) => {
          const rName = (
            r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
            r['NAME'] ||
            r['Aplikante'] ||
            r['SURNAME'] ||
            ''
          )
            .trim()
            .toLowerCase();
          if (namesToDelete.some((delName) => rName.includes(delName) || delName.includes(rName))) {
            return false;
          }
          return true;
        });

        if (filteredDocRows.length === 0) {
          await deleteDoc(doc(db, 'extracted_documents', docSnap.id));
        } else if (filteredDocRows.length !== allDocRows.length) {
          const cleanedSections = chunkRowsIntoSections(filteredDocRows, dData.sections[0]?.checkboxes || []);
          const cleanedDoc = { ...dData, id: docSnap.id, sections: cleanedSections };
          await saveDocumentToFirestore(cleanedDoc);
        }
      }
    } catch (fsErr) {
      console.warn('[Firestore] Sheet purge error:', fsErr);
    }

    // Delete associated PDS pictures
    for (const delName of namesToDelete) {
      try {
        await deletePdsImagesByApplicantNameFromFirebaseAndIndexedDB(delName, currentAccountId);
      } catch (e) {}
    }
    const remainingPics = storedPdsImages.filter((p) => {
      const app = (p.applicantName || '').trim().toLowerCase();
      return !namesToDelete.some((delName) => app.includes(delName) || delName.includes(app));
    });
    setStoredPdsImages(remainingPics);

    try {
      await pushToCloudServerApi({
        activeTable: activeTableToSync,
        pdsPictures: remainingPics,
        documents: firestoreDocs,
      });
    } catch (e) {}

    triggerAutoSaveToast(`🗑️ Nabura nang permanente ang seksyong "${sec.sectionTitle}" sa Database!`);
  };

  // Comprehensive Reset All Handler (Opens custom confirmation modal)
  const handleResetAll = () => {
    setShowDeleteAllConfirmModal(true);
  };

  // Execution function for Delete All with live fast permanent feedback
  const handleExecuteDeleteAll = async () => {
    setIsDeletingAll(true);
    setIsCloudSyncing(true);

    try {
      // 0. Record clear timestamp in localStorage to immediately invalidate stale cache
      const clearTimestamp = Date.now();
      try {
        localStorage.setItem('tindahan_doc_extractor_cleared_at', clearTimestamp.toString());
      } catch (e) {}

      resetQuotaExhausted();
      try {
        await enableNetwork(db);
      } catch (e) {}

      // 1. Instantly reset all React UI state (Table, Database Table, PDS Pictures, Gallery Queue, Headers)
      setResult(null);
      setFirestoreDocs([]);
      setSavedHistory([]);
      setSelectedImages([]);
      setStoredPdsImages([]);
      setCustomPhotoNames({});
      setTitleHint('');
      setSearchTerm('');
      setActiveCell(null);
      setEditingCell(null);
      setEditingHeader(null);
      setSelectedSheetTab(0);
      setAgeFilter('all');
      setActiveTargetHeaders(TARGET_REQUESTED_HEADERS);
      setActiveTemplateName('Personal Data Sheet (19 Columns)');
      setGalleryBoxes([
        { id: 'box-1', boxNumber: 1, imageSrc: null, status: 'empty' },
        { id: 'box-2', boxNumber: 2, imageSrc: null, status: 'empty' },
        { id: 'box-3', boxNumber: 3, imageSrc: null, status: 'empty' },
        { id: 'box-4', boxNumber: 4, imageSrc: null, status: 'empty' },
      ]);

      // 2. Instantly wipe all relevant LocalStorage caches
      try {
        const keysToRemove = Object.keys(localStorage).filter(
          (k) =>
            k.startsWith('tindahan_doc_') ||
            k.startsWith('tindahan_pds_') ||
            k.startsWith('tindahan_custom_table_') ||
            k.startsWith('tindahan_deleted_archive_') ||
            k.startsWith('tindahan_home_monitoring_') ||
            k.startsWith('tindahan_print_') ||
            k.startsWith('tindahan_gallery_')
        );
        keysToRemove.forEach((k) => {
          if (k !== 'tindahan_doc_extractor_cleared_at') {
            localStorage.removeItem(k);
          }
        });
        localStorage.removeItem('tindahan_doc_extracted_active_table');
        localStorage.removeItem('tindahan_doc_extracted_history');
        localStorage.removeItem('tindahan_pds_custom_photo_names');
        localStorage.removeItem('tindahan_custom_table_headers');
        localStorage.removeItem('tindahan_custom_table_template_name');
        localStorage.removeItem('tindahan_deleted_archive_v1');
        localStorage.removeItem('tindahan_gallery_boxes');
      } catch (e) {
        console.warn('[LocalStorage] Clear error:', e);
      }

      // 3. Clear IndexedDB storage
      try {
        await clearAllPdsImagesFromFirebaseAndIndexedDB(currentAccountId);
      } catch (e) {
        console.warn('[IndexedDB] Clear error:', e);
      }

      // 4. Directly delete all known Firestore document IDs (bypasses getDocs quota limits)
      const scopedMasterId = `${SHARED_MASTER_TABLE_ID}_${currentAccountId}`;
      const knownDocIds = Array.from(
        new Set([
          scopedMasterId,
          SHARED_MASTER_TABLE_ID,
          'master_extracted_document',
          ...firestoreDocs.map((d) => d.id),
          ...firestoreDocs.map((d) => `${d.id}_${currentAccountId}`),
          ...savedHistory.map((d) => d.id),
          ...savedHistory.map((d) => `${d.id}_${currentAccountId}`),
          ...(result?.id ? [result.id, `${result.id}_${currentAccountId}`] : []),
        ])
      );
      await Promise.allSettled(
        knownDocIds.map((id) => deleteDoc(doc(db, 'extracted_documents', id)))
      );

      // 5. Delete only this account's records from Firestore collections
      const collectionsToClear = [
        'extracted_documents',
        'pds_pictures',
        'deletedArchive',
      ];
      for (const colName of collectionsToClear) {
        try {
          const snapshot = await getDocs(collection(db, colName));
          if (snapshot && !snapshot.empty) {
            const docs = snapshot.docs.filter((d) => {
              const dData = d.data();
              const docAcc = dData?.accountId || 'user-admin1';
              return docAcc === currentAccountId || (currentAccountId === 'user-admin1' && docAcc === 'user-admin');
            });
            for (let i = 0; i < docs.length; i += 300) {
              const batch = writeBatch(db);
              docs.slice(i, i + 300).forEach((d) => batch.delete(d.ref));
              await batch.commit();
            }
          }
        } catch (colErr) {
          console.warn(`[Firestore] Clear collection ${colName} notice:`, colErr);
        }
      }

      // 6. Clear Cloud SQL PostgreSQL and Server Cache for this account
      try {
        await fetch('/api/doc-extractor/clear', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ accountId: currentAccountId, deviceId: 'local_device' }),
        });
      } catch (e) {}

      triggerAutoSaveToast('⚡ Ganap nang nabura ang lahat ng data sa Table, Gallery, at Cloud Database!');
    } catch (err) {
      console.error('Error during reset all execution:', err);
      triggerAutoSaveToast('Nalinis at nabura ang lahat ng data!');
    } finally {
      setIsDeletingAll(false);
      setIsCloudSyncing(false);
      setShowDeleteAllConfirmModal(false);
    }
  };

  // Add Manual Empty Row to Table (supports adding at the first cell of Sheet 1 or appending)
  const handleAddManualRow = (insertAtFirstCell = true) => {
    const targetHeaders =
      activeTargetHeaders && activeTargetHeaders.length > 0 ? activeTargetHeaders : TARGET_REQUESTED_HEADERS;
    const newRow: Record<string, string> = {};
    targetHeaders.forEach((h) => (newRow[h] = ''));

    // If no active table exists yet, initialize Sheet 1 with an empty row at Cell A1
    if (!result || !result.sections || result.sections.length === 0) {
      const mdHeaders = targetHeaders.join(' | ');
      const mdDividers = targetHeaders.map(() => '---').join(' | ');
      const mdRows = targetHeaders.map(() => '-').join(' | ');

      const initialDoc: ExtractedDocumentResult = {
        id: `DOC-TABLE-${Date.now()}`,
        title: 'Sheet 1',
        detectedPersonName: '',
        documentType: `Custom Table (${targetHeaders.length} Columns)`,
        totalPages: 1,
        detectedPageNumbers: ['Sheet 1'],
        sections: [
          {
            sectionTitle: 'Sheet 1',
            headers: targetHeaders,
            rows: [newRow],
            checkboxes: [],
          },
        ],
        consolidatedMarkdownTable: `| ${mdHeaders} |\n| ${mdDividers} |\n| ${mdRows} |`,
        signaturesAndDates: [],
        unreadableSummary: '',
        privacyNoticeAcknowledged: true,
        scannedAt: new Date().toISOString(),
        imagesBase64: [],
      };
      saveUpdatedResult(initialDoc);
      setSelectedSheetTab(0);
      setActiveCell({
        secIdx: 0,
        rowIdx: 0,
        colIdx: 0,
        colLetter: 'A',
        colName: targetHeaders[0] || 'NAME (SURNAME, FIRST NAME, MIDDLE NAME)',
        cellCoord: 'A1',
        value: '',
      });
      triggerAutoSaveToast('✨ Nagdagdag ng row sa unang cell (A1) ng Sheet 1!');
      return;
    }

    const allRows = (result.sections || []).flatMap((s) => s.rows || []);
    let updatedAllRows: Record<string, string>[];

    if (insertAtFirstCell) {
      // Magdagdag ng bagong row sa pinakaunang cell ng unang sheet (Row 1 / Cell A1)
      updatedAllRows = [newRow, ...allRows];
    } else {
      // Magdagdag ng row sa dulo
      updatedAllRows = [...allRows, newRow];
    }

    const prevSheetsCount = result.sections?.length || 1;
    const updatedSections = chunkRowsIntoSections(
      updatedAllRows,
      result.sections?.[0]?.checkboxes || []
    );
    const updatedResult: ExtractedDocumentResult = {
      ...result,
      sections: updatedSections,
    };
    saveUpdatedResult(updatedResult);

    if (insertAtFirstCell) {
      setSelectedSheetTab(0);
      setActiveCell({
        secIdx: 0,
        rowIdx: 0,
        colIdx: 0,
        colLetter: 'A',
        colName: targetHeaders[0] || 'NAME (SURNAME, FIRST NAME, MIDDLE NAME)',
        cellCoord: 'A1',
        value: '',
      });
      triggerAutoSaveToast('✨ Nagdagdag ng bagong row sa unang cell (A1) ng Sheet 1!');
    } else if (updatedSections.length > prevSheetsCount) {
      setSelectedSheetTab(updatedSections.length - 1);
      triggerAutoSaveToast(
        `Lumagpas sa 20 rows! Awtomatikong nilikha ang Sheet ${updatedSections.length} para sa sobrang data.`
      );
    } else {
      triggerAutoSaveToast(`Nagdagdag ng bagong row! (Kabuuang Rows: ${updatedAllRows.length})`);
    }
  };

  // Commit and auto-save cell value
  const handleCommitCellEdit = (
    secIdx: number,
    rowIdx: number,
    colKey: string,
    newValue: string
  ) => {
    if (!result || !result.sections || !result.sections[secIdx]) return;

    const oldRow = result.sections[secIdx]?.rows?.[rowIdx];
    const oldName = oldRow?.[colKey] || '';

    const newSections = result.sections.map((sec, sI) => {
      if (sI !== secIdx) return sec;
      const newRows = sec.rows.map((row, rI) => {
        if (rI !== rowIdx) return row;
        return {
          ...row,
          [colKey]: newValue,
        };
      });
      return {
        ...sec,
        rows: newRows,
      };
    });

    const updatedResult: ExtractedDocumentResult = {
      ...result,
      sections: newSections,
    };

    saveUpdatedResult(updatedResult);

    // Bidirectional sync: If applicant name column was edited, update storedPdsImages metadata too!
    const isNameCol =
      colKey.toLowerCase().includes('name') ||
      colKey.toLowerCase().includes('pangalan') ||
      colKey.toLowerCase().includes('surname');
    if (isNameCol && newValue.trim() && newValue.trim() !== oldName.trim()) {
      const trimmedNew = newValue.trim().toUpperCase();
      setStoredPdsImages((prev) => {
        const updated = prev.map((p, pIdx) => {
          const globalRowIdx = secIdx * 20 + rowIdx;
          if (
            (oldName && checkApplicantNamesMatch(p.applicantName, oldName)) ||
            pIdx === globalRowIdx
          ) {
            updatePdsImageMetadataInFirebaseAndIndexedDB(p.id, { applicantName: trimmedNew }).catch(() => {});
            return { ...p, applicantName: trimmedNew };
          }
          return p;
        });
        return updated;
      });
    }

    if (
      activeCell &&
      activeCell.secIdx === secIdx &&
      activeCell.rowIdx === rowIdx &&
      activeCell.colName === colKey
    ) {
      setActiveCell({
        ...activeCell,
        value: newValue,
      });
    }

    setEditingCell(null);
    triggerAutoSaveToast(`Na-save sa Firestore ang cell ${activeCell?.cellCoord || ''}`);
  };

  // Commit and auto-save column header rename
  const handleCommitHeaderEdit = (
    secIdx: number,
    colIdx: number,
    oldKey: string,
    newHeaderName: string
  ) => {
    const trimmedNew = newHeaderName.trim();
    if (!result || !result.sections || !result.sections[secIdx] || !trimmedNew || trimmedNew === oldKey) {
      setEditingHeader(null);
      return;
    }

    const newSections = result.sections.map((sec, sI) => {
      if (sI !== secIdx) return sec;
      const newHeaders = [...sec.headers];
      newHeaders[colIdx] = trimmedNew;

      const newRows = sec.rows.map((row) => {
        const newRow: Record<string, string> = {};
        Object.keys(row).forEach((k) => {
          if (k === oldKey) {
            newRow[trimmedNew] = row[k];
          } else {
            newRow[k] = row[k];
          }
        });
        return newRow;
      });

      return {
        ...sec,
        headers: newHeaders,
        rows: newRows,
      };
    });

    const updatedResult: ExtractedDocumentResult = {
      ...result,
      sections: newSections,
    };

    saveUpdatedResult(updatedResult);

    if (activeCell && activeCell.secIdx === secIdx && activeCell.colName === oldKey) {
      setActiveCell({
        ...activeCell,
        colName: trimmedNew,
      });
    }

    setEditingHeader(null);
    triggerAutoSaveToast(`Na-save sa Firestore ang header: "${trimmedNew}"`);
  };

  // Helper function to extract or resolve person's name
  const getDocumentPersonName = (doc: ExtractedDocumentResult): string => {
    if (doc.detectedPersonName && doc.detectedPersonName.trim()) {
      return doc.detectedPersonName.trim();
    }
    for (const sec of doc.sections || []) {
      for (const row of sec.rows || []) {
        const keys = Object.keys(row);
        for (const k of keys) {
          const lowerK = k.toLowerCase();
          if (
            (lowerK.includes('surname') ||
              lowerK.includes('pangalan') ||
              lowerK.includes('applicant') ||
              lowerK.includes('full name') ||
              lowerK.includes('first name') ||
              lowerK.includes('name of')) &&
            row[k] &&
            row[k].trim() &&
            !row[k].toLowerCase().includes('hindi matukoy')
          ) {
            return row[k].trim();
          }
        }
      }
    }
    if (doc.signaturesAndDates && doc.signaturesAndDates.length > 0 && doc.signaturesAndDates[0].signerName) {
      return doc.signaturesAndDates[0].signerName;
    }
    return doc.title || 'Dokumento / Form';
  };

  // Real-time incremental search filtering for Nakalipas na Scans
  const filteredHistory = savedHistory.filter((doc) => {
    if (!historySearchQuery.trim()) return true;
    const q = historySearchQuery.toLowerCase().trim();
    const personName = getDocumentPersonName(doc).toLowerCase();
    const title = (doc.title || '').toLowerCase();
    const docType = (doc.documentType || '').toLowerCase();
    const rawMarkdown = (doc.consolidatedMarkdownTable || '').toLowerCase();
    return personName.includes(q) || title.includes(q) || docType.includes(q) || rawMarkdown.includes(q);
  });

  // Helper to extract image files recursively from dropped items or file inputs (including subfolders)
  const extractImageFilesFromInput = async (filesOrItems: FileList | DataTransferItemList | File[]): Promise<File[]> => {
    const imageFiles: File[] = [];

    const isImageFile = (file: File) => {
      return file && (file.type.startsWith('image/') || /\.(jpe?g|png|webp|gif|bmp|heic|tiff)$/i.test(file.name));
    };

    if (filesOrItems instanceof FileList || Array.isArray(filesOrItems)) {
      const arr = Array.from(filesOrItems);
      arr.forEach((f) => {
        if (isImageFile(f)) imageFiles.push(f);
      });
      return imageFiles;
    }

    const itemList = Array.from(filesOrItems);
    const traverseEntry = async (entry: any): Promise<void> => {
      if (!entry) return;
      if (entry.isFile) {
        await new Promise<void>((resolve) => {
          entry.file(
            (file: File) => {
              if (isImageFile(file)) {
                imageFiles.push(file);
              }
              resolve();
            },
            () => resolve()
          );
        });
      } else if (entry.isDirectory) {
        const dirReader = entry.createReader();
        const readEntries = async (): Promise<any[]> => {
          return new Promise((resolve) => {
            dirReader.readEntries(
              (entries: any[]) => resolve(entries || []),
              () => resolve([])
            );
          });
        };
        let entries: any[] = [];
        let batch: any[];
        do {
          batch = await readEntries();
          entries = entries.concat(batch);
        } while (batch.length > 0);

        for (const childEntry of entries) {
          await traverseEntry(childEntry);
        }
      }
    };

    const promises: Promise<void>[] = [];
    for (const item of itemList) {
      if (item.kind === 'file') {
        const entry = item.webkitGetAsEntry ? item.webkitGetAsEntry() : null;
        if (entry) {
          promises.push(traverseEntry(entry));
        } else {
          const file = item.getAsFile();
          if (file && isImageFile(file)) {
            imageFiles.push(file);
          }
        }
      }
    }

    await Promise.all(promises);
    return imageFiles;
  };

  // Unified File & Folder Upload Handler (Guarantees ALL images process automatically without truncation)
  const processUploadedFiles = async (files: File[], sourceName: string = 'Upload') => {
    if (!files || files.length === 0) {
      setErrorMessage('Walang natagpuang larawan sa in-upload na file o folder.');
      return;
    }

    setErrorMessage(null);
    setScanStep(`Binabasa at inihahanda ang ${files.length} larawan mula sa ${sourceName}...`);

    try {
      const base64Promises = files.map(
        (file) =>
          new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (event) => resolve((event.target?.result as string) || '');
            reader.onerror = (err) => reject(err);
            reader.readAsDataURL(file);
          })
      );

      const loadedImagesRaw = (await Promise.all(base64Promises)).filter((img) => img && img.trim().length > 0);
      
      // Fast parallel optimization to ensure clean, 100% natural color and text fidelity
      const loadedImages = await Promise.all(
        loadedImagesRaw.map((img) => compressImageForAi(img, 2048, 0.92))
      );

      if (loadedImages.length > 0) {
        // AI Organizer: Automatic Duplicate Detection & Removal
        let finalImagesToProcess = loadedImages;
        let removedDupes = 0;

        if (autoDeduplicateEnabled) {
          const dedupeCheck = await detectAndRemoveDuplicatePictures(loadedImages);
          finalImagesToProcess = dedupeCheck.uniqueImages;
          removedDupes = dedupeCheck.removedCount;

          // Also check against existing selectedImages
          const combined = Array.from(new Set([...(selectedImages || []), ...finalImagesToProcess]));
          const combinedDedupe = await detectAndRemoveDuplicatePictures(combined);
          setSelectedImages(combinedDedupe.uniqueImages);
          finalImagesToProcess = combinedDedupe.uniqueImages;
        } else {
          setSelectedImages((prev) => [...prev, ...loadedImages]);
        }

        if (removedDupes > 0) {
          triggerAutoSaveToast(`🤖 AI Organizer: Awtomatikong inalis ang ${removedDupes} duplicate na larawan!`);
        } else {
          triggerAutoSaveToast(`Matagumpay na nabasa ang ${finalImagesToProcess.length} larawan mula sa ${sourceName}!`);
        }

        // Guaranteed Instant PDS Picture Persistence to Cloud Firestore & IndexedDB
        // This guarantees uploaded pictures appear immediately in PDS Picture button content and never disappear across reloads!
        const uploadTimestamp = Date.now();
        const initialPdsItems: PdsStoredImage[] = finalImagesToProcess.map((imgSrc, idx) => ({
          id: `pds_${uploadTimestamp}_${idx}_${Math.random().toString(36).substr(2, 6)}`,
          src: imgSrc,
          applicantName: `Aplikante ${storedPdsImages.length + idx + 1}`,
          pageTitle: `PDS Pahina ${idx + 1}`,
          pageNumber: idx + 1,
          searchKey: `aplikante ${storedPdsImages.length + idx + 1}`,
          createdAt: new Date().toISOString(),
          uploadedAt: new Date().toISOString(),
          order: storedPdsImages.length + idx,
        }));
        savePdsImagesToFirebaseAndIndexedDB(initialPdsItems, activeUser?.id).catch(() => {});
        setStoredPdsImages((prev) => [...prev, ...initialPdsItems]);
        try {
          localStorage.removeItem('tindahan_doc_extractor_cleared_at');
        } catch (e) {}

        // AUTOMATIC AI EXTRACTION SCAN on unique images
        handleScanDocument(finalImagesToProcess);
      } else {
        setErrorMessage('Walang valid na larawan (.png, .jpg, .jpeg, .webp) ang nabasa.');
      }
    } catch (err) {
      console.error('Error processing uploaded file/folder:', err);
      setErrorMessage('Nagkaroon ng problema sa pag-basa sa in-upload na larawan o folder.');
    }
  };

  // Direct PDS Gallery Picture Upload Handlers (Accessible directly inside the PDS Pictures modal)
  const processPdsDirectUpload = async (fileList: File[]) => {
    if (!fileList || fileList.length === 0) return;
    try {
      setIsCloudSyncing(true);
      triggerAutoSaveToast(`Binabasa at sini-save sa Cloud ang ${fileList.length} PDS picture(s)...`);

      const base64Promises = fileList.map(
        (file) =>
          new Promise<{ name: string; base64: string }>((resolve) => {
            const reader = new FileReader();
            reader.onload = (ev) =>
              resolve({
                name: file.name.replace(/\.[^/.]+$/, ''),
                base64: (ev.target?.result as string) || '',
              });
            reader.onerror = () => resolve({ name: file.name, base64: '' });
            reader.readAsDataURL(file);
          })
      );

      const readResults = await Promise.all(base64Promises);
      const validResults = readResults.filter((r) => r.base64 && r.base64.trim().length > 0);

      const allTableRows = (result?.sections || []).flatMap((s) => s.rows || []);
      const candidateNames: string[] = [];
      allTableRows.forEach((r) => {
        const rName = (
          r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
          r['FULL NAME'] ||
          r['PANGALAN'] ||
          r['SURNAME'] ||
          ''
        )?.trim();
        if (rName && isRealApplicantName(rName) && !isLikelyFilenameOrHash(rName)) {
          candidateNames.push(rName);
        }
      });

      const newPdsItems: PdsStoredImage[] = [];
      const timestamp = Date.now();

      for (let i = 0; i < validResults.length; i++) {
        const item = validResults[i];
        const compressed = await compressImageForAi(item.base64, 2048, 0.92);

        // Determine real applicant Full Name:
        let finalFullName = '';

        // Check if filename itself is a real name (and not a UUID, hash, or camera prefix)
        const isFilenameReal = isRealApplicantName(item.name) && !isLikelyFilenameOrHash(item.name);
        if (isFilenameReal) {
          const matchedCand = candidateNames.find((c) => checkApplicantNamesMatch(item.name, c));
          finalFullName = matchedCand || item.name.replace(/[-_]/g, ' ').toUpperCase();
        }

        // If filename is a hash/UUID or unrecognized, extract applicant Full Name via AI OCR from PDS Box I
        if (!finalFullName) {
          try {
            const thumb = await createOptimizedPdsThumbnailForOcr(item.base64);
            const aiRes = await extractPdsApplicantName(thumb, candidateNames);
            let resolved = (aiRes.applicantName || '').trim();
            if (aiRes.matchedCandidate && checkApplicantNamesMatch(resolved, aiRes.matchedCandidate)) {
              resolved = aiRes.matchedCandidate.trim();
            }
            if (resolved && isRealApplicantName(resolved) && !isLikelyFilenameOrHash(resolved)) {
              finalFullName = resolved.toUpperCase();
            }
          } catch (aiErr) {
            console.warn('[Direct Upload] AI OCR name extraction:', aiErr);
          }
        }

        // Final fallback if name could not be extracted
        if (!finalFullName) {
          finalFullName = `PDS Aplikante ${storedPdsImages.length + i + 1}`;
        }

        newPdsItems.push({
          id: `pds_${timestamp}_${i}_${Math.random().toString(36).substr(2, 6)}`,
          src: compressed || item.base64,
          applicantName: finalFullName,
          pageTitle: `PDS • ${finalFullName}`,
          pageNumber: storedPdsImages.length + i + 1,
          searchKey: `${finalFullName.toLowerCase()} pds pahina ${storedPdsImages.length + i + 1}`,
          createdAt: new Date().toISOString(),
          uploadedAt: new Date().toISOString(),
          order: storedPdsImages.length + i,
        });
      }

      if (newPdsItems.length > 0) {
        // Guaranteed Cloud & Local Save
        await savePdsImagesToFirebaseAndIndexedDB(newPdsItems, activeUser?.id);
        const allStored = await getAllPdsImagesFromIndexedDB().catch(() => [
          ...storedPdsImages,
          ...newPdsItems,
        ]);
        setStoredPdsImages(allStored);
        try {
          localStorage.removeItem('tindahan_doc_extractor_cleared_at');
        } catch (e) {}

        // ALSO GUARANTEE CORRESPONDING ROWS IN TABLE & DATABASE FOR EVERY UPLOADED PICTURE!
        const targetHeaders = activeTargetHeaders && activeTargetHeaders.length > 0 ? activeTargetHeaders : TARGET_REQUESTED_HEADERS;
        const primaryHdrKey =
          targetHeaders.find((h) => {
            const hl = h.toLowerCase();
            return hl.includes('name') || hl.includes('pangalan') || hl.includes('surname');
          }) || 'NAME (SURNAME, FIRST NAME, MIDDLE NAME)';

        const currentActiveRows = (result?.sections || []).flatMap((s) => s.rows || []);
        const workingRows = [...currentActiveRows];
        let rowsModified = false;

        for (let i = 0; i < newPdsItems.length; i++) {
          const item = newPdsItems[i];
          const cleanName = item.applicantName.toUpperCase();

          const existsIdx = workingRows.findIndex((r) => {
            const rName = (r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || r['FULL NAME'] || r[primaryHdrKey] || '').trim();
            return checkApplicantNamesMatch(cleanName, rName);
          });

          if (existsIdx === -1) {
            // Check if there is an empty/placeholder/hash row at this slot
            const slotIdx = storedPdsImages.length + i;
            if (slotIdx < workingRows.length) {
              const existingRow = workingRows[slotIdx];
              const curName = (existingRow['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || existingRow[primaryHdrKey] || '').trim();
              if (isValuePlaceholderOrNA(curName) || curName.toLowerCase().startsWith('aplikante') || isLikelyFilenameOrHash(curName)) {
                workingRows[slotIdx] = {
                  ...existingRow,
                  [primaryHdrKey]: cleanName,
                  'NAME (SURNAME, FIRST NAME, MIDDLE NAME)': cleanName,
                };
                rowsModified = true;
                continue;
              }
            }

            const newRow: Record<string, string> = {
              [primaryHdrKey]: cleanName,
              'NAME (SURNAME, FIRST NAME, MIDDLE NAME)': cleanName,
            };
            targetHeaders.forEach((h) => {
              if (newRow[h] === undefined) newRow[h] = '';
            });
            workingRows.push(newRow);
            rowsModified = true;
          } else {
            // Update existing row if generic or placeholder
            const curRow = workingRows[existsIdx];
            const curName = (curRow['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || curRow[primaryHdrKey] || '').trim();
            if (isValuePlaceholderOrNA(curName) || curName.toLowerCase().startsWith('aplikante') || isLikelyFilenameOrHash(curName)) {
              workingRows[existsIdx] = {
                ...curRow,
                [primaryHdrKey]: cleanName,
                'NAME (SURNAME, FIRST NAME, MIDDLE NAME)': cleanName,
              };
              rowsModified = true;
            }
          }
        }

        if (rowsModified) {
          const rechunked = chunkRowsIntoSections(
            workingRows,
            result?.sections?.[0]?.checkboxes || [],
            targetHeaders
          );
          const updatedTable: ExtractedDocumentResult = {
            id: result?.id || SHARED_MASTER_TABLE_ID,
            title: result?.title || 'Personal Data Sheet (19 Columns)',
            detectedPersonName: workingRows[0]?.[primaryHdrKey] || workingRows[0]?.['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || 'Master Applicant List',
            documentType: result?.documentType || `Personal Data Sheet (${targetHeaders.length} Columns)`,
            totalPages: rechunked.length,
            detectedPageNumbers: rechunked.map((_, i) => `Sheet ${i + 1}`),
            sections: rechunked,
            consolidatedMarkdownTable: '',
            signaturesAndDates: result?.signaturesAndDates || [],
            unreadableSummary: result?.unreadableSummary || '',
            privacyNoticeAcknowledged: true,
            scannedAt: new Date().toISOString(),
            imagesBase64: Array.from(new Set([...(result?.imagesBase64 || []), ...newPdsItems.map((p) => p.src)])),
          };
          setResult(updatedTable);
          saveUpdatedResult(updatedTable);
        }

        triggerAutoSaveToast(
          `⚡ Tagumpay! Naka-save na sa PDS Pictures, Table Content, at Cloud Database ang ${newPdsItems.length} PDS picture(s). Parehong-pareho ang bilang at nilalaman!`
        );
      }
    } catch (err) {
      console.error('PDS direct upload error:', err);
      setErrorMessage('Nagkaroon ng problema sa pag-upload ng PDS picture.');
    } finally {
      setIsCloudSyncing(false);
    }
  };

  const handlePdsGalleryUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const rawFiles: File[] = Array.from(files);
    const fileList = rawFiles.filter(
      (f) => f.type.startsWith('image/') || /\.(jpe?g|png|webp|gif|bmp|heic|tiff)$/i.test(f.name)
    );
    await processPdsDirectUpload(fileList);
    e.target.value = '';
  };

  const handlePdsGalleryFolderUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const imageFiles = await extractImageFilesFromInput(files);
    await processPdsDirectUpload(imageFiles);
    e.target.value = '';
  };

  // Standard File Upload (Multiple images)
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const rawFiles: File[] = Array.from(files);
    const fileList = rawFiles.filter(f => f.type.startsWith('image/') || /\.(jpe?g|png|webp|gif|bmp|heic|tiff)$/i.test(f.name));
    await processUploadedFiles(fileList, `${fileList.length} Larawan`);
    e.target.value = '';
  };

  // Folder Upload (Entire folder containing images)
  const handleFolderUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const imageFiles = await extractImageFilesFromInput(files);
    await processUploadedFiles(imageFiles, 'Folder Upload');
    e.target.value = '';
  };

  // Drag and Drop Event Handlers for Files or Folders
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer && e.dataTransfer.items) {
      const imageFiles = await extractImageFilesFromInput(e.dataTransfer.items);
      if (imageFiles.length > 0) {
        await processUploadedFiles(imageFiles, 'Drag & Drop Folder / Files');
      } else if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        const rawFiles: File[] = Array.from(e.dataTransfer.files);
        const fileList = rawFiles.filter(f => f.type.startsWith('image/') || /\.(jpe?g|png|webp|gif|bmp|heic|tiff)$/i.test(f.name));
        await processUploadedFiles(fileList, 'Drag & Drop Files');
      }
    }
  };

  // Remove Page Image
  const handleRemoveImage = (index: number) => {
    setSelectedImages((prev) => prev.filter((_, i) => i !== index));
  };

  // Perform Gemini AI Document Vision Extraction (Supports direct automatic calls on upload)
  const handleScanDocument = async (customImages?: string[] | unknown) => {
    const imagesToProcess =
      Array.isArray(customImages) && customImages.length > 0 ? customImages : selectedImages;
    if (imagesToProcess.length === 0) {
      setErrorMessage('Mangyaring mag-upload muna o pumili ng kahit isang larawan o folder ng dokumento.');
      return;
    }

    setIsScanning(true);
    setErrorMessage(null);

    // Process each image individually (iisa-isahin) for maximum speed, accuracy, and zero payload lag
    const totalImages = imagesToProcess.length;
    const BATCH_SIZE = 1;
    const totalBatches = totalImages;

    let imagesWithDataCount = 0;
    let imagesWithoutDataCount = 0;
    const duplicateBlockedNames: string[] = [];

    try {
      let currentActiveResult = result;

      for (let bIdx = 0; bIdx < totalBatches; bIdx++) {
        const rawBatchImages = [imagesToProcess[bIdx]];

        setScanStep(
          isAiBoostEnabled
            ? totalImages > 1
              ? `⚡ AI Boost: Mabilis na sinusuri ang Larawan ${bIdx + 1} sa ${totalImages}... (Iisa-isahing tinitiyak)`
              : `⚡ AI Boost: Mabilis na sinusuri ang larawan sa Gemini Vision...`
            : totalImages > 1
              ? `Ina-scan ng AI ang Larawan ${bIdx + 1} sa ${totalImages}...`
              : `Mabilis na sinusuri ang larawan sa AI Vision...`
        );

        // Fast high-speed compression: reduces 5MB-10MB mobile photos to ~70KB for lightning ~1s extraction
        const batchImages = await Promise.all(
          rawBatchImages.map((img) => compressImageForAi(img, isAiBoostEnabled ? 1080 : 1200, isAiBoostEnabled ? 0.70 : 0.75))
        );

        const currentTargetHeaders = activeTargetHeaders && activeTargetHeaders.length > 0 ? activeTargetHeaders : TARGET_REQUESTED_HEADERS;

        let data: any = null;
        try {
          const response = await fetch('/api/extract-document', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              images: batchImages,
              titleHint,
              customHeaders: currentTargetHeaders,
            }),
          });

          if (response.ok) {
            const jsonRes = await response.json();
            if (jsonRes && jsonRes.success) {
              data = jsonRes;
            }
          }
        } catch (serverErr) {
          console.warn('[DocExtractor] Express backend endpoint unavailable. Falling back to client-side Gemini extraction (Netlify static host mode):', serverErr);
        }

        // Netlify static host mode: If backend API endpoint is not present or returned error, execute client-side vision extraction
        if (!data || !data.success) {
          try {
            data = await extractDocumentClientSide(batchImages, titleHint, undefined, currentTargetHeaders);
          } catch (clientErr: any) {
            if (clientErr?.message === 'NO_API_KEY') {
              setIsApiKeyModalOpen(true);
              throw new Error('Nasa Netlify ka (Static Hosting). Mangyaring ilagay ang iyong Gemini API Key sa Settings popup.');
            }
            throw new Error(clientErr?.message || `Nabigo ang pag-scan sa larawan ${bIdx + 1}.`);
          }
        }

        // Normalize newly extracted sections & rows to target columns
        const newSections = (data.data.sections || []).map((sec: any) => normalizeSectionTable(sec));

        // Filter rows from this scan that contain actual meaningful data
        const newlyExtractedRows: any[] = [];
        newSections.forEach((sec: any) => {
          if (sec.rows && Array.isArray(sec.rows)) {
            sec.rows.forEach((r: any) => {
              const normalizedRow: Record<string, string> = {};
              currentTargetHeaders.forEach((hdr) => {
                if (r[hdr] !== undefined) {
                  normalizedRow[hdr] = String(r[hdr] || '');
                } else {
                  const cleanHdr = hdr.toLowerCase().replace(/[^a-z0-9]/g, '');
                  const foundKey = Object.keys(r).find((k) => {
                    const cleanK = k.toLowerCase().replace(/[^a-z0-9]/g, '');
                    return cleanHdr.includes(cleanK) || cleanK.includes(cleanHdr);
                  });
                  normalizedRow[hdr] = foundKey ? String(r[foundKey] || '') : (r[hdr] || '');
                }
              });

              // Check if row has meaningful value (not just empty strings or hyphens)
              const hasMeaningfulData = Object.values(normalizedRow).some((v) => {
                const str = String(v || '').trim();
                return str !== '' && str !== '-' && str !== 'HINDI MATUKOY' && str !== 'N/A';
              });
              if (hasMeaningfulData) {
                newlyExtractedRows.push(normalizedRow);
              }
            });
          }
        });

        // ONLY IF DATA WAS EXTRACTED FROM THIS PICTURE AND PLACED IN THE TABLE:
        if (newlyExtractedRows.length > 0) {
          const primaryHdrKey = currentTargetHeaders.find((h) => {
            const hLow = h.toLowerCase();
            return hLow.includes('name') || hLow.includes('pangalan') || hLow.includes('surname') || hLow.includes('item');
          }) || currentTargetHeaders[0];

          const detectedCandidateName = (
            (data.data?.detectedPersonName && data.data.detectedPersonName !== 'Maramihang Rekord / Aplikante' ? data.data.detectedPersonName : '') ||
            newlyExtractedRows[0]?.[primaryHdrKey] ||
            newlyExtractedRows[0]?.['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
            ''
          ).trim();

          // 🛑 BAGO I-UPLOAD: AUTOMATIC NA I-CHECK KUNG MAY KAPAREHONG NAME / DUPLICATE DATA
          let isDuplicate = false;
          let matchedDuplicateName = detectedCandidateName;

          if (isRealApplicantName(detectedCandidateName)) {
            // 1. Check existing stored PDS pictures
            const existingStoredPds = await getAllPdsImagesFromIndexedDB().catch(() => storedPdsImages);
            const foundInPds = existingStoredPds.find((p) => checkApplicantNamesMatch(detectedCandidateName, p.applicantName));

            // 2. Check existing rows in current active table
            const existingTableRows = (currentActiveResult?.sections || []).flatMap((s) => s.rows || []);
            const foundInTable = existingTableRows.find((r) => {
              const rName = r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || r[primaryHdrKey] || r['PANGALAN'] || '';
              return checkApplicantNamesMatch(detectedCandidateName, rName);
            });

            // 3. Check previously processed images in this same batch
            const foundInCurrentBatch = duplicateBlockedNames.some((n) => checkApplicantNamesMatch(detectedCandidateName, n));

            if (foundInPds || foundInTable || foundInCurrentBatch) {
              isDuplicate = true;
              matchedDuplicateName = foundInPds?.applicantName || (foundInTable ? (foundInTable['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] || foundInTable[primaryHdrKey]) : detectedCandidateName);
            }
          }

          if (isDuplicate) {
            // ⚠️ NA-DETECT NA DUPLICATE ANG DATA: HINDI ITO MA-U-UPLOAD!
            duplicateBlockedNames.push(matchedDuplicateName || detectedCandidateName);
            console.log(`[Duplicate Gatekeeper] Na-detect na duplicate si "${matchedDuplicateName}". Hindi ito ia-upload sa PDS Pictures o Table.`);
            continue;
          }

          // ✅ WALANG KAPAREHONG DATA -> MAGPAPATULOY ITO SA PAG-UPLOAD
          imagesWithDataCount += rawBatchImages.length;

          let accumulatedRows: any[] = [];
          if (currentActiveResult && currentActiveResult.sections && currentActiveResult.sections.length > 0) {
            const existingRows = currentActiveResult.sections.flatMap((s) => s.rows || []);
            accumulatedRows = [...existingRows];
          }

          accumulatedRows.push(...newlyExtractedRows);

          // Chunk automatically into 20 rows per sheet (Sheet 1: 1-20, Sheet 2: 21-40, etc.)
          const chunkedSections = chunkRowsIntoSections(
            accumulatedRows,
            [
              ...(currentActiveResult?.sections?.[0]?.checkboxes || []),
              ...(newSections[0]?.checkboxes || []),
            ],
            currentTargetHeaders
          );

          // Generate consolidated markdown table
          const mdHeaders = currentTargetHeaders.join(' | ');
          const mdDividers = currentTargetHeaders.map(() => '---').join(' | ');
          const mdRows = accumulatedRows
            .map((row) => currentTargetHeaders.map((h) => String(row[h] || '-')).join(' | '))
            .join('\n');
          const combinedMarkdown = `| ${mdHeaders} |\n| ${mdDividers} |\n${mdRows.length > 0 ? mdRows : ''}`;

          const newImagesBase64 = Array.from(new Set([
            ...(currentActiveResult?.imagesBase64 || []),
            ...rawBatchImages,
          ]));

          const accumulatedData: ExtractedDocumentResult = {
            id: currentActiveResult?.id || `DOC-${Date.now()}`,
            title: currentActiveResult?.title || titleHint || activeTemplateName || 'Master Form Database',
            detectedPersonName: data.data.detectedPersonName || currentActiveResult?.detectedPersonName || 'Maramihang Rekord / Aplikante',
            documentType: `${activeTemplateName} (${currentTargetHeaders.length} Columns)`,
            totalPages: newImagesBase64.length,
            detectedPageNumbers: [
              ...(currentActiveResult?.detectedPageNumbers || []),
              ...(data.data.detectedPageNumbers || [`Upload ${new Date().toLocaleTimeString()}`]),
            ],
            sections: chunkedSections,
            consolidatedMarkdownTable: combinedMarkdown,
            signaturesAndDates: [
              ...(currentActiveResult?.signaturesAndDates || []),
              ...(data.data.signaturesAndDates || []),
            ],
            unreadableSummary: data.data.unreadableSummary || currentActiveResult?.unreadableSummary || '',
            privacyNoticeAcknowledged: true,
            scannedAt: new Date().toISOString(),
            imagesBase64: newImagesBase64,
          };

          currentActiveResult = accumulatedData;
          saveUpdatedResult(accumulatedData);

          // SAVE ONLY THIS PICTURE TO INDEXEDDB / PDS PICTURES CONTENT (Since data was extracted from it and it is not a duplicate)
          const pdsStorageItems: PdsStoredImage[] = rawBatchImages.map((src, idx) => {
            const correspondingRow = newlyExtractedRows[idx] || newlyExtractedRows[0];
            const rowFullName = (
              correspondingRow?.['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
              correspondingRow?.['FULL NAME'] ||
              correspondingRow?.[primaryHdrKey] ||
              ''
            )?.trim();

            const finalApplicantName =
              rowFullName && isRealApplicantName(rowFullName) && !isLikelyFilenameOrHash(rowFullName)
                ? rowFullName.toUpperCase()
                : data.data?.detectedPersonName &&
                  data.data.detectedPersonName !== 'Maramihang Rekord / Aplikante' &&
                  isRealApplicantName(data.data.detectedPersonName) &&
                  !isLikelyFilenameOrHash(data.data.detectedPersonName)
                ? data.data.detectedPersonName.toUpperCase()
                : `Aplikante ${storedPdsImages.length + idx + 1}`;

            return {
              id: `PDS-IMG-${Date.now()}-${idx}-${Math.random().toString(36).substr(2, 5)}`,
              src,
              applicantName: finalApplicantName,
              pageTitle: `PDS • ${finalApplicantName}`,
              uploadedAt: new Date().toISOString(),
              order: idx,
            };
          });

          await savePdsImagesToFirebaseAndIndexedDB(pdsStorageItems, activeUser?.id).catch((err) => console.warn('[PDS Storage] Error saving picture to Firebase/IndexedDB:', err));
          const allStored = await getAllPdsImagesFromIndexedDB().catch(() => []);
          setStoredPdsImages(allStored);

          if (chunkedSections.length > 1) {
            setSelectedSheetTab(chunkedSections.length - 1);
          }
        } else {
          // NO DATA WAS EXTRACTED FROM THIS PICTURE -> AUTOMATICALLY DO NOT ADD TO PDS PICTURE BUTTON CONTENT!
          imagesWithoutDataCount += rawBatchImages.length;
          console.log(`[PDS Filter] Image ${bIdx + 1} produced no extracted table data. Skipping upload to PDS picture button content.`);
        }

        // Smart inter-image pause (600ms) to ensure continuous multi-image processing stays well within rate limits
        if (bIdx < totalBatches - 1) {
          await new Promise((r) => setTimeout(r, 600));
        }
      }

      setSelectedImages([]);
      setTitleHint('');

      // Kung may na-detect na duplicate, awtomatikong mag-message sa user at ipakitang hindi ito na-upload
      if (duplicateBlockedNames.length > 0) {
        const uniqueBlocked = Array.from(new Set(duplicateBlockedNames));
        const namesStr = uniqueBlocked.join(', ');
        setDuplicateWarningInfo({
          isOpen: true,
          duplicateName: namesStr,
          message: `Na-detect na DUPLICATE ang datos para kay "${namesStr}". Hindi ito nai-upload sa PDS Pictures o Table upang maiwasan ang duplicate. Kung nais mong i-upload ang bago o panibagong larawan nito, burahin mo muna ang dating naka-upload na datos o larawan sa PDS Pictures o Table.`
        });
        triggerAutoSaveToast(`⚠️ Duplicate Na-detect: Hindi nai-upload ang datos para kay "${namesStr}" dahil may kapareho nang naka-upload. Burahin muna ang dating data kung nais palitan.`);
      }

      if (imagesWithDataCount > 0 && imagesWithoutDataCount === 0 && duplicateBlockedNames.length === 0) {
        triggerAutoSaveToast(`✨ Matagumpay na na-extract ang datos at nailagay sa Table at PDS Pictures! (${imagesWithDataCount} larawan).`);
      } else if (imagesWithDataCount > 0 && imagesWithoutDataCount > 0) {
        triggerAutoSaveToast(`✨ Na-extract ang datos mula sa ${imagesWithDataCount} larawan (Nailagay sa Table at PDS Pictures). Ang ${imagesWithoutDataCount} larawan na walang datos ay awtomatikong hindi isinama sa PDS Pictures.`);
      } else if (imagesWithDataCount === 0 && duplicateBlockedNames.length === 0) {
        triggerAutoSaveToast(`⚠️ Walang natagpuang datos sa in-upload na larawan kaya awtomatiko itong HINDI isinama sa PDS Pictures button content.`);
      }
    } catch (err: any) {
      console.error('Scan Error:', err);
      setErrorMessage(err.message || 'Nagkaroon ng problema sa pag-extract ng datos mula sa larawan.');
    } finally {
      setIsScanning(false);
      setScanStep('');
    }
  };

  // Copy Markdown Table to Clipboard
  const handleCopyMarkdown = () => {
    if (!result) return;
    navigator.clipboard.writeText(result.consolidatedMarkdownTable);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Robust cell value resolution that matches exact keys, trimmed keys, clean normalized keys, fuzzy keys, or positional column indices
  const resolveExactCellValue = (
    row: Record<string, any> | undefined | null,
    header: string,
    headerIdx: number
  ): string => {
    if (!row || typeof row !== 'object') return '';

    // 1. Direct key match
    if (row[header] !== undefined && row[header] !== null && String(row[header]).trim() !== '') {
      return String(row[header]).trim();
    }

    const trimmedH = header.trim();
    if (row[trimmedH] !== undefined && row[trimmedH] !== null && String(row[trimmedH]).trim() !== '') {
      return String(row[trimmedH]).trim();
    }

    // 2. Normalized key match (stripping punctuation, case-insensitive)
    const cleanH = trimmedH.toLowerCase().replace(/[^a-z0-9]/g, '');
    const foundKey = Object.keys(row).find((k) => {
      const cleanK = k.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
      return cleanK === cleanH;
    });
    if (foundKey && row[foundKey] !== undefined && row[foundKey] !== null && String(row[foundKey]).trim() !== '') {
      return String(row[foundKey]).trim();
    }

    // 3. Substring / Inclusion matching (e.g. "Name" vs "PANGALAN / FULL NAME")
    const subKey = Object.keys(row).find((k) => {
      const cleanK = k.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
      return cleanH.length >= 3 && cleanK.length >= 3 && (cleanK.includes(cleanH) || cleanH.includes(cleanK));
    });
    if (subKey && row[subKey] !== undefined && row[subKey] !== null && String(row[subKey]).trim() !== '') {
      return String(row[subKey]).trim();
    }

    // 4. Calculated Age check if the column is Age/Edad
    if (cleanH.includes('age') || cleanH.includes('edad')) {
      const calculatedAge = getRowAge(row);
      if (calculatedAge !== null) return `${calculatedAge}`;
    }

    // 5. Positional index fallback: matches Object.values(row)[headerIdx]
    const values = Object.values(row);
    if (values[headerIdx] !== undefined && values[headerIdx] !== null && String(values[headerIdx]).trim() !== '') {
      return String(values[headerIdx]).trim();
    }

    return '';
  };

  // Helper to export a single table to Excel (.xlsx) with 100% exact layout fidelity
  const exportSingleTableToExcel = (targetDoc: ExtractedDocumentResult) => {
    if (!targetDoc || !targetDoc.sections || targetDoc.sections.length === 0) {
      triggerAutoSaveToast('⚠️ Walang data sa table na mai-e-export.');
      return;
    }

    const currentHeaders =
      targetDoc.sections[0]?.headers && targetDoc.sections[0].headers.length > 0
        ? targetDoc.sections[0].headers
        : (activeTargetHeaders && activeTargetHeaders.length > 0 ? activeTargetHeaders : TARGET_REQUESTED_HEADERS);

    const wb = XLSX.utils.book_new();
    const allDocRows = targetDoc.sections.flatMap((s) => s.rows || []);

    // Filter out completely empty dummy rows if all columns are blank, but keep valid rows
    const meaningfulRows = allDocRows.filter((r) => {
      return Object.values(r).some((v) => v !== undefined && v !== null && String(v).trim() !== '');
    });

    // 1. Export each section / sheet with 100% exact 2D grid layout matching screen
    targetDoc.sections.forEach((sec, idx) => {
      const headers = sec.headers && sec.headers.length > 0 ? sec.headers : currentHeaders;
      const sheetAoa: any[][] = [];

      // Row 1: Exact Column Headers [ #, Header1, Header2, Header3, ... ]
      const headerRow = ['#', ...headers];
      sheetAoa.push(headerRow);

      // Data Rows: [ 1, Val1, Val2, Val3, ... ]
      const secRows = sec.rows && sec.rows.length > 0 ? sec.rows : (idx === 0 && meaningfulRows.length > 0 ? meaningfulRows : []);
      secRows.forEach((r, rowNum) => {
        const rowData: any[] = [rowNum + 1];
        headers.forEach((h, hIdx) => {
          const val = resolveExactCellValue(r, h, hIdx);
          rowData.push(val);
        });
        sheetAoa.push(rowData);
      });

      // Optional Checkboxes / Status rows
      if (sec.checkboxes && sec.checkboxes.length > 0) {
        sheetAoa.push([]);
        sheetAoa.push(['STATUS', '--- MGA CHECKBOX AT STATUS ---']);
        sec.checkboxes.forEach((cb, cbIdx) => {
          sheetAoa.push([cbIdx + 1, cb.label, cb.status.toUpperCase(), cb.notes || '']);
        });
      }

      const ws = XLSX.utils.aoa_to_sheet(sheetAoa);

      // Auto-fit column widths for crystal clear opening in Excel app & Google Sheets
      const colWidths = headerRow.map((h, colIdx) => {
        if (colIdx === 0) return { wch: 6 };
        let maxLen = h.length;
        sheetAoa.forEach((r) => {
          const valStr = String(r[colIdx] || '');
          if (valStr.length > maxLen) maxLen = Math.min(valStr.length, 50);
        });
        return { wch: Math.max(maxLen + 4, 16) };
      });
      ws['!cols'] = colWidths;

      const sheetName = `Sheet ${idx + 1}`.substring(0, 31);
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
    });

    // If there are multiple sheets, add a master "Lahat ng Rekord (All)" sheet at the end
    if (targetDoc.sections.length > 1 && allDocRows.length > 0) {
      const masterAoa: any[][] = [];
      const masterHeaders = ['#', ...currentHeaders];
      masterAoa.push(masterHeaders);

      allDocRows.forEach((r, rowIdx) => {
        const rowData: any[] = [rowIdx + 1];
        currentHeaders.forEach((h, hIdx) => {
          const val = resolveExactCellValue(r, h, hIdx);
          rowData.push(val);
        });
        masterAoa.push(rowData);
      });

      const masterWs = XLSX.utils.aoa_to_sheet(masterAoa);
      const masterColWidths = masterHeaders.map((h, colIdx) => {
        if (colIdx === 0) return { wch: 6 };
        let maxLen = h.length;
        masterAoa.forEach((r) => {
          const valStr = String(r[colIdx] || '');
          if (valStr.length > maxLen) maxLen = Math.min(valStr.length, 50);
        });
        return { wch: Math.max(maxLen + 4, 16) };
      });
      masterWs['!cols'] = masterColWidths;

      XLSX.utils.book_append_sheet(wb, masterWs, 'Lahat ng Rekord (All)');
    }

    const safeTitle = (targetDoc.title || targetDoc.detectedPersonName || 'Personal_Data_Sheet_Table')
      .replace(/[/\\?%*:|"<>]/g, '_')
      .replace(/\s+/g, '_');
    const exportFileName = `${safeTitle}.xlsx`;
    XLSX.writeFile(wb, exportFileName);
    triggerAutoSaveToast(`📥 Matagumpay na na-download ang Excel file: "${exportFileName}"!`);
  };

  // Helper to export ALL tables into 1 unified multi-sheet Excel workbook
  const exportAllTablesToExcel = (tablesList: ExtractedDocumentResult[]) => {
    if (!tablesList || tablesList.length === 0) {
      triggerAutoSaveToast('⚠️ Walang mga table na mai-e-export.');
      return;
    }

    const wb = XLSX.utils.book_new();

    tablesList.forEach((tableDoc, tIdx) => {
      const sheetTitle = (tableDoc.title || `Table ${tIdx + 1}`).substring(0, 28).replace(/[/\\?%*:|"[\]]/g, '_');
      const tableHeaders = tableDoc.sections?.[0]?.headers && tableDoc.sections[0].headers.length > 0
        ? tableDoc.sections[0].headers
        : (activeTargetHeaders || TARGET_REQUESTED_HEADERS);

      const allRows = tableDoc.sections?.flatMap((s) => s.rows || []) || [];
      const sheetAoa: any[][] = [];

      const allSheetHeaders = ['#', ...tableHeaders];
      sheetAoa.push(allSheetHeaders);

      allRows.forEach((r, rowIdx) => {
        const rowData: any[] = [rowIdx + 1];
        tableHeaders.forEach((h, hIdx) => {
          const val = resolveExactCellValue(r, h, hIdx);
          rowData.push(val);
        });
        sheetAoa.push(rowData);
      });

      const ws = XLSX.utils.aoa_to_sheet(sheetAoa);

      const colWidths = allSheetHeaders.map((h, colIdx) => {
        if (colIdx === 0) return { wch: 6 };
        let maxLen = h.length;
        sheetAoa.forEach((r) => {
          const valStr = String(r[colIdx] || '');
          if (valStr.length > maxLen) maxLen = Math.min(valStr.length, 50);
        });
        return { wch: Math.max(maxLen + 4, 16) };
      });
      ws['!cols'] = colWidths;

      const uniqueSheetName = `${tIdx + 1}. ${sheetTitle}`.substring(0, 31);
      XLSX.utils.book_append_sheet(wb, ws, uniqueSheetName);
    });

    const exportFileName = `All_${tablesList.length}_Tables_Workbook_${new Date().toISOString().slice(0, 10)}.xlsx`;
    XLSX.writeFile(wb, exportFileName);
    triggerAutoSaveToast(`📥 Matagumpay na na-download ang Lahat ng ${tablesList.length} Tables bilang "${exportFileName}"!`);
  };

  // Open the interactive Excel download table selector modal
  const handleOpenExcelDownloadModal = () => {
    if (combinedDatabaseDocs.length === 0 && (!result || !result.sections)) {
      triggerAutoSaveToast('⚠️ Walang available na table na mai-e-export.');
      return;
    }
    setSelectedTableIdForDownload(result?.id || 'active');
    setIsDownloadTableModalOpen(true);
  };

  // Confirm download based on selection from Table List or modal
  const handleConfirmExcelDownload = () => {
    setIsDownloadTableModalOpen(false);

    if (selectedTableIdForDownload === 'ALL') {
      exportAllTablesToExcel(combinedDatabaseDocs);
      return;
    }

    if (selectedTableIdForDownload === 'active' || (result && selectedTableIdForDownload === result.id)) {
      if (result) {
        exportSingleTableToExcel(result);
      } else if (combinedDatabaseDocs[0]) {
        exportSingleTableToExcel(combinedDatabaseDocs[0]);
      }
      return;
    }

    const target = combinedDatabaseDocs.find((d) => d.id === selectedTableIdForDownload);
    if (target) {
      exportSingleTableToExcel(target);
    } else if (result) {
      exportSingleTableToExcel(result);
    }
  };

  // Export Table Data to Excel (.xlsx) - Automatically downloads the visible table directly!
  const handleExportExcel = () => {
    if (result && result.sections && result.sections.length > 0) {
      exportSingleTableToExcel(result);
    } else if (combinedDatabaseDocs.length > 0 && combinedDatabaseDocs[0]) {
      exportSingleTableToExcel(combinedDatabaseDocs[0]);
    } else {
      triggerAutoSaveToast('⚠️ Walang aktibong data sa table na mai-e-export.');
    }
  };

  // 1. UPLOAD EXCEL BUTTON HANDLER: Awtomatikong binabasa ang Excel (.xlsx / .xls / .csv) at inilalagay ang lahat ng laman nito sa Table Content
  const handleExcelFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsScanning(true);
      setScanStep(`Binabasa ang Excel file "${file.name}"...`);

      const reader = new FileReader();
      reader.onload = async (evt) => {
        try {
          const data = new Uint8Array(evt.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array', cellDates: true, dateNF: 'mm/dd/yyyy' });

          if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
            triggerAutoSaveToast('⚠️ Walang sheets na natagpuan sa in-upload na Excel file.');
            setIsScanning(false);
            setScanStep('');
            return;
          }

          let detectedHeaders: string[] = [];
          const allImportedRows: Record<string, string>[] = [];

          // Process worksheets: prioritize "Lahat ng Rekord" or read all sheets
          const sheetNames = workbook.SheetNames;
          const masterSheet = sheetNames.find((s) => {
            const low = s.toLowerCase();
            return low.includes('lahat') || low.includes('all') || low.includes('master');
          });

          const sheetsToRead = masterSheet ? [masterSheet] : sheetNames;

          sheetsToRead.forEach((sName) => {
            const sheet = workbook.Sheets[sName];
            if (!sheet) return;
            const rawAoa: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
            if (!rawAoa || rawAoa.length === 0) return;

            // Find header row: the first row with multiple text strings that look like columns
            let headerRowIdx = -1;
            for (let i = 0; i < Math.min(rawAoa.length, 6); i++) {
              const row = rawAoa[i] || [];
              const meaningfulTextCells = row.filter(
                (c: any) =>
                  typeof c === 'string' &&
                  c.trim().length > 0 &&
                  !c.toLowerCase().includes('status') &&
                  !c.toLowerCase().includes('checkbox')
              );
              if (meaningfulTextCells.length >= 2) {
                headerRowIdx = i;
                break;
              }
            }

            if (headerRowIdx === -1 && rawAoa.length > 0) {
              headerRowIdx = 0;
            }

            const headerRow: string[] = (rawAoa[headerRowIdx] || []).map((h: any) => String(h || '').trim());
            const sheetHeaders: string[] = [];
            const colIndexMap: number[] = [];

            headerRow.forEach((h, colIdx) => {
              if (h && h !== '#' && h.toLowerCase() !== 'no.' && h.toLowerCase() !== 'no' && h.toLowerCase() !== 'id') {
                sheetHeaders.push(h);
                colIndexMap.push(colIdx);
              } else if (h === '#' && colIdx === 0) {
                // skip leading sequence index
              } else if (h) {
                sheetHeaders.push(h);
                colIndexMap.push(colIdx);
              }
            });

            if (sheetHeaders.length > 0 && detectedHeaders.length === 0) {
              detectedHeaders = sheetHeaders;
            }

            // Extract rows and strictly discard empty rows
            for (let r = headerRowIdx + 1; r < rawAoa.length; r++) {
              const row = rawAoa[r];
              if (!row || !Array.isArray(row)) continue;

              // Stop if encountering footer checkbox/status rows
              const firstCell = String(row[0] || '').trim().toLowerCase();
              const secondCell = String(row[1] || '').trim().toLowerCase();
              if (firstCell === 'status' || secondCell.includes('checkbox')) {
                break;
              }

              const rowObj: Record<string, string> = {};
              const headersToUse = sheetHeaders.length > 0 ? sheetHeaders : detectedHeaders;

              headersToUse.forEach((h, hIdx) => {
                const colIdx = colIndexMap[hIdx] !== undefined ? colIndexMap[hIdx] : hIdx + (headerRow[0] === '#' ? 1 : 0);
                const cellVal = row[colIdx];
                
                if (cellVal instanceof Date && !isNaN(cellVal.getTime())) {
                  const mm = String(cellVal.getMonth() + 1).padStart(2, '0');
                  const dd = String(cellVal.getDate()).padStart(2, '0');
                  const yyyy = cellVal.getFullYear();
                  rowObj[h] = `${mm}/${dd}/${yyyy}`;
                } else if (cellVal !== undefined && cellVal !== null) {
                  let strVal = String(cellVal).trim();
                  // Check if numeric serial date in Date of Birth column
                  const hl = h.toLowerCase();
                  const isDateCol = hl.includes('birth') || hl.includes('dob') || hl.includes('date');
                  if (isDateCol && typeof cellVal === 'number' && cellVal > 10000 && cellVal < 60000) {
                    const d = new Date((cellVal - 25569) * 86400 * 1000);
                    const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
                    const dd = String(d.getUTCDate()).padStart(2, '0');
                    const yyyy = d.getUTCFullYear();
                    strVal = `${mm}/${dd}/${yyyy}`;
                  }
                  rowObj[h] = strVal;
                } else {
                  rowObj[h] = '';
                }
              });

              // CRITICAL FILTER: Automatic na hindi isasama sa table ang bawat isang buong row na walang laman kahit isa!
              const hasMeaningfulData = Object.entries(rowObj).some(([key, val]) => {
                const kLow = key.toLowerCase();
                // Huwag ituring na data kung simpleng row index/sequence lang ang may laman
                if (kLow === '#' || kLow === 'no.' || kLow === 'no' || kLow === 'id' || kLow === 'bilang') return false;
                const vTrim = val.trim();
                return (
                  vTrim !== '' &&
                  vTrim !== '-' &&
                  vTrim !== '--' &&
                  vTrim !== '---' &&
                  vTrim.toLowerCase() !== 'n/a' &&
                  vTrim.toLowerCase() !== 'na' &&
                  vTrim.toLowerCase() !== 'none' &&
                  vTrim.toLowerCase() !== 'null' &&
                  vTrim.toLowerCase() !== 'undefined'
                );
              });

              if (hasMeaningfulData) {
                allImportedRows.push(rowObj);
              }
            }
          });

          if (allImportedRows.length === 0) {
            triggerAutoSaveToast('⚠️ Walang natagpuang data rows sa in-upload na Excel file.');
            setIsScanning(false);
            setScanStep('');
            return;
          }

          // Deduplicate imported rows
          const uniqueRows: Record<string, string>[] = [];
          allImportedRows.forEach((r) => {
            const rName =
              r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
              r['PANGALAN'] ||
              r['FULL NAME'] ||
              r['SURNAME'] ||
              Object.values(r)[0] ||
              '';
            const isDupe = uniqueRows.some((ex) => {
              const exName =
                ex['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
                ex['PANGALAN'] ||
                ex['FULL NAME'] ||
                ex['SURNAME'] ||
                Object.values(ex)[0] ||
                '';
              if (rName && exName && checkApplicantNamesMatch(rName, exName)) return true;
              return JSON.stringify(r) === JSON.stringify(ex);
            });
            if (!isDupe) {
              uniqueRows.push(r);
            }
          });

          const finalHeaders =
            detectedHeaders.length > 0
              ? detectedHeaders
              : (activeTargetHeaders && activeTargetHeaders.length > 0
                ? activeTargetHeaders
                : TARGET_REQUESTED_HEADERS);

          setActiveTargetHeaders(finalHeaders);
          try {
            localStorage.setItem('tindahan_custom_table_headers', JSON.stringify(finalHeaders));
          } catch (e) {}

          // Chunk rows into sections of 20 (Sheet 1, Sheet 2, etc.)
          const chunkedSections = chunkRowsIntoSections(uniqueRows, [], finalHeaders);
          const fileNameClean = file.name.replace(/\.[^/.]+$/, '');

          const newTableDoc: ExtractedDocumentResult = {
            id: result?.id || SHARED_MASTER_TABLE_ID,
            title: fileNameClean,
            detectedPersonName:
              uniqueRows[0]?.['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
              uniqueRows[0]?.['PANGALAN'] ||
              uniqueRows[0]?.[finalHeaders[0]] ||
              'Excel Imported Data',
            documentType: `Excel Form (${finalHeaders.length} Columns)`,
            totalPages: chunkedSections.length,
            detectedPageNumbers: chunkedSections.map((_, i) => `Sheet ${i + 1}`),
            sections: chunkedSections,
            consolidatedMarkdownTable: '',
            signaturesAndDates: [],
            unreadableSummary: '',
            privacyNoticeAcknowledged: true,
            scannedAt: new Date().toISOString(),
            imagesBase64: result?.imagesBase64 || [],
          };

          // Save and persist immediately to React state, Firestore, LocalStorage, and Cloud
          saveUpdatedResult(newTableDoc);
          setSelectedSheetTab(0);

          triggerAutoSaveToast(
            `📊 Matagumpay na na-upload ang Excel file "${file.name}"! Naipasok ang ${uniqueRows.length} rows (${finalHeaders.length} columns) sa Table Content.`
          );
        } catch (parseErr) {
          console.error('[Excel Upload Error]', parseErr);
          triggerAutoSaveToast('⚠️ Nagkaroon ng error sa pag-basa sa Excel file. Pakitiyak na maayos ang format.');
        } finally {
          setIsScanning(false);
          setScanStep('');
        }
      };

      reader.onerror = () => {
        setIsScanning(false);
        setScanStep('');
        triggerAutoSaveToast('⚠️ Nabigong basahin ang file.');
      };

      reader.readAsArrayBuffer(file);
    } catch (err) {
      console.error('[Excel Upload Error]', err);
      setIsScanning(false);
      setScanStep('');
    } finally {
      e.target.value = '';
    }
  };

  // Manual linker and uploader for unmatched PDS pictures from Excel Verification modal
  const handleManualLinkAndUploadPdsPicture = async (
    unmatchedItem: {
      id: string;
      fileName: string;
      base64?: string;
      candidateName: string;
      pdsDetectedName?: string;
      selectedApplicantToLink?: string;
    },
    chosenName: string
  ) => {
    const targetName = (
      chosenName ||
      unmatchedItem.selectedApplicantToLink ||
      unmatchedItem.pdsDetectedName ||
      unmatchedItem.candidateName ||
      ''
    ).trim();

    if (!targetName) {
      triggerAutoSaveToast('⚠️ Pumili o maglagay muna ng pangalan ng aplikante para sa larawang ito.');
      return;
    }

    if (!unmatchedItem.base64) {
      triggerAutoSaveToast('⚠️ Hindi makita ang larawan. Pakisubukan muli.');
      return;
    }

    try {
      const timestamp = Date.now();
      const optimized = await compressImageForAi(unmatchedItem.base64, 1800, 0.88);
      const newPdsItem: PdsStoredImage = {
        id: `pds_manual_${timestamp}_${Math.random().toString(36).substr(2, 6)}`,
        src: optimized || unmatchedItem.base64,
        applicantName: targetName.toUpperCase(),
        pageTitle: `PDS • ${targetName.toUpperCase()}`,
        pageNumber: storedPdsImages.length + 1,
        searchKey: `${targetName} pds pahina ${storedPdsImages.length + 1}`.toLowerCase(),
        createdAt: new Date().toISOString(),
        uploadedAt: new Date().toISOString(),
        order: storedPdsImages.length,
      };

      // Save to Firebase Firestore & IndexedDB
      await savePdsImagesToFirebaseAndIndexedDB([newPdsItem], currentAccountId);

      // Update state
      setStoredPdsImages((prev) => [...prev, newPdsItem]);

      // Move from unmatched to matched in modal
      setExcelMatchReportModal((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          matched: [
            ...prev.matched,
            {
              fileName: unmatchedItem.fileName,
              applicantName: targetName.toUpperCase(),
              pdsDetectedName: unmatchedItem.pdsDetectedName,
              tableMatchedName: targetName.toUpperCase(),
            },
          ],
          unmatched: prev.unmatched.filter((u) => u.id !== unmatchedItem.id),
        };
      });

      triggerAutoSaveToast(`⚡ Matagumpay na nai-upload ang larawan kay "${targetName.toUpperCase()}"!`);
    } catch (err) {
      console.error('[Manual Link Error]', err);
      triggerAutoSaveToast('⚠️ Nagkaroon ng problema sa pag-upload ng larawan.');
    }
  };

  // Batch upload all remaining unmatched pictures
  const handleBatchUploadAllRemainingPdsPictures = async () => {
    if (!excelMatchReportModal || excelMatchReportModal.unmatched.length === 0) return;

    const currentTableRows = (result?.sections || []).flatMap((s) => s.rows || []);
    const primaryHdrKey =
      activeTargetHeaders.find((h) => {
        const hl = h.toLowerCase();
        return hl.includes('name') || hl.includes('pangalan') || hl.includes('surname');
      }) || activeTargetHeaders[0] || 'NAME (SURNAME, FIRST NAME, MIDDLE NAME)';

    const tableApplicants: { name: string; rowIndex: number }[] = [];
    currentTableRows.forEach((r, idx) => {
      const raw = (
        r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
        r['FULL NAME'] ||
        r['PANGALAN'] ||
        r['SURNAME'] ||
        r[primaryHdrKey] ||
        ''
      ).trim();
      if (raw && isRealApplicantName(raw)) {
        tableApplicants.push({ name: raw, rowIndex: idx });
      }
    });

    const timestamp = Date.now();
    const newItems: PdsStoredImage[] = [];
    const newMatched: {
      fileName: string;
      applicantName: string;
      pdsDetectedName?: string;
      tableMatchedName?: string;
    }[] = [];

    for (let i = 0; i < excelMatchReportModal.unmatched.length; i++) {
      const u = excelMatchReportModal.unmatched[i];
      if (!u.base64) continue;

      const fallbackApplicantName =
        (u.selectedApplicantToLink && u.selectedApplicantToLink.trim()) ||
        (tableApplicants[i]?.name) ||
        (u.pdsDetectedName && isRealApplicantName(u.pdsDetectedName) ? u.pdsDetectedName : '') ||
        `APLIKANTE #${storedPdsImages.length + i + 1}`;

      const optimized = await compressImageForAi(u.base64, 1800, 0.88);
      newItems.push({
        id: `pds_batch_${timestamp}_${i}_${Math.random().toString(36).substr(2, 6)}`,
        src: optimized || u.base64,
        applicantName: fallbackApplicantName.toUpperCase(),
        pageTitle: `PDS • ${fallbackApplicantName.toUpperCase()}`,
        pageNumber: storedPdsImages.length + i + 1,
        searchKey: `${fallbackApplicantName} pds pahina ${storedPdsImages.length + i + 1}`.toLowerCase(),
        createdAt: new Date().toISOString(),
        uploadedAt: new Date().toISOString(),
        order: storedPdsImages.length + i,
      });

      newMatched.push({
        fileName: u.fileName,
        applicantName: fallbackApplicantName.toUpperCase(),
        pdsDetectedName: u.pdsDetectedName,
        tableMatchedName: fallbackApplicantName.toUpperCase(),
      });
    }

    if (newItems.length > 0) {
      await savePdsImagesToFirebaseAndIndexedDB(newItems, currentAccountId);
      setStoredPdsImages((prev) => [...prev, ...newItems]);
      setExcelMatchReportModal((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          matched: [...prev.matched, ...newMatched],
          unmatched: [],
        };
      });
      triggerAutoSaveToast(`⚡ Nai-upload ang lahat ng ${newItems.length} natitirang PDS pictures!`);
    }
  };

  // 2. EXCEL PDS PICTURE BUTTON HANDLER (Strict Conditional Upload with Intelligent Turbo Matching):
  // Bago ma-upload ang PDS picture, sisiguruhin munang may katugma itong pangalan sa Table Content!
  // Kapag nasigurong may katugmang pangalan, saka lamang ito ia-upload sa PDS Pictures button content.
  const handleExcelPdsPictureUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    // Get all applicant names currently in Table Content
    const currentTableRows = (result?.sections || []).flatMap((s) => s.rows || []);
    const primaryHdrKey =
      activeTargetHeaders.find((h) => {
        const hl = h.toLowerCase();
        return hl.includes('name') || hl.includes('pangalan') || hl.includes('surname');
      }) || activeTargetHeaders[0] || 'NAME (SURNAME, FIRST NAME, MIDDLE NAME)';

    const tableApplicants: { name: string; rowIndex: number; row: Record<string, string> }[] = [];
    currentTableRows.forEach((r, idx) => {
      const raw = (
        r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
        r['FULL NAME'] ||
        r['PANGALAN'] ||
        r['SURNAME'] ||
        r[primaryHdrKey] ||
        ''
      ).trim();
      if (raw && isRealApplicantName(raw)) {
        tableApplicants.push({ name: raw, rowIndex: idx, row: r });
      }
    });

    if (tableApplicants.length === 0) {
      triggerAutoSaveToast(
        '⚠️ Walang makitang pangalan ng aplikante sa kasalukuyang Table Content! Mag-upload muna ng Excel file o mag-scan ng table bago mag-upload ng PDS Picture.'
      );
      e.target.value = '';
      return;
    }

    try {
      setIsVerifyingExcelPdsMatch(true);
      pdsVerificationAbortRef.current = false;
      setPdsVerificationProgress({
        current: 0,
        total: files.length,
        matchedCount: 0,
        unmatchedCount: 0,
        activeFileNames: [],
      });
      setVerifyingPdsStepText(`Nagsisimula: Ihinahanda ang Turbo AI Engine para sa ${files.length} larawan...`);

      const candidateNames = tableApplicants.map((a) => a.name);

      const matchedPictures: {
        file: File;
        fileName: string;
        base64: string;
        applicantName: string;
        pdsDetectedName: string;
        tableMatchedName: string;
        matchedRowIndex: number;
      }[] = [];

      const unmatchedPictures: {
        id: string;
        fileName: string;
        base64: string;
        candidateName: string;
        pdsDetectedName: string;
        reason: string;
        selectedApplicantToLink: string;
      }[] = [];

      // Helper to read original image as Base64 when needed for final saving
      const readOriginalBase64 = (file: File): Promise<string> =>
        new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = (ev) => resolve((ev.target?.result as string) || '');
          reader.onerror = () => resolve('');
          reader.readAsDataURL(file);
        });

      // Individual file processor (Fast-Path + AI Matching)
      const processSingleFile = async (file: File, fileIndex: number) => {
        if (pdsVerificationAbortRef.current) return;

        const isHashOrUuid = isLikelyFilenameOrHash(file.name);
        const cleanName = extractNameCandidateFromFilename(file.name);
        const rawFileNameNoExt = file.name.replace(/\.[^/.]+$/, '');

        // 1. FAST-PATH: Suriin kung ang mismong pangalan ng file ay tugma na agad sa Table (kung hindi ito pure UUID / hash)
        if (!isHashOrUuid && isRealApplicantName(cleanName)) {
          const directApplicantMatch = tableApplicants.find((a) => {
            return (
              checkApplicantNamesMatch(cleanName, a.name) ||
              checkApplicantNamesMatch(rawFileNameNoExt, a.name) ||
              checkApplicantNamesMatch(file.name, a.name)
            );
          });

          if (directApplicantMatch) {
            // Instant match nang hindi na kailangang dumaan sa AI network call!
            const fullBase64 = await readOriginalBase64(file);
            if (fullBase64) {
              matchedPictures.push({
                file,
                fileName: file.name,
                base64: fullBase64,
                applicantName: directApplicantMatch.name.toUpperCase(),
                pdsDetectedName: (cleanName || rawFileNameNoExt).toUpperCase(),
                tableMatchedName: directApplicantMatch.name.toUpperCase(),
                matchedRowIndex: directApplicantMatch.rowIndex,
              });
              setPdsVerificationProgress((prev) => ({
                ...prev,
                matchedCount: prev.matchedCount + 1,
              }));
              return;
            }
          }
        }

        // 2. TURBO AI VISION PATH (Para sa mga file na camera prefix o uuid, hal. "IMG_001", "a23dbd0b-158d...")
        // Mag-generate ng malinaw na high-resolution OCR thumbnail para mabasa ang PDS Box I
        let ocrThumbnail = '';
        try {
          ocrThumbnail = await createOptimizedPdsThumbnailForOcr(file, 2048, 0.90);
        } catch (thumbErr) {
          console.warn('[PDS Optimize] Thumbnail fallback:', thumbErr);
        }

        if (!ocrThumbnail) {
          ocrThumbnail = await readOriginalBase64(file);
        }

        if (!ocrThumbnail) {
          unmatchedPictures.push({
            id: `unmatched_${Date.now()}_${fileIndex}_${Math.random().toString(36).substr(2, 6)}`,
            fileName: file.name,
            base64: '',
            candidateName: file.name,
            pdsDetectedName: 'Hindi mabasa ang file',
            reason: 'Hindi mabasa o masira ang larawan',
            selectedApplicantToLink: tableApplicants[0]?.name || '',
          });
          setPdsVerificationProgress((prev) => ({
            ...prev,
            unmatchedCount: prev.unmatchedCount + 1,
          }));
          return;
        }

        let detectedName = '';
        let matchedCandidateName: string | null = null;

        try {
          // Ipadala sa high-speed endpoint kasama ang table candidate list
          const aiResult = await extractPdsApplicantName(ocrThumbnail, candidateNames);
          detectedName = (aiResult?.applicantName || '').trim();
          matchedCandidateName = aiResult?.matchedCandidate || null;
        } catch (aiErr) {
          console.warn('[PDS Matching] AI extract error:', aiErr);
        }

        // 3. I-CROSS-CHECK SA LAHAT NG TABLE APPLICANTS
        let verifiedApplicant: { name: string; rowIndex: number; row: Record<string, string> } | null = null;

        // A. Kung tinukoy agad ng AI ang candidate mula sa listahan
        if (matchedCandidateName) {
          verifiedApplicant =
            tableApplicants.find((a) => a.name.toLowerCase() === matchedCandidateName!.toLowerCase()) ||
            tableApplicants.find((a) => checkApplicantNamesMatch(matchedCandidateName!, a.name)) ||
            null;
        }

        // B. Kung detectedName lamang ang naibalik
        if (!verifiedApplicant && detectedName && isRealApplicantName(detectedName)) {
          verifiedApplicant = tableApplicants.find((a) => checkApplicantNamesMatch(detectedName, a.name)) || null;
        }

        // C. Fallback: Subukan din ang malinis na pangalan mula sa filename kung mayroon at hindi UUID
        if (!verifiedApplicant && !isHashOrUuid && cleanName && isRealApplicantName(cleanName)) {
          verifiedApplicant = tableApplicants.find((a) => checkApplicantNamesMatch(cleanName, a.name)) || null;
        }

        // 4. KUNG NA-VERIFY NA MAY KATUGMA, KUNIN ANG ORIGINAL FULL RESOLUTION IMAGE PARA SA GALLERY
        const fullBase64 = await readOriginalBase64(file);
        if (verifiedApplicant) {
          matchedPictures.push({
            file,
            fileName: file.name,
            base64: fullBase64 || ocrThumbnail,
            applicantName: verifiedApplicant.name.toUpperCase(),
            pdsDetectedName: (detectedName || cleanName || rawFileNameNoExt).toUpperCase(),
            tableMatchedName: verifiedApplicant.name.toUpperCase(),
            matchedRowIndex: verifiedApplicant.rowIndex,
          });
          setPdsVerificationProgress((prev) => ({
            ...prev,
            matchedCount: prev.matchedCount + 1,
          }));
        } else {
          // Default selection to currently active row if clicked, or closest candidate
          const defaultLinkCandidate =
            (activeCell && tableApplicants[activeCell.rowIdx]?.name) ||
            tableApplicants[fileIndex % tableApplicants.length]?.name ||
            tableApplicants[0]?.name ||
            '';

          unmatchedPictures.push({
            id: `unmatched_${Date.now()}_${fileIndex}_${Math.random().toString(36).substr(2, 6)}`,
            fileName: file.name,
            base64: fullBase64 || ocrThumbnail,
            candidateName: cleanName || rawFileNameNoExt,
            pdsDetectedName: (detectedName || (isHashOrUuid ? 'Di pa matukoy sa OCR' : cleanName || rawFileNameNoExt)).toUpperCase(),
            reason: `Walang awtomatikong katugmang pangalan sa Table Content (Sinuri ang lahat ng ${tableApplicants.length} rows). Maaari mong i-ugnay mano-mano sa ibaba.`,
            selectedApplicantToLink: defaultLinkCandidate,
          });
          setPdsVerificationProgress((prev) => ({
            ...prev,
            unmatchedCount: prev.unmatchedCount + 1,
          }));
        }
      };

      // 5. CONCURRENT PARALLEL WORKER POOL (3 files sabay-sabay para mabilis at walang lag)
      const CONCURRENCY = Math.min(3, files.length);
      let nextIndex = 0;
      const activeFileSet = new Set<string>();

      const runWorker = async () => {
        while (nextIndex < files.length) {
          if (pdsVerificationAbortRef.current) break;
          const currentFileIdx = nextIndex++;
          const currentFile = files[currentFileIdx];

          activeFileSet.add(currentFile.name);
          setPdsVerificationProgress((prev) => ({
            ...prev,
            activeFileNames: Array.from(activeFileSet),
          }));
          setVerifyingPdsStepText(
            `[${currentFileIdx + 1}/${files.length}]: Sinusuri ang "${currentFile.name}" sa Table Content...`
          );

          try {
            await processSingleFile(currentFile, currentFileIdx);
          } catch (err) {
            console.error(`Error processing file ${currentFile.name}:`, err);
          } finally {
            activeFileSet.delete(currentFile.name);
            setPdsVerificationProgress((prev) => ({
              ...prev,
              current: Math.min(files.length, prev.current + 1),
              activeFileNames: Array.from(activeFileSet),
            }));
          }
        }
      };

      // Simulan ang mga parallel workers nang sabay-sabay
      await Promise.all(Array.from({ length: CONCURRENCY }, () => runWorker()));

      if (pdsVerificationAbortRef.current) {
        triggerAutoSaveToast('⚠️ Kinansela ang pagsusuri ng PDS pictures.');
        setIsVerifyingExcelPdsMatch(false);
        return;
      }

      // 4. Upload ONLY the verified matched pictures to PDS Picture Button Content
      if (matchedPictures.length > 0) {
        const timestamp = Date.now();
        const newPdsItems: PdsStoredImage[] = [];

        for (let idx = 0; idx < matchedPictures.length; idx++) {
          const item = matchedPictures[idx];
          // Quick compression to preserve high clarity while saving space
          const optimized = await compressImageForAi(item.base64, 1800, 0.88);
          newPdsItems.push({
            id: `pds_excel_${timestamp}_${idx}_${Math.random().toString(36).substr(2, 6)}`,
            src: optimized || item.base64,
            applicantName: item.applicantName,
            pageTitle: `PDS • ${item.applicantName}`,
            pageNumber: storedPdsImages.length + idx + 1,
            searchKey: `${item.applicantName} pds pahina ${storedPdsImages.length + idx + 1}`.toLowerCase(),
            createdAt: new Date().toISOString(),
            uploadedAt: new Date().toISOString(),
            order: storedPdsImages.length + idx,
          });
        }

        // Save to Firebase Firestore & IndexedDB
        await savePdsImagesToFirebaseAndIndexedDB(newPdsItems, currentAccountId);

        // Update React state for instant PDS Picture gallery view
        setStoredPdsImages((prev) => [...prev, ...newPdsItems]);
      }

      // 5. Open transparent verification status modal
      setExcelMatchReportModal({
        isOpen: true,
        matched: matchedPictures.map((m) => ({
          fileName: m.fileName,
          applicantName: m.applicantName,
          pdsDetectedName: m.pdsDetectedName,
          tableMatchedName: m.tableMatchedName,
          rowIndex: m.matchedRowIndex,
        })),
        unmatched: unmatchedPictures,
      });

      // Show toast summary
      if (matchedPictures.length > 0 && unmatchedPictures.length === 0) {
        triggerAutoSaveToast(
          `✅ 100% Tagumpay! Na-verify at nai-upload ang ${matchedPictures.length} PDS picture(s) sa PDS Pictures (Lahat ay may katugmang pangalan sa Table).`
        );
      } else if (matchedPictures.length > 0 && unmatchedPictures.length > 0) {
        triggerAutoSaveToast(
          `✅ Na-verify at nai-upload ang ${matchedPictures.length} may katugmang larawan. ℹ️ ${unmatchedPictures.length} larawan ang maaari mong i-ugnay mano-mano sa modal.`
        );
      } else {
        triggerAutoSaveToast(
          `ℹ️ ${unmatchedPictures.length} larawan ang nasuri: Pumili ng katugmang pangalan sa modal upang i-ugnay at i-upload.`
        );
      }
    } catch (err) {
      console.error('[Excel PDS Picture Upload Error]', err);
      triggerAutoSaveToast('⚠️ Nagkaroon ng problema sa pagsusuri ng PDS picture.');
    } finally {
      setIsVerifyingExcelPdsMatch(false);
      setVerifyingPdsStepText('');
      e.target.value = '';
    }
  };

  // Print Form Tables
  const handlePrintTables = () => {
    window.print();
  };

  const personDisplayName = result ? getDocumentPersonName(result) : 'Walang Nakasalang';

  // Filtered Database Documents for Database Modal
  const filteredDbDocs = useMemo(() => {
    if (!dbSearchQuery.trim()) return combinedDatabaseDocs;
    const q = dbSearchQuery.toLowerCase().trim();
    return combinedDatabaseDocs.filter((docItem) => {
      const pName = getDocumentPersonName(docItem).toLowerCase();
      const title = (docItem.title || '').toLowerCase();
      const docType = (docItem.documentType || '').toLowerCase();
      const id = (docItem.id || '').toLowerCase();
      const rowMatch = (docItem.sections || []).some((sec) =>
        (sec.rows || []).some((r) =>
          Object.values(r).some((val) => String(val).toLowerCase().includes(q))
        )
      );
      return pName.includes(q) || title.includes(q) || docType.includes(q) || id.includes(q) || rowMatch;
    });
  }, [combinedDatabaseDocs, dbSearchQuery]);

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans selection:bg-emerald-500 selection:text-white relative"
    >
      {/* Visual Drag and Drop Overlay for Folders and Files */}
      {isDragging && (
        <div className="fixed inset-0 z-50 bg-emerald-950/85 backdrop-blur-md flex flex-col items-center justify-center text-white border-4 border-dashed border-emerald-400 pointer-events-none p-6 text-center animate-pulse">
          <FolderPlus className="w-24 h-24 text-emerald-300 mb-4 animate-bounce" />
          <h3 className="text-3xl font-black text-white">I-drop Dito ang Folder o mga Larawan ng PDS</h3>
          <p className="text-sm text-emerald-200 max-w-lg mt-2 font-medium">
            Awtomatikong babasahin ang lahat ng larawan mula sa folder at i-e-extract sa 19-column table nang walang nawawalang larawan!
          </p>
        </div>
      )}
      {/* 1. TOP HEADER & NAVIGATION BAR */}
      <header className="sticky top-0 z-30 px-3 sm:px-5 py-2.5 bg-slate-900 text-white border-b border-slate-800 shadow-md">
        <div className="max-w-[99%] mx-auto flex flex-wrap items-center justify-between gap-2.5">
          {/* Left Brand */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => {
                if (result) {
                  saveDocumentToFirestore(result);
                }
                onBackToPortal();
              }}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 active:scale-95 transition-all flex items-center gap-1.5 text-xs font-bold"
              title="Bumalik sa Portal Front Page (Awtomatikong naka-save)"
            >
              <ArrowLeft className="w-4 h-4 text-emerald-400" />
              <span className="hidden md:inline">Portal</span>
            </button>

            <div className="h-5 w-px bg-slate-700 hidden sm:block" />

            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-black shadow text-sm">
                X
              </div>
              <div>
                <h1 className="text-xs sm:text-sm font-extrabold tracking-tight text-white flex items-center gap-1.5 leading-tight">
                  <span>AI FORM & DOCUMENT TABLE EXTRACTOR</span>
                  <span className="text-[9px] uppercase font-mono font-bold tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    EXCEL ENGINE
                  </span>
                </h1>
                <p className="text-[10px] text-slate-300 hidden sm:block">
                  Awtomatikong binabasa ang bawat Main Section, Roman Numerals, sulat-kamay, at awtomatikong naka-sync sa Firebase Database
                </p>
              </div>
            </div>
          </div>

          {/* Right Header Badges & Database Button */}
          <div className="flex items-center gap-2">
            {/* Primary Firebase Database Button with Real-Time Live Status */}
            <button
              onClick={() => setIsDatabaseModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-extrabold border border-emerald-500/50 flex items-center gap-2 transition-all shadow-md active:scale-95"
              title="Awtomatikong naka-sync sa Cloud Firebase Firestore Database"
            >
              <Database className="w-3.5 h-3.5 text-emerald-200" />
              <span>Database</span>
              <span className="px-1.5 py-0.2 rounded-md bg-emerald-950 text-emerald-200 text-[10px] font-mono font-bold">
                {firestoreDocs.length}
              </span>
              <div
                className={`w-2 h-2 rounded-full ${
                  isCloudConnected ? 'bg-emerald-300 animate-pulse' : 'bg-amber-400'
                }`}
                title={isCloudConnected ? 'Real-Time Connected sa Cloud Firestore' : 'Connecting to Firestore...'}
              />
            </button>

            <div className="hidden lg:flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800/90 text-slate-300 text-[11px] font-mono border border-slate-700">
              <User className="w-3 h-3 text-emerald-400" />
              <span className="truncate max-w-[140px] font-bold text-white">{personDisplayName}</span>
            </div>
          </div>
        </div>
      </header>

      {/* 2. COMPACT & ORGANIZED ACTION TOOLBAR */}
      <div className="bg-white border-b border-slate-300 px-2.5 sm:px-4 py-2 shadow-xs sticky top-[49px] z-20">
        <div className="max-w-[99%] mx-auto flex flex-col gap-1.5">
          {/* Top Row: AI Extraction, Upload, Scanner, Queue, Form Hint & Extract */}
          <div className="flex items-center justify-between gap-1.5 flex-wrap">
            {/* Left AI & Scan Group */}
            <div className="flex items-center gap-1.5 flex-wrap">
              {/* ✨ Text Generated Headers */}
              <button
                onClick={() => {
                  setCustomHeadersInputText(activeTargetHeaders.join(', '));
                  setIsTextGeneratedModalOpen(true);
                }}
                className="px-2.5 py-1 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-900 text-[11px] font-bold flex items-center gap-1.5 transition-all border border-purple-300 shadow-2xs active:scale-95 shrink-0"
                title="Text Generated: I-define ang mga Header ng Table at awtomatikong hahanapin ng AI Camera Scanner o Upload ang mga datos!"
              >
                <Wand2 className="w-3.5 h-3.5 text-purple-600" />
                <span>Text Generated</span>
                <span className="px-1.5 py-0.2 bg-purple-200 text-purple-900 text-[9px] font-black rounded-md font-mono">
                  Headers
                </span>
              </button>

              {/* 📋 Table List */}
              <button
                onClick={() => setIsTableListModalOpen(true)}
                className="px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-900 text-[11px] font-bold flex items-center gap-1.5 transition-all border border-blue-300 shadow-2xs active:scale-95 shrink-0"
                title="Table List: Tingnan, buksan, at burahin ang lahat ng naidagdag na mga Table"
              >
                <Table className="w-3.5 h-3.5 text-blue-600" />
                <span>Table List</span>
                <span className="px-1.5 py-0.2 bg-blue-200 text-blue-950 text-[9px] font-mono font-black rounded-md">
                  {combinedDatabaseDocs.length}
                </span>
              </button>

              {/* Hidden File Inputs */}
              <input
                ref={textGeneratedFileInputRef}
                type="file"
                multiple
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
              <input
                ref={excelUploadFileInputRef}
                type="file"
                accept=".xlsx, .xls, .csv"
                onChange={handleExcelFileUpload}
                className="hidden"
              />
              <input
                ref={excelPdsPictureFileInputRef}
                type="file"
                multiple
                accept="image/*"
                onChange={handleExcelPdsPictureUpload}
                className="hidden"
              />

              <div className="h-4 w-px bg-slate-300 hidden sm:block" />

              {/* Upload / Camera Scan */}
              <label className="relative cursor-pointer px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-800 text-[11px] font-bold flex items-center gap-1.5 transition-all shadow-2xs active:scale-98 shrink-0">
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Upload className="w-3.5 h-3.5 text-emerald-700" />
                <span>
                  {selectedImages.length > 0
                    ? `+ Larawan (${selectedImages.length} P.)`
                    : '+ Upload / Scan'}
                </span>
              </label>

              {/* Folder Upload */}
              <label
                className="relative cursor-pointer px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-900 text-[11px] font-bold flex items-center gap-1.5 transition-all shadow-2xs active:scale-98 shrink-0"
                title="Mag-upload ng buong Folder na may lamang mga larawan ng PDS"
              >
                <input
                  type="file"
                  multiple
                  {...({ webkitdirectory: '', directory: '' } as any)}
                  accept="image/*"
                  onChange={handleFolderUpload}
                  className="hidden"
                />
                <FolderPlus className="w-3.5 h-3.5 text-indigo-600" />
                <span>📁 Folder</span>
              </label>

              {/* AI Live Scanner */}
              <button
                onClick={() => setIsLiveScannerOpen(true)}
                className="px-2.5 py-1 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-[11px] font-bold flex items-center gap-1.5 transition-all shadow-2xs active:scale-95 border border-emerald-600 shrink-0"
                title="Buksan ang AI Fullscreen Mobile Camera Scanner na may Laser Line Detector"
              >
                <ScanLine className="w-3.5 h-3.5 text-emerald-200 animate-pulse" />
                <span>AI Scanner</span>
                <span className="px-1 py-0.2 bg-emerald-300 text-slate-950 text-[9px] font-black rounded-xs">LIVE</span>
              </button>

              {/* Gallery Queue */}
              <button
                onClick={() => setIsGalleryQueueOpen(true)}
                className="px-2.5 py-1 rounded-lg bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-950 text-[11px] font-bold flex items-center gap-1.5 transition-all shadow-2xs active:scale-95 shrink-0"
                title="Buksan ang Gallery Table (4-Box Queue Grid) para sa mabilis na AI Sequential Scanning"
              >
                <Package className="w-3.5 h-3.5 text-amber-700" />
                <span>Gallery</span>
                <span className="px-1.5 py-0.2 bg-amber-200 text-amber-950 text-[9px] font-mono font-black rounded-md">
                  {galleryBoxes.filter(b => !!b.imageSrc).length}/{galleryBoxes.length}
                </span>
              </button>

              {/* API Key */}
              <button
                onClick={() => setIsApiKeyModalOpen(true)}
                className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-semibold flex items-center gap-1 border border-slate-300 transition-all shrink-0"
                title="Gemini API Key Settings"
              >
                <Key className="w-3 h-3 text-amber-600" />
                <span className="hidden xl:inline">API Key</span>
              </button>

              {/* Form Title / Hint */}
              <div className="hidden lg:flex items-center gap-1 bg-slate-50 border border-slate-300 rounded-lg px-2 py-0.5">
                <Edit3 className="w-3 h-3 text-slate-400" />
                <input
                  type="text"
                  value={titleHint}
                  onChange={(e) => setTitleHint(e.target.value)}
                  placeholder="Pangalan / Hint (Opsyonal)..."
                  className="bg-transparent text-[11px] text-slate-800 placeholder-slate-400 outline-none w-36 font-medium"
                />
              </div>
            </div>

            {/* Right Primary Extract / + Idagdag Button */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => handleScanDocument()}
                disabled={isScanning || selectedImages.length === 0}
                className="px-3.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[11px] shadow-sm flex items-center gap-1.5 transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-98 shrink-0"
              >
                {isScanning ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-white" />
                    <span>Ina-extract ng AI...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-emerald-200" />
                    <span>
                      {result && result.sections && result.sections[0]?.rows?.length > 0
                        ? `+ Idagdag sa Table ${selectedImages.length > 0 ? `(${selectedImages.length} P.)` : ''}`
                        : `I-extract sa Table ${selectedImages.length > 0 ? `(${selectedImages.length} P.)` : ''}`}
                    </span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Bottom Row: Data Management, Add Row (Unang Cell), Excel, Filters & Actions */}
          <div className="flex items-center justify-between gap-1.5 flex-wrap pt-1 border-t border-slate-200/80">
            {/* Left Data Management Buttons */}
            <div className="flex items-center gap-1.5 flex-wrap">
              {/* PDS Pictures Button */}
              <button
                onClick={() => setIsPdsGalleryOpen(true)}
                className="px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border border-indigo-200 text-[11px] font-bold flex items-center gap-1.5 transition-all active:scale-95 shrink-0"
                title="Ipakita ang lahat ng inupload na PDS pictures"
              >
                <ImageIcon className="w-3.5 h-3.5 text-indigo-600" />
                <span>PDS Pictures</span>
                <span className="px-1.5 py-0.2 bg-indigo-200 text-indigo-950 text-[9px] font-mono font-black rounded-md">
                  {getPdsPictureList().length}
                </span>
              </button>

              {/* Upload Excel Button */}
              <button
                onClick={() => excelUploadFileInputRef.current?.click()}
                className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 text-[11px] font-bold flex items-center gap-1.5 transition-all active:scale-95 shrink-0 cursor-pointer"
                title="Mag-upload ng Excel file (.xlsx, .xls, .csv)"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
                <span>Upload Excel</span>
                <span className="px-1 py-0.2 bg-emerald-200 text-emerald-950 text-[9px] font-mono rounded">.xlsx</span>
              </button>

              {/* Excel PDS Picture Match Button */}
              <button
                onClick={() => excelPdsPictureFileInputRef.current?.click()}
                className="px-2.5 py-1 rounded-lg bg-cyan-50 hover:bg-cyan-100 text-cyan-950 border border-cyan-300 text-[11px] font-bold flex items-center gap-1.5 transition-all active:scale-95 shrink-0 cursor-pointer"
                title="Mag-upload ng PDS Picture na may match checking sa Table"
              >
                <Upload className="w-3.5 h-3.5 text-cyan-700" />
                <span>Excel PDS Picture</span>
                <span className="px-1 py-0.2 bg-cyan-200 text-cyan-950 text-[9px] font-mono rounded font-bold">MATCH</span>
              </button>

              {/* AI Organizer */}
              <button
                onClick={() => handleRunAiOrganizer(false)}
                disabled={isAiOrganizing || getPdsPictureList().length === 0}
                className="px-2.5 py-1 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200 text-[11px] font-bold flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-50 shrink-0"
                title="AI Organizer: Awtomatikong suriin at burahin ang anumang duplicate na mga larawan"
              >
                <Sparkles className={`w-3.5 h-3.5 text-purple-600 ${isAiOrganizing ? 'animate-spin' : ''}`} />
                <span>{isAiOrganizing ? 'Sinisuri...' : 'AI Organizer'}</span>
              </button>

              {/* ⚡ Magdagdag ng Row sa Unang Cell (Sheet 1) */}
              <button
                onClick={() => handleAddManualRow(true)}
                className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-400 text-[11px] font-black flex items-center gap-1 transition-all active:scale-95 shadow-2xs shrink-0"
                title="Magdagdag ng bagong row sa pinakaunang cell (A1) ng Sheet 1"
              >
                <Plus className="w-3.5 h-3.5 text-emerald-700" />
                <span>+ Row (Unang Cell)</span>
              </button>

              {/* Quick 1:1 Table Sync Action Button */}
              {storedPdsImages.length > 0 && (
                <button
                  onClick={handleManualPdsTableSync}
                  className="px-2 py-1 rounded-lg bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-300 text-[11px] font-bold flex items-center gap-1 transition-all active:scale-95 shrink-0"
                  title="I-sync ang Table sa PDS Pictures para 100% magkatugma ang bilang"
                >
                  <RefreshCw className="w-3 h-3 text-teal-700" />
                  <span>1:1 Sync</span>
                </button>
              )}
            </div>

            {/* Right Export, Grid, Age Filter & Delete Buttons */}
            {result && (
              <div className="flex items-center gap-1.5 flex-wrap">
                {/* Download Excel */}
                <button
                  onClick={handleExportExcel}
                  disabled={!result}
                  className="px-2.5 py-1 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-[11px] font-bold flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-50 shrink-0 shadow-2xs cursor-pointer"
                  title="I-download ang buong table bilang Excel (.xlsx)"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-200" />
                  <span>Download Excel</span>
                </button>

                {/* Copy Markdown */}
                <button
                  onClick={handleCopyMarkdown}
                  disabled={!result}
                  className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-700 text-[11px] font-semibold flex items-center gap-1 transition-all disabled:opacity-50 shrink-0"
                  title="Kopyahin sa clipboard"
                >
                  <Copy className="w-3 h-3 text-slate-600" />
                  <span className="hidden md:inline">{copied ? 'Copied!' : 'Copy'}</span>
                </button>

                {/* Print */}
                <button
                  onClick={handlePrintTables}
                  disabled={!result}
                  className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-700 text-[11px] font-semibold flex items-center gap-1 transition-all disabled:opacity-50 shrink-0"
                  title="I-print ang table"
                >
                  <Printer className="w-3 h-3 text-slate-600" />
                  <span className="hidden lg:inline">Print</span>
                </button>

                {/* Gridlines toggle */}
                <button
                  onClick={() => setShowExcelGridlines(!showExcelGridlines)}
                  className={`px-2 py-1 rounded-lg text-[11px] font-semibold border transition-all flex items-center gap-1 shrink-0 ${
                    showExcelGridlines
                      ? 'bg-emerald-50 text-emerald-900 border-emerald-300 font-bold'
                      : 'bg-slate-100 text-slate-600 border-slate-300'
                  }`}
                  title="Toggle Gridlines"
                >
                  <Grid className="w-3 h-3" />
                  <span className="hidden xl:inline">Grid: {showExcelGridlines ? 'ON' : 'OFF'}</span>
                </button>

                {/* Age Filter Segmented Pill Group */}
                {(() => {
                  const allFlatRows = result?.sections ? result.sections.flatMap((s) => s.rows || []) : [];
                  const youthCount = allFlatRows.filter((r) => {
                    const age = getRowAge(r);
                    return age !== null && age <= 24;
                  }).length;
                  const nonYouthCount = allFlatRows.filter((r) => {
                    const age = getRowAge(r);
                    return age !== null && age >= 25;
                  }).length;
                  const totalCount = allFlatRows.length;

                  return (
                    <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-300 shrink-0">
                      <button
                        onClick={() => setAgeFilter('all')}
                        className={`px-2 py-0.5 rounded-md text-[10px] font-black transition-all flex items-center gap-1 ${
                          ageFilter === 'all'
                            ? 'bg-slate-900 text-white shadow-xs'
                            : 'text-slate-700 hover:text-slate-900'
                        }`}
                        title="Ipakita ang lahat ng edad"
                      >
                        <span>Lahat</span>
                        <span className="text-[9px] font-mono opacity-80">({totalCount})</span>
                      </button>

                      <button
                        onClick={() => setAgeFilter('youth')}
                        className={`px-2 py-0.5 rounded-md text-[10px] font-black transition-all flex items-center gap-1 ${
                          ageFilter === 'youth'
                            ? 'bg-emerald-600 text-white shadow-xs'
                            : 'text-emerald-900 hover:text-emerald-950'
                        }`}
                        title="Filter: Youth (24 Pababa)"
                      >
                        <span>Youth ≤24</span>
                        <span className="text-[9px] font-mono opacity-80">({youthCount})</span>
                      </button>

                      <button
                        onClick={() => setAgeFilter('non-youth')}
                        className={`px-2 py-0.5 rounded-md text-[10px] font-black transition-all flex items-center gap-1 ${
                          ageFilter === 'non-youth'
                            ? 'bg-indigo-600 text-white shadow-xs'
                            : 'text-indigo-900 hover:text-indigo-950'
                        }`}
                        title="Filter: Non-Youth (25 Pataas)"
                      >
                        <span>Non-Youth ≥25</span>
                        <span className="text-[9px] font-mono opacity-80">({nonYouthCount})</span>
                      </button>
                    </div>
                  );
                })()}

                {/* Delete All Button */}
                <button
                  onClick={handleResetAll}
                  className="px-2 py-1 rounded-lg bg-rose-50 hover:bg-rose-600 hover:text-white text-rose-700 border border-rose-200 text-[11px] font-bold flex items-center gap-1 transition-all active:scale-95 shrink-0 cursor-pointer"
                  title="Permanenteng burahin ang lahat ng table data at mga larawan"
                >
                  <Trash2 className="w-3 h-3 text-rose-600 group-hover:text-white" />
                  <span>Delete All</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Selected Images Strip with Automatic AI Boost Icon (Optimized for Mobile & Desktop) */}
        {selectedImages.length > 0 && (
          <div className="mt-2.5 pt-2.5 pb-2 px-3 rounded-2xl bg-gradient-to-r from-emerald-50/90 via-teal-50/80 to-slate-50 border border-emerald-300 shadow-sm space-y-2">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-black text-slate-800 shrink-0 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Naka-attach ({selectedImages.length} pahina):</span>
                </span>

                {/* AUTOMATIC AI BOOST ICON & BADGE */}
                <button
                  onClick={() => setShowAiBoostModal(true)}
                  className="px-2.5 py-0.5 rounded-full bg-gradient-to-r from-emerald-600 via-teal-600 to-amber-500 text-white text-[10px] font-black shadow-xs flex items-center gap-1 hover:scale-105 active:scale-95 transition-all animate-pulse border border-emerald-400/60 cursor-pointer"
                  title="Pindutin para makita ang AI Boost Turbo Speed Engine status"
                >
                  <Zap className="w-3 h-3 text-amber-300 fill-amber-300" />
                  <span className="tracking-wide">AI BOOST: AKTIBO</span>
                  <Sparkles className="w-2.5 h-2.5 text-amber-200" />
                </button>
              </div>

              {/* Action Buttons for Attached Images */}
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => handleScanDocument()}
                  disabled={isScanning}
                  className="px-3 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shrink-0 shadow-sm flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-50 border border-emerald-500"
                  title="Mabilis na i-extract at i-scan ang lahat ng in-attach na pahina"
                >
                  <Zap className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300 animate-pulse" />
                  <span>I-scan ang {selectedImages.length} Pahina</span>
                </button>

                <button
                  onClick={() => setSelectedImages([])}
                  disabled={isScanning}
                  className="p-1 rounded-lg bg-slate-200/80 hover:bg-rose-100 hover:text-rose-700 text-slate-600 text-xs transition-colors shrink-0"
                  title="Alisin ang lahat ng naka-attach na larawan"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Carousel of image thumbnails */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5 scrollbar-thin">
              {selectedImages.filter((img) => typeof img === 'string' && img.trim().length > 0).map((img, idx) => (
                <div
                  key={idx}
                  className="relative group rounded-xl overflow-hidden border-2 border-emerald-300/80 bg-slate-200 w-14 h-16 shrink-0 shadow-xs hover:border-emerald-600 transition-all cursor-pointer"
                  onClick={() => setPreviewModalImage({ src: img, title: `Pahina ${idx + 1}`, pageNum: idx + 1 })}
                >
                  <img src={img || undefined} alt={`P.${idx + 1}`} className="w-full h-full object-cover" />
                  <span className="absolute bottom-0 inset-x-0 bg-slate-950/85 text-emerald-300 text-[9px] text-center font-mono font-black py-0.2">
                    P.{idx + 1}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRemoveImage(idx);
                    }}
                    className="absolute top-0.5 right-0.5 p-0.5 rounded-full bg-rose-600 text-white opacity-80 hover:opacity-100 transition-opacity shadow"
                    title="Alisin ang pahinang ito"
                  >
                    <X className="w-2.5 h-2.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Error message notification if any */}
        {errorMessage && (
          <div className="mt-2 p-2 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button onClick={() => setErrorMessage(null)} className="text-rose-600 font-bold text-xs">
              Isara
            </button>
          </div>
        )}

        {/* Scanning in progress banner */}
        {isScanning && (
          <div className="mt-2 p-2.5 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs flex items-center gap-2.5 animate-pulse">
            <RefreshCw className="w-4 h-4 animate-spin text-emerald-700 shrink-0" />
            <div className="font-bold">{scanStep}</div>
          </div>
        )}
      </div>

      {/* 3. MAIN SPREADSHEET WORKBOOK CONTENT (LIGHT THEME - INSTANTLY VISIBLE) */}
      <main className="flex-1 max-w-[99%] w-full mx-auto px-2 sm:px-4 py-3 space-y-3">
        {isInitialLoading && !result ? (
          /* Cloud Fetching Loading State */
          <div className="bg-white border border-slate-200 rounded-3xl p-8 sm:p-14 text-center flex flex-col items-center justify-center max-w-2xl mx-auto my-8 shadow-sm space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-200 shadow-sm">
              <RefreshCw className="w-7 h-7 animate-spin text-emerald-600" />
            </div>
            <div className="space-y-1">
              <h3 className="text-base sm:text-lg font-black text-slate-900">
                Nilo-load ang mga Form at Table mula sa Firebase Cloud...
              </h3>
              <p className="text-xs text-slate-500 max-w-md">
                Sini-sync ang pinakahuling table records at PDS pictures upang maging pareho sa lahat ng iyong mobile at desktop device.
              </p>
            </div>
          </div>
        ) : !result ? (
          /* Empty / Reset State Canvas */
          <div className="bg-white border-2 border-dashed border-slate-300 rounded-3xl p-8 sm:p-14 text-center flex flex-col items-center justify-center max-w-4xl mx-auto my-6 shadow-sm space-y-6">
            <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-200 shadow-sm">
              <FileSpreadsheet className="w-8 h-8" />
            </div>

            <div className="space-y-2 max-w-lg">
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                Walang Aktibong Nakasalang na Form o Table
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                Maaari kang mag-upload ng bagong dokumento o larawan para awtomatikong mai-extract sa 19-column spreadsheet table, o pumili mula sa mga naka-save na rekord sa Firebase Database.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-8 gap-3 w-full max-w-7xl pt-2">
              {/* 0. Upload Excel File Card */}
              <button
                onClick={() => excelUploadFileInputRef.current?.click()}
                className="p-5 rounded-2xl bg-gradient-to-br from-emerald-600 to-green-700 hover:from-emerald-500 hover:to-green-600 text-white flex flex-col items-center justify-center gap-2.5 shadow-md shadow-emerald-700/25 active:scale-98 transition-all group border border-emerald-400/50 cursor-pointer"
              >
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <FileSpreadsheet className="w-5 h-5 text-emerald-200" />
                </div>
                <div className="text-center">
                  <span className="text-xs font-black block">📊 Upload Excel</span>
                  <span className="text-[10px] text-emerald-100 font-medium">Auto-populate Table</span>
                </div>
              </button>

              {/* 1. Excel PDS Picture Card */}
              <button
                onClick={() => excelPdsPictureFileInputRef.current?.click()}
                className="p-5 rounded-2xl bg-gradient-to-br from-blue-700 via-indigo-600 to-cyan-600 hover:from-blue-600 hover:to-cyan-500 text-white flex flex-col items-center justify-center gap-2.5 shadow-md shadow-cyan-600/25 active:scale-98 transition-all group border border-cyan-400/50 cursor-pointer"
              >
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Upload className="w-5 h-5 text-cyan-200" />
                </div>
                <div className="text-center">
                  <span className="text-xs font-black block">🖼️ Excel PDS Picture</span>
                  <span className="text-[10px] text-cyan-100 font-medium">Strict Name Match</span>
                </div>
              </button>

              {/* 2. Text Generated Custom Table */}
              <button
                onClick={() => {
                  setCustomHeadersInputText(activeTargetHeaders.join(', '));
                  setIsTextGeneratedModalOpen(true);
                }}
                className="p-5 rounded-2xl bg-gradient-to-br from-violet-600 via-purple-600 to-fuchsia-700 hover:from-violet-500 hover:to-fuchsia-600 text-white flex flex-col items-center justify-center gap-2.5 shadow-md shadow-purple-600/20 active:scale-98 transition-all group border border-purple-400/50"
              >
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Wand2 className="w-5 h-5 text-yellow-300 fill-yellow-300 animate-pulse" />
                </div>
                <div className="text-center">
                  <span className="text-xs font-black block">✨ Text Generated</span>
                  <span className="text-[10px] text-purple-100 font-medium">I-define ang table headers</span>
                </div>
              </button>

              {/* 3. Upload new image */}
              <label className="p-5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white flex flex-col items-center justify-center gap-2.5 cursor-pointer shadow-md shadow-emerald-600/20 active:scale-98 transition-all group">
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Upload className="w-5 h-5 text-white" />
                </div>
                <div className="text-center">
                  <span className="text-xs font-black block">+ Mag-upload ng Larawan</span>
                  <span className="text-[10px] text-emerald-100 font-medium">Maramihang photo scan</span>
                </div>
              </label>

              {/* 4. Upload entire folder */}
              <label className="p-5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white flex flex-col items-center justify-center gap-2.5 cursor-pointer shadow-md shadow-indigo-600/20 active:scale-98 transition-all group">
                <input
                  type="file"
                  multiple
                  {...({ webkitdirectory: '', directory: '' } as any)}
                  accept="image/*"
                  onChange={handleFolderUpload}
                  className="hidden"
                />
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <FolderPlus className="w-5 h-5 text-white" />
                </div>
                <div className="text-center">
                  <span className="text-xs font-black block">📁 Mag-upload ng Folder</span>
                  <span className="text-[10px] text-indigo-100 font-medium">Folder ng PDS Pictures</span>
                </div>
              </label>

              {/* 5. AI Live Mobile Scanner Button (Placed directly beside folder upload) */}
              <button
                onClick={() => setIsLiveScannerOpen(true)}
                className="p-5 rounded-2xl bg-gradient-to-br from-emerald-600 via-teal-600 to-emerald-800 hover:from-emerald-500 hover:to-teal-500 text-white flex flex-col items-center justify-center gap-2.5 shadow-md shadow-emerald-600/30 active:scale-98 transition-all group border border-emerald-400/50"
              >
                <div className="w-10 h-10 rounded-xl bg-white/25 flex items-center justify-center group-hover:scale-110 transition-transform shadow-[0_0_15px_rgba(16,185,129,0.5)]">
                  <ScanLine className="w-5 h-5 text-white animate-pulse" />
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1">
                    <span className="text-xs font-black block">AI Scanner</span>
                    <span className="px-1.5 py-0.2 rounded bg-emerald-300 text-slate-950 font-black text-[9px]">LIVE</span>
                  </div>
                  <span className="text-[10px] text-emerald-100 font-medium">Laser line detector & Auto-Sync</span>
                </div>
              </button>

              {/* 6. Open Firebase Database */}
              <button
                onClick={() => setIsDatabaseModalOpen(true)}
                className="p-5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white flex flex-col items-center justify-center gap-2.5 shadow-sm active:scale-98 transition-all group border border-slate-700"
              >
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center group-hover:scale-110 transition-transform border border-emerald-500/30">
                  <Database className="w-5 h-5 text-emerald-400" />
                </div>
                <div className="text-center">
                  <span className="text-xs font-black block">
                    Firebase Database ({totalDatabaseRecords})
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium">Lahat ng naka-save sa cloud</span>
                </div>
              </button>

              {/* 7. Force Cloud Sync / Pull from Firebase */}
              <button
                onClick={handleManualSync}
                disabled={isManualSyncing}
                className="p-5 rounded-2xl bg-gradient-to-br from-cyan-600 via-teal-600 to-blue-700 hover:from-cyan-500 hover:to-blue-600 text-white flex flex-col items-center justify-center gap-2.5 shadow-md shadow-cyan-600/20 active:scale-98 transition-all group border border-cyan-400/50 cursor-pointer disabled:opacity-60"
              >
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <RefreshCw className={`w-5 h-5 text-cyan-200 ${isManualSyncing ? 'animate-spin' : ''}`} />
                </div>
                <div className="text-center">
                  <span className="text-xs font-black block">
                    {isManualSyncing ? 'Nagsi-sync...' : '⚡ I-sync sa Cloud'}
                  </span>
                  <span className="text-[10px] text-cyan-100 font-medium">Pull data mula sa Firebase</span>
                </div>
              </button>
            </div>

            {/* System Status / Database Wipe Button when empty table */}
            {combinedDatabaseDocs.length > 0 || storedPdsImages.length > 0 ? (
              <div className="pt-2 flex flex-col items-center gap-2">
                <button
                  onClick={handleResetAll}
                  className="px-4 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 text-xs font-black flex items-center gap-2 transition-all active:scale-95 shadow-xs cursor-pointer"
                  title="Burahin ang lahat ng data sa Firebase Database at Local Storage"
                >
                  <Trash2 className="w-4 h-4 text-rose-600" />
                  <span>Burahin ang Lahat ng Naka-save sa Database ({combinedDatabaseDocs.length} Tables, {storedPdsImages.length} Larawan)</span>
                </button>
              </div>
            ) : (
              <div className="pt-2 flex items-center justify-center">
                <span className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold shadow-2xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>100% Malinis ang System (0 Tables, 0 Larawan sa Database)</span>
                </span>
              </div>
            )}
          </div>
        ) : (
          <>
            {/* Quality summary alert if applicable */}
            {result.unreadableSummary && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-2.5 text-xs text-amber-900 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong>Tala sa Pagbasa:</strong> {result.unreadableSummary}
                </div>
              </div>
            )}

            {/* Main Excel Spreadsheet Card */}
            <div className="bg-white border border-slate-300 rounded-2xl overflow-hidden shadow-lg flex flex-col">
              {/* Top Search Bar with AI Boost Instant Deep Search Engine */}
              <div className="bg-slate-50 px-3.5 py-2.5 border-b border-slate-300 flex flex-col gap-2 text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="text-emerald-800 font-serif italic font-black select-none text-sm flex items-center gap-1">
                    <span>fx</span>
                  </div>
                  <div className="flex-1 bg-white border border-slate-300 rounded-xl px-3 py-1.5 font-mono text-slate-800 text-xs flex items-center gap-2 shadow-inner focus-within:ring-2 focus-within:ring-emerald-600 focus-within:border-emerald-600 transition-all">
                    <Search className="w-4 h-4 text-emerald-700 shrink-0" />
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="AI Boost Smart Search: Pangalan, Tirahan, Edad ('Youth', '23'), CP No., Sheet ('Sheet 1'), Header..."
                      className="w-full bg-transparent outline-none font-sans text-slate-900 text-xs font-semibold placeholder:text-slate-400"
                    />
                    {searchTerm && (
                      <button
                        onClick={() => setSearchTerm('')}
                        className="p-0.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition-colors"
                        title="Burahin ang search"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {/* AI BOOST SEARCH BADGE */}
                  <button
                    onClick={() => setShowAiBoostModal(true)}
                    className="px-2 py-1 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-900 text-[11px] font-black flex items-center gap-1 shadow-2xs hover:bg-amber-500/25 transition-all shrink-0"
                    title="AI Boost Search Engine: Sub-millisecond instant search"
                  >
                    <Zap className="w-3 h-3 text-amber-600 fill-amber-500" />
                    <span className="hidden sm:inline">AI Boost Search</span>
                  </button>
                </div>

                {/* Quick Smart Search Filters */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 pt-0.5 scrollbar-thin text-[11px]">
                  <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider shrink-0 flex items-center gap-1">
                    <Zap className="w-2.5 h-2.5 text-amber-500" />
                    <span>Quick:</span>
                  </span>
                  {[
                    { label: '⚡ Lahat', query: '' },
                    { label: '👤 Dela Cruz / Santos', query: 'Cruz' },
                    { label: '🎂 Youth (24 Pababa)', query: 'Youth' },
                    { label: '🎂 Non-Youth (25+)', query: 'Non-Youth' },
                    { label: '📍 Barangay / Lalawigan', query: 'Brgy' },
                    { label: '📱 Cell / 09', query: '09' },
                    { label: '📄 Sheet 1', query: 'Sheet 1' },
                    { label: '📄 Sheet 2', query: 'Sheet 2' },
                  ].map((preset, pIdx) => (
                    <button
                      key={pIdx}
                      onClick={() => setSearchTerm(preset.query)}
                      className={`px-2 py-0.5 rounded-lg border text-[10px] font-bold shrink-0 transition-all ${
                        searchTerm === preset.query
                          ? 'bg-emerald-600 text-white border-emerald-700 shadow-2xs'
                          : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>

                {searchTerm && result && result.sections && (
                  (() => {
                    const sheetMatches = result.sections
                      .map((sec, idx) => {
                        const matchCount = (sec.rows || []).filter((r) =>
                          checkRowMatchesSearch(sec, idx, r, searchTerm)
                        ).length;
                        return { sheetIdx: idx, count: matchCount };
                      })
                      .filter((m) => m.count > 0);

                    const totalMatches = sheetMatches.reduce((acc, m) => acc + m.count, 0);

                    return (
                      <div className="flex items-center gap-1.5 flex-wrap text-xs pt-1 border-t border-slate-200">
                        <span className="bg-amber-100 text-amber-900 border border-amber-300 px-2.5 py-1 rounded-lg text-[11px] font-extrabold font-mono flex items-center gap-1">
                          <Zap className="w-3.5 h-3.5 text-amber-700 fill-amber-500" />
                          <span>⚡ {totalMatches} Nahanap sa Kidlat na Bilis</span>
                        </span>
                        {sheetMatches.map(({ sheetIdx, count }) => (
                          <button
                            key={sheetIdx}
                            onClick={() => setSelectedSheetTab(sheetIdx)}
                            className={`px-2 py-1 rounded-lg font-extrabold text-[11px] transition-all flex items-center gap-1 border ${
                              selectedSheetTab === sheetIdx
                                ? 'bg-amber-600 text-white border-amber-700 shadow-xs ring-1 ring-amber-500'
                                : 'bg-white text-amber-900 border-amber-300 hover:bg-amber-50'
                            }`}
                          >
                            <span>Sheet {sheetIdx + 1}</span>
                            <span className="bg-amber-950/20 px-1 rounded text-[10px]">{count}</span>
                          </button>
                        ))}
                      </div>
                    );
                  })()
                )}
              </div>

              {/* TAB: SPREADSHEET GRIDS (LIGHT THEME DIRECTLY) */}
              <div className="p-3 sm:p-4 space-y-4 bg-slate-50 min-h-[50vh]">
                {ageFilter !== 'all' && (
                  <div className="bg-amber-50 border border-amber-300 rounded-xl px-3 py-2 text-xs font-bold text-amber-900 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-600" />
                      <span>
                        Naka-filter ang Table: <strong>{ageFilter === 'youth' ? 'Youth (24 Pababa)' : 'Non-Youth (25 Pataas)'}</strong>
                      </span>
                    </span>
                    <button
                      onClick={() => setAgeFilter('all')}
                      className="px-2.5 py-1 rounded-lg bg-amber-200 hover:bg-amber-300 text-amber-950 font-black text-[11px] transition-colors"
                    >
                      Ipakita ang Lahat ng Edad
                    </button>
                  </div>
                )}

                {/* Excel Workbook Sheet Tabs Bar */}
                <div className="flex items-center justify-between flex-wrap gap-2 bg-slate-200/80 p-1.5 rounded-xl border border-slate-300">
                  <div className="flex items-center gap-1 overflow-x-auto pb-0.5 max-w-full">
                    <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider px-2 font-mono shrink-0 flex items-center gap-1">
                      <Grid className="w-3.5 h-3.5 text-emerald-700" />
                      <span>Excel Sheets:</span>
                    </span>
                    {(result.sections || []).map((sec, idx) => {
                      const isSelected = selectedSheetTab === idx;
                      const rCount = (sec.rows || []).length;
                      return (
                        <button
                          key={idx}
                          onClick={() => setSelectedSheetTab(idx)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 border ${
                            isSelected
                              ? 'bg-white text-emerald-900 border-emerald-600 shadow-sm ring-1 ring-emerald-500 font-extrabold'
                              : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-white hover:text-slate-900'
                          }`}
                        >
                          <span className="w-2 h-2 rounded-full bg-emerald-600" />
                          <span>Sheet {idx + 1}</span>
                          <span className="text-[10px] opacity-75 font-mono">
                            ({rCount}/20 rows)
                          </span>
                        </button>
                      );
                    })}
                    {(result.sections || []).length > 1 && (
                      <button
                        onClick={() => setSelectedSheetTab('all')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 border ${
                          selectedSheetTab === 'all'
                            ? 'bg-emerald-800 text-white border-emerald-900 shadow-sm font-extrabold'
                            : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-white'
                        }`}
                      >
                        Ipakita ang Lahat ({(result.sections || []).length} Sheets)
                      </button>
                    )}
                  </div>

                  <div className="text-[11px] font-mono text-slate-600 px-2 font-semibold">
                    Kabuuan: {(result.sections || []).flatMap((s) => s.rows || []).length} rows
                  </div>
                </div>

                {(result.sections || [])
                  .map((sec, originalSecIdx) => ({ sec, secIdx: originalSecIdx }))
                  .filter(({ secIdx }) => selectedSheetTab === 'all' || selectedSheetTab === secIdx)
                  .map(({ sec, secIdx }) => {
                  const getColLetter = (index: number) => {
                    let letter = '';
                    let temp = index;
                    while (temp >= 0) {
                      letter = String.fromCharCode((temp % 26) + 65) + letter;
                      temp = Math.floor(temp / 26) - 1;
                    }
                    return letter;
                  };

                  const currentHeaders = sec.headers && sec.headers.length > 0 ? sec.headers : activeTargetHeaders;

                  const visibleHeaders = (() => {
                    if (!searchTerm || !searchTerm.trim()) {
                      return currentHeaders.map((h, i) => ({ h, hIdx: i }));
                    }

                    const q = searchTerm.trim().toLowerCase();
                    const isSheetPattern = /^(?:sheet|seksyon|pds sheet)?\s*#?\s*\d+$/i.test(q);
                    if (isSheetPattern) {
                      return currentHeaders.map((h, i) => ({ h, hIdx: i }));
                    }

                    const matchingHeaderIndices = currentHeaders
                      .map((h, i) => (h.toLowerCase().includes(q) ? i : -1))
                      .filter((i) => i !== -1);

                    if (matchingHeaderIndices.length > 0) {
                      return currentHeaders
                        .map((h, i) => ({ h, hIdx: i }))
                        .filter(({ hIdx }) => hIdx === 0 || matchingHeaderIndices.includes(hIdx));
                    }

                    return currentHeaders.map((h, i) => ({ h, hIdx: i }));
                  })();

                  const safeRows = sec.rows || [];

                  return (
                    <div
                      key={secIdx}
                      className="bg-white border border-slate-300 rounded-xl overflow-hidden shadow-sm space-y-0"
                    >
                      {/* Section Roman Numeral Header */}
                      <div className="bg-slate-100 border-b border-slate-300 px-3.5 py-2 flex items-center justify-between flex-wrap gap-2">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-900 text-[11px] font-mono font-bold border border-emerald-300">
                            SEKSYON {secIdx + 1}
                          </span>
                          <h3 className="text-xs sm:text-sm font-extrabold text-slate-900">
                            {sec.sectionTitle || `Sheet ${secIdx + 1}`}
                          </h3>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-[11px] text-slate-500 font-mono">
                            {safeRows.length} Rows • {currentHeaders.length} Columns
                          </span>
                          <button
                            onClick={() => handleDeleteSheet(secIdx)}
                            className="p-1 rounded bg-rose-50 hover:bg-rose-600 hover:text-white text-rose-700 text-xs font-bold transition-colors border border-rose-200 cursor-pointer"
                            title="Permanenteng burahin ang seksyong ito sa Firebase Database"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      {/* Spreadsheet Table Grid */}
                      <div className="overflow-x-auto">
                        <table
                          className={`w-full text-left text-xs border-collapse min-w-[650px] ${
                            showExcelGridlines ? 'border border-slate-300' : ''
                          }`}
                        >
                          <thead>
                            {/* Column Letters Row (A, B, C, D...) */}
                            <tr className="bg-slate-100 text-slate-600 font-mono text-[10px] border-b border-slate-300 select-none">
                              <th className="w-10 p-1 text-center bg-slate-200 border-r border-slate-300 text-slate-500 font-bold">
                                ◢
                              </th>
                              {visibleHeaders.map(({ hIdx }) => (
                                <th
                                  key={hIdx}
                                  className="p-1 text-center border-r border-slate-300 last:border-r-0 font-extrabold text-emerald-800 bg-slate-100"
                                >
                                  {getColLetter(hIdx)}
                                </th>
                              ))}
                              <th className="p-1 text-center w-12 text-slate-400 font-mono bg-slate-100">DEL</th>
                            </tr>

                            {/* Column Header Names (Field / Label / Descriptors directly under ABCD) */}
                            <tr className="bg-[#107c41] text-white border-b border-emerald-800 font-bold uppercase font-mono text-[11px]">
                              <th className="w-10 p-2.5 text-center bg-emerald-900 border-r border-emerald-700 text-emerald-200 font-mono">
                                #
                              </th>
                              {visibleHeaders.map(({ h, hIdx }) => {
                                const isFirstCol = hIdx === 0;
                                const isEditingThisHeader =
                                  editingHeader &&
                                  editingHeader.secIdx === secIdx &&
                                  editingHeader.colIdx === hIdx;

                                return (
                                  <th
                                    key={hIdx}
                                    onDoubleClick={() =>
                                      setEditingHeader({
                                        secIdx,
                                        colIdx: hIdx,
                                        oldKey: h,
                                        tempValue: h,
                                      })
                                    }
                                    title="I-double click para palitan ang pangalan ng Column Header"
                                    className={`p-2.5 border-r border-emerald-700 last:border-r-0 tracking-wide text-xs font-black whitespace-nowrap min-w-[150px] cursor-pointer group/th ${
                                      isFirstCol
                                        ? 'bg-emerald-800 text-emerald-100'
                                        : 'bg-[#107c41] text-white'
                                    }`}
                                  >
                                    {isEditingThisHeader ? (
                                      <input
                                        type="text"
                                        autoFocus
                                        value={editingHeader.tempValue}
                                        onChange={(e) =>
                                          setEditingHeader({
                                            ...editingHeader,
                                            tempValue: e.target.value,
                                          })
                                        }
                                        onBlur={() =>
                                          handleCommitHeaderEdit(
                                            secIdx,
                                            hIdx,
                                            editingHeader.oldKey,
                                            editingHeader.tempValue
                                          )
                                        }
                                        onKeyDown={(e) => {
                                          if (e.key === 'Enter') {
                                            handleCommitHeaderEdit(
                                              secIdx,
                                              hIdx,
                                              editingHeader.oldKey,
                                              editingHeader.tempValue
                                            );
                                          } else if (e.key === 'Escape') {
                                            setEditingHeader(null);
                                          }
                                        }}
                                        className="w-full bg-white text-slate-900 px-2 py-1 rounded text-xs font-bold outline-none ring-2 ring-emerald-300"
                                      />
                                    ) : (
                                      <div className="flex items-center justify-between gap-1.5">
                                        <span>
                                          {searchTerm && h.toLowerCase().includes(searchTerm.toLowerCase().trim()) ? (
                                            <mark className="bg-amber-300 text-amber-950 px-1 py-0.5 rounded border border-amber-400 font-black shadow-2xs">
                                              {h}
                                            </mark>
                                          ) : (
                                            h
                                          )}
                                        </span>
                                        <Edit3 className="w-3 h-3 text-emerald-300 opacity-0 group-hover/th:opacity-100 transition-opacity" />
                                      </div>
                                    )}
                                  </th>
                                );
                              })}
                              <th className="p-2 text-center w-12 bg-emerald-900 text-emerald-200">Aksyon</th>
                            </tr>
                          </thead>

                          <tbody className="divide-y divide-slate-200">
                            {safeRows.map((row, rIdx) => {
                              const isMatch = checkRowMatchesSearch(sec, secIdx, row, searchTerm);
                              if (!isMatch && searchTerm) return null;

                              const rowAge = getRowAge(row);
                              const isAgeMatch =
                                ageFilter === 'all'
                                  ? true
                                  : ageFilter === 'youth'
                                  ? rowAge !== null && rowAge <= 24
                                  : ageFilter === 'non-youth'
                                  ? rowAge !== null && rowAge >= 25
                                  : true;

                              if (!isAgeMatch) return null;

                              return (
                                <tr
                                  key={rIdx}
                                  className="hover:bg-emerald-50/60 transition-colors group/row"
                                >
                                  {/* Row Index */}
                                  <td className="p-2 text-center bg-slate-100/90 border-r border-slate-300 text-slate-700 font-mono font-bold select-none text-[11px]">
                                    {rIdx + 1}
                                  </td>

                                  {visibleHeaders.map(({ h, hIdx }) => {
                                    const cellVal = row[h] ?? Object.values(row)[hIdx] ?? '';
                                    const isUnreadable =
                                      String(cellVal).toLowerCase().includes('hindi matukoy') ||
                                      String(cellVal).toLowerCase().includes('unreadable');
                                    const colLetter = getColLetter(hIdx);
                                    const coord = `${colLetter}${rIdx + 1}`;
                                    const isSelected =
                                      activeCell?.secIdx === secIdx &&
                                      activeCell?.rowIdx === rIdx &&
                                      activeCell?.colIdx === hIdx;
                                    const isFirstColumn = hIdx === 0;

                                    const isDobCol = (() => {
                                      const hl = h.toLowerCase().trim();
                                      return (
                                        hl.includes('date of birth') ||
                                        hl.includes('birth') ||
                                        hl.includes('dob') ||
                                        hl.includes('birtdey') ||
                                        hl.includes('kaarawan') ||
                                        hl.includes('kapanganakan')
                                      );
                                    })();

                                    // Strictly ONLY calculate and show age & youth/non-youth on DATE OF BIRTH header column
                                    const calculatedAgeInCell = isDobCol ? calculateAgeFromDob(cellVal) : null;

                                    const isEditingThisCell =
                                      editingCell &&
                                      editingCell.secIdx === secIdx &&
                                      editingCell.rowIdx === rIdx &&
                                      editingCell.colKey === h;

                                    const isCellMatching =
                                      searchTerm.trim().length > 0 &&
                                      String(cellVal).toLowerCase().includes(searchTerm.toLowerCase().trim());

                                    return (
                                      <td
                                        key={hIdx}
                                        onClick={() =>
                                          setActiveCell({
                                            secIdx,
                                            rowIdx: rIdx,
                                            colIdx: hIdx,
                                            colLetter,
                                            colName: h,
                                            value: String(cellVal),
                                            cellCoord: coord,
                                          })
                                        }
                                        onDoubleClick={() => {
                                          setActiveCell({
                                            secIdx,
                                            rowIdx: rIdx,
                                            colIdx: hIdx,
                                            colLetter,
                                            colName: h,
                                            value: String(cellVal),
                                            cellCoord: coord,
                                          });
                                          setEditingCell({
                                            secIdx,
                                            rowIdx: rIdx,
                                            colKey: h,
                                            tempValue: String(cellVal),
                                          });
                                        }}
                                        title="I-double click para i-edit ang cell na ito (Awtomatikong magse-save)"
                                        className={`p-2.5 border-r border-slate-200 last:border-r-0 align-middle cursor-cell transition-all whitespace-nowrap min-w-[150px] relative ${
                                          isCellMatching
                                            ? 'bg-amber-200 text-amber-950 font-black ring-2 ring-amber-400 border border-amber-400 shadow-xs'
                                            : isSelected
                                            ? 'bg-emerald-100/80 ring-2 ring-emerald-600 ring-inset font-bold text-slate-950 shadow-inner'
                                            : isFirstColumn
                                            ? 'bg-slate-50/60 font-bold text-slate-900'
                                            : 'text-slate-800 font-medium'
                                        }`}
                                      >
                                        {isEditingThisCell ? (
                                          <input
                                            type="text"
                                            autoFocus
                                            value={editingCell.tempValue}
                                            onFocus={(e) => e.target.select()}
                                            onChange={(e) =>
                                              setEditingCell({
                                                ...editingCell,
                                                tempValue: e.target.value,
                                              })
                                            }
                                            onBlur={() => {
                                              handleCommitCellEdit(
                                                secIdx,
                                                rIdx,
                                                h,
                                                editingCell.tempValue
                                              );
                                            }}
                                            onKeyDown={(e) => {
                                              if (e.key === 'Enter' || e.key === 'Tab') {
                                                e.preventDefault();
                                                handleCommitCellEdit(
                                                  secIdx,
                                                  rIdx,
                                                  h,
                                                  editingCell.tempValue
                                                );
                                              } else if (e.key === 'Escape') {
                                                setEditingCell(null);
                                              }
                                            }}
                                            className="w-full bg-white text-slate-950 px-2 py-1 border-2 border-emerald-600 rounded shadow-md text-xs font-mono font-bold outline-none ring-2 ring-emerald-400 min-w-[120px]"
                                          />
                                        ) : isUnreadable ? (
                                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
                                            <AlertTriangle className="w-3 h-3 text-amber-700" />
                                            <span>Hindi Matukoy</span>
                                          </span>
                                        ) : cellVal.toLowerCase() === 'naka-check' ? (
                                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-900 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-400">
                                            <CheckCircle2 className="w-3 h-3 text-emerald-700" />
                                            <span>Naka-check</span>
                                          </span>
                                        ) : cellVal.toLowerCase() === 'hindi naka-check' ? (
                                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full border border-slate-300">
                                            <XCircle className="w-3 h-3 text-slate-500" />
                                            <span>Hindi Naka-check</span>
                                          </span>
                                        ) : calculatedAgeInCell !== null ? (
                                          <div className="flex items-center justify-between gap-2.5 w-full">
                                            <span className="font-mono text-slate-900 font-semibold">
                                              {searchTerm && cellVal && cellVal.toLowerCase().includes(searchTerm.toLowerCase()) ? (
                                                (() => {
                                                  const text = String(cellVal);
                                                  const q = searchTerm;
                                                  const idx = text.toLowerCase().indexOf(q.toLowerCase());
                                                  if (idx === -1) return text;
                                                  const b = text.substring(0, idx);
                                                  const m = text.substring(idx, idx + q.length);
                                                  const a = text.substring(idx + q.length);
                                                  return (
                                                    <>
                                                      {b}
                                                      <mark className="bg-amber-200 text-amber-950 font-bold px-0.5 rounded shadow-2xs border border-amber-300">
                                                        {m}
                                                      </mark>
                                                      {a}
                                                    </>
                                                  );
                                                })()
                                              ) : (
                                                cellVal || '-'
                                              )}
                                            </span>
                                            <span
                                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-black font-mono border shadow-2xs shrink-0 select-none ${
                                                calculatedAgeInCell <= 24
                                                  ? 'bg-emerald-100 text-emerald-950 border-emerald-300 ring-1 ring-emerald-400/50'
                                                  : 'bg-indigo-100 text-indigo-950 border-indigo-300 ring-1 ring-indigo-400/50'
                                              }`}
                                              title={`Edad ngayon: ${calculatedAgeInCell} taong gulang (${calculatedAgeInCell <= 24 ? 'Youth' : 'Non-Youth'})`}
                                            >
                                              <User className="w-3 h-3 text-slate-600" />
                                              <span>{calculatedAgeInCell} yrs old</span>
                                              <span
                                                className={`px-1 py-0.2 rounded text-[9px] font-black text-white ${
                                                  calculatedAgeInCell <= 24 ? 'bg-emerald-700' : 'bg-indigo-700'
                                                }`}
                                              >
                                                {calculatedAgeInCell <= 24 ? 'Youth' : 'Non-Youth'}
                                              </span>
                                            </span>
                                          </div>
                                        ) : (
                                          <span className="font-mono text-slate-900">
                                            {searchTerm && cellVal && cellVal.toLowerCase().includes(searchTerm.toLowerCase()) ? (
                                              (() => {
                                                const text = String(cellVal);
                                                const q = searchTerm;
                                                const idx = text.toLowerCase().indexOf(q.toLowerCase());
                                                if (idx === -1) return text;
                                                const b = text.substring(0, idx);
                                                const m = text.substring(idx, idx + q.length);
                                                const a = text.substring(idx + q.length);
                                                return (
                                                  <>
                                                    {b}
                                                    <mark className="bg-amber-200 text-amber-950 font-bold px-0.5 rounded shadow-2xs border border-amber-300">
                                                      {m}
                                                    </mark>
                                                    {a}
                                                  </>
                                                );
                                              })()
                                            ) : (
                                              cellVal
                                            )}
                                          </span>
                                        )}
                                      </td>
                                    );
                                  })}

                                  {/* Row Delete Button */}
                                  <td className="p-1.5 text-center align-middle bg-white">
                                    <button
                                      onClick={() => handleDeleteSingleRow(secIdx, rIdx)}
                                      className="p-1.5 rounded-lg text-rose-500 hover:text-white hover:bg-rose-600 transition-all cursor-pointer active:scale-95 shadow-2xs hover:shadow-rose-500/30"
                                      title="Burahin ang row na ito (Permanenteng mabubura sa Firebase Cloud Database at magpapa-pop up ng Deleted Permanently)"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>

                      {/* Table Footer: Add Row buttons and Row Counter */}
                      <div className="bg-slate-50 border-t border-slate-200 px-3.5 py-2 flex items-center justify-between flex-wrap gap-2 text-xs">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleAddManualRow(true)}
                            className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold flex items-center gap-1.5 shadow-2xs active:scale-95 transition-all text-xs"
                            title="Magdagdag ng panibagong blankong row sa pinakaunang cell (A1) ng Sheet 1"
                          >
                            <Plus className="w-3.5 h-3.5 text-white" />
                            <span>+ Row sa Unang Cell (A1)</span>
                          </button>

                          <button
                            onClick={() => handleAddManualRow(false)}
                            className="px-3 py-1.5 rounded-lg bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 font-bold flex items-center gap-1.5 shadow-2xs active:scale-95 transition-all text-xs"
                            title="Magdagdag ng panibagong row sa dulo ng listahan"
                          >
                            <Plus className="w-3.5 h-3.5 text-slate-600" />
                            <span>+ Row sa Dulo</span>
                          </button>
                        </div>

                        <div className="text-[11px] text-slate-500 font-mono flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                          <span>Awtomatikong naka-sync sa Firebase • {sec.rows.length} rows</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        )}
      </main>

      {/* 4. FIREBASE FIRESTORE DATABASE MODAL */}
      {isDatabaseModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
          <div className="w-full max-w-4xl bg-white rounded-3xl border border-slate-300 overflow-hidden flex flex-col shadow-2xl max-h-[92vh] space-y-0">
            {/* Modal Header */}
            <div className="p-5 sm:p-6 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-600/30 text-emerald-400 border border-emerald-500/40 flex items-center justify-center shadow">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base sm:text-lg font-black tracking-tight text-white">
                      Firebase Cloud Database
                    </h3>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold border border-emerald-500/30 flex items-center gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span>Firestore Live</span>
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">
                    Awtomatikong naka-save ang bawat form scan at double-click table edits sa Cloud Firestore
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsDatabaseModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="Isara ang database"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Sub-header info banner & Search Bar */}
            <div className="p-4 sm:p-5 bg-slate-50 border-b border-slate-200 space-y-3">
              {/* Cloud Info Bar */}
              <div className="flex items-center justify-between flex-wrap gap-2 text-xs">
                <div className="flex items-center gap-2 text-slate-600">
                  <span className="font-mono text-[11px] bg-slate-200/80 px-2 py-0.5 rounded text-slate-800 font-bold">
                    Collection: extracted_documents
                  </span>
                  <span className="hidden md:inline">•</span>
                  <span className="text-emerald-800 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Auto-sync Active</span>
                  </span>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-emerald-800 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Auto-sync Active</span>
                  </span>
                  <button
                    onClick={handleManualSync}
                    disabled={isManualSyncing}
                    className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-[11px] font-black shadow flex items-center gap-1 border border-cyan-400/40 transition-all active:scale-95 disabled:opacity-60"
                    title="I-force sync ang buong cloud database sa iyong mobile o computer device"
                  >
                    <RefreshCw className={`w-3 h-3 text-cyan-200 ${isManualSyncing ? 'animate-spin' : ''}`} />
                    <span>{isManualSyncing ? 'Nagsi-sync...' : '⚡ Sync Data Ngayon'}</span>
                  </button>
                </div>
              </div>

              {/* Real-time Incremental Search */}
              <div className="relative">
                <Search className="w-4 h-4 text-emerald-700 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={dbSearchQuery}
                  onChange={(e) => setDbSearchQuery(e.target.value)}
                  placeholder="Maghanap ayon sa pangalan ng aplikante, titulo ng form, o ID..."
                  className="w-full bg-white border border-slate-300 rounded-xl pl-10 pr-10 py-2.5 text-xs text-slate-900 placeholder-slate-400 outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 transition-all font-medium shadow-xs"
                />
                {dbSearchQuery && (
                  <button
                    onClick={() => setDbSearchQuery('')}
                    className="absolute right-3 top-2.5 p-1 rounded-lg text-slate-400 hover:text-slate-600 text-xs"
                    title="Linisin ang search"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Document Records Cards Body */}
            <div className="p-4 sm:p-6 overflow-y-auto flex-1 max-h-[55vh] space-y-3 bg-slate-100/60">
              {combinedDatabaseDocs.length === 0 ? (
                <div className="text-center py-16 space-y-4 bg-white rounded-3xl border border-slate-200 p-8 shadow-xs">
                  <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center mx-auto border border-emerald-200">
                    <Database className="w-7 h-7" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-bold text-slate-900">Walang Nakitang Rekord sa Database</p>
                    <p className="text-xs text-slate-500 max-w-sm mx-auto">
                      Kapag nag-scan ka ng form o nag-edit ng cell sa table, awtomatiko itong mapapasok at mase-save sa Firebase Database.
                    </p>
                  </div>
                  {result && (
                    <button
                      onClick={() => {
                        saveDocumentToFirestore(result);
                        triggerAutoSaveToast('Na-save ang kasalukuyang table sa Firestore!');
                      }}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow transition-all"
                    >
                      I-save ang Kasalukuyang Form sa Database
                    </button>
                  )}
                </div>
              ) : filteredDbDocs.length === 0 ? (
                <div className="text-center py-12 space-y-2 bg-white rounded-3xl border border-slate-200 p-6">
                  <p className="text-xs font-bold text-emerald-800">Walang tumugmang dokumento</p>
                  <p className="text-xs text-slate-500">
                    Walang nakitang rekord na naglalaman ng &ldquo;<strong>{dbSearchQuery}</strong>&rdquo;.
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto rounded-xl border border-slate-200">
                  <table className="w-full text-left text-xs whitespace-nowrap bg-white">
                    <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                      <tr>
                        <th className="px-4 py-3 font-extrabold">#</th>
                        <th className="px-4 py-3 font-extrabold">Pangalan (Name)</th>
                        <th className="px-4 py-3 font-extrabold">Petsa ng Kapanganakan</th>
                        <th className="px-4 py-3 font-extrabold">Form Tag</th>
                        <th className="px-4 py-3 font-extrabold">Aksyon</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(() => {
                        const allRows: any[] = [];
                        let absoluteIndex = 1;
                        filteredDbDocs.forEach((docItem) => {
                          (docItem.sections || []).forEach((sec, sIdx) => {
                            (sec.rows || []).forEach((r, rIdx) => {
                              allRows.push({
                                docItem,
                                section: sec,
                                row: r,
                                rIdx,
                                sIdx,
                                absoluteIndex: absoluteIndex++
                              });
                            });
                          });
                        });
                        
                        return allRows.map((item) => {
                          const { docItem, row, absoluteIndex, sIdx, rIdx } = item;
                          const rawName = row['NAME (SURNAME, FIRST NAME, MIDDLE NAME)']?.trim() || docItem.detectedPersonName || 'HINDI MATUKOY';
                          const rawDOB = row['DATE OF BIRTH (MM, DD, YYYY)']?.trim() || row['DATE OF BIRTH']?.trim() || '-';
                          const isCurrentlyActive = result && result.id === docItem.id;
                          
                          return (
                            <tr key={`db-row-${docItem.id}-${sIdx}-${rIdx}`} className={`hover:bg-emerald-50/50 transition-colors ${isCurrentlyActive ? 'bg-emerald-50/20' : ''}`}>
                              <td className="px-4 py-3 font-mono text-slate-400">{absoluteIndex}</td>
                              <td className="px-4 py-3 font-bold text-emerald-900">
                                {rawName}
                                {isCurrentlyActive && (
                                  <span className="ml-2 px-1.5 py-0.5 rounded text-[9px] bg-emerald-100 text-emerald-700 font-bold uppercase tracking-wide">
                                    Aktibo
                                  </span>
                                )}
                              </td>
                              <td className="px-4 py-3 text-slate-600">{rawDOB}</td>
                              <td className="px-4 py-3 text-slate-500 font-mono text-[10px] truncate max-w-[150px]" title={docItem.title || docItem.documentType}>
                                {docItem.title || docItem.documentType}
                              </td>
                              <td className="px-4 py-3">
                                <div className="flex items-center gap-2">
                                  <button
                                    onClick={() => {
                                      setResult(docItem);
                                      if (docItem.imagesBase64 && docItem.imagesBase64.length > 0) {
                                        setSelectedImages(docItem.imagesBase64);
                                      }
                                      setIsDatabaseModalOpen(false);
                                      triggerAutoSaveToast(`Na-load ang rekord ni "${rawName}" sa table!`);
                                    }}
                                    className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-[10px] hover:bg-emerald-700 flex items-center gap-1 shadow-sm"
                                  >
                                    <FileCheck className="w-3 h-3" />
                                    Load Document
                                  </button>
                                  
                                  <button
                                    onClick={async () => {
                                      // Permanently purge this row across table, Firestore, history & pictures
                                      await handleDeleteDatabaseDocRow(docItem, sIdx, rIdx);
                                    }}
                                    className="p-1.5 rounded-lg text-rose-500 bg-rose-50 hover:bg-rose-600 hover:text-white border border-rose-200 transition-all cursor-pointer active:scale-95 shadow-2xs"
                                    title="Burahin ang Row (Permanenteng mabubura sa Firebase Database)"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        });
                      })()}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Modal Bottom Bar */}
            <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    if (result) {
                      saveDocumentToFirestore(result);
                      triggerAutoSaveToast('Na-save sa Cloud Firestore!');
                    }
                  }}
                  disabled={!result}
                  className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow transition-all disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>I-save ang Kasalukuyang Table</span>
                </button>

                {firestoreDocs.length > 0 && (
                  <button
                    onClick={() => {
                      handleExecuteDeleteAll();
                    }}
                    className="px-3.5 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all active:scale-95"
                    title="Permanenteng burahin ang lahat ng dokumento sa Firebase Database"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Burahin Lahat ng Data sa Database</span>
                  </button>
                )}
              </div>

              <button
                onClick={() => setIsDatabaseModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold transition-all"
              >
                Isara
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4b. DIRECT DEVICE-TO-DEVICE SYNC CODE & BACKUP MODAL */}
      {isSyncCodeModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200">
          <div className="w-full max-w-xl bg-white rounded-3xl border border-purple-200 overflow-hidden flex flex-col shadow-2xl space-y-0 max-h-[90vh]">
            {/* Header */}
            <div className="p-5 bg-gradient-to-r from-slate-900 via-purple-950 to-slate-900 text-white flex items-center justify-between border-b border-purple-900">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-purple-600/30 text-purple-300 border border-purple-500/40 flex items-center justify-center shadow">
                  <Share2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black tracking-tight text-white flex items-center gap-2">
                    <span>📲 Direct Device Sync & Backup Code</span>
                  </h3>
                  <p className="text-xs text-purple-200">
                    Ilipat agad ang lahat ng table rows at PDS pictures sa anumang phone o computer
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsSyncCodeModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-xs text-slate-700 bg-slate-50/50">
              {/* Step 1: Export from this device */}
              <div className="p-4 rounded-2xl bg-white border border-purple-200 space-y-3 shadow-xs">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-purple-100 text-purple-800 flex items-center justify-center text-xs font-mono font-black">1</span>
                    <span>Mula sa Computer / Device na Ito:</span>
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                    {totalDatabaseRecords} Rows Ready
                  </span>
                </div>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  I-click ang button sa ibaba para kopyahin ang <strong>Device Sync Code</strong>. I-paste at i-send sa iyong Messenger, Viber, o Notes para mabuksan sa iyong Mobile Phone!
                </p>
                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    onClick={handleExportSyncCode}
                    className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 text-white font-extrabold flex items-center gap-2 shadow-md active:scale-95 transition-all text-xs"
                  >
                    <Copy className="w-4 h-4 text-purple-200" />
                    <span>📋 Kopyahin ang Sync Code (Copy)</span>
                  </button>
                  <button
                    onClick={() => {
                      const backupData = {
                        activeTable: result,
                        history: savedHistory,
                        pdsImages: storedPdsImages,
                        exportedAt: new Date().toISOString(),
                        appName: 'AI FORM EXTRACTOR',
                      };
                      downloadBackupFile(JSON.stringify(backupData));
                    }}
                    className="px-3.5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold border border-slate-300 flex items-center gap-1.5 transition-all text-xs"
                  >
                    <Download className="w-3.5 h-3.5 text-slate-600" />
                    <span>📁 Download Backup JSON</span>
                  </button>
                </div>
              </div>

              {/* Step 2: Import into this device */}
              <div className="p-4 rounded-2xl bg-white border border-indigo-200 space-y-3 shadow-xs">
                <span className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-800 flex items-center justify-center text-xs font-mono font-black">2</span>
                  <span>Ilipat sa Mobile Phone / Device na Ito:</span>
                </span>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  Kung kinopya mo ang Sync Code mula sa ibang device, i-paste ito rito at pindutin ang <strong>I-sync</strong>.
                </p>
                <textarea
                  rows={3}
                  value={syncCodeInput}
                  onChange={(e) => setSyncCodeInput(e.target.value)}
                  placeholder="I-paste dito ang kinopyang Sync Code o JSON text..."
                  className="w-full p-3 rounded-xl border border-slate-300 font-mono text-[11px] bg-slate-50 focus:bg-white focus:border-indigo-600 focus:ring-1 focus:ring-indigo-600 outline-none transition-all"
                />
                <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                  <button
                    onClick={() => handleImportSyncCode()}
                    className="px-4 py-2.5 rounded-xl bg-indigo-700 hover:bg-indigo-600 text-white font-extrabold flex items-center gap-2 shadow-md active:scale-95 transition-all text-xs"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-indigo-200" />
                    <span>⚡ I-sync at I-load sa Phone/Device na Ito</span>
                  </button>

                  <label className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-300 cursor-pointer flex items-center gap-1.5 transition-all">
                    <Upload className="w-3.5 h-3.5 text-slate-600" />
                    <span>📁 Upload Backup JSON File</span>
                    <input
                      type="file"
                      accept=".json"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (event) => {
                            const content = event.target?.result as string;
                            if (content) handleImportSyncCode(content);
                          };
                          reader.readAsText(file);
                        }
                      }}
                    />
                  </label>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
              <span className="text-[11px] text-slate-500 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>100% Offline & Online Transfer Compatible</span>
              </span>
              <button
                onClick={() => setIsSyncCodeModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold transition-all"
              >
                Isara
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. NAKALIPAS NA SCANS (DRAWER / MODAL WITH SEARCH & PHOTO GALLERY) */}
      {isHistoryOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex justify-center sm:justify-end animate-in fade-in duration-200">
          <div className="w-full max-w-2xl bg-white border-l border-slate-300 p-6 flex flex-col justify-between overflow-y-auto space-y-5 h-full shadow-2xl">
            <div className="space-y-4">
              {/* Modal Header */}
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center border border-emerald-300">
                    <History className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-extrabold text-slate-900">Nakalipas na Scanned Documents</h3>
                    <p className="text-xs text-slate-500">I-click ang alinman para buksan sa live Excel table</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsHistoryOpen(false)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                  title="Isara ang history"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Real-time Incremental Search */}
              <div className="space-y-2">
                <div className="relative">
                  <Search className="w-4 h-4 text-emerald-700 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    value={historySearchQuery}
                    onChange={(e) => setHistorySearchQuery(e.target.value)}
                    placeholder="I-type ang pangalan o letra (hal. Juan, Dela Cruz)..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-10 pr-10 py-2.5 text-xs text-slate-900 placeholder-slate-400 outline-none focus:border-emerald-600 focus:bg-white transition-all font-medium shadow-inner"
                  />
                  {historySearchQuery && (
                    <button
                      onClick={() => setHistorySearchQuery('')}
                      className="absolute right-3 top-2.5 p-1 rounded-lg text-slate-400 hover:text-slate-600 text-xs"
                      title="Linisin ang search"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <div className="flex items-center justify-between text-[11px] px-1 text-slate-500">
                  <span>
                    Kabuuan: <strong className="text-slate-800 font-mono">{savedHistory.length}</strong> nakaraang scan
                  </span>
                  {historySearchQuery && (
                    <span className="text-emerald-700 font-bold">
                      {filteredHistory.length} ang tumutugma kay &ldquo;{historySearchQuery}&rdquo;
                    </span>
                  )}
                </div>
              </div>

              {/* History Document Cards List */}
              {savedHistory.length === 0 ? (
                <div className="text-center py-16 space-y-3 bg-slate-50 rounded-2xl border border-slate-200 p-8">
                  <div className="w-12 h-12 rounded-2xl bg-slate-200 text-slate-500 flex items-center justify-center mx-auto">
                    <FileText className="w-6 h-6" />
                  </div>
                  <p className="text-sm font-bold text-slate-800">Walang Naka-save na Scan History</p>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    Kapag nag-upload ka ng larawan ng form at nag-scan, awtomatikong maiipon dito ang bawat scan.
                  </p>
                </div>
              ) : filteredHistory.length === 0 ? (
                <div className="text-center py-12 space-y-2 bg-slate-50 rounded-2xl border border-slate-200 p-6">
                  <p className="text-xs font-bold text-emerald-800">Walang tumugmang pangalan</p>
                  <p className="text-xs text-slate-500">
                    Walang nakitang scan na naglalaman ng &ldquo;<strong>{historySearchQuery}</strong>&rdquo;.
                  </p>
                </div>
              ) : (
                <div className="space-y-3 max-h-[58vh] overflow-y-auto pr-1">
                  {filteredHistory.map((h, idx) => {
                    const personName = getDocumentPersonName(h);
                    const photos = h.imagesBase64 && h.imagesBase64.length > 0 ? h.imagesBase64 : [];

                    return (
                      <div
                        key={h.id || idx}
                        className="p-4 rounded-2xl bg-white border border-slate-300 hover:border-emerald-500 hover:shadow-md transition-all space-y-3 shadow-xs"
                      >
                        <div className="flex items-start justify-between gap-3 flex-wrap">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-emerald-100 text-emerald-900 border border-emerald-300 text-xs font-extrabold">
                                <User className="w-3.5 h-3.5 text-emerald-700" />
                                <span>{personName}</span>
                              </span>
                              <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-mono text-[10px] border border-slate-200">
                                {h.totalPages || photos.length || 1} Pahina
                              </span>
                            </div>
                            <h4 className="text-xs font-bold text-slate-900 mt-1">
                              {h.title || h.documentType}
                            </h4>
                            <p className="text-[11px] text-slate-500 font-mono">
                              {new Date(h.scannedAt).toLocaleString()}
                            </p>
                          </div>

                          <button
                            onClick={async (e) => {
                              e.stopPropagation();
                              await deleteDocumentFromFirestore(h.id);
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                            title="Permanenteng burahin ang scan record sa Firebase Database"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Pictures Preview Reel if images exist */}
                        {photos.length > 0 && (
                          <div className="space-y-1">
                            <div className="flex items-center justify-between text-[10px] text-slate-500 font-medium">
                              <span>Mga Larawan ({photos.length}):</span>
                              <span>I-click para ma-zoom</span>
                            </div>
                            <div className="grid grid-cols-4 gap-2">
                              {photos.map((imgSrc, pIdx) => (
                                <div
                                  key={pIdx}
                                  onClick={() =>
                                    setPreviewModalImage({
                                      src: imgSrc,
                                      title: personName,
                                      pageNum: pIdx + 1,
                                    })
                                  }
                                  className="group/img relative aspect-[3/4] rounded-lg overflow-hidden bg-slate-100 border border-slate-300 hover:border-emerald-500 cursor-pointer shadow-xs"
                                >
                                  <img
                                    src={imgSrc || undefined}
                                    alt={`P.${pIdx + 1}`}
                                    className="w-full h-full object-cover"
                                  />
                                  <div className="absolute inset-0 bg-slate-950/30 opacity-0 group-hover/img:opacity-100 flex items-center justify-center transition-opacity">
                                    <ZoomIn className="w-4 h-4 text-white" />
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                          <span className="text-[11px] text-slate-500 font-mono">
                            {h.sections ? h.sections.length : 0} Seksyon
                          </span>
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => {
                                setResult(h);
                                if (h.imagesBase64 && h.imagesBase64.length > 0) {
                                  setSelectedImages(h.imagesBase64);
                                }
                                setIsHistoryOpen(false);
                              }}
                              className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1 shadow-sm transition-all"
                            >
                              <FileCheck className="w-3.5 h-3.5" />
                              <span>Buksan sa Table</span>
                            </button>
                            <button
                              onClick={() => {
                                if (window.confirm(`Burahin ang scan history record "${h.title || h.documentType || 'Dokumento'}"?`)) {
                                  deleteDocumentFromFirestore(h.id);
                                }
                              }}
                              className="p-1.5 rounded-xl bg-rose-50 hover:bg-rose-600 hover:text-white text-rose-700 text-xs font-bold border border-rose-200 transition-colors"
                              title="Burahin ang scan record na ito"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Bottom Clear All */}
            {savedHistory.length > 0 && (
              <div className="pt-3 border-t border-slate-200 flex items-center justify-between gap-3">
                <span className="text-[11px] text-slate-500">Naka-save sa lokal na browser</span>
                <button
                  onClick={() => {
                    handleExecuteDeleteAll();
                  }}
                  className="px-3 py-1.5 bg-rose-50 hover:bg-rose-600 hover:text-white text-rose-700 rounded-xl text-xs font-bold border border-rose-200 transition-all flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Burahin Lahat</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 5. LIGHTBOX MODAL PARA SA PHOTO VIEW */}
      {previewModalImage && (
        <div
          onClick={() => setPreviewModalImage(null)}
          className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-4xl w-full max-h-[92vh] bg-slate-900 text-white rounded-3xl border border-slate-700 overflow-hidden flex flex-col shadow-2xl space-y-3 p-4 sm:p-5"
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 flex-wrap gap-2">
              <span className="text-sm font-black text-white flex items-center gap-2">
                <User className="w-4.5 h-4.5 text-emerald-400" />
                <span>{previewModalImage.title} {previewModalImage.pageNum ? `(Pahina ${previewModalImage.pageNum})` : ''}</span>
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const title = `${previewModalImage.title} ${previewModalImage.pageNum ? `(Pahina ${previewModalImage.pageNum})` : ''}`;
                    setFullScreenPdsImage({
                      id: 'lightbox-img',
                      src: previewModalImage.src,
                      applicantName: title,
                      pageTitle: 'PDS Image View',
                      zoom: 1,
                      rotation: 0,
                    });
                    setPreviewModalImage(null);
                  }}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black flex items-center gap-1.5 shadow-md transition-all border border-indigo-400/30"
                  title="Tingnan sa 100% Fullscreen PC View"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span>100% Fullscreen View</span>
                </button>

                <button
                  onClick={() => setPreviewModalImage(null)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Scrollable Container showing FULL HEIGHT of PDS picture without clipping */}
            <div className="flex-1 overflow-y-auto bg-slate-950 rounded-2xl p-3 sm:p-5 flex flex-col items-center justify-start min-h-[60vh] max-h-[75vh] border border-slate-800 shadow-inner custom-scrollbar">
              <img
                src={previewModalImage.src || undefined}
                alt={previewModalImage.title}
                className="w-full max-w-3xl h-auto object-contain rounded-xl shadow-2xl border border-slate-800 my-auto"
              />
            </div>

            {/* Modal Bottom Helper Bar */}
            <div className="flex items-center justify-between text-xs text-slate-400 pt-1 flex-wrap gap-2 border-t border-slate-800/80">
              <span className="text-[11px] font-medium text-emerald-400 flex items-center gap-1">
                <span>✓ Naka-scroll ang buong larawan. I-scroll pababa para makita ang iba pang bahagi.</span>
              </span>
              <a
                href={previewModalImage.src}
                download={getPdsPictureFileName(previewModalImage.title)}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold flex items-center gap-1.5 shadow transition-all"
                title={`I-download bilang "${getPdsPictureFileName(previewModalImage.title)}"`}
              >
                <Download className="w-3.5 h-3.5" />
                <span>I-download</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* 6. FLOATING AUTO-SAVE TOAST NOTIFICATION */}
      {autoSaveNotification && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-xl shadow-2xl border border-emerald-500/40 flex items-center gap-2.5 text-xs font-bold animate-in slide-in-from-bottom-2 fade-in duration-200">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{autoSaveNotification}</span>
        </div>
      )}

      {/* 7. PDS PICTURES GALLERY MODAL WITH AI ORGANIZER, 10-PIC PAGINATION & AI CLARITY FILTER */}
      {isPdsGalleryOpen && (() => {
        const allPictures = getPdsPictureList();
        const searchQ = pdsSearchQuery.toLowerCase().trim();
        
        // Global search across ALL pictures regardless of page
        const filteredList = allPictures.filter((img) => {
          if (!searchQ) return true;
          return (
            img.searchKey.includes(searchQ) ||
            img.applicantName.toLowerCase().includes(searchQ) ||
            img.pageTitle.toLowerCase().includes(searchQ)
          );
        });

        const totalFiltered = filteredList.length;
        const totalPages = Math.max(1, Math.ceil(totalFiltered / GALLERY_PAGE_SIZE));
        const safeCurrentPage = Math.min(Math.max(1, galleryCurrentPage), totalPages);
        const startIndex = (safeCurrentPage - 1) * GALLERY_PAGE_SIZE;
        const endIndex = Math.min(startIndex + GALLERY_PAGE_SIZE, totalFiltered);
        const paginatedPictures = filteredList.slice(startIndex, endIndex);

        // Detect if any duplicate applicant names currently exist in the PDS pictures list
        const duplicateNamesInModal: string[] = [];
        const seenNameMap = new Map<string, string>();
        allPictures.forEach((p) => {
          const raw = (p.applicantName || '').trim();
          if (isRealApplicantName(raw)) {
            const norm = normalizeApplicantName(raw);
            if (seenNameMap.has(norm)) {
              const origName = seenNameMap.get(norm)!;
              if (!duplicateNamesInModal.includes(origName)) {
                duplicateNamesInModal.push(origName);
              }
            } else {
              seenNameMap.set(norm, raw);
            }
          }
        });

        return (
          <div
            onClick={() => setIsPdsGalleryOpen(false)}
            className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-5 animate-in fade-in duration-200"
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="max-w-6xl w-full max-h-[95vh] bg-white rounded-3xl border border-slate-300 overflow-hidden flex flex-col shadow-2xl"
            >
              {/* Modal Header */}
              <div className="bg-slate-900 text-white px-4 sm:px-6 py-3.5 flex items-center justify-between flex-wrap gap-3 border-b border-slate-800 shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md border border-indigo-400/30 shrink-0">
                    <ImageIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-black text-white flex items-center gap-2 flex-wrap">
                      <span>MGA UPLOADED NA PDS PICTURES</span>
                      <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/30 text-indigo-300 text-xs font-mono font-bold border border-indigo-400/30">
                        {allPictures.length} Larawan
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-900/60 text-emerald-300 text-[11px] font-mono border border-emerald-400/30">
                        10 Larawan bawat Pahina
                      </span>
                    </h3>
                    <p className="text-[11px] sm:text-xs text-slate-400">
                      AI Organizer (Auto-Deduplicate) • 10 Larawan kada Pahina • Global Search • AI Clarity Text Filter
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5 bg-slate-800 p-1 rounded-xl border border-slate-700">
                    <button
                      onClick={() => setPdsGalleryViewMode('table')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                        pdsGalleryViewMode === 'table'
                          ? 'bg-indigo-600 text-white shadow-md border border-indigo-400 font-extrabold'
                          : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
                      }`}
                      title="Table View: Ipakita lamang muna ang pangalan ng mga aplikante sa table"
                    >
                      <Table className="w-3.5 h-3.5" />
                      <span>📋 Table (Pangalan Lamang)</span>
                    </button>
                    <button
                      onClick={() => setPdsGalleryViewMode('grid')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                        pdsGalleryViewMode === 'grid'
                          ? 'bg-indigo-600 text-white shadow-md border border-indigo-400 font-extrabold'
                          : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
                      }`}
                      title="Grid View: Ipakita ang photo cards na may thumbnails"
                    >
                      <Grid className="w-3.5 h-3.5" />
                      <span>🖼️ Grid View</span>
                    </button>
                  </div>

                  {/* Direct PDS Picture Upload Buttons */}
                  <label className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md border border-emerald-400/50 transition-all cursor-pointer active:scale-95">
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handlePdsGalleryUpload}
                      className="hidden"
                    />
                    <Upload className="w-3.5 h-3.5 text-white" />
                    <span>+ Mag-upload ng PDS Picture</span>
                  </label>

                  <label
                    className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md border border-indigo-400/50 transition-all cursor-pointer active:scale-95"
                    title="Mag-upload ng buong folder ng PDS pictures"
                  >
                    <input
                      type="file"
                      multiple
                      {...({ webkitdirectory: '', directory: '' } as any)}
                      accept="image/*"
                      onChange={handlePdsGalleryFolderUpload}
                      className="hidden"
                    />
                    <FolderPlus className="w-3.5 h-3.5 text-indigo-200" />
                    <span>📁 Folder Upload</span>
                  </label>

                  {/* 1:1 Accurate Table Sync Button */}
                  <button
                    onClick={handleManualPdsTableSync}
                    disabled={allPictures.length === 0}
                    className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-black text-xs flex items-center gap-1.5 shadow-md border border-teal-400/50 transition-all active:scale-95 cursor-pointer"
                    title="Garantisadong 1-to-1 sync: Siguraduhing kung ilan ang PDS picture ay eksaktong ganun din ang bilang ng rows sa Table (100% Tugma)"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-teal-200" />
                    <span>🔄 I-sync sa Table (100% Tugma)</span>
                  </button>

                  {/* AI Organizer: Auto-Deduplicate Button */}
                  <button
                    onClick={() => handleRunAiOrganizer(false)}
                    disabled={isAiOrganizing || allPictures.length === 0}
                    className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all border shadow-sm ${
                      isAiOrganizing
                        ? 'bg-purple-900 text-purple-200 border-purple-600 animate-pulse'
                        : 'bg-purple-600 hover:bg-purple-500 text-white border-purple-400/40 active:scale-95'
                    }`}
                    title="AI Organizer: Awtomatikong iisa-isahin ang bawat PDS picture at buburahin ang naulit na pangalan at larawan"
                  >
                    <Sparkles className={`w-3.5 h-3.5 ${isAiOrganizing ? 'animate-spin text-purple-200' : 'text-yellow-300'}`} />
                    <span>{isAiOrganizing ? 'Sinisuri ang Duplicate...' : '🤖 AI Organizer (Alisin ang Duplicate)'}</span>
                  </button>

                  {/* AI Filter 1-Click Clarify All Button */}
                  <button
                    onClick={handleAutoClarifyAllPictures}
                    disabled={isAutoClarifyingAll || allPictures.length === 0}
                    className="px-3 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md border border-amber-300 transition-all active:scale-95"
                    title="Awtomatikong papalinawin ang lahat ng larawan para maging malinaw ang sulat at text"
                  >
                    <Wand2 className={`w-3.5 h-3.5 text-slate-950 ${isAutoClarifyingAll ? 'animate-spin' : ''}`} />
                    <span>⚡ AI Filter: Papalinawin Lahat</span>
                  </button>

                  {/* Global Search Bar in Modal */}
                  <div className="relative w-48 sm:w-64">
                    <Search className="w-3.5 h-3.5 text-emerald-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={pdsSearchQuery}
                      onChange={(e) => {
                        setPdsSearchQuery(e.target.value);
                        setGalleryCurrentPage(1); // Reset to page 1 on search
                      }}
                      placeholder="Global search (lahat ng pahina)..."
                      className="w-full bg-slate-950 text-white border border-slate-700 rounded-xl pl-8 pr-7 py-1.5 text-xs placeholder:text-slate-400 outline-none focus:border-emerald-500 font-medium shadow-inner"
                    />
                    {pdsSearchQuery && (
                      <button
                        onClick={() => {
                          setPdsSearchQuery('');
                          setGalleryCurrentPage(1);
                        }}
                        className="absolute right-2.5 top-2 text-slate-400 hover:text-white"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <button
                    onClick={() => setIsPdsGalleryOpen(false)}
                    className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Sub-Header Toolbar: AI Filter Presets & AI Organizer Status */}
              <div className="bg-slate-850 bg-slate-900/95 px-4 sm:px-6 py-2.5 border-b border-slate-800 flex items-center justify-between flex-wrap gap-2 text-xs">
                {/* AI Filter Mode Selector */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[11px] font-extrabold text-slate-300 flex items-center gap-1 uppercase tracking-wider">
                    <Sliders className="w-3.5 h-3.5 text-amber-400" />
                    <span>AI Filter Mode:</span>
                  </span>

                  <button
                    onClick={() => {
                      setAiFilterMode('ai_ultra_clear');
                      setIsHdClarityMode(true);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all border flex items-center gap-1 ${
                      aiFilterMode === 'ai_ultra_clear' && isHdClarityMode
                        ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md font-extrabold'
                        : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                    }`}
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>🤖 Ultra-Clear Text (Malinaw)</span>
                  </button>

                  <button
                    onClick={() => {
                      setAiFilterMode('clean_scanner');
                      setIsHdClarityMode(true);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all border flex items-center gap-1 ${
                      aiFilterMode === 'clean_scanner' && isHdClarityMode
                        ? 'bg-emerald-400 text-slate-950 border-emerald-300 shadow-md font-extrabold'
                        : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                    }`}
                  >
                    <FileText className="w-3 h-3" />
                    <span>📄 Clean Scanner (High Contrast)</span>
                  </button>

                  <button
                    onClick={() => {
                      setAiFilterMode('edge_sharpen');
                      setIsHdClarityMode(true);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all border flex items-center gap-1 ${
                      aiFilterMode === 'edge_sharpen' && isHdClarityMode
                        ? 'bg-indigo-400 text-slate-950 border-indigo-300 shadow-md font-extrabold'
                        : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                    }`}
                  >
                    <ZoomIn className="w-3 h-3" />
                    <span>🔍 Edge Sharpener</span>
                  </button>

                  <button
                    onClick={() => {
                      setAiFilterMode('normal');
                      setIsHdClarityMode(false);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all border flex items-center gap-1 ${
                      !isHdClarityMode
                        ? 'bg-slate-700 text-white border-slate-500 shadow-md font-extrabold'
                        : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                    }`}
                  >
                    <span>🖼️ Normal Photo</span>
                  </button>
                </div>

                {/* Auto-Deduplicate Indicator & Toggle */}
                <div className="flex items-center gap-2">
                  <label className="flex items-center gap-1.5 cursor-pointer text-[11px] font-bold text-slate-300">
                    <input
                      type="checkbox"
                      checked={autoDeduplicateEnabled}
                      onChange={(e) => setAutoDeduplicateEnabled(e.target.checked)}
                      className="rounded text-purple-600 focus:ring-purple-500 w-3.5 h-3.5"
                    />
                    <span>Auto-Delete Duplicate sa Upload (AI Organizer)</span>
                  </label>
                </div>
              </div>

              {/* DUPLICATE DETECTED WARNING BANNER IN MODAL */}
              {duplicateNamesInModal.length > 0 && (
                <div className="bg-amber-950/90 border-b border-amber-600/60 px-4 sm:px-6 py-2.5 flex items-center justify-between flex-wrap gap-2 text-amber-200 text-xs font-bold shrink-0 animate-in slide-in-from-top-1">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>
                      ⚠️ May na-detect na duplicate applicant name sa PDS Pictures: <strong className="text-amber-300 underline font-black">{duplicateNamesInModal.join(', ')}</strong>. 
                      I-click ang <strong>Alisin ang Duplicate</strong> o gamitin ang <strong>Trash icon</strong> upang burahin ang sobrang datos.
                    </span>
                  </div>
                  <button
                    onClick={() => handleRunAiOrganizer(false)}
                    disabled={isAiOrganizing}
                    className="px-3.5 py-1 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded-xl text-xs shrink-0 flex items-center gap-1.5 shadow-md transition-all cursor-pointer active:scale-95"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-slate-950" />
                    <span>{isAiOrganizing ? 'Tinatanggal...' : 'Alisin ang Duplicate Ngayon'}</span>
                  </button>
                </div>
              )}

              {/* AI Organizer Banner / Toast Message if present */}
              {aiOrganizerToast && (
                <div className="bg-purple-900/90 text-purple-100 px-4 sm:px-6 py-2 border-b border-purple-700 text-xs font-bold flex items-center justify-between animate-in slide-in-from-top-1">
                  <span className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-yellow-300" />
                    <span>{aiOrganizerToast}</span>
                  </span>
                  <button
                    onClick={() => setAiOrganizerToast(null)}
                    className="text-purple-300 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Global Search Results Indicator Bar */}
              {searchQ && (
                <div className="bg-amber-50 px-4 sm:px-6 py-2 border-b border-amber-200 text-amber-900 text-xs font-bold flex items-center justify-between">
                  <span>
                    🔍 Global Search: Nahanap ang <strong>{totalFiltered}</strong> sa kabuuang <strong>{allPictures.length}</strong> larawan para sa query &ldquo;{pdsSearchQuery}&rdquo;
                  </span>
                  <button
                    onClick={() => {
                      setPdsSearchQuery('');
                      setGalleryCurrentPage(1);
                    }}
                    className="text-amber-800 underline text-[11px] hover:text-amber-950 font-extrabold"
                  >
                    I-reset ang Search
                  </button>
                </div>
              )}

              {/* Modal Content - Table View (Default: Name-First) OR Grid View */}
              <div className="flex-1 p-4 sm:p-6 overflow-y-auto bg-slate-100 min-h-[380px]">
                {totalFiltered === 0 ? (
                  <div className="py-16 text-center space-y-4 bg-white rounded-3xl border border-slate-200 p-8 max-w-lg mx-auto my-8 shadow-sm">
                    <ImageIcon className="w-14 h-14 text-indigo-300 mx-auto" />
                    <div>
                      <h4 className="text-base font-black text-slate-800">Walang PDS Picture na Nahanap</h4>
                      <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                        {searchQ
                          ? `Walang larawan na tumutugma sa "${pdsSearchQuery}".`
                          : 'Mag-upload ng mga PDS pictures dito upang permanenteng mai-save sa Cloud Database at Device. Hindi mawawala kahit i-refresh!'}
                      </p>
                    </div>
                    <div className="flex items-center justify-center gap-3 pt-2 flex-wrap">
                      <label className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center gap-2 shadow-md transition-all cursor-pointer active:scale-95">
                        <input
                          type="file"
                          multiple
                          accept="image/*"
                          onChange={handlePdsGalleryUpload}
                          className="hidden"
                        />
                        <Upload className="w-4 h-4 text-white" />
                        <span>+ Mag-upload ng PDS Picture</span>
                      </label>
                      <label className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs flex items-center gap-2 shadow-md transition-all cursor-pointer active:scale-95">
                        <input
                          type="file"
                          multiple
                          {...({ webkitdirectory: '', directory: '' } as any)}
                          accept="image/*"
                          onChange={handlePdsGalleryFolderUpload}
                          className="hidden"
                        />
                        <FolderPlus className="w-4 h-4 text-indigo-200" />
                        <span>📁 Mag-upload ng Folder</span>
                      </label>
                    </div>
                  </div>
                ) : pdsGalleryViewMode === 'table' ? (
                  /* 1. TABLE VIEW: Only Name is shown initially; Clicking the name opens the Full PDS Picture */
                  <div className="bg-white rounded-2xl border border-slate-300 shadow-sm overflow-hidden">
                    <div className="bg-indigo-50/70 px-4 py-2.5 border-b border-indigo-100 flex items-center justify-between text-xs text-indigo-950 font-bold">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-indigo-600" />
                        <span>I-click ang <strong>Pangalan ng Aplikante</strong> upang buksan ang buong PDS Picture sa Fullscreen Screen View:</span>
                      </div>
                      <span className="text-[11px] text-indigo-700 font-mono">
                        Pahina {safeCurrentPage} ng {totalPages} ({paginatedPictures.length} rekord)
                      </span>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="bg-slate-900 text-white font-mono text-[11px] uppercase tracking-wider">
                            <th className="py-3 px-3.5 border-b border-slate-800 w-12 text-center">#</th>
                            <th className="py-3 px-4 border-b border-slate-800">
                              <div className="flex items-center gap-1.5">
                                <User className="w-3.5 h-3.5 text-emerald-400" />
                                <span>PANGALAN NG APLIKANTE (PDS PICTURE)</span>
                              </div>
                            </th>
                            <th className="py-3 px-4 border-b border-slate-800">DOKUMENTO / PAHINA</th>
                            <th className="py-3 px-4 border-b border-slate-800">PETSA NG PAG-UPLOAD</th>
                            <th className="py-3 px-4 border-b border-slate-800 text-right">MGA AKSYON</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {paginatedPictures.map((item, idx) => {
                            const absoluteIndex = startIndex + idx + 1;
                            const isEditing = editingPhotoId === item.id;

                            return (
                              <tr
                                key={item.id || idx}
                                className="hover:bg-indigo-50/50 transition-colors group cursor-pointer"
                                onClick={() => {
                                  if (!isEditing) {
                                    setFullScreenPdsImage({
                                      id: item.id,
                                      src: item.src,
                                      applicantName: item.applicantName,
                                      pageTitle: item.pageTitle,
                                      zoom: 1,
                                      rotation: 0,
                                    });
                                  }
                                }}
                              >
                                {/* Index Number */}
                                <td className="py-3.5 px-3.5 text-center font-mono font-bold text-slate-500 bg-slate-50/50 group-hover:bg-indigo-50/80">
                                  <span className="px-2 py-0.5 rounded-md bg-slate-200 text-slate-800 text-[11px] font-extrabold">
                                    #{absoluteIndex}
                                  </span>
                                </td>

                                {/* Applicant Name (Clickable to reveal Full PDS Picture) */}
                                <td className="py-3.5 px-4">
                                  {isEditing ? (
                                    <div
                                      className="flex items-center gap-1.5"
                                      onClick={(e) => e.stopPropagation()}
                                    >
                                      <input
                                        type="text"
                                        value={editingPhotoNameInput}
                                        onChange={(e) => setEditingPhotoNameInput(e.target.value)}
                                        onKeyDown={(e) => {
                                          if (e.key === 'Enter') {
                                            handleSavePhotoName(item, editingPhotoNameInput);
                                            setEditingPhotoId(null);
                                          }
                                        }}
                                        className="px-2.5 py-1 bg-white border-2 border-indigo-500 rounded-lg text-xs font-black text-slate-900 outline-none w-64 shadow-xs"
                                        autoFocus
                                      />
                                      <button
                                        onClick={() => {
                                          handleSavePhotoName(item, editingPhotoNameInput);
                                          setEditingPhotoId(null);
                                        }}
                                        className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 shadow-xs"
                                      >
                                        <Check className="w-3.5 h-3.5" />
                                        <span>Save</span>
                                      </button>
                                      <button
                                        onClick={() => setEditingPhotoId(null)}
                                        className="px-2 py-1 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold"
                                      >
                                        Cancel
                                      </button>
                                    </div>
                                  ) : (
                                    <div className="flex items-center gap-2 flex-wrap">
                                      <button
                                        type="button"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          setFullScreenPdsImage({
                                            id: item.id,
                                            src: item.src,
                                            applicantName: item.applicantName,
                                            pageTitle: item.pageTitle,
                                            zoom: 1,
                                            rotation: 0,
                                          });
                                        }}
                                        className="text-left font-black text-sm text-indigo-700 hover:text-indigo-900 group-hover:underline flex items-center gap-1.5"
                                      >
                                        <div className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs shrink-0 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                                          <User className="w-3.5 h-3.5" />
                                        </div>
                                        <span>{item.applicantName}</span>
                                      </button>
                                      <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full font-bold border border-emerald-200">
                                        🔍 I-click para buksan ang buong PDS
                                      </span>
                                    </div>
                                  )}
                                </td>

                                {/* Document / Page Title */}
                                <td className="py-3.5 px-4 text-slate-600 font-medium">
                                  <span className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-[11px] font-bold border border-slate-200">
                                    {item.pageTitle}
                                  </span>
                                </td>

                                {/* Upload Date */}
                                <td className="py-3.5 px-4 text-slate-500 font-mono text-[11px]">
                                  {item.uploadedAt}
                                </td>

                                {/* Action Buttons */}
                                <td
                                  className="py-3.5 px-4 text-right"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  <div className="flex items-center justify-end gap-1.5">
                                    {/* View Full PDS Picture Button */}
                                    <button
                                      onClick={() =>
                                        setFullScreenPdsImage({
                                          id: item.id,
                                          src: item.src,
                                          applicantName: item.applicantName,
                                          pageTitle: item.pageTitle,
                                          zoom: 1,
                                          rotation: 0,
                                        })
                                      }
                                      className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs flex items-center gap-1 shadow-sm transition-all active:scale-95 border border-indigo-500"
                                      title="Buksan ang buong larawan ng PDS"
                                    >
                                      <Maximize2 className="w-3 h-3" />
                                      <span>Tingnan ang PDS Picture</span>
                                    </button>

                                    {/* AI OCR Re-scan Name Button */}
                                    <button
                                      onClick={() => handleRescanSinglePicture(item)}
                                      className="p-1.5 rounded-xl bg-amber-50 hover:bg-amber-500 hover:text-slate-950 text-amber-700 text-xs font-bold border border-amber-200 transition-colors"
                                      title="Basahin ang tunay na pangalan sa PDS picture gamit ang AI OCR"
                                    >
                                      <Sparkles className="w-3.5 h-3.5" />
                                    </button>

                                    {/* Direct Download with Exact Applicant Full Name */}
                                    <a
                                      href={item.src}
                                      download={getPdsPictureFileName(item.applicantName)}
                                      className="p-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-600 hover:text-white text-emerald-700 text-xs font-bold border border-emerald-200 transition-colors"
                                      title={`I-download bilang "${getPdsPictureFileName(item.applicantName)}"`}
                                    >
                                      <Download className="w-3.5 h-3.5" />
                                    </a>

                                    {/* Edit Name Button */}
                                    <button
                                      onClick={() => {
                                        setEditingPhotoId(item.id);
                                        setEditingPhotoNameInput(item.applicantName);
                                      }}
                                      className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold border border-slate-300 transition-colors"
                                      title="Baguhin ang pangalan ng aplikante"
                                    >
                                      <Edit3 className="w-3.5 h-3.5" />
                                    </button>

                                    {/* Delete Button */}
                                    <button
                                      onClick={() => handleDeleteSinglePicture(item)}
                                      className="p-1.5 rounded-xl bg-rose-50 hover:bg-rose-600 hover:text-white text-rose-700 text-xs font-bold border border-rose-200 transition-colors"
                                      title="Burahin ang PDS picture na ito"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : (
                  /* 2. GRID VIEW: Thumbnail Cards (Optional Switch) */
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                    {paginatedPictures.map((item, idx) => {
                      const absoluteIndex = startIndex + idx + 1;
                      return (
                        <div
                          key={item.id || idx}
                          className="bg-white rounded-2xl border border-slate-300 overflow-hidden shadow-md hover:shadow-xl hover:border-indigo-500 transition-all flex flex-col group"
                        >
                          {/* Image Thumbnail Container with Automatic AI Filter Enhancement */}
                          <div
                            onClick={() =>
                              setFullScreenPdsImage({
                                id: item.id,
                                src: item.src,
                                applicantName: item.applicantName,
                                pageTitle: item.pageTitle,
                                zoom: 1,
                                rotation: 0,
                              })
                            }
                            className="relative aspect-[4/3] bg-slate-950 cursor-pointer overflow-hidden flex items-center justify-center p-1"
                          >
                            <img
                              src={item.src || undefined}
                              alt={item.applicantName}
                              style={{
                                filter: isHdClarityMode ? getAiFilterCss(aiFilterMode) : 'none',
                                imageRendering: '-webkit-optimize-contrast',
                              }}
                              className="max-w-full max-h-full object-contain rounded-lg transition-transform duration-300 group-hover:scale-105"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-slate-950/30 opacity-50 group-hover:opacity-75 transition-opacity" />

                            {/* Top Tag & Clarity Indicator */}
                            <div className="absolute top-2 left-2 flex items-center gap-1">
                              <span className="bg-indigo-900/90 backdrop-blur-md text-indigo-100 px-2 py-0.5 rounded-md text-[9px] font-extrabold font-mono border border-indigo-400/30 shadow-sm flex items-center gap-1">
                                <span>#{absoluteIndex}</span>
                              </span>
                              {isHdClarityMode && (
                                <span className="bg-amber-400 text-slate-950 px-1.5 py-0.5 rounded text-[8px] font-black uppercase shadow">
                                  AI CLEAR
                                </span>
                              )}
                            </div>

                            {/* Quick Delete Trash Button on Top Right */}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteSinglePicture(item);
                              }}
                              className="absolute top-2 right-2 p-1.5 rounded-lg bg-rose-600/90 hover:bg-rose-600 text-white border border-rose-400/40 shadow-lg transition-all active:scale-95"
                              title="Burahin itong larawan"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>

                            {/* Hover Fullscreen Prompt Button */}
                            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                              <span className="px-2.5 py-1.5 rounded-lg bg-indigo-600 text-white text-[11px] font-black shadow-lg flex items-center gap-1 transform translate-y-2 group-hover:translate-y-0 transition-all">
                                <Maximize2 className="w-3.5 h-3.5" />
                                <span>Fullscreen</span>
                              </span>
                            </div>
                          </div>

                          {/* Card Info Details */}
                          <div className="p-3 space-y-1.5 bg-white flex-1 flex flex-col justify-between border-t border-slate-100">
                            <div className="space-y-1">
                              <div className="flex items-center justify-between gap-1">
                                <span className="text-[9px] font-mono font-extrabold text-indigo-700 uppercase tracking-wider">
                                  Aplikante:
                                </span>
                                <button
                                  onClick={() => {
                                    setEditingPhotoId(item.id);
                                    setEditingPhotoNameInput(item.applicantName);
                                  }}
                                  className="text-[9px] font-bold text-slate-400 hover:text-indigo-600 flex items-center gap-0.5"
                                  title="Baguhin ang pangalan ng larawan"
                                >
                                  <Edit3 className="w-2.5 h-2.5" />
                                  <span>Edit</span>
                                </button>
                              </div>

                              {editingPhotoId === item.id ? (
                                <div className="flex items-center gap-1 pt-0.5">
                                  <input
                                    type="text"
                                    value={editingPhotoNameInput}
                                    onChange={(e) => setEditingPhotoNameInput(e.target.value)}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') {
                                        handleSavePhotoName(item, editingPhotoNameInput);
                                        setEditingPhotoId(null);
                                      }
                                    }}
                                    className="w-full px-2 py-0.5 bg-slate-50 border border-indigo-500 rounded text-xs font-black text-slate-900 outline-none"
                                    autoFocus
                                  />
                                  <button
                                    onClick={() => {
                                      handleSavePhotoName(item, editingPhotoNameInput);
                                      setEditingPhotoId(null);
                                    }}
                                    className="p-1 rounded bg-emerald-600 text-white text-xs font-bold"
                                  >
                                    <Check className="w-3 h-3" />
                                  </button>
                                </div>
                              ) : (
                                <h4 className="text-xs font-black text-slate-900 leading-snug flex items-center gap-1 group-hover:text-indigo-900">
                                  <User className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                  <span className="truncate" title={item.applicantName}>
                                    {item.applicantName}
                                  </span>
                                </h4>
                              )}

                              <p className="text-[10px] text-slate-500 font-medium truncate">
                                {item.pageTitle}
                              </p>
                            </div>

                            <div className="pt-1.5 border-t border-slate-100 flex items-center justify-between gap-1">
                              <span className="text-[9px] text-slate-400 font-mono">Pahina {safeCurrentPage}</span>

                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() => handleRescanSinglePicture(item)}
                                  className="p-1 rounded-lg bg-amber-50 hover:bg-amber-500 hover:text-slate-950 text-amber-700 text-[10px] font-extrabold transition-all border border-amber-200"
                                  title="Basahin ang tunay na pangalan sa PDS picture gamit ang AI OCR"
                                >
                                  <Sparkles className="w-3 h-3" />
                                </button>

                                <a
                                  href={item.src}
                                  download={getPdsPictureFileName(item.applicantName)}
                                  className="p-1 rounded-lg bg-emerald-50 hover:bg-emerald-600 hover:text-white text-emerald-700 text-[10px] font-extrabold transition-all border border-emerald-200"
                                  title={`I-download bilang "${getPdsPictureFileName(item.applicantName)}"`}
                                >
                                  <Download className="w-3 h-3" />
                                </a>

                                <button
                                  onClick={() => handleDeleteSinglePicture(item)}
                                  className="p-1 rounded-lg bg-rose-50 hover:bg-rose-600 hover:text-white text-rose-700 text-[10px] font-extrabold transition-all border border-rose-200"
                                  title="Burahin itong larawan"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>

                                <button
                                  onClick={() =>
                                    setFullScreenPdsImage({
                                      id: item.id,
                                      src: item.src,
                                      applicantName: item.applicantName,
                                      pageTitle: item.pageTitle,
                                      zoom: 1,
                                      rotation: 0,
                                    })
                                  }
                                  className="px-2 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-600 hover:text-white text-indigo-800 text-[10px] font-bold transition-all border border-indigo-200"
                                >
                                  Tingnan
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Modal Pagination Footer (Strictly 10 Pictures Per Page with multi-page controls) */}
              <div className="bg-slate-900 text-white px-4 sm:px-6 py-3 border-t border-slate-800 flex items-center justify-between flex-wrap gap-3 shrink-0">
                {/* Left Side: Summary & Page Counter */}
                <div className="flex items-center gap-3 text-xs text-slate-300">
                  <span className="font-bold flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-indigo-400" />
                    <span>
                      Ipinapakita: <strong>{totalFiltered > 0 ? startIndex + 1 : 0}-{endIndex}</strong> sa <strong>{totalFiltered}</strong> larawan (10 bawat pahina)
                    </span>
                  </span>
                  <span className="hidden sm:inline text-slate-500">|</span>
                  <span className="hidden sm:inline text-indigo-300 font-mono font-bold">
                    Pahina {safeCurrentPage} ng {totalPages}
                  </span>
                </div>

                {/* Center / Right: Pagination Controls */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  {/* Previous Page Button */}
                  <button
                    onClick={() => setGalleryCurrentPage((p) => Math.max(1, p - 1))}
                    disabled={safeCurrentPage <= 1}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-bold flex items-center gap-1 border border-slate-700 transition-all active:scale-95"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                    <span>Nauna</span>
                  </button>

                  {/* Numbered Page Buttons */}
                  <div className="flex items-center gap-1">
                    {Array.from({ length: totalPages }).map((_, pIdx) => {
                      const pageNum = pIdx + 1;
                      // Display smart window if lots of pages
                      if (
                        totalPages > 8 &&
                        Math.abs(pageNum - safeCurrentPage) > 2 &&
                        pageNum !== 1 &&
                        pageNum !== totalPages
                      ) {
                        if (pageNum === 2 || pageNum === totalPages - 1) {
                          return (
                            <span key={pageNum} className="text-slate-500 px-1 text-xs">
                              ...
                            </span>
                          );
                        }
                        return null;
                      }

                      return (
                        <button
                          key={pageNum}
                          onClick={() => setGalleryCurrentPage(pageNum)}
                          className={`w-8 h-8 rounded-xl text-xs font-black transition-all flex items-center justify-center ${
                            pageNum === safeCurrentPage
                              ? 'bg-indigo-600 text-white shadow-md ring-2 ring-indigo-400/50 border border-indigo-400'
                              : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                          }`}
                        >
                          {pageNum}
                        </button>
                      );
                    })}
                  </div>

                  {/* Next Page Button */}
                  <button
                    onClick={() => setGalleryCurrentPage((p) => Math.min(totalPages, p + 1))}
                    disabled={safeCurrentPage >= totalPages}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-bold flex items-center gap-1 border border-slate-700 transition-all active:scale-95"
                  >
                    <span>Susunod</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>

                  {/* Close Modal Button */}
                  <button
                    onClick={() => setIsPdsGalleryOpen(false)}
                    className="ml-2 px-4 py-1.5 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-bold transition-all shadow-sm"
                  >
                    Isara
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* 8. 100% FULLSCREEN PC SCREEN OVERLAY FOR PDS IMAGE (WITH SCROLLABLE FULL HEIGHT) */}
      {fullScreenPdsImage && (
        <div className="fixed inset-0 w-screen h-screen z-[99999] bg-slate-950/98 flex flex-col text-white backdrop-blur-md select-none animate-in fade-in duration-150">
          {/* Top Fullscreen Header Control Bar */}
          <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-3 flex items-center justify-between flex-wrap gap-3 shrink-0 shadow-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold shadow">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] text-indigo-300 font-mono uppercase tracking-wider font-extrabold block">
                  BUONG LARAWAN NG PDS (FULL PC SCREEN SCROLL VIEW)
                </span>
                {isEditingFullScreenName ? (
                  <div className="flex items-center gap-2 mt-1">
                    <input
                      type="text"
                      value={editingFullScreenNameInput}
                      onChange={(e) => setEditingFullScreenNameInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          const val = editingFullScreenNameInput.trim().toUpperCase();
                          if (val) {
                            handleSavePhotoName(
                              { id: fullScreenPdsImage.id, src: fullScreenPdsImage.src },
                              val
                            );
                            setFullScreenPdsImage((prev) => (prev ? { ...prev, applicantName: val } : null));
                            setIsEditingFullScreenName(false);
                            triggerAutoSaveToast(`Pangalan ng larawan na-update: ${val}`);
                          }
                        } else if (e.key === 'Escape') {
                          setIsEditingFullScreenName(false);
                        }
                      }}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 border border-indigo-400 text-white font-black text-sm outline-none w-64 sm:w-80 shadow-inner"
                      placeholder="Ilagay ang buong pangalan..."
                      autoFocus
                    />
                    <button
                      onClick={() => {
                        const val = editingFullScreenNameInput.trim().toUpperCase();
                        if (val) {
                          handleSavePhotoName(
                            { id: fullScreenPdsImage.id, src: fullScreenPdsImage.src },
                            val
                          );
                          setFullScreenPdsImage((prev) => (prev ? { ...prev, applicantName: val } : null));
                          setIsEditingFullScreenName(false);
                          triggerAutoSaveToast(`Pangalan ng larawan na-update: ${val}`);
                        }
                      }}
                      className="p-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow"
                      title="I-save ang pangalan"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setIsEditingFullScreenName(false)}
                      className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white transition-all shadow"
                      title="Kanselahin"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 flex-wrap mt-0.5">
                    <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                      <User className="w-5 h-5 text-emerald-400" />
                      <span>{fullScreenPdsImage.applicantName}</span>
                    </h2>

                    <button
                      onClick={() => {
                        setEditingFullScreenNameInput(fullScreenPdsImage.applicantName);
                        setIsEditingFullScreenName(true);
                      }}
                      className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold flex items-center gap-1 border border-slate-700 transition-all"
                      title="Palitan o i-edit ang pangalan ng larawan"
                    >
                      <Edit3 className="w-3 h-3 text-indigo-300" />
                      <span>Edit</span>
                    </button>

                    <button
                      onClick={handleAiRescanFullScreenImage}
                      disabled={isAiScanningFullScreen}
                      className="px-2.5 py-0.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-black flex items-center gap-1 transition-all disabled:opacity-50"
                      title="Tignan at basahin ang tunay na pangalan sa loob ng PDS picture gamit ang AI OCR"
                    >
                      <Sparkles className={`w-3 h-3 ${isAiScanningFullScreen ? 'animate-spin' : ''}`} />
                      <span>{isAiScanningFullScreen ? 'Binabasa ang PDS...' : 'Basahin ang Pangalan sa Larawan (AI)'}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Image Zoom & View Toolset Controls */}
            <div className="flex items-center gap-2 bg-slate-800/90 p-1.5 rounded-2xl border border-slate-700">
              <button
                onClick={() =>
                  setFullScreenPdsImage((prev) =>
                    prev ? { ...prev, zoom: Math.max(0.5, prev.zoom - 0.25) } : null
                  )
                }
                className="p-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white transition-all"
                title="Zoom Out (-)"
              >
                <ZoomOut className="w-4 h-4" />
              </button>

              <span className="px-3 text-xs font-mono font-black text-emerald-300 min-w-[55px] text-center">
                {Math.round(fullScreenPdsImage.zoom * 100)}%
              </span>

              <button
                onClick={() =>
                  setFullScreenPdsImage((prev) =>
                    prev ? { ...prev, zoom: Math.min(4, prev.zoom + 0.25) } : null
                  )
                }
                className="p-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white transition-all"
                title="Zoom In (+)"
              >
                <ZoomIn className="w-4 h-4" />
              </button>

              <button
                onClick={() =>
                  setFullScreenPdsImage((prev) => (prev ? { ...prev, zoom: 1, rotation: 0 } : null))
                }
                className="px-2.5 py-1.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-xs font-extrabold transition-all"
                title="I-reset ang Zoom (100%)"
              >
                Reset
              </button>

              <button
                onClick={() =>
                  setFullScreenPdsImage((prev) =>
                    prev ? { ...prev, rotation: (prev.rotation + 90) % 360 } : null
                  )
                }
                className="p-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white transition-all"
                title="Iikot ang larawan (Rotate 90 deg)"
              >
                <RotateCw className="w-4 h-4" />
              </button>

              <a
                href={fullScreenPdsImage.src}
                download={getPdsPictureFileName(fullScreenPdsImage.applicantName)}
                className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold flex items-center gap-1.5 transition-all shadow-md"
                title={`I-download bilang "${getPdsPictureFileName(fullScreenPdsImage.applicantName)}"`}
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Download ({getPdsPictureFileName(fullScreenPdsImage.applicantName)})</span>
              </a>

              <button
                onClick={() => {
                  handleDeleteSinglePicture({
                    id: fullScreenPdsImage.id,
                    src: fullScreenPdsImage.src,
                    applicantName: fullScreenPdsImage.applicantName,
                  });
                  setFullScreenPdsImage(null);
                }}
                className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-extrabold flex items-center gap-1 transition-all cursor-pointer"
                title="Burahin itong PDS photo"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Burahin</span>
              </button>
            </div>

            {/* Close Button */}
            <button
              onClick={() => setFullScreenPdsImage(null)}
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black flex items-center gap-1.5 shadow-md transition-all active:scale-95"
            >
              <X className="w-4 h-4" />
              <span>Isara (Esc)</span>
            </button>
          </div>

          {/* Main Viewport Workspace: Full 100% Screen Display with Vertical Scroll */}
          <div className="flex-1 w-full h-full overflow-y-auto overflow-x-auto flex flex-col items-center justify-start p-4 sm:p-8 bg-slate-950/95 relative custom-scrollbar">
            <div className="w-full max-w-4xl mx-auto flex flex-col items-center py-4 my-auto">
              <img
                src={fullScreenPdsImage.src || undefined}
                alt={fullScreenPdsImage.applicantName}
                style={{
                  imageRendering: '-webkit-optimize-contrast',
                  filter: isHdClarityMode ? getAiFilterCss(aiFilterMode) : 'none',
                  transform: `scale(${fullScreenPdsImage.zoom}) rotate(${fullScreenPdsImage.rotation}deg)`,
                  transformOrigin: 'top center',
                }}
                className="w-full h-auto object-contain rounded-xl shadow-2xl transition-transform duration-150 cursor-grab active:cursor-grabbing border border-slate-800"
              />
            </div>
          </div>
        </div>
      )}

      {/* DELETE ALL CONFIRMATION & ANIMATED DELETING MODAL OVERLAY */}
      {showDeleteAllConfirmModal && (
        <div
          onClick={() => !isDeletingAll && setShowDeleteAllConfirmModal(false)}
          className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-md w-full bg-white rounded-3xl border-2 border-rose-500 overflow-hidden shadow-2xl p-6 text-center space-y-5 animate-in zoom-in-95 duration-200"
          >
            {/* Animated Trash Icon with Spinner/Pulse Ring */}
            <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
              <div className="absolute inset-0 bg-rose-200 rounded-full animate-ping opacity-75" />
              <div className="relative w-20 h-20 rounded-3xl bg-rose-600 text-white flex items-center justify-center shadow-xl shadow-rose-600/40">
                <Trash2 className={`w-10 h-10 ${isDeletingAll ? 'animate-bounce text-yellow-300' : 'animate-bounce text-white'}`} />
              </div>
              {isDeletingAll && (
                <div className="absolute -inset-3 border-4 border-rose-600 border-t-transparent rounded-full animate-spin" />
              )}
            </div>

            <div className="space-y-2">
              <h3 className="text-xl font-black text-slate-900 tracking-tight">
                {isDeletingAll ? 'Binubura ang Lahat ng Datos...' : 'Burahin ang Lahat ng Data sa System?'}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed font-medium">
                {isDeletingAll
                  ? 'Gumagalaw ang pagbura... Inaalis at linilinis ang lahat ng datos sa lahat ng Sheet 1, 2, 3, mga PDS pictures, at Firebase Cloud Database.'
                  : 'Sigurado ka bang nais mong BURAHIN NANG PERMANENTE ang lahat ng datos sa lahat ng sheet, mga inupload na larawan, at Firebase Database? Hindi na ito maibabalik.'}
              </p>
            </div>

            {isDeletingAll ? (
              <div className="py-2.5 px-4 rounded-2xl bg-rose-50 border border-rose-200 flex items-center justify-center gap-2 text-xs font-black text-rose-700">
                <RefreshCw className="w-4 h-4 animate-spin text-rose-600" />
                <span>Gumagalaw ang System Deletion Engine...</span>
              </div>
            ) : (
              <div className="flex items-center gap-3 pt-2">
                <button
                  onClick={() => setShowDeleteAllConfirmModal(false)}
                  className="flex-1 py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all border border-slate-300 active:scale-95"
                >
                  Huwag Muna (Kanselahin)
                </button>
                <button
                  onClick={handleExecuteDeleteAll}
                  className="flex-1 py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-black shadow-lg shadow-rose-600/30 transition-all active:scale-95 flex items-center justify-center gap-2 border border-rose-500"
                >
                  <Trash2 className="w-4 h-4 text-rose-200 animate-bounce" />
                  <span>Oo, Burahin Lahat</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Live AI Fullscreen Mobile Document Scanner Modal */}
      {isLiveScannerOpen && (
        <LiveAiDocumentScanner
          isOpen={isLiveScannerOpen}
          onClose={() => setIsLiveScannerOpen(false)}
          headers={activeTargetHeaders && activeTargetHeaders.length > 0 ? activeTargetHeaders : TARGET_REQUESTED_HEADERS}
          templateName={activeTemplateName || 'Custom Form Extractor'}
          onRowExtracted={handleLiveScannerRowExtracted}
          apiKeyModalTrigger={() => setIsApiKeyModalOpen(true)}
          galleryBoxes={galleryBoxes}
          onAssignToGalleryBox={handleAssignPhotoToBox}
          onAddNew4BoxesAndAssign={handleAddNew4BoxesAndAssignPhoto}
          onOpenGallery={() => setIsGalleryQueueOpen(true)}
        />
      )}

      {/* 🖼️ MODAL: GALLERY TABLE (4-BOX AI SCANNER QUEUE) */}
      {isGalleryQueueOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-150">
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-7xl max-h-[95vh] bg-slate-900 border-2 border-emerald-500/60 rounded-3xl overflow-hidden shadow-2xl flex flex-col text-white animate-in zoom-in-95 duration-200"
          >
            {/* Modal Header */}
            <div className="px-4 sm:px-6 py-3.5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 text-slate-950 flex items-center justify-center shadow-lg font-black shrink-0">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-sm sm:text-base font-black text-white tracking-wide flex items-center gap-1.5">
                      <span>GALLERY TABLE (PAHIGA NA 4-BOX QUEUE)</span>
                    </h2>
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-black border border-emerald-500/30">
                      {galleryBoxes.filter(b => !!b.imageSrc).length} Nakasalang / {galleryBoxes.length} Boxes ({Math.ceil(galleryBoxes.length / 4)}/50 Serye)
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    ⚡ Turbo 5s (Malinaw) / 10s (Malabo/Handwritten) Vision OCR. <strong>Tuloy-tuloy na nag-i-iscan kahit i-close o i-X mo ang modal na ito!</strong>
                  </p>
                </div>
              </div>

              {/* Header Action Buttons */}
              <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                {/* Add 4 Box Button */}
                <button
                  onClick={() => handleAdd4MoreBoxes(1)}
                  disabled={Math.ceil(galleryBoxes.length / 4) >= 50}
                  className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black flex items-center gap-1 shadow transition-all active:scale-95 border border-indigo-400/40 disabled:opacity-40"
                  title="Magdagdag ng 1 Serye (4 na bagong kahon)"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+4 Box (1 Set)</span>
                </button>

                {/* Add 20 Box Button (5 Sets) */}
                <button
                  onClick={() => handleAdd4MoreBoxes(5)}
                  disabled={Math.ceil(galleryBoxes.length / 4) >= 50}
                  className="hidden md:flex px-2.5 py-1.5 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-bold items-center gap-1 shadow transition-all active:scale-95 border border-purple-400/40 disabled:opacity-40"
                  title="Magdagdag ng 5 Serye (20 Boxes)"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>+20 Box (5 Sets)</span>
                </button>

                {/* Open AI Camera Scanner */}
                <button
                  onClick={() => {
                    setIsGalleryQueueOpen(false);
                    setIsLiveScannerOpen(true);
                  }}
                  className="px-2.5 sm:px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center gap-1 shadow transition-all active:scale-95 border border-emerald-400/40"
                  title="Kumuha ng bagong PDS gamit ang camera"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>📸 AI Scanner</span>
                </button>

                {/* Start AI Sequential Scan (Strict FIFO 1-by-1) */}
                <button
                  onClick={handleStartScanAllGalleryBoxes}
                  disabled={isSequentialScanning || galleryBoxes.every(b => !b.imageSrc)}
                  className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:brightness-110 text-slate-950 text-xs font-black flex items-center gap-1.5 shadow-lg shadow-amber-500/20 transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed border border-amber-300"
                  title="Simulan ang 1-by-1 sequential AI scan"
                >
                  {isSequentialScanning ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-slate-950" />
                      <span>Ini-iscan ang Unang Pumasok...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-3.5 h-3.5 text-slate-950 fill-slate-950" />
                      <span>🚀 I-scan (1-by-1 FIFO)</span>
                    </>
                  )}
                </button>

                {/* Clear All Boxes Button */}
                <button
                  onClick={handleClearAllGalleryBoxes}
                  disabled={galleryBoxes.every(b => !b.imageSrc)}
                  className="p-1.5 rounded-xl bg-slate-800 hover:bg-rose-900/60 text-slate-400 hover:text-rose-300 border border-slate-700 transition-colors disabled:opacity-40"
                  title="Linisin ang lahat ng nakasalang na larawan"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                {/* Close Button */}
                <button
                  onClick={() => setIsGalleryQueueOpen(false)}
                  className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 transition-colors"
                  title="Isara ang Gallery Table"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Main Content Area: Horizontal 4-Box Sets with Adaptive Dynamic Shrinking */}
            <div className="p-3 sm:p-4 overflow-y-auto max-h-[calc(95vh-130px)] space-y-3">
              {/* Active Sequential Scanner Status Banner */}
              {isSequentialScanning && (
                <div className="p-3 rounded-2xl bg-emerald-950/90 border-2 border-emerald-400 text-emerald-300 flex items-center justify-between gap-3 shadow-lg">
                  <div className="flex items-center gap-2.5">
                    <RefreshCw className="w-5 h-5 animate-spin text-emerald-400 shrink-0" />
                    <div>
                      <div className="text-xs font-black text-white flex items-center gap-2">
                        <span>⚡ TURBO 5s/10s AI VISION SCANNER (0% LAG)</span>
                        <span className="px-1.5 py-0.2 rounded bg-emerald-500 text-slate-950 text-[9px] font-black">
                          FIFO ACTIVE
                        </span>
                      </div>
                      <div className="text-[11px] text-emerald-300">
                        Kasalukuyang ini-iscan ang <strong>{currentScanningBoxNum ? `Box ${currentScanningBoxNum}` : 'pinakaunang pumasok'}</strong> (5s malinaw / 10s malabo). Kahit i-close/i-X ang modal, <strong>patuloy padin ang scan sa background</strong> at automatic na papasok sa Table at PDS Pictures!
                      </div>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-xs font-black text-amber-300">
                      {galleryBoxes.filter(b => b.status === 'queued').length} natitirang nakapila
                    </div>
                  </div>
                </div>
              )}

              {/* Dynamic Sizing Logic: As rowCount grows up to 50 sets, boxes adaptively shrink */}
              {(() => {
                const totalSets = Math.ceil(galleryBoxes.length / 4);
                
                // Determine dynamic compact scale level based on total box sets
                let densityClass = 'comfortable';
                let boxHeightClass = 'h-20 sm:h-22';
                let thumbSizeClass = 'w-14 h-16 sm:w-16 sm:h-18';
                let labelTextClass = 'text-xs';
                let subTextClass = 'text-[10px]';
                let gapClass = 'gap-2';

                if (totalSets > 15) {
                  // Ultra-compact dense mode (16 to 50 sets)
                  densityClass = 'ultra-dense';
                  boxHeightClass = 'h-13 sm:h-14';
                  thumbSizeClass = 'w-9 h-11 sm:w-10 sm:h-12';
                  labelTextClass = 'text-[10px]';
                  subTextClass = 'text-[8px]';
                  gapClass = 'gap-1.5';
                } else if (totalSets > 6) {
                  // Dense mode (7 to 15 sets)
                  densityClass = 'dense';
                  boxHeightClass = 'h-16 sm:h-17';
                  thumbSizeClass = 'w-11 h-13 sm:w-12 sm:h-14';
                  labelTextClass = 'text-[11px]';
                  subTextClass = 'text-[9px]';
                  gapClass = 'gap-1.5';
                } else if (totalSets > 2) {
                  // Compact mode (3 to 6 sets)
                  densityClass = 'compact';
                  boxHeightClass = 'h-18 sm:h-20';
                  thumbSizeClass = 'w-12 h-14 sm:w-14 sm:h-16';
                  labelTextClass = 'text-xs';
                  subTextClass = 'text-[9px]';
                  gapClass = 'gap-2';
                }

                // Group boxes into horizontal rows of 4
                const rows: GalleryBoxItem[][] = [];
                for (let i = 0; i < galleryBoxes.length; i += 4) {
                  rows.push(galleryBoxes.slice(i, i + 4));
                }

                return (
                  <div className="space-y-2.5">
                    {/* Capacity Indicator & Quick Expand Bar */}
                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 px-1">
                      <span className="flex items-center gap-1.5">
                        <Table className="w-3.5 h-3.5 text-amber-400" />
                        <span>Kapasidad ng Table: {totalSets} / 50 Serye ({galleryBoxes.length} / 200 Max Boxes)</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-mono">
                          Scale: {densityClass.toUpperCase()}
                        </span>
                      </span>

                      {totalSets < 50 && (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleAdd4MoreBoxes(1)}
                            className="text-amber-400 hover:text-amber-300 flex items-center gap-0.5 hover:underline"
                          >
                            <Plus className="w-3 h-3" />
                            <span>+4 Box</span>
                          </button>
                          {totalSets <= 40 && (
                            <button
                              onClick={() => handleAdd4MoreBoxes(10)}
                              className="text-indigo-400 hover:text-indigo-300 flex items-center gap-0.5 hover:underline"
                            >
                              <Plus className="w-3 h-3" />
                              <span>+10 Serye</span>
                            </button>
                          )}
                          <button
                            onClick={() => handleAdd4MoreBoxes(50 - totalSets)}
                            className="text-emerald-400 hover:text-emerald-300 flex items-center gap-0.5 hover:underline font-mono"
                          >
                            <span>Punuin sa 50 Sets</span>
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Render each horizontal row of 4 boxes */}
                    {rows.map((rowBoxes, rowIndex) => {
                      const firstBoxNum = rowIndex * 4 + 1;
                      const lastBoxNum = rowIndex * 4 + rowBoxes.length;
                      const hasAnyImageInRow = rowBoxes.some(b => !!b.imageSrc);

                      return (
                        <div
                          key={rowIndex}
                          className="p-2 sm:p-2.5 rounded-2xl bg-slate-950/70 border border-slate-800/90 hover:border-slate-700 transition-all flex flex-col md:flex-row items-stretch md:items-center gap-2 shadow-sm"
                        >
                          {/* Row Left Label Tag */}
                          <div className="flex md:flex-col items-center justify-between md:justify-center px-2 py-1 md:py-0 md:w-32 shrink-0 border-b md:border-b-0 md:border-r border-slate-800/80 text-left">
                            <span className="text-[11px] font-black text-amber-300 flex items-center gap-1">
                              <span className="w-4 h-4 rounded bg-amber-500/20 text-amber-300 flex items-center justify-center text-[10px] font-mono font-bold">
                                {rowIndex + 1}
                              </span>
                              <span>Serye {rowIndex + 1}</span>
                            </span>
                            <span className="text-[10px] font-black text-emerald-400 font-mono">
                              👉 ROW {rowIndex + 1} SA TABLE
                            </span>
                            <span className="text-[9px] text-slate-400 font-mono">
                              Box {firstBoxNum} - {lastBoxNum} (Pahina 1-4)
                            </span>
                          </div>

                          {/* Horizontal 4-Box Grid */}
                          <div className={`grid grid-cols-2 lg:grid-cols-4 ${gapClass} flex-1`}>
                            {rowBoxes.map((box) => {
                              const isScanningThis = isSequentialScanning && currentScanningBoxNum === box.boxNumber;
                              const hasImage = !!box.imageSrc;
                              const seryeNumber = rowIndex + 1;
                              const pageNumInSet = ((box.boxNumber - 1) % 4) + 1;

                              let pageThemeLabel = `Pahina ${pageNumInSet}`;
                              if (pageNumInSet === 1) pageThemeLabel = 'Pahina 1 (Personal)';
                              else if (pageNumInSet === 2) pageThemeLabel = 'Pahina 2 (Edukasyon)';
                              else if (pageNumInSet === 3) pageThemeLabel = 'Pahina 3 (Trabaho)';
                              else if (pageNumInSet === 4) pageThemeLabel = 'Pahina 4 (Skills)';

                              return (
                                <div
                                  key={box.id}
                                  className={`${boxHeightClass} p-1.5 rounded-xl border transition-all flex items-center gap-2 overflow-hidden shadow-sm relative ${
                                    isScanningThis
                                      ? 'bg-slate-900 border-emerald-400 shadow-emerald-500/20 ring-1 ring-emerald-400'
                                      : hasImage
                                      ? 'bg-slate-900/90 border-amber-500/40 hover:border-amber-400'
                                      : 'bg-slate-950/50 border-slate-800 hover:border-slate-700'
                                  }`}
                                >
                                  {/* Left: Mini Thumbnail or Upload Action */}
                                  {hasImage ? (
                                    <div
                                      onClick={() =>
                                        setFullScreenPdsImage({
                                          id: box.id,
                                          src: box.imageSrc!,
                                          applicantName: `Row ${seryeNumber} - ${pageThemeLabel}`,
                                          pageTitle: `Box ${box.boxNumber} (PDS Pahina ${pageNumInSet})`,
                                          zoom: 1,
                                          rotation: 0,
                                        })
                                      }
                                      className={`${thumbSizeClass} rounded-lg bg-slate-950 border border-slate-700 overflow-hidden shrink-0 relative group cursor-pointer flex items-center justify-center`}
                                    >
                                      <img
                                        src={box.imageSrc || undefined}
                                        alt={`Box ${box.boxNumber}`}
                                        className="w-full h-full object-cover"
                                      />

                                      {/* Laser Scanning Animation */}
                                      {isScanningThis && (
                                        <div className="absolute inset-0 pointer-events-none overflow-hidden">
                                          <div className="w-full h-1 bg-emerald-400 shadow-[0_0_10px_#10b981] animate-laser-scan absolute top-0 left-0" />
                                          <div className="absolute inset-0 bg-emerald-500/15" />
                                        </div>
                                      )}

                                      {/* Hover View Icon */}
                                      {!isScanningThis && (
                                        <div className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                          <Eye className="w-3 h-3 text-emerald-300" />
                                        </div>
                                      )}
                                    </div>
                                  ) : (
                                    <label className={`${thumbSizeClass} rounded-lg bg-slate-800/60 hover:bg-slate-800 border border-dashed border-slate-700 hover:border-emerald-500 flex flex-col items-center justify-center text-slate-400 hover:text-white cursor-pointer shrink-0 transition-colors`}>
                                      <input
                                        type="file"
                                        accept="image/*"
                                        className="hidden"
                                        onChange={(e) => {
                                          const file = e.target.files?.[0];
                                          if (!file) return;
                                          const reader = new FileReader();
                                          reader.onload = (event) => {
                                            const base64 = event.target?.result as string;
                                            if (base64) {
                                              handleAssignPhotoToBox(base64, box.boxNumber);
                                            }
                                          };
                                          reader.readAsDataURL(file);
                                        }}
                                      />
                                      <Plus className="w-3.5 h-3.5" />
                                      <span className="text-[8px] font-bold">Pahina {pageNumInSet}</span>
                                    </label>
                                  )}

                                  {/* Right: Info & Controls */}
                                  <div className="flex-1 min-w-0 flex flex-col justify-between h-full py-0.5">
                                    {/* Top Row: Box badge & Status */}
                                    <div className="flex items-center justify-between gap-1">
                                      <span className="font-mono font-black text-[10px] text-amber-300 flex items-center gap-1 min-w-0">
                                        <span className="w-3.5 h-3.5 rounded bg-amber-500/20 flex items-center justify-center text-[8px] shrink-0">
                                          {box.boxNumber}
                                        </span>
                                        <span className="truncate text-[9px] text-slate-200">{pageThemeLabel}</span>
                                      </span>

                                      {/* Mini Status Pill */}
                                      {isScanningThis ? (
                                        <span className="text-[8px] font-black px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 animate-pulse">
                                          Scan...
                                        </span>
                                      ) : box.status === 'completed' ? (
                                        <span className="text-[8px] font-black px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/50 flex items-center gap-0.5">
                                          <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />
                                          <span>NA-DETECT</span>
                                        </span>
                                      ) : hasImage ? (
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            handleRemoveSingleBoxPhoto(box.boxNumber);
                                          }}
                                          className="text-slate-500 hover:text-rose-400 transition-colors p-0.5"
                                          title="Alisin ang picture"
                                        >
                                          <Trash2 className="w-3 h-3" />
                                        </button>
                                      ) : (
                                        <span className="text-[8px] text-slate-500 font-mono">Row {seryeNumber}</span>
                                      )}
                                    </div>

                                    {/* Middle Row: Detected Header Content & Person Name Preview */}
                                    {box.personName && (
                                      <div className="my-0.5 space-y-0.5">
                                        <div className="text-[9px] font-black text-emerald-300 truncate bg-emerald-950/70 px-1.5 py-0.5 rounded border border-emerald-500/30 flex items-center gap-1">
                                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping shrink-0" />
                                          <span className="truncate">{box.personName}</span>
                                        </div>
                                        {box.extractedData && (
                                          <div className="text-[8px] text-slate-300 font-mono truncate bg-slate-950/90 px-1 py-0.5 rounded border border-slate-800/80">
                                            {Object.entries(box.extractedData)
                                              .filter(([_, v]) => !isValuePlaceholderOrNA(v) && String(v).trim())
                                              .slice(0, 2)
                                              .map(([k, v]) => `${k.split(' ')[0]}: ${v}`)
                                              .join(' | ') || 'Header data confirmed'}
                                          </div>
                                        )}
                                      </div>
                                    )}

                                    {/* Bottom Row: Quick Scan or Fast Snap Trigger */}
                                    <div className="flex items-center justify-between gap-1 mt-auto">
                                      {hasImage ? (
                                        <button
                                          onClick={async (e) => {
                                            e.stopPropagation();
                                            if (isSequentialScanning || !box.imageSrc) return;
                                            setGalleryBoxes((prev) =>
                                              prev.map((b) =>
                                                b.boxNumber === box.boxNumber
                                                  ? { ...b, status: 'queued', enqueuedAt: Date.now() }
                                                  : b
                                              )
                                            );
                                            triggerSequentialAiBoxProcessing();
                                          }}
                                          disabled={isSequentialScanning}
                                          className={`w-full py-0.5 px-1.5 rounded-lg font-black text-[9px] flex items-center justify-center gap-1 transition-all active:scale-95 disabled:opacity-40 ${
                                            box.status === 'completed'
                                              ? 'bg-emerald-700/80 hover:bg-emerald-600 text-emerald-100 border border-emerald-500/40'
                                              : 'bg-emerald-600/90 hover:bg-emerald-600 text-white'
                                          }`}
                                        >
                                          <Zap className="w-2.5 h-2.5 text-yellow-300 fill-yellow-300" />
                                          <span>{box.status === 'completed' ? 'Re-scan Box' : `I-scan sa Row ${seryeNumber}`}</span>
                                        </button>
                                      ) : (
                                        <button
                                          onClick={() => {
                                            setIsGalleryQueueOpen(false);
                                            setIsLiveScannerOpen(true);
                                          }}
                                          className="text-[9px] text-emerald-400 hover:text-emerald-300 flex items-center gap-1 hover:underline font-bold"
                                        >
                                          <Camera className="w-2.5 h-2.5" />
                                          <span>Kumuha</span>
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>

            {/* Modal Bottom Bar */}
            <div className="px-4 sm:px-6 py-2.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between flex-wrap gap-2 text-xs">
              <div className="flex items-center gap-2 text-slate-400 text-[11px]">
                <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>
                  <strong>Pahiga na Queue:</strong> Kapag na-scan ng AI ang PDS, awtomatikong mabubura ang picture sa box at lilipat sa <strong>PDS Pictures</strong> at Table.
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsGalleryQueueOpen(false)}
                  className="px-3.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs border border-slate-700 transition-colors"
                >
                  Isara
                </button>

                <button
                  onClick={handleStartScanAllGalleryBoxes}
                  disabled={isSequentialScanning || galleryBoxes.every(b => !b.imageSrc)}
                  className="px-3.5 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-md shadow-emerald-600/30 flex items-center gap-1.5 disabled:opacity-40 cursor-pointer transition-all active:scale-95"
                >
                  <Zap className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300" />
                  <span>I-scan Lahat ng Laman</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* AI BOOST ENGINE STATUS & CONTROLS MODAL */}
      {showAiBoostModal && (
        <div
          onClick={() => setShowAiBoostModal(false)}
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-150"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-md w-full bg-white rounded-3xl border-2 border-emerald-500 overflow-hidden shadow-2xl p-5 space-y-4 animate-in zoom-in-95 duration-200"
          >
            {/* Header with Glowing Animated Zap */}
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-amber-500 text-white flex items-center justify-center shadow-lg shadow-emerald-600/30 animate-pulse">
                  <Zap className="w-6 h-6 text-amber-200 fill-amber-300" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-base flex items-center gap-1.5">
                    <span>AI Boost Engine</span>
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                      3x Turbo Speed
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    Awtomatikong nagpapabilis ng pag-upload, OCR scan, at paghahanap
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowAiBoostModal(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Feature Highlights Grid */}
            <div className="space-y-2.5 pt-1">
              <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200/80 flex items-start gap-3">
                <div className="p-2 rounded-xl bg-emerald-600 text-white shrink-0 shadow-xs">
                  <Rocket className="w-4 h-4" />
                </div>
                <div className="space-y-0.5">
                  <h4 className="text-xs font-black text-emerald-950">Mabilis na Upload & Compression</h4>
                  <p className="text-[11px] text-emerald-800 leading-tight">
                    Binabawasan ang file size ng 75% nang nananatiling malinaw ang bawat sulat-kamay at text.
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200/80 flex items-start gap-3">
                <div className="p-2 rounded-xl bg-amber-600 text-white shrink-0 shadow-xs">
                  <Zap className="w-4 h-4 fill-amber-300" />
                </div>
                <div className="space-y-0.5">
                  <h4 className="text-xs font-black text-amber-950">Iisa-Isang Precision Vision Extraction</h4>
                  <p className="text-[11px] text-amber-800 leading-tight">
                    Iisa-isahing sinusuri ang bawat larawan (hindi pinagsasabay-sabay) para walang payload lag, mabilis ang upload, at 100% tumpak ang pagkuha ng bawat rekord.
                  </p>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200/80 flex items-start gap-3">
                <div className="p-2 rounded-xl bg-blue-600 text-white shrink-0 shadow-xs">
                  <Search className="w-4 h-4" />
                </div>
                <div className="space-y-0.5">
                  <h4 className="text-xs font-black text-blue-950">Instant Deep Search Index</h4>
                  <p className="text-[11px] text-blue-800 leading-tight">
                    Agad na nahahanap ang mga pangalan, tirahan, cell numbers, at bawat rekord sa loob ng ilang millisecond.
                  </p>
                </div>
              </div>
            </div>

            {/* Toggle Status Bar */}
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Gauge className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-bold text-slate-800">Katayuan ng AI Boost:</span>
              </div>
              <button
                onClick={() => {
                  const nextState = !isAiBoostEnabled;
                  setIsAiBoostEnabled(nextState);
                  triggerAutoSaveToast(
                    nextState
                      ? '⚡ AI Boost: Pinagana ang Turbo Speed Engine!'
                      : 'AI Boost: Naka-standard mode.'
                  );
                }}
                className={`px-3 py-1 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 shadow-xs ${
                  isAiBoostEnabled
                    ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                    : 'bg-slate-300 text-slate-700 hover:bg-slate-400'
                }`}
              >
                {isAiBoostEnabled ? (
                  <>
                    <Zap className="w-3.5 h-3.5 fill-amber-300 text-amber-200" />
                    <span>Naka-ON (Turbo)</span>
                  </>
                ) : (
                  <>
                    <ZapOff className="w-3.5 h-3.5" />
                    <span>Naka-OFF</span>
                  </>
                )}
              </button>
            </div>

            <button
              onClick={() => setShowAiBoostModal(false)}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-md transition-all active:scale-95"
            >
              Naiintindihan Ko (Ipagpatuloy)
            </button>
          </div>
        </div>
      )}

      {/* ✨ MODAL: TEXT GENERATED TABLE & CUSTOM HEADERS EXTRACTOR */}
      {isTextGeneratedModalOpen && (
        <div
          onClick={() => setIsTextGeneratedModalOpen(false)}
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-150"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-3xl max-h-[92vh] bg-white rounded-3xl border-2 border-purple-500 overflow-hidden shadow-2xl flex flex-col animate-in zoom-in-95 duration-200"
          >
            {/* Modal Header */}
            <div className="px-5 py-4 bg-gradient-to-r from-violet-900 via-purple-900 to-slate-900 text-white flex items-center justify-between border-b border-purple-700/50 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-400 via-purple-500 to-violet-600 text-white flex items-center justify-center shadow-lg shadow-purple-600/30 font-black shrink-0">
                  <Wand2 className="w-6 h-6 text-yellow-300 fill-yellow-300 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base sm:text-lg font-black tracking-tight text-white flex items-center gap-2">
                      <span>TEXT GENERATED: AI TABLE HEADERS BUILDER</span>
                    </h3>
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-yellow-400 text-slate-950 shadow-xs">
                      DYNAMIC AI VISION
                    </span>
                  </div>
                  <p className="text-xs text-purple-200 font-medium">
                    Itakda ang mga Column Header ng Table. Hahanapin ng AI ang mga totoong datos lamang (0% imbento / 0% hallucination).
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsTextGeneratedModalOpen(false)}
                className="p-2 rounded-xl text-purple-300 hover:text-white hover:bg-white/10 transition-colors"
                title="Isara"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1 text-slate-800 text-xs">
              {/* 1. Quick Presets Selection */}
              <div className="space-y-2">
                <label className="block text-xs font-black text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-purple-600" />
                  <span>1. Pumili sa mga Handa nang Template (Presets)</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
                  {TARGET_PRESET_TEMPLATES.map((tmpl) => {
                    const isSelected =
                      activeTemplateName === tmpl.name ||
                      JSON.stringify(activeTargetHeaders) === JSON.stringify(tmpl.headers);
                    return (
                      <button
                        key={tmpl.id}
                        onClick={() => {
                          setActiveTemplateName(tmpl.name);
                          setActiveTargetHeaders(tmpl.headers);
                          setCustomHeadersInputText(tmpl.headers.join(', '));
                        }}
                        className={`p-2.5 rounded-2xl text-left border transition-all flex flex-col justify-between gap-1 group ${
                          isSelected
                            ? 'bg-purple-50 border-purple-600 ring-2 ring-purple-600/30 text-purple-950 font-black shadow-xs'
                            : 'bg-slate-50 hover:bg-purple-50/50 border-slate-200 text-slate-700 hover:border-purple-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[11px] font-extrabold truncate max-w-[130px] block">
                            {tmpl.name}
                          </span>
                          <span
                            className={`text-[9px] font-mono px-1.5 py-0.2 rounded-full font-bold ${
                              isSelected
                                ? 'bg-purple-600 text-white'
                                : 'bg-slate-200 text-slate-700 group-hover:bg-purple-200'
                            }`}
                          >
                            {tmpl.headers.length} Cols
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-500 line-clamp-1 font-medium">{tmpl.description}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 2. Custom Header Textarea (Comma or Newline separated) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-black text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <Edit3 className="w-4 h-4 text-purple-600" />
                    <span>2. I-type o I-paste ang Custom Column Headers (Pinaghihiwalay ng Comma o Bagong Linya)</span>
                  </label>
                  <span className="text-[11px] font-mono font-bold text-purple-700 bg-purple-100 px-2 py-0.5 rounded-full">
                    Kabuuan: {activeTargetHeaders.length} Columns
                  </span>
                </div>

                <textarea
                  rows={3}
                  value={customHeadersInputText}
                  onChange={(e) => {
                    const text = e.target.value;
                    setCustomHeadersInputText(text);
                    const parsed = text
                      .split(/[\n,]+/)
                      .map((h) => h.trim())
                      .filter((h) => h.length > 0);
                    if (parsed.length > 0) {
                      setActiveTargetHeaders(Array.from(new Set(parsed)));
                    }
                  }}
                  placeholder="Halimbawa: PANGALAN, EDAD, KASARIAN, TIRAHAN, CONTACT NO, TIN, TRABAHO..."
                  className="w-full p-3 rounded-2xl border-2 border-slate-200 focus:border-purple-600 focus:ring-4 focus:ring-purple-500/15 font-mono text-xs text-slate-900 outline-none leading-relaxed resize-y shadow-inner"
                />

                {/* Add single custom tag input */}
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="text"
                    value={customNewSingleHeader}
                    onChange={(e) => setCustomNewSingleHeader(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && customNewSingleHeader.trim()) {
                        e.preventDefault();
                        const val = customNewSingleHeader.trim();
                        if (!activeTargetHeaders.includes(val)) {
                          const updated = [...activeTargetHeaders, val];
                          setActiveTargetHeaders(updated);
                          setCustomHeadersInputText(updated.join(', '));
                          setCustomNewSingleHeader('');
                        }
                      }
                    }}
                    placeholder="+ Magdagdag ng isang bagong header column..."
                    className="flex-1 px-3 py-2 rounded-xl border border-slate-300 focus:border-purple-500 text-xs outline-none"
                  />
                  <button
                    onClick={() => {
                      if (customNewSingleHeader.trim()) {
                        const val = customNewSingleHeader.trim();
                        if (!activeTargetHeaders.includes(val)) {
                          const updated = [...activeTargetHeaders, val];
                          setActiveTargetHeaders(updated);
                          setCustomHeadersInputText(updated.join(', '));
                          setCustomNewSingleHeader('');
                        }
                      }
                    }}
                    className="px-3 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs flex items-center gap-1 shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Idagdag</span>
                  </button>
                  <button
                    onClick={() => {
                      setActiveTargetHeaders(TARGET_REQUESTED_HEADERS);
                      setActiveTemplateName('Personal Data Sheet (19 Columns)');
                      setCustomHeadersInputText(TARGET_REQUESTED_HEADERS.join(', '));
                    }}
                    className="px-2.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
                    title="Ibalik sa default na 19 Columns ng PDS"
                  >
                    I-reset sa PDS
                  </button>
                </div>
              </div>

              {/* 3. Live Chips of Active Table Headers */}
              <div className="space-y-2 p-3 bg-purple-50/50 rounded-2xl border border-purple-200/60">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-black uppercase text-purple-900">
                    Aktibong Table Columns ({activeTargetHeaders.length}):
                  </span>
                  <span className="text-[10px] text-slate-500">Pindutin ang [×] para tanggalin ang column</span>
                </div>
                <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto p-1 scrollbar-thin">
                  {activeTargetHeaders.map((hdr, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-white text-purple-950 border border-purple-300 text-[11px] font-bold shadow-2xs group hover:border-purple-500"
                    >
                      <span className="text-purple-400 font-mono text-[9px]">{idx + 1}.</span>
                      <span className="truncate max-w-[200px]">{hdr}</span>
                      <button
                        onClick={() => {
                          const updated = activeTargetHeaders.filter((_, i) => i !== idx);
                          setActiveTargetHeaders(updated);
                          setCustomHeadersInputText(updated.join(', '));
                        }}
                        className="text-slate-400 hover:text-rose-600 transition-colors ml-0.5 p-0.5 rounded"
                        title={`Alisin ang "${hdr}"`}
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              {/* Strict 0% Hallucination & 5-Minute Inactivity Guarantee Banner */}
              <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-2xl flex items-start gap-2.5 text-emerald-950 text-xs">
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <p className="font-extrabold">Mahigpit na Garantisadong Katumpakan (0% Hallucination):</p>
                  <p className="text-[11px] text-emerald-800 leading-relaxed">
                    Tanging ang mga totoong nakikita sa larawan na tugma sa mga header sa itaas ang ie-extract. Kung walang makitang datos, patuloy ang pag-scan hanggang 5 minuto bago awtomatikong magpahinga ang camera scanner.
                  </p>
                </div>
              </div>
            </div>

            {/* Modal Actions Footer */}
            <div className="px-5 py-3.5 bg-slate-100 border-t border-slate-200 flex items-center justify-between flex-wrap gap-2">
              <button
                onClick={() => setIsTextGeneratedModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-700 bg-white hover:bg-slate-200 border border-slate-300 transition-colors"
              >
                Kanselahin
              </button>

              <div className="flex items-center gap-2 flex-wrap">
                {/* Option A: Apply to Table Only */}
                <button
                  onClick={() =>
                    handleApplyCustomHeaders(activeTargetHeaders, activeTemplateName, 'apply_only')
                  }
                  className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs transition-all shadow-sm active:scale-95"
                >
                  I-apply sa Table
                </button>

                {/* Option B: Apply and Upload Picture */}
                <button
                  onClick={() =>
                    handleApplyCustomHeaders(activeTargetHeaders, activeTemplateName, 'upload')
                  }
                  className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs shadow-md shadow-indigo-600/25 flex items-center gap-1.5 transition-all active:scale-95 border border-indigo-400"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Mag-upload ng Larawan</span>
                </button>

                {/* Option C: Apply and Open AI Camera Scanner */}
                <button
                  onClick={() =>
                    handleApplyCustomHeaders(activeTargetHeaders, activeTemplateName, 'scanner')
                  }
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs shadow-md shadow-emerald-700/30 flex items-center gap-2 transition-all active:scale-95 border border-emerald-400"
                >
                  <Camera className="w-4 h-4 text-emerald-200 animate-pulse" />
                  <span>I-apply at Buksan ang AI Camera Scanner</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Gemini API Key Modal for Netlify & Static Hostings */}
      {isApiKeyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-base">Gemini API Key (Netlify Setup)</h3>
                  <p className="text-xs text-slate-500">Kailangan ng API Key upang makapag-extract sa Netlify static host</p>
                </div>
              </div>
              <button
                onClick={() => setIsApiKeyModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="bg-amber-50/60 border border-amber-200/80 rounded-2xl p-3 text-xs text-amber-900 leading-relaxed">
                Naka-deploy ang app sa <strong>Netlify</strong> (static hosting). Dahil walang Node backend server sa static hostings, gagamitin ng browser ang iyong libreng Google Gemini API Key direct sa AI Vision.
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Iyong Google Gemini API Key:
                </label>
                <input
                  type="password"
                  value={geminiApiKeyInput}
                  onChange={(e) => setGeminiApiKeyInput(e.target.value)}
                  placeholder="AIzaSy..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 text-xs font-mono outline-none"
                />
              </div>

              <div className="text-[11px] text-slate-500 flex items-center justify-between">
                <span>Wala ka pang key?</span>
                <a
                  href="https://aistudio.google.com/app/apikey"
                  target="_blank"
                  rel="noreferrer"
                  className="text-emerald-600 font-bold hover:underline flex items-center gap-1"
                >
                  Kumuha ng libreng Key sa Google AI Studio <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
              <button
                onClick={() => setIsApiKeyModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Kanselahin
              </button>
              <button
                onClick={() => {
                  setClientGeminiApiKey(geminiApiKeyInput);
                  setIsApiKeyModalOpen(false);
                  triggerAutoSaveToast('Na-save ang iyong Gemini API Key sa browser!');
                  if (selectedImages.length > 0) {
                    handleScanDocument();
                  }
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition-all shadow-sm"
              >
                I-save Key at I-scan
              </button>
            </div>
          </div>
        </div>
      )}


      {/* ROW DELETED PERMANENTLY POPUP MODAL */}
      {deletedRowPopupInfo?.isOpen && (
        <div
          onClick={() => setDeletedRowPopupInfo(null)}
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-md w-full bg-slate-900 border-2 border-rose-500 rounded-3xl p-6 shadow-2xl text-slate-100 text-center space-y-4 animate-in zoom-in-95 duration-200"
          >
            <div className="w-16 h-16 rounded-full bg-rose-500/20 border-2 border-rose-500 text-rose-400 flex items-center justify-center mx-auto shadow-lg shadow-rose-500/30 animate-pulse">
              <Trash2 className="w-8 h-8 text-rose-500" />
            </div>

            <div className="space-y-1.5">
              <div className="inline-block px-3 py-1 rounded-full bg-rose-500/20 border border-rose-500/50 text-rose-300 font-black text-[11px] uppercase tracking-wider mb-1">
                DELETED PERMANENTLY
              </div>
              <h3 className="text-xl font-black text-white">
                Permanente Nang Nabura!
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Ang buong data ng row {deletedRowPopupInfo.rowName ? <strong className="text-amber-300 font-bold">"{deletedRowPopupInfo.rowName}"</strong> : ''} ay <strong className="text-rose-400 font-bold">automatic at permanenteng nabura</strong> sa Table, Local Cache, at Firebase Cloud Database!
              </p>
            </div>

            <div className="pt-2">
              <button
                onClick={() => setDeletedRowPopupInfo(null)}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-rose-600 to-red-500 hover:from-rose-500 hover:to-red-400 text-white font-extrabold text-sm shadow-xl shadow-rose-600/30 transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4 text-white" />
                <span>OK, Naintindihan Ko!</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 🛑 DUPLICATE DATA DETECTED - PROACTIVE BLOCKING POPUP MODAL */}
      {duplicateWarningInfo?.isOpen && (
        <div
          onClick={() => setDuplicateWarningInfo(null)}
          className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-lg w-full bg-slate-900 border-2 border-amber-500 rounded-3xl p-6 sm:p-7 shadow-2xl text-slate-100 text-center space-y-4 animate-in zoom-in-95 duration-200"
          >
            <div className="w-16 h-16 rounded-3xl bg-amber-500/20 border-2 border-amber-500/80 text-amber-400 flex items-center justify-center mx-auto shadow-lg shadow-amber-500/30 animate-bounce">
              <AlertTriangle className="w-8 h-8 text-amber-400" />
            </div>

            <div className="space-y-2">
              <div className="inline-block px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/50 text-amber-300 font-black text-[11px] uppercase tracking-wider">
                DUPLICATE DATA DETECTED • HINDI NAI-UPLOAD
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-white">
                May Kaparehong Name / Data Na!
              </h3>
              <div className="p-3.5 bg-amber-950/60 border border-amber-600/50 rounded-2xl text-amber-200 font-medium text-xs sm:text-sm text-left space-y-2">
                <p>
                  <strong className="text-amber-300 font-bold">Pangalan:</strong> {duplicateWarningInfo.duplicateName}
                </p>
                <p className="text-xs text-amber-100/90 leading-relaxed">
                  {duplicateWarningInfo.message || 'Na-detect na may umiiral nang datos o larawan na may kaparehong pangalan. Hindi ito nai-upload upang maiwasan ang duplicate data.'}
                </p>
                <p className="text-[11px] text-amber-300 font-bold border-t border-amber-600/40 pt-2">
                  💡 Paalala: Kung gusto mong ma-upload ang bago o panibagong larawan nito, burahin mo muna ang dating naka-upload na rekord sa PDS Pictures o Table.
                </p>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-center gap-3">
              <button
                onClick={() => {
                  setDuplicateWarningInfo(null);
                  setIsPdsGalleryOpen(true);
                }}
                className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs sm:text-sm border border-slate-700 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <ImageIcon className="w-4 h-4 text-indigo-400" />
                <span>Buksan ang PDS Pictures</span>
              </button>
              <button
                onClick={() => setDuplicateWarningInfo(null)}
                className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs sm:text-sm shadow-xl shadow-amber-500/30 transition-all active:scale-95 cursor-pointer flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4 text-slate-950" />
                <span>Naintindihan Ko</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 📋 1. TABLE LIST MODAL (Makikita ang lahat ng Table, buksan, at pwede idelete) */}
      {isTableListModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
            {/* Modal Header */}
            <div className="px-5 py-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between border-b border-indigo-900/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-400/40 flex items-center justify-center text-indigo-300 shadow-inner">
                  <Table className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base sm:text-lg flex items-center gap-2">
                    <span>MGA NAKA-SAVE NA TABLE LIST</span>
                    <span className="px-2 py-0.5 rounded-full bg-indigo-500 text-white text-xs font-mono font-bold">
                      {combinedDatabaseDocs.length} Tables
                    </span>
                  </h3>
                  <p className="text-xs text-indigo-200">
                    Pumili ng table na bubuksan, i-download sa Excel, o burahin
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setIsTableListModalOpen(false);
                    setCustomHeadersInputText(activeTargetHeaders.join(', '));
                    setIsTextGeneratedModalOpen(true);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs shadow-sm flex items-center gap-1.5 transition-all active:scale-95 border border-emerald-400/40 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Mag-add ng Table</span>
                </button>
                <button
                  onClick={() => setIsTableListModalOpen(false)}
                  className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Search & Stats Bar */}
            <div className="p-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-3 flex-wrap">
              <div className="relative flex-1 min-w-[240px]">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={tableListSearch}
                  onChange={(e) => setTableListSearch(e.target.value)}
                  placeholder="Maghanap ng table ayon sa pamagat, headers, o aplikante..."
                  className="w-full pl-9 pr-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-800 placeholder-slate-400 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="flex items-center gap-2 text-xs font-bold text-slate-600">
                <button
                  onClick={() => {
                    setIsTableListModalOpen(false);
                    exportAllTablesToExcel(combinedDatabaseDocs);
                  }}
                  disabled={combinedDatabaseDocs.length === 0}
                  className="px-3 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-black shadow-sm flex items-center gap-1.5 transition-all disabled:opacity-50 active:scale-95 cursor-pointer"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  <span>I-download Lahat sa Isang Excel Workbook</span>
                </button>
              </div>
            </div>

            {/* Tables Grid List */}
            <div className="p-4 sm:p-5 overflow-y-auto max-h-[60vh] space-y-3">
              {combinedDatabaseDocs.length === 0 ? (
                <div className="p-10 text-center space-y-3 bg-slate-50 rounded-2xl border border-dashed border-slate-300">
                  <Table className="w-12 h-12 text-slate-400 mx-auto opacity-60" />
                  <div className="space-y-1">
                    <p className="font-extrabold text-slate-700 text-sm">Walang Table na Naka-save</p>
                    <p className="text-xs text-slate-500">
                      Pindutin ang "Text Generated" button sa toolbar o "+ Mag-add ng Table" upang gumawa ng bagong table.
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      setIsTableListModalOpen(false);
                      setIsTextGeneratedModalOpen(true);
                    }}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs shadow-md transition-all inline-flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Gumawa ng Unang Table</span>
                  </button>
                </div>
              ) : (
                (() => {
                  const filtered = combinedDatabaseDocs.filter((tableItem) => {
                    if (!tableListSearch.trim()) return true;
                    const query = tableListSearch.toLowerCase();
                    const titleMatch = (tableItem.title || '').toLowerCase().includes(query);
                    const personMatch = (tableItem.detectedPersonName || '').toLowerCase().includes(query);
                    const headerMatch = (tableItem.sections?.[0]?.headers || []).some((h) =>
                      h.toLowerCase().includes(query)
                    );
                    return titleMatch || personMatch || headerMatch;
                  });

                  if (filtered.length === 0) {
                    return (
                      <div className="p-8 text-center bg-slate-50 rounded-2xl text-slate-500 text-xs">
                        Walang table na tumugma sa paghahanap na "{tableListSearch}".
                      </div>
                    );
                  }

                  return filtered.map((tableItem, idx) => {
                    const isActive = result && result.id === tableItem.id;
                    const headers = tableItem.sections?.[0]?.headers || activeTargetHeaders || [];
                    const rowCount = tableItem.sections?.reduce((acc, s) => acc + (s.rows?.length || 0), 0) || 0;
                    const sheetCount = tableItem.sections?.length || 1;

                    return (
                      <div
                        key={tableItem.id || `table-idx-${idx}`}
                        className={`p-4 rounded-2xl border transition-all ${
                          isActive
                            ? 'bg-indigo-50/70 border-indigo-400 shadow-md ring-2 ring-indigo-500/20'
                            : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-sm'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3 flex-wrap">
                          <div className="space-y-1.5 flex-1 min-w-[200px]">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="w-6 h-6 rounded-lg bg-slate-900 text-white font-mono font-black text-xs flex items-center justify-center">
                                {idx + 1}
                              </span>
                              <h4 className="font-extrabold text-slate-900 text-sm sm:text-base">
                                {tableItem.title || `Table #${idx + 1}`}
                              </h4>
                              {isActive && (
                                <span className="px-2 py-0.5 rounded-full bg-emerald-600 text-white font-black text-[10px] tracking-wide uppercase shadow-xs">
                                  ✓ Kasalukuyang Aktibo
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-3 text-xs text-slate-500 flex-wrap">
                              <span className="flex items-center gap-1 font-bold text-slate-700">
                                <Layers className="w-3.5 h-3.5 text-indigo-600" />
                                <span>{sheetCount} Sheet{sheetCount > 1 ? 's' : ''}</span>
                              </span>
                              <span>•</span>
                              <span className="font-bold text-slate-700">
                                {rowCount} Row{rowCount > 1 ? 's' : ''} na may laman
                              </span>
                              <span>•</span>
                              <span className="font-bold text-slate-700">
                                {headers.length} Columns
                              </span>
                              <span>•</span>
                              <span>
                                {tableItem.scannedAt
                                  ? new Date(tableItem.scannedAt).toLocaleDateString('fil-PH', {
                                      month: 'short',
                                      day: 'numeric',
                                      year: 'numeric',
                                      hour: '2-digit',
                                      minute: '2-digit',
                                    })
                                  : 'Kamakailan'}
                              </span>
                            </div>

                            {/* Sample Column Chips Preview */}
                            <div className="flex items-center gap-1.5 flex-wrap pt-1">
                              {headers.slice(0, 6).map((h, hIdx) => (
                                <span
                                  key={hIdx}
                                  className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded-md text-[10px] font-mono text-slate-700 max-w-[150px] truncate"
                                  title={h}
                                >
                                  {h}
                                </span>
                              ))}
                              {headers.length > 6 && (
                                <span className="text-[10px] font-bold text-slate-500">
                                  +{headers.length - 6} iba pa
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Table Actions */}
                          <div className="flex items-center gap-2 self-center shrink-0 flex-wrap">
                            {/* Switch / Open Table */}
                            <button
                              onClick={() => handleSwitchActiveTable(tableItem)}
                              className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                                isActive
                                  ? 'bg-slate-200 text-slate-700 cursor-default'
                                  : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm active:scale-95'
                              }`}
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>{isActive ? 'Nasa Table na' : 'Buksan Table'}</span>
                            </button>

                            {/* Download Single Table Excel */}
                            <button
                              onClick={() => exportSingleTableToExcel(tableItem)}
                              className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                              title="I-download ang table na ito bilang Excel file"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">Excel</span>
                            </button>

                            {/* Delete Table Button */}
                            <button
                              onClick={() =>
                                setTableToDeleteConfirm({
                                  id: tableItem.id,
                                  title: tableItem.title || `Table #${idx + 1}`,
                                })
                              }
                              className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 hover:border-rose-300 font-bold text-xs flex items-center gap-1 transition-all active:scale-95 cursor-pointer"
                              title="Burahin ang Table na ito"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                              <span className="hidden sm:inline">Burahin</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  });
                })()
              )}
            </div>

            {/* Footer */}
            <div className="px-5 py-3.5 bg-slate-100 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600">
              <span>
                💡 Awtomatikong nai-sa-save ang bawat bagong table sa Cloud Database at Local Storage.
              </span>
              <button
                onClick={() => setIsTableListModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-700 bg-white hover:bg-slate-200 border border-slate-300 transition-colors cursor-pointer"
              >
                Isara
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 🗑️ TABLE DELETION CONFIRMATION MODAL */}
      {tableToDeleteConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="max-w-md w-full bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 space-y-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto border border-rose-200">
              <Trash2 className="w-7 h-7" />
            </div>

            <div className="space-y-1.5">
              <h3 className="text-lg font-black text-slate-900">Burahin ang Table?</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Sigurado ka bang nais mong burahin ang table na{' '}
                <strong className="text-rose-600 font-extrabold">"{tableToDeleteConfirm.title}"</strong>?
                Mawawala ang lahat ng rows at sheets na nakapaloob sa table na ito.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-center gap-2.5">
              <button
                onClick={() => setTableToDeleteConfirm(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 transition-all cursor-pointer"
              >
                Huwag Burahin
              </button>
              <button
                onClick={() => handleDeleteTable(tableToDeleteConfirm.id, tableToDeleteConfirm.title)}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-extrabold text-xs shadow-md shadow-rose-600/30 transition-all active:scale-95 cursor-pointer"
              >
                Oo, Burahin ang Table
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 📥 2. EXCEL DOWNLOAD TABLE SELECTION MODAL (Tatanungin kung anong table ang idadownload) */}
      {isDownloadTableModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden space-y-0">
            {/* Header */}
            <div className="px-5 py-4 bg-gradient-to-r from-emerald-800 via-green-800 to-teal-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-200">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base">PUMILI NG TABLE NA I-DA-DOWNLOAD SA EXCEL</h3>
                  <p className="text-xs text-emerald-200">
                    Eksaktong pagkakaayos ng mga columns at sheets (.xlsx)
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsDownloadTableModalOpen(false)}
                className="p-1.5 rounded-xl text-emerald-200 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Selection Body */}
            <div className="p-5 space-y-4 max-h-[60vh] overflow-y-auto">
              <p className="text-xs font-bold text-slate-700">
                Aling table ang nais mong i-export at buksan sa Microsoft Excel o Google Sheets?
              </p>

              {/* Option A: Kasalukuyang Aktibong Table */}
              <label
                onClick={() => setSelectedTableIdForDownload(result?.id || 'active')}
                className={`p-3.5 rounded-2xl border flex items-start gap-3 cursor-pointer transition-all ${
                  selectedTableIdForDownload === (result?.id || 'active')
                    ? 'bg-emerald-50/90 border-emerald-500 shadow-sm ring-2 ring-emerald-500/20'
                    : 'bg-white border-slate-200 hover:border-slate-300'
                }`}
              >
                <input
                  type="radio"
                  name="downloadTableChoice"
                  checked={selectedTableIdForDownload === (result?.id || 'active')}
                  onChange={() => setSelectedTableIdForDownload(result?.id || 'active')}
                  className="mt-1 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                />
                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-extrabold text-slate-900 text-xs sm:text-sm">
                      {result?.title || 'Kasalukuyang Aktibong Table'}
                    </span>
                    <span className="px-2 py-0.2 rounded-full bg-emerald-600 text-white font-bold text-[9px] uppercase">
                      Aktibong Table
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    {result?.sections?.length || 1} Sheet(s) •{' '}
                    {result?.sections?.reduce((acc, s) => acc + (s.rows?.length || 0), 0) || 0} na mga Rows •{' '}
                    {(result?.sections?.[0]?.headers || activeTargetHeaders).length} Columns
                  </p>
                </div>
              </label>

              {/* Option B: Download Lahat ng Tables in 1 Workbook */}
              {combinedDatabaseDocs.length > 1 && (
                <label
                  onClick={() => setSelectedTableIdForDownload('ALL')}
                  className={`p-3.5 rounded-2xl border flex items-start gap-3 cursor-pointer transition-all ${
                    selectedTableIdForDownload === 'ALL'
                      ? 'bg-indigo-50/90 border-indigo-500 shadow-sm ring-2 ring-indigo-500/20'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <input
                    type="radio"
                    name="downloadTableChoice"
                    checked={selectedTableIdForDownload === 'ALL'}
                    onChange={() => setSelectedTableIdForDownload('ALL')}
                    className="mt-1 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                  />
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-extrabold text-indigo-950 text-xs sm:text-sm">
                        📦 I-download Lahat ng mga Table ({combinedDatabaseDocs.length} Tables)
                      </span>
                      <span className="px-2 py-0.2 rounded-full bg-indigo-600 text-white font-bold text-[9px] uppercase">
                        Multi-Sheet Workbook
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Pagsasama-samahin ang lahat ng {combinedDatabaseDocs.length} tables sa loob ng isang Excel file kung saan ang bawat table ay may sariling sheet.
                    </p>
                  </div>
                </label>
              )}

              {/* Option C: Individual Tables from List */}
              {combinedDatabaseDocs
                .filter((d) => d.id !== (result?.id || 'active'))
                .map((tbl, tIdx) => {
                  const isSelected = selectedTableIdForDownload === tbl.id;
                  const rowCount = tbl.sections?.reduce((acc, s) => acc + (s.rows?.length || 0), 0) || 0;
                  const colCount = tbl.sections?.[0]?.headers?.length || 0;

                  return (
                    <label
                      key={tbl.id || tIdx}
                      onClick={() => setSelectedTableIdForDownload(tbl.id)}
                      className={`p-3.5 rounded-2xl border flex items-start gap-3 cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-emerald-50/90 border-emerald-500 shadow-sm ring-2 ring-emerald-500/20'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <input
                        type="radio"
                        name="downloadTableChoice"
                        checked={isSelected}
                        onChange={() => setSelectedTableIdForDownload(tbl.id)}
                        className="mt-1 text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      />
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-slate-900 text-xs sm:text-sm">
                            {tbl.title || `Table #${tIdx + 1}`}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500">
                          {rowCount} Rows • {colCount} Columns •{' '}
                          {tbl.scannedAt ? new Date(tbl.scannedAt).toLocaleDateString('fil-PH') : 'Saved'}
                        </p>
                      </div>
                    </label>
                  );
                })}
            </div>

            {/* Modal Actions */}
            <div className="px-5 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
              <button
                onClick={() => setIsDownloadTableModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-700 bg-white hover:bg-slate-200 border border-slate-300 transition-colors cursor-pointer"
              >
                Kanselahin
              </button>

              <button
                onClick={handleConfirmExcelDownload}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-green-700 hover:from-emerald-500 hover:to-green-600 text-white font-black text-xs shadow-md shadow-emerald-700/30 flex items-center gap-2 transition-all active:scale-95 cursor-pointer"
              >
                <Download className="w-4 h-4 text-emerald-200" />
                <span>Ipagpatuloy ang Pag-download (.xlsx)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 🚀 PERSISTENT FLOATING BACKGROUND SCANNER BAR (Kahit naka-X o naka-close ang Gallery Table modal, patuloy ang scan) */}
      {isSequentialScanning && !isGalleryQueueOpen && (
        <div className="fixed bottom-6 right-4 sm:right-8 z-50 animate-in slide-in-from-bottom-5 duration-300">
          <div
            onClick={() => setIsGalleryQueueOpen(true)}
            className="flex items-center gap-3 bg-slate-950/95 text-white px-4 py-3 rounded-2xl border-2 border-emerald-400/90 shadow-2xl shadow-emerald-950/60 backdrop-blur-md cursor-pointer hover:border-emerald-300 hover:scale-[1.02] transition-all group"
            title="I-click para buksan muli ang Gallery Table"
          >
            <div className="relative flex items-center justify-center">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-md shadow-emerald-500/30">
                <RefreshCw className="w-4 h-4 text-white animate-spin" />
              </div>
              <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
            </div>

            <div className="text-left space-y-0.5">
              <div className="text-xs font-black text-emerald-300 flex items-center gap-1.5">
                <span>⚡ AI Background Scanner Active</span>
                <span className="px-1.5 py-0.2 rounded bg-emerald-500/30 text-emerald-200 text-[9px] font-bold border border-emerald-500/40">
                  {galleryBoxes.filter((b) => b.status === 'queued').length} natitira
                </span>
              </div>
              <p className="text-[11px] text-slate-300 font-medium">
                Ini-iscan ang <strong>{currentScanningBoxNum ? `Box ${currentScanningBoxNum}` : 'pinakaunang pumasok'}</strong> (Auto-populate sa Table)...
              </p>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsGalleryQueueOpen(true);
              }}
              className="ml-2 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-black transition-all shadow-sm flex items-center gap-1"
            >
              <Eye className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Buksan Table</span>
            </button>
          </div>
        </div>
      )}

      {/* EXCEL PDS PICTURE STRICT VERIFICATION LOADING OVERLAY WITH TURBO PARALLEL PROGRESS */}
      {isVerifyingExcelPdsMatch && (
        <div className="fixed inset-0 z-[100] bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-cyan-500/40 rounded-2xl max-w-lg w-full p-6 shadow-2xl text-white space-y-4 text-center">
            {/* Header Icon */}
            <div className="flex items-center justify-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-emerald-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shadow-inner">
                <ShieldCheck className="w-7 h-7 animate-pulse text-cyan-400" />
              </div>
            </div>

            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-800/80 text-[11px] font-black text-cyan-300 uppercase tracking-wide">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                <span>Turbo AI Batch Verification (Walang Lag)</span>
              </div>
              <h3 className="text-base sm:text-lg font-black text-white pt-1">
                Sinisiguro ang Katugmang Pangalan...
              </h3>
              <p className="text-xs text-slate-300 font-medium leading-relaxed max-w-md mx-auto">
                Sinusuri nang sabay-sabay kung may katugmang aplikante sa Table Content bago opisyal na i-upload sa PDS Pictures.
              </p>
            </div>

            {/* Progress Bar & Percentage */}
            {pdsVerificationProgress.total > 0 && (
              <div className="space-y-2 p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-cyan-300 flex items-center gap-1.5">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                    <span>Progreso:</span>
                  </span>
                  <span className="font-mono text-white">
                    {pdsVerificationProgress.current} ng {pdsVerificationProgress.total} larawan (
                    {Math.round((pdsVerificationProgress.current / pdsVerificationProgress.total) * 100)}%)
                  </span>
                </div>
                <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700/60">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 transition-all duration-300"
                    style={{
                      width: `${Math.min(
                        100,
                        Math.max(
                          6,
                          Math.round((pdsVerificationProgress.current / pdsVerificationProgress.total) * 100)
                        )
                      )}%`,
                    }}
                  />
                </div>

                {/* Counter Badges */}
                <div className="flex items-center justify-center gap-2 pt-1 text-[11px] font-bold">
                  <span className="px-2.5 py-1 rounded-lg bg-emerald-950/80 border border-emerald-700/80 text-emerald-300 flex items-center gap-1">
                    ✅ Tugma: <strong className="font-mono text-white">{pdsVerificationProgress.matchedCount}</strong>
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-rose-950/80 border border-rose-700/80 text-rose-300 flex items-center gap-1">
                    ⚠️ Walang Tugma: <strong className="font-mono text-white">{pdsVerificationProgress.unmatchedCount}</strong>
                  </span>
                </div>
              </div>
            )}

            {/* Current Active Workers / Step Info */}
            <div className="p-3 bg-slate-950/90 border border-slate-800 rounded-xl font-mono text-[11px] text-cyan-200 text-left space-y-1.5">
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1">
                <span>⚡ Kasalukuyang Takbo:</span>
              </div>
              <div className="truncate text-cyan-300 font-medium">
                {verifyingPdsStepText || 'Sinusuri ang datos gamit ang AI Vision...'}
              </div>
              {pdsVerificationProgress.activeFileNames.length > 0 && (
                <div className="text-[10px] text-slate-400 truncate flex items-center gap-1">
                  <span>Sabay-sabay na binabasa:</span>
                  <span className="text-white font-mono">
                    {pdsVerificationProgress.activeFileNames.slice(0, 3).join(', ')}
                    {pdsVerificationProgress.activeFileNames.length > 3 ? '...' : ''}
                  </span>
                </div>
              )}
            </div>

            {/* Footer Actions */}
            <div className="flex items-center justify-between gap-3 pt-1">
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400 text-left">
                <ShieldCheck className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span className="truncate">Strict 100% Name Verification Active</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  pdsVerificationAbortRef.current = true;
                  setIsVerifyingExcelPdsMatch(false);
                }}
                className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-bold transition-all cursor-pointer"
              >
                Kanselahin
              </button>
            </div>
          </div>
        </div>
      )}

      {/* EXCEL PDS PICTURE MATCHING RESULT REPORT MODAL */}
      {excelMatchReportModal?.isOpen && (() => {
        const currentTableRows = (result?.sections || []).flatMap((s) => s.rows || []);
        const primaryHdrKey =
          activeTargetHeaders.find((h) => {
            const hl = h.toLowerCase();
            return hl.includes('name') || hl.includes('pangalan') || hl.includes('surname');
          }) || activeTargetHeaders[0] || 'NAME (SURNAME, FIRST NAME, MIDDLE NAME)';

        const availableTableApplicants: { name: string; rowIndex: number }[] = [];
        currentTableRows.forEach((r, idx) => {
          const raw = (
            r['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
            r['FULL NAME'] ||
            r['PANGALAN'] ||
            r['SURNAME'] ||
            r[primaryHdrKey] ||
            ''
          ).trim();
          if (raw && isRealApplicantName(raw)) {
            availableTableApplicants.push({ name: raw.toUpperCase(), rowIndex: idx });
          }
        });

        const activeRowApplicant =
          activeCell && availableTableApplicants[activeCell.rowIdx]
            ? availableTableApplicants[activeCell.rowIdx].name
            : availableTableApplicants[0]?.name || '';

        return (
          <div className="fixed inset-0 z-[100] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
            <div className="bg-white border border-slate-300 rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
              {/* Modal Header */}
              <div className="px-5 py-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between border-b border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-white">Excel PDS Picture Verification Report</h3>
                    <p className="text-[11px] text-cyan-200">Intelligent Name Matching & Direct Linker</p>
                  </div>
                </div>
                <button
                  onClick={() => setExcelMatchReportModal(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-5 overflow-y-auto space-y-4 flex-1 text-xs">
                {/* Matched Summary */}
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-950 space-y-2">
                  <div className="flex items-center justify-between font-black text-xs">
                    <span className="flex items-center gap-1.5 text-emerald-800">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>MAY KATUGMA SA TABLE (Nai-upload sa PDS Pictures):</span>
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-600 text-white font-mono text-[11px]">
                      {excelMatchReportModal.matched.length} Picture(s)
                    </span>
                  </div>
                  {excelMatchReportModal.matched.length > 0 ? (
                    <div className="max-h-40 overflow-y-auto space-y-2 pr-1">
                      {excelMatchReportModal.matched.map((m, idx) => (
                        <div
                          key={idx}
                          className="p-2.5 rounded-xl bg-white border border-emerald-200 shadow-xs space-y-1 text-[11px]"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <div className="font-black text-slate-900 flex items-center gap-1.5 truncate">
                              <span className="text-xs">🖼️</span>
                              <span>PDS Larawan:</span>
                              <span className="text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 font-mono">
                                {m.pdsDetectedName || m.applicantName}
                              </span>
                            </div>
                            <span className="shrink-0 text-[10px] font-black text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                              ✅ NAI-UPLOAD
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-[10px] text-slate-600 pl-4 border-l-2 border-emerald-400">
                            <div>
                              📋 Katugma sa Table: <strong className="text-slate-900">{m.tableMatchedName || m.applicantName}</strong>
                              {m.rowIndex !== undefined && (
                                <span className="ml-1 font-mono text-emerald-800 font-bold">(Row #{m.rowIndex + 1})</span>
                              )}
                            </div>
                            <div className="font-mono text-slate-400 truncate max-w-[140px]">
                              📄 {m.fileName}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[11px] text-emerald-700 italic">Walang awtomatikong nagtugma. Maaari mong i-ugnay ang mga larawan sa ibaba.</p>
                  )}
                </div>

                {/* Unmatched Summary with Interactive Linking */}
                {excelMatchReportModal.unmatched.length > 0 && (
                  <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-300 text-amber-950 space-y-3">
                    <div className="flex items-center justify-between font-black text-xs">
                      <span className="flex items-center gap-1.5 text-amber-900">
                        <AlertTriangle className="w-4 h-4 text-amber-600" />
                        <span>KAILANGAN NG PAG-UGNAY / HINDI NA-AUTOLOAD ({excelMatchReportModal.unmatched.length}):</span>
                      </span>
                      <button
                        type="button"
                        onClick={handleBatchUploadAllRemainingPdsPictures}
                        className="px-2.5 py-1 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-black text-[11px] flex items-center gap-1 transition-all shadow-xs cursor-pointer active:scale-95"
                      >
                        <Zap className="w-3.5 h-3.5" />
                        <span>I-upload Lahat ng Natira</span>
                      </button>
                    </div>

                    <div className="max-h-64 overflow-y-auto space-y-3 pr-1">
                      {excelMatchReportModal.unmatched.map((u) => (
                        <div
                          key={u.id}
                          className="p-3 rounded-xl bg-white border border-amber-200 shadow-xs space-y-2 text-[11px]"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-2 min-w-0">
                              {u.base64 ? (
                                <img
                                  src={u.base64}
                                  alt="PDS Preview"
                                  className="w-10 h-12 object-cover rounded border border-slate-300 shrink-0"
                                />
                              ) : (
                                <div className="w-10 h-12 bg-slate-100 rounded border border-slate-200 flex items-center justify-center text-slate-400 shrink-0">
                                  <ImageIcon className="w-4 h-4" />
                                </div>
                              )}
                              <div className="min-w-0">
                                <div className="font-bold text-slate-900 truncate">
                                  📄 {u.fileName}
                                </div>
                                <div className="text-[10px] text-slate-500 truncate">
                                  Deteksyon: <span className="font-mono text-amber-800 font-semibold">{u.pdsDetectedName || u.candidateName}</span>
                                </div>
                              </div>
                            </div>
                            <span className="shrink-0 text-[10px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full">
                              Piliin ang Aplikante
                            </span>
                          </div>

                          {/* Quick Link Selector */}
                          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-1 border-t border-amber-100">
                            <div className="flex-1 flex items-center gap-1.5">
                              <span className="text-[10px] font-bold text-slate-600 shrink-0">I-ugnay kay:</span>
                              <select
                                value={u.selectedApplicantToLink || ''}
                                onChange={(e) => {
                                  const newVal = e.target.value;
                                  setExcelMatchReportModal((prev) => {
                                    if (!prev) return null;
                                    return {
                                      ...prev,
                                      unmatched: prev.unmatched.map((item) =>
                                        item.id === u.id
                                          ? { ...item, selectedApplicantToLink: newVal }
                                          : item
                                      ),
                                    };
                                  });
                                }}
                                className="w-full text-xs px-2 py-1.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                              >
                                {availableTableApplicants.map((app, idx) => (
                                  <option key={idx} value={app.name}>
                                    Row #{app.rowIndex + 1}: {app.name}
                                  </option>
                                ))}
                              </select>
                            </div>

                            <button
                              type="button"
                              onClick={() =>
                                handleManualLinkAndUploadPdsPicture(
                                  u,
                                  u.selectedApplicantToLink || availableTableApplicants[0]?.name || ''
                                )
                              }
                              className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs flex items-center justify-center gap-1 transition-all shrink-0 cursor-pointer active:scale-95 shadow-xs"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>⚡ I-ugnay at I-upload</span>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Modal Footer */}
              <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
                <button
                  onClick={() => {
                    setExcelMatchReportModal(null);
                    setIsPdsGalleryOpen(true);
                  }}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer"
                >
                  <ImageIcon className="w-4 h-4 text-indigo-200" />
                  <span>Tingnan ang PDS Pictures Gallery</span>
                </button>
                <button
                  onClick={() => setExcelMatchReportModal(null)}
                  className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs transition-colors cursor-pointer"
                >
                  Isara
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
};
