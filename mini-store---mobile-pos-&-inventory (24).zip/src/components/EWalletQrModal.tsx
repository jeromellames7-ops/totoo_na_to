import React, { useState, useEffect } from 'react';
import { PaymentMethod, EWalletConfig } from '../types';
import { getEWalletConfig, saveEWalletConfig, isReferenceNoUsed, addSecurityLog } from '../utils/storage';
import { getLanguage, LANG_CHANGE_EVENT, Language } from '../utils/language';
import { QrCode, X, Copy, Check, ShieldCheck, AlertCircle, Sparkles, Smartphone, CreditCard, Building2, ExternalLink } from 'lucide-react';

interface EWalletQrModalProps {
  isOpen: boolean;
  onClose: () => void;
  paymentMethod: PaymentMethod; // 'GCash' | 'Maya'
  amount: number;
  onConfirmRefNo?: (refNo: string) => void;
}

export const EWalletQrModal: React.FC<EWalletQrModalProps> = ({
  isOpen,
  onClose,
  paymentMethod,
  amount,
  onConfirmRefNo,
}) => {
  const [config, setConfig] = useState<EWalletConfig>(getEWalletConfig());
  const [refNoInput, setRefNoInput] = useState('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isDuplicate, setIsDuplicate] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [lang, setLang] = useState<Language>(getLanguage());

  // Form states for editing
  const [editGcashNum, setEditGcashNum] = useState(config.gcashNumber);
  const [editGcashName, setEditGcashName] = useState(config.gcashName);
  const [editMayaNum, setEditMayaNum] = useState(config.mayaNumber);
  const [editMayaName, setEditMayaName] = useState(config.mayaName);

  useEffect(() => {
    const handleLangChange = () => setLang(getLanguage());
    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
  }, []);

  useEffect(() => {
    if (isOpen) {
      const currentConfig = getEWalletConfig();
      setConfig(currentConfig);
      setEditGcashNum(currentConfig.gcashNumber);
      setEditGcashName(currentConfig.gcashName);
      setEditMayaNum(currentConfig.mayaNumber);
      setEditMayaName(currentConfig.mayaName);
      setRefNoInput('');
      setIsDuplicate(false);
      setLang(getLanguage());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const isGcash = paymentMethod === 'GCash';
  const targetNumber = isGcash ? config.gcashNumber : config.mayaNumber;
  const targetName = isGcash ? config.gcashName : config.mayaName;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleRefNoChange = (val: string) => {
    setRefNoInput(val);
    if (val.trim()) {
      const used = isReferenceNoUsed(val.trim());
      setIsDuplicate(used);
    } else {
      setIsDuplicate(false);
    }
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const newConfig: EWalletConfig = {
      ...config,
      gcashNumber: editGcashNum.trim(),
      gcashName: editGcashName.trim(),
      mayaNumber: editMayaNum.trim(),
      mayaName: editMayaName.trim(),
    };
    saveEWalletConfig(newConfig);
    setConfig(newConfig);
    setIsEditMode(false);
  };

  const handleApplyRef = () => {
    if (!refNoInput.trim() || isDuplicate) return;
    addSecurityLog('EWALLET_PAYMENT_VERIFIED', `Verified ${paymentMethod} payment ref: ${refNoInput.trim()} for ₱${amount.toFixed(2)}`, 'INFO');
    if (onConfirmRefNo) {
      onConfirmRefNo(refNoInput.trim());
    }
    onClose();
  };

  // Generate dynamic QR Code SVG url using quickchart QR API or SVG fallback
  const qrData = encodeURIComponent(
    `ph.qr.00020101021226${isGcash ? '5800115800' : '5900115900'}${targetNumber.replace(/\D/g, '')}520459995303608540${amount.toFixed(2)}5802PH59${targetName.substring(0, 15)}`
  );
  const qrImageSrc = `https://quickchart.io/qr?text=${qrData}&size=240&margin=1`;

  const isTl = lang === 'tl';

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in">
      <div className="w-full max-w-sm bg-white border border-slate-200/90 rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200">
        {/* Top Header Banner */}
        <div
          className={`px-5 py-4 text-white flex items-center justify-between ${
            isGcash
              ? 'bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700'
              : 'bg-gradient-to-r from-emerald-700 via-teal-600 to-slate-800'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20">
              <QrCode className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-sm font-black tracking-wide flex items-center gap-1.5">
                {paymentMethod} Official QR Code
                <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-bold">Verified POS</span>
              </h3>
              <p className="text-[11px] text-white/80 font-medium">
                {isTl ? 'I-scan para magbayad nang direkta' : 'Scan code to pay directly'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-white/80 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4 overflow-y-auto max-h-[80vh]">
          {isEditMode ? (
            /* Edit Account Details Form */
            <form onSubmit={handleSaveSettings} className="space-y-3 text-xs">
              <h4 className="font-extrabold text-slate-900 flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-indigo-600" />{' '}
                {isTl ? 'Baguhin ang E-Wallet Details' : 'Edit E-Wallet Details'}
              </h4>

              <div className="p-3 bg-blue-50/60 rounded-2xl border border-blue-100 space-y-2">
                <p className="font-bold text-blue-900">GCash Details:</p>
                <div>
                  <label className="text-[10px] text-slate-600 font-semibold block">GCash Mobile Number</label>
                  <input
                    type="text"
                    required
                    value={editGcashNum}
                    onChange={(e) => setEditGcashNum(e.target.value)}
                    className="w-full bg-white border border-blue-200 rounded-xl px-2.5 py-1.5 font-bold text-slate-800"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-600 font-semibold block">Account Name</label>
                  <input
                    type="text"
                    required
                    value={editGcashName}
                    onChange={(e) => setEditGcashName(e.target.value)}
                    className="w-full bg-white border border-blue-200 rounded-xl px-2.5 py-1.5 font-bold text-slate-800"
                  />
                </div>
              </div>

              <div className="p-3 bg-emerald-50/60 rounded-2xl border border-emerald-100 space-y-2">
                <p className="font-bold text-emerald-900">Maya Details:</p>
                <div>
                  <label className="text-[10px] text-slate-600 font-semibold block">Maya Mobile Number</label>
                  <input
                    type="text"
                    required
                    value={editMayaNum}
                    onChange={(e) => setEditMayaNum(e.target.value)}
                    className="w-full bg-white border border-emerald-200 rounded-xl px-2.5 py-1.5 font-bold text-slate-800"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-slate-600 font-semibold block">Account Name</label>
                  <input
                    type="text"
                    required
                    value={editMayaName}
                    onChange={(e) => setEditMayaName(e.target.value)}
                    className="w-full bg-white border border-emerald-200 rounded-xl px-2.5 py-1.5 font-bold text-slate-800"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditMode(false)}
                  className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200"
                >
                  {isTl ? 'Kanselahin' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-indigo-600 text-white font-bold hover:bg-indigo-500 shadow-sm"
                >
                  {isTl ? 'I-save Details' : 'Save Details'}
                </button>
              </div>
            </form>
          ) : (
            /* Standard Display */
            <>
              {/* Total Amount Badge */}
              <div className="text-center bg-slate-50 border border-slate-200/80 p-3 rounded-2xl">
                <span className="text-[11px] font-semibold text-slate-500 block uppercase tracking-wider">
                  {isTl ? 'Babayarang Halaga (Total)' : 'Total Amount Due'}
                </span>
                <span className="text-2xl font-black text-indigo-600">₱{amount.toFixed(2)}</span>
              </div>

              {/* QR Code Container */}
              <div className="flex flex-col items-center justify-center p-3 bg-white border-2 border-dashed border-slate-200 rounded-3xl relative">
                <img
                  src={qrImageSrc || undefined}
                  alt={`${paymentMethod} QR`}
                  className="w-48 h-48 rounded-2xl object-contain shadow-xs border border-slate-100"
                  onError={(e) => {
                    // Fallback visual QR
                    (e.target as HTMLImageElement).src =
                      'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' + qrData;
                  }}
                />
                <div className="flex items-center gap-1.5 mt-2 text-[11px] text-slate-500 font-bold">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Scan via {paymentMethod} App or Any QR Ph</span>
                </div>
              </div>

              {/* Merchant Account Details Box */}
              <div className="p-3 bg-slate-50 border border-slate-200/90 rounded-2xl space-y-2 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Account Name:</span>
                  <span className="font-extrabold text-slate-900 uppercase">{targetName}</span>
                </div>
                <div className="flex justify-between items-center pt-1 border-t border-slate-200">
                  <span className="text-slate-500 font-medium">Number:</span>
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono font-bold text-slate-900">{targetNumber}</span>
                    <button
                      onClick={() => handleCopy(targetNumber, 'num')}
                      className="p-1 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                      title={isTl ? 'Kopyahin ang number' : 'Copy account number'}
                    >
                      {copiedKey === 'num' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Reference Number Verification Input with Anti-Duplicate */}
              <div className="space-y-1.5">
                <label className="text-xs font-extrabold text-slate-800 flex items-center justify-between">
                  <span>{paymentMethod} Reference No. (Ref #):</span>
                  <span className="text-[10px] text-indigo-600 font-semibold">Anti-Fraud Validation</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={refNoInput}
                    onChange={(e) => handleRefNoChange(e.target.value)}
                    placeholder="e.g. 1029 3847 5612"
                    className={`w-full bg-slate-50 border rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-none transition-colors ${
                      isDuplicate
                        ? 'border-rose-500 text-rose-700 bg-rose-50 focus:border-rose-600'
                        : refNoInput.trim()
                        ? 'border-emerald-500 text-emerald-900 bg-emerald-50/50'
                        : 'border-slate-300 focus:border-indigo-600'
                    }`}
                  />
                  {refNoInput.trim() && !isDuplicate && (
                    <Check className="w-4 h-4 text-emerald-600 absolute right-3 top-2.5" />
                  )}
                </div>

                {isDuplicate && (
                  <div className="flex items-center gap-1.5 text-[11px] font-bold text-rose-600 bg-rose-50 border border-rose-200 p-2 rounded-xl">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>
                      {isTl
                        ? 'Babala: Ang Ref No. na ito ay NAGGAMIT NA sa nakaraang transaction!'
                        : 'Warning: This Ref No. has ALREADY BEEN USED in a previous sale!'}
                    </span>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  onClick={() => setIsEditMode(true)}
                  className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all"
                >
                  Edit QR Info
                </button>
                {onConfirmRefNo && (
                  <button
                    onClick={handleApplyRef}
                    disabled={!refNoInput.trim() || isDuplicate}
                    className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-100 active:scale-95 transition-all"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>{isTl ? 'I-confirm ang Payment' : 'Confirm Payment'}</span>
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
