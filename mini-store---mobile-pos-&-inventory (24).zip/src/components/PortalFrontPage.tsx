import React, { useEffect, useRef, useState } from 'react';
import { AppModule, UserAccount } from '../types';
import {
  Store,
  Printer,
  Home,
  Sparkles,
  ArrowRight,
  Zap,
  Droplets,
  Flame,
  Heart,
  Layers,
  Lock,
  LogIn,
  UserPlus,
  KeyRound,
  Shield,
  CheckCircle2,
  RefreshCw,
  Settings,
  Globe,
  Sun,
  Moon,
  History,
  FileText,
} from 'lucide-react';
import { PortalPinModal } from './PortalPinModal';
import { AuthModal } from './AuthModal';
import { AdminManagerModal } from './AdminManagerModal';
import { AccountSettingsModal } from './AccountSettingsModal';
import { BusinessHistoryModal } from './BusinessHistoryModal';
import { AdminRegisterAccountsModal } from './AdminRegisterAccountsModal';
import { getLanguage, setLanguage, Language } from '../utils/language';
import { getLocalGasRecords } from '../utils/homeMonitoringStorage';
import {
  isCurrentUserAdmin,
  getAdminTargetAccountId,
  setAdminTargetAccountId,
  getAccounts,
} from '../utils/storage';

interface PortalFrontPageProps {
  activeUser: UserAccount;
  onSelectModule: (module: AppModule) => void;
  productCount: number;
  unpaidBillsCount?: number;
  gasRemainingDays?: number;
  nextPeriodDays?: number;
  onUserChanged?: (user: UserAccount) => void;
}

export const PortalFrontPage: React.FC<PortalFrontPageProps> = ({
  activeUser,
  onSelectModule,
  productCount,
  unpaidBillsCount = 2,
  gasRemainingDays = 24,
  nextPeriodDays = 8,
  onUserChanged,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isAdmin = isCurrentUserAdmin(activeUser);
  const targetAccountId = isAdmin ? getAdminTargetAccountId() : null;
  const accounts = getAccounts();
  const targetAccount = targetAccountId ? accounts.find((a) => a.id === targetAccountId) : null;

  // Security PIN Modal State for the 3 Portal Buttons
  const [pinTargetModule, setPinTargetModule] = useState<AppModule | null>(null);

  // Theme & Language State
  const [portalTheme, setPortalTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('tindahan_portal_theme') as 'dark' | 'light') || 'dark';
  });
  const [currentLang, setCurrentLangState] = useState<Language>(getLanguage());
  const [isBusinessHistoryOpen, setIsBusinessHistoryOpen] = useState(false);

  const toggleTheme = () => {
    const next = portalTheme === 'dark' ? 'light' : 'dark';
    setPortalTheme(next);
    localStorage.setItem('tindahan_portal_theme', next);
  };

  const toggleLang = () => {
    const next = currentLang === 'tl' ? 'en' : 'tl';
    setCurrentLangState(next);
    setLanguage(next);
  };

  // User Gas LPG Status for current account
  const userGasRecords = getLocalGasRecords();
  const latestGasRecord = userGasRecords.length > 0 ? userGasRecords[0] : null;
  const dynamicGasLabel = latestGasRecord
    ? `${latestGasRecord.estimatedDaysRemaining ?? 30}d LPG`
    : 'LPG Tank';

  // Auth / Login / Register Modal State
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authInitialMode, setAuthInitialMode] = useState<'login' | 'register'>('login');
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isAdminRegisterModalOpen, setIsAdminRegisterModalOpen] = useState(false);
  const [isAccountSettingsModalOpen, setIsAccountSettingsModalOpen] = useState(false);

  // Handle module button click (triggers PIN modal)
  const handleModuleClick = (mod: AppModule) => {
    setPinTargetModule(mod);
  };

  // 3D Floating Illuminated Cubes Canvas Particle Animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    // Particle / Cube nodes
    interface CubeNode {
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;
      rotation: number;
      rotSpeed: number;
      opacity: number;
      pulseSpeed: number;
      color: string;
    }

    const cubes: CubeNode[] = [];
    const colors = [
      'rgba(56, 189, 248, ', // sky cyan
      'rgba(6, 182, 212, ', // cyan
      'rgba(14, 165, 233, ', // blue
      'rgba(99, 102, 241, ', // indigo
      'rgba(45, 212, 191, ', // teal
    ];

    const count = Math.min(Math.floor((width * height) / 25000), 40);
    for (let i = 0; i < count; i++) {
      cubes.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 32 + 16,
        speedX: (Math.random() - 0.5) * 0.4,
        speedY: (Math.random() - 0.5) * 0.4 - 0.2, // slow upward drift
        rotation: Math.random() * Math.PI * 2,
        rotSpeed: (Math.random() - 0.5) * 0.015,
        opacity: Math.random() * 0.6 + 0.2,
        pulseSpeed: Math.random() * 0.02 + 0.01,
        color: colors[Math.floor(Math.random() * colors.length)],
      });
    }

    let time = 0;
    const render = () => {
      time += 0.02;
      ctx.clearRect(0, 0, width, height);

      // Draw subtle ambient glow in center
      const grad = ctx.createRadialGradient(width / 2, height / 2, 50, width / 2, height / 2, width * 0.7);
      grad.addColorStop(0, 'rgba(6, 182, 212, 0.12)');
      grad.addColorStop(0.5, 'rgba(15, 23, 42, 0.25)');
      grad.addColorStop(1, 'rgba(2, 6, 23, 0.6)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Draw floating isometric 3D cubes
      cubes.forEach((cube) => {
        cube.x += cube.speedX;
        cube.y += cube.speedY;
        cube.rotation += cube.rotSpeed;

        if (cube.x < -50) cube.x = width + 50;
        if (cube.x > width + 50) cube.x = -50;
        if (cube.y < -50) cube.y = height + 50;
        if (cube.y > height + 50) cube.y = -50;

        const currentOpacity = Math.max(0.1, cube.opacity + Math.sin(time * 2 + cube.size) * 0.2);

        ctx.save();
        ctx.translate(cube.x, cube.y);
        ctx.rotate(cube.rotation);

        const s = cube.size;
        // Isometric top face
        ctx.fillStyle = cube.color + currentOpacity + ')';
        ctx.beginPath();
        ctx.moveTo(0, -s * 0.5);
        ctx.lineTo(s * 0.86, 0);
        ctx.lineTo(0, s * 0.5);
        ctx.lineTo(-s * 0.86, 0);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.lineWidth = 1;
        ctx.stroke();

        // Left face
        ctx.fillStyle = cube.color + currentOpacity * 0.6 + ')';
        ctx.beginPath();
        ctx.moveTo(-s * 0.86, 0);
        ctx.lineTo(0, s * 0.5);
        ctx.lineTo(0, s * 1.2);
        ctx.lineTo(-s * 0.86, s * 0.7);
        ctx.closePath();
        ctx.fill();

        // Right face
        ctx.fillStyle = cube.color + currentOpacity * 0.8 + ')';
        ctx.beginPath();
        ctx.moveTo(0, s * 0.5);
        ctx.lineTo(s * 0.86, 0);
        ctx.lineTo(s * 0.86, s * 0.7);
        ctx.lineTo(0, s * 1.2);
        ctx.closePath();
        ctx.fill();

        ctx.restore();
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className={`relative min-h-screen w-full flex flex-col justify-between overflow-hidden select-none transition-all duration-500 ${
      portalTheme === 'light' ? 'bg-slate-100 text-slate-900' : 'bg-slate-950 text-white'
    }`}>
      {/* Background Static Image with Dynamic Scale & Glow */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-transform duration-1000 scale-105 opacity-60 mix-blend-screen pointer-events-none"
        style={{
          backgroundImage: `url('/portal_cubes_bg.jpg')`,
        }}
      />

      {/* Floating 3D Interactive Cubes Animation Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none z-0" />

      {/* Dark Gradient Overlay for optimal readability */}
      <div className={`absolute inset-0 pointer-events-none z-1 transition-all duration-500 ${
        portalTheme === 'light' ? 'bg-gradient-to-b from-slate-100/80 via-slate-100/40 to-slate-200/90' : 'bg-gradient-to-b from-slate-950/70 via-slate-950/40 to-slate-950/90'
      }`} />

      {/* Top Header Bar */}
      <header className={`relative z-10 w-full px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3 border-b backdrop-blur-md transition-all duration-500 ${
        portalTheme === 'light' ? 'bg-white/90 border-slate-300 text-slate-900 shadow-sm' : 'bg-slate-950/50 border-cyan-500/20 text-white'
      }`}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-indigo-600 p-0.5 shadow-lg shadow-cyan-500/30 flex items-center justify-center">
            <div className={`w-full h-full rounded-[10px] flex items-center justify-center ${portalTheme === 'light' ? 'bg-white text-slate-900' : 'bg-slate-900 text-cyan-400'}`}>
              <Layers className="w-5 h-5" />
            </div>
          </div>
          <div>
            <h1 className={`text-sm sm:text-base font-extrabold tracking-tight flex items-center gap-1.5 ${portalTheme === 'light' ? 'text-slate-900' : 'text-white'}`}>
              <span>ALL-IN-ONE SMART PORTAL</span>
              <span className="text-[9px] uppercase font-mono font-bold tracking-wider px-1.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                v3.0 PRO
              </span>
            </h1>
            <p className={`text-[11px] ${portalTheme === 'light' ? 'text-slate-600' : 'text-cyan-200/70'}`}>Tindahan POS • Print Studio • Home & Family</p>
          </div>
        </div>

        {/* User Status & Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          {/* Business History Button */}
          <button
            onClick={() => setIsBusinessHistoryOpen(true)}
            className="px-3 py-1.5 sm:py-2 rounded-2xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-extrabold border border-cyan-500/40 flex items-center gap-1.5 active:scale-95 transition-all shadow-md"
            title="Business History: Tingnan ang lahat ng print transactions at kinita"
          >
            <History className="w-4 h-4 text-cyan-400" />
            <span className="hidden sm:inline">Business History</span>
          </button>

          {/* Language Switch Button (EN / TL) */}
          <button
            onClick={toggleLang}
            className="px-2.5 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-amber-300 text-xs font-bold border border-amber-500/30 flex items-center gap-1 active:scale-95 transition-all"
            title="I-switch ang wika (English / Tagalog)"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-mono">{currentLang.toUpperCase()}</span>
          </button>

          {/* Light / Dark Mode Toggle Button */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 active:scale-95 transition-all"
            title="I-toggle ang Light at Dark mode"
          >
            {portalTheme === 'light' ? (
              <Moon className="w-4 h-4 text-indigo-400" />
            ) : (
              <Sun className="w-4 h-4 text-amber-400" />
            )}
          </button>

          {/* Active User Pill */}
          <div
            onClick={() => setIsAccountSettingsModalOpen(true)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-2xl cursor-pointer transition-all shadow-md group ${
              portalTheme === 'light' ? 'bg-white border border-slate-300 text-slate-900' : 'bg-slate-900/80 border border-cyan-500/30 text-white'
            }`}
            title="I-click para buksan ang Account Settings"
          >
            <div className="relative shrink-0">
              <img
                src={activeUser.avatar || undefined}
                alt={activeUser.name}
                className="w-7 h-7 rounded-full object-cover ring-1 ring-cyan-400"
              />
              {activeUser.role === 'Admin' && (
                <Shield className="w-3 h-3 text-amber-400 absolute -bottom-0.5 -right-0.5 bg-slate-950 rounded-full p-0.2" />
              )}
            </div>
            <div className="text-left hidden sm:block max-w-[130px]">
              <p className={`text-xs font-bold truncate leading-tight group-hover:text-cyan-300 ${portalTheme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                {activeUser.name}
              </p>
              <p className="text-[10px] text-cyan-400 font-mono truncate">{activeUser.email || `${activeUser.role} Account`}</p>
            </div>
          </div>

          {/* Account Settings Button */}
          <button
            id="frontpage-account-settings-btn"
            onClick={() => setIsAccountSettingsModalOpen(true)}
            className="px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-cyan-300 text-xs font-bold border border-cyan-500/40 flex items-center gap-1.5 active:scale-95 transition-all shadow-md"
            title="Baguhin ang Password, Email, at 4-Digit Security PIN"
          >
            <Settings className="w-3.5 h-3.5 text-cyan-400 animate-spin-slow" />
            <span className="hidden sm:inline">Account Settings</span>
          </button>

          {/* Admin Exclusive: Register Account & All Accounts Hub Button */}
          {isAdmin && (
            <button
              id="frontpage-register-account-btn"
              onClick={() => setIsAdminRegisterModalOpen(true)}
              className="px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-extrabold shadow-lg shadow-amber-500/25 flex items-center gap-1.5 active:scale-95 transition-all border border-amber-400 cursor-pointer"
              title="Admin: Tingnan ang lahat ng account at mag-register ng bagong account"
            >
              <UserPlus className="w-3.5 h-3.5 text-slate-950" />
              <span>Register Account</span>
              <span className="text-[9px] bg-slate-950/20 px-1.5 py-0.5 rounded-full font-mono uppercase font-bold text-slate-950 hidden sm:inline">
                Admin
              </span>
            </button>
          )}

          {/* Prominent Login Button */}
          <button
            id="frontpage-login-btn"
            onClick={() => {
              setAuthInitialMode('login');
              setIsAuthModalOpen(true);
            }}
            className="px-3 sm:px-4 py-1.5 sm:py-2 rounded-2xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 text-xs font-extrabold shadow-lg shadow-cyan-500/25 flex items-center gap-1.5 active:scale-95 transition-all"
            title="Mag-Login sa iyong Account"
          >
            <LogIn className="w-3.5 h-3.5 text-slate-950" />
            <span>Mag-Login</span>
          </button>
        </div>
      </header>

      {/* Admin Target Account Notification Bar on Front Page */}
      {isAdmin && targetAccount && (
        <div className="relative z-20 max-w-5xl mx-auto px-4 w-full mb-3">
          <div className="bg-amber-500/20 border border-amber-400/40 backdrop-blur-md rounded-2xl p-3 flex flex-wrap items-center justify-between gap-2 text-xs text-amber-200">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-amber-400" />
              <span>
                <strong>Admin Mode:</strong> Kasalukuyan mong binabasa/ina-access ang database ni <strong>{targetAccount.name}</strong> ({targetAccount.email || targetAccount.id}).
              </span>
            </div>
            <button
              onClick={() => {
                setAdminTargetAccountId(null);
                window.location.reload();
              }}
              className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-[11px] flex items-center gap-1 active:scale-95 transition-all"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Bumalik sa Admin DB</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Hub Portal - 3 Central Feature Buttons */}
      <main className="relative z-10 flex-1 flex flex-col justify-center max-w-5xl w-full mx-auto px-4 py-6 sm:py-10">
        <div className="text-center mb-6 sm:mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-medium mb-3 backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span>4-Digit Security PIN Protected Modules</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-100 to-cyan-400 tracking-tight">
            Pumili ng System na Bubuksan
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1.5 max-w-lg mx-auto">
            I-tap ang alinman sa mga button sa ibaba at i-enter ang 4-digit PIN code.
          </p>
        </div>

        {/* 4 Main Glowing Buttons Grid with Specific PINs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6">
          {/* BUTTON 1: MINI STORE POS & INVENTORY (PIN: 2803) */}
          <div
            className={`group relative flex flex-col justify-between p-6 rounded-3xl transition-all duration-500 text-left overflow-hidden backdrop-blur-xl ${
              portalTheme === 'light'
                ? 'bg-white border-2 border-slate-300 shadow-xl text-slate-900 hover:border-indigo-500'
                : 'bg-gradient-to-b from-slate-900/85 to-slate-950/95 border border-indigo-500/30 hover:border-indigo-400/80 text-white shadow-[0_0_30px_rgba(79,70,229,0.15)]'
            }`}
          >
            {/* Background Glow */}
            <div className="absolute top-0 right-0 w-36 h-36 bg-indigo-500/15 rounded-full blur-2xl group-hover:bg-indigo-500/25 transition-all" />

            <div onClick={() => handleModuleClick('ministore')} className="cursor-pointer">
              <div className="flex items-center justify-between mb-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 to-indigo-500 p-0.5 shadow-lg shadow-indigo-500/40 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Store className="w-7 h-7 text-white" />
                </div>
                {/* 4-PIN Badge & Reset PIN button */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      alert('Na-reset ang PIN ng Mini Store POS sa default code: 2803');
                    }}
                    className="px-2 py-0.5 rounded-full bg-indigo-500/20 hover:bg-indigo-500/35 text-indigo-300 text-[10px] font-mono font-bold border border-indigo-500/40 transition-all"
                    title="Reset PIN sa default (2803)"
                  >
                    Reset PIN
                  </button>
                  <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-[11px] font-mono font-bold">
                    <Lock className="w-3 h-3 text-indigo-400" />
                    <span>2803</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <h3 className={`text-lg sm:text-xl font-bold transition-colors ${portalTheme === 'light' ? 'text-slate-900 group-hover:text-indigo-600' : 'text-white group-hover:text-indigo-300'}`}>
                  Mini Store POS
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  {productCount} Items
                </span>
              </div>
              <p className={`text-xs mt-2 leading-relaxed ${portalTheme === 'light' ? 'text-slate-700' : 'text-slate-300/80'}`}>
                Tindahan POS, Barcode Scanner na may tunog, Real-time Inventory, Utang Ledger, at Sales Reports.
              </p>
            </div>

            <div onClick={() => handleModuleClick('ministore')} className={`mt-6 pt-4 border-t flex items-center justify-between text-xs font-semibold cursor-pointer ${portalTheme === 'light' ? 'border-slate-200 text-indigo-600 hover:text-indigo-800' : 'border-slate-800/80 text-indigo-400 group-hover:text-indigo-300'}`}>
              <span className="flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-indigo-400" />
                <span>PIN Code &rarr;</span>
              </span>
              <div className="w-7 h-7 rounded-full bg-indigo-500/20 flex items-center justify-center group-hover:bg-indigo-500 group-hover:text-white transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* BUTTON 2: PRINT STUDIO & BONDPAPER EDITOR */}
          <div
            className={`group relative flex flex-col justify-between p-6 rounded-3xl transition-all duration-500 text-left overflow-hidden backdrop-blur-xl ${
              portalTheme === 'light'
                ? 'bg-white border-2 border-slate-300 shadow-xl text-slate-900 hover:border-cyan-500'
                : 'bg-gradient-to-b from-slate-900/85 to-slate-950/95 border border-cyan-500/40 hover:border-cyan-300/90 text-white shadow-[0_0_30px_rgba(6,182,212,0.2)]'
            }`}
          >
            {/* Ambient Cyan Glow */}
            <div className="absolute top-0 right-0 w-36 h-36 bg-cyan-500/20 rounded-full blur-2xl group-hover:bg-cyan-500/30 transition-all" />

            <div onClick={() => handleModuleClick('printstudio')} className="cursor-pointer">
              <div className="flex items-center justify-between mb-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-cyan-500 to-teal-400 p-0.5 shadow-lg shadow-cyan-500/40 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Printer className="w-7 h-7 text-slate-950" />
                </div>
                {/* 4-PIN Badge & Reset PIN button */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      alert('Na-reset ang PIN ng Print Studio sa default code: 2623');
                    }}
                    className="px-2 py-0.5 rounded-full bg-cyan-500/20 hover:bg-cyan-500/35 text-cyan-300 text-[10px] font-mono font-bold border border-cyan-500/40 transition-all"
                    title="Reset PIN sa default (2623)"
                  >
                    Reset PIN
                  </button>
                  <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-[11px] font-mono font-bold">
                    <Lock className="w-3 h-3 text-cyan-400" />
                    <span>2623</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <h3 className={`text-lg sm:text-xl font-bold transition-colors ${portalTheme === 'light' ? 'text-slate-900 group-hover:text-cyan-600' : 'text-white group-hover:text-cyan-300'}`}>
                  Print Studio
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 animate-pulse">
                  HP 580 Ready
                </span>
              </div>
              <p className={`text-xs mt-2 leading-relaxed ${portalTheme === 'light' ? 'text-slate-700' : 'text-slate-300/80'}`}>
                Full-screen blank bondpaper editor. Multi-touch picture resize, directional D-Pad, HP Smart Tank 580 print sync.
              </p>
            </div>

            <div onClick={() => handleModuleClick('printstudio')} className={`mt-6 pt-4 border-t flex items-center justify-between text-xs font-semibold cursor-pointer ${portalTheme === 'light' ? 'border-slate-200 text-cyan-600 hover:text-cyan-800' : 'border-slate-800/80 text-cyan-400 group-hover:text-cyan-300'}`}>
              <span className="flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                <span>PIN Code &rarr;</span>
              </span>
              <div className="w-7 h-7 rounded-full bg-cyan-500/20 flex items-center justify-center group-hover:bg-cyan-400 group-hover:text-slate-950 transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* BUTTON 3: HOME MONITORING & UTILITY TRACKER */}
          <div
            className={`group relative flex flex-col justify-between p-6 rounded-3xl transition-all duration-500 text-left overflow-hidden backdrop-blur-xl ${
              portalTheme === 'light'
                ? 'bg-white border-2 border-slate-300 shadow-xl text-slate-900 hover:border-emerald-500'
                : 'bg-gradient-to-b from-slate-900/85 to-slate-950/95 border border-emerald-500/30 hover:border-emerald-400/80 text-white shadow-[0_0_30px_rgba(16,185,129,0.15)]'
            }`}
          >
            {/* Ambient Emerald Glow */}
            <div className="absolute top-0 right-0 w-36 h-36 bg-emerald-500/15 rounded-full blur-2xl group-hover:bg-emerald-500/25 transition-all" />

            <div onClick={() => handleModuleClick('homemonitoring')} className="cursor-pointer">
              <div className="flex items-center justify-between mb-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 p-0.5 shadow-lg shadow-emerald-500/40 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Home className="w-7 h-7 text-white" />
                </div>
                {/* 4-PIN Badge & Reset PIN button */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      alert('Na-reset ang PIN ng Home Monitoring sa default code: 0000');
                    }}
                    className="px-2 py-0.5 rounded-full bg-emerald-500/20 hover:bg-emerald-500/35 text-emerald-300 text-[10px] font-mono font-bold border border-emerald-500/40 transition-all"
                    title="Reset PIN sa default (0000)"
                  >
                    Reset PIN
                  </button>
                  <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[11px] font-mono font-bold">
                    <Lock className="w-3 h-3 text-emerald-400" />
                    <span>0000</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <h3 className={`text-lg sm:text-xl font-bold transition-colors ${portalTheme === 'light' ? 'text-slate-900 group-hover:text-emerald-600' : 'text-white group-hover:text-emerald-300'}`}>
                  Home Monitoring
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  4 Trackers
                </span>
              </div>
              <p className={`text-xs mt-2 leading-relaxed ${portalTheme === 'light' ? 'text-slate-700' : 'text-slate-300/80'}`}>
                Electric Bill (kWh), Water Bill (m³), Gas Stove LPG tank level, at Women's Menstruation Tracker.
              </p>
            </div>

            {/* Glance indicators */}
            <div className="mt-4 grid grid-cols-4 gap-1 py-1" onClick={() => handleModuleClick('homemonitoring')}>
              <div className="flex flex-col items-center p-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-600">
                <Zap className="w-3.5 h-3.5 mb-0.5" />
                <span className="text-[8px] font-bold">Kuryente</span>
              </div>
              <div className="flex flex-col items-center p-1 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-600">
                <Droplets className="w-3.5 h-3.5 mb-0.5" />
                <span className="text-[8px] font-bold">Tubig</span>
              </div>
              <div className="flex flex-col items-center p-1 rounded-lg bg-orange-500/10 border border-orange-500/20 text-orange-600">
                <Flame className="w-3.5 h-3.5 mb-0.5" />
                <span className="text-[8px] font-bold">{dynamicGasLabel}</span>
              </div>
              <div className="flex flex-col items-center p-1 rounded-lg bg-pink-500/10 border border-pink-500/20 text-pink-600">
                <Heart className="w-3.5 h-3.5 mb-0.5" />
                <span className="text-[8px] font-bold">Regla</span>
              </div>
            </div>

            <div onClick={() => handleModuleClick('homemonitoring')} className={`mt-4 pt-4 border-t flex items-center justify-between text-xs font-semibold cursor-pointer ${portalTheme === 'light' ? 'border-slate-200 text-emerald-600 hover:text-emerald-800' : 'border-slate-800/80 text-emerald-400 group-hover:text-emerald-300'}`}>
              <span className="flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-emerald-400" />
                <span>PIN Code &rarr;</span>
              </span>
              <div className="w-7 h-7 rounded-full bg-emerald-500/20 flex items-center justify-center group-hover:bg-emerald-500 group-hover:text-white transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>

          {/* BUTTON 4: AI FORM & DOCUMENT EXTRACTOR (PIN: 1234) */}
          <div
            className={`group relative flex flex-col justify-between p-6 rounded-3xl transition-all duration-500 text-left overflow-hidden backdrop-blur-xl ${
              portalTheme === 'light'
                ? 'bg-white border-2 border-slate-300 shadow-xl text-slate-900 hover:border-amber-500'
                : 'bg-gradient-to-b from-slate-900/85 to-slate-950/95 border border-amber-500/40 hover:border-amber-400/90 text-white shadow-[0_0_30px_rgba(245,158,11,0.2)]'
            }`}
          >
            {/* Ambient Amber Glow */}
            <div className="absolute top-0 right-0 w-36 h-36 bg-amber-500/20 rounded-full blur-2xl group-hover:bg-amber-500/30 transition-all" />

            <div onClick={() => handleModuleClick('docscanner')} className="cursor-pointer">
              <div className="flex items-center justify-between mb-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 p-0.5 shadow-lg shadow-amber-500/40 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <FileText className="w-7 h-7 text-slate-950" />
                </div>
                {/* 4-PIN Badge & Reset PIN button */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      alert('Na-reset ang PIN ng AI Form Extractor sa default code: 1234');
                    }}
                    className="px-2 py-0.5 rounded-full bg-amber-500/20 hover:bg-amber-500/35 text-amber-300 text-[10px] font-mono font-bold border border-amber-500/40 transition-all"
                    title="Reset PIN sa default (1234)"
                  >
                    Reset PIN
                  </button>
                  <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[11px] font-mono font-bold">
                    <Lock className="w-3 h-3 text-amber-400" />
                    <span>1234</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <h3 className={`text-lg sm:text-xl font-bold transition-colors ${portalTheme === 'light' ? 'text-slate-900 group-hover:text-amber-600' : 'text-white group-hover:text-amber-300'}`}>
                  AI Form Extractor
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono">
                  Vision AI
                </span>
              </div>
              <p className={`text-xs mt-2 leading-relaxed ${portalTheme === 'light' ? 'text-slate-700' : 'text-slate-300/80'}`}>
                I-scan ang mga larawan ng form o dokumento (printed, handwritten, checkboxes, multi-page) at i-convert sa organisadong tables.
              </p>
            </div>

            <div onClick={() => handleModuleClick('docscanner')} className={`mt-6 pt-4 border-t flex items-center justify-between text-xs font-semibold cursor-pointer ${portalTheme === 'light' ? 'border-slate-200 text-amber-600 hover:text-amber-800' : 'border-slate-800/80 text-amber-400 group-hover:text-amber-300'}`}>
              <span className="flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                <span>PIN Code &rarr;</span>
              </span>
              <div className="w-7 h-7 rounded-full bg-amber-500/20 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-slate-950 transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer Info Bar */}
      <footer className="relative z-10 px-5 py-4 text-center border-t border-slate-800/60 bg-slate-950/60 backdrop-blur-md">
        <p className="text-xs text-slate-400">
          MINI STORE & FAMILY UTILITY PLATFORM • Isolated Firebase Database per Account • HP Smart Tank 580 Print Support
        </p>
      </footer>

      {/* 4-Digit Security PIN Modal for Selected Portal Module */}
      <PortalPinModal
        isOpen={!!pinTargetModule}
        targetModule={pinTargetModule}
        onClose={() => setPinTargetModule(null)}
        onSuccess={(mod) => {
          onSelectModule(mod);
        }}
      />

      {/* Login / Register Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        activeUser={activeUser}
        initialMode={authInitialMode}
        onUserChanged={(newUser) => {
          if (onUserChanged) {
            onUserChanged(newUser);
          }
        }}
      />

      {/* Admin Register & All Accounts Management Modal */}
      <AdminRegisterAccountsModal
        isOpen={isAdminRegisterModalOpen}
        onClose={() => setIsAdminRegisterModalOpen(false)}
        activeUser={activeUser}
        onUserChanged={(newUser) => {
          if (onUserChanged) {
            onUserChanged(newUser);
          }
        }}
      />

      {/* Admin Credentials & Database Control Hub */}
      <AdminManagerModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
        onAccountChanged={() => {
          if (onUserChanged) {
            onUserChanged(activeUser);
          }
        }}
      />

      {/* User Account Settings Modal (Email, Password, 4-Digit Security PIN) */}
      <AccountSettingsModal
        isOpen={isAccountSettingsModalOpen}
        onClose={() => setIsAccountSettingsModalOpen(false)}
        activeUser={activeUser}
        onUserChanged={(updatedUser) => {
          if (onUserChanged) {
            onUserChanged(updatedUser);
          }
        }}
      />

      {/* Business History Modal */}
      <BusinessHistoryModal
        isOpen={isBusinessHistoryOpen}
        onClose={() => setIsBusinessHistoryOpen(false)}
        lang={currentLang}
      />
    </div>
  );
};

