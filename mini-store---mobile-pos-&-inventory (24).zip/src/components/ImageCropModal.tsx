import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Crop,
  X,
  Check,
  RotateCw,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Maximize2,
  RefreshCw,
  Sparkles,
  Scissors,
} from 'lucide-react';
import { playSuccessChime, playTickSound } from '../utils/sound';

interface ImageCropModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageSrc: string;
  imageName?: string;
  onApplyCrop: (croppedDataUrl: string) => void;
}

type AspectPreset = 'free' | '1:1' | '2:2' | 'passport' | '1x1' | '4:6' | '3.5:5' | '16:9';

export const ImageCropModal: React.FC<ImageCropModalProps> = ({
  isOpen,
  onClose,
  imageSrc,
  imageName,
  onApplyCrop,
}) => {
  const [aspectPreset, setAspectPreset] = useState<AspectPreset>('free');
  const [rotation, setRotation] = useState<number>(0);
  const [cropBox, setCropBox] = useState<{ x: number; y: number; width: number; height: number }>({
    x: 10,
    y: 10,
    width: 80,
    height: 80,
  });

  const [isDraggingBox, setIsDraggingBox] = useState(false);
  const [activeHandle, setActiveHandle] = useState<string | null>(null);
  const [dragStart, setDragStart] = useState<{ x: number; y: number; initialBox: typeof cropBox } | null>(null);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [naturalSize, setNaturalSize] = useState<{ w: number; h: number }>({ w: 800, h: 600 });

  // Reset when opened
  useEffect(() => {
    if (isOpen) {
      setRotation(0);
      setAspectPreset('free');
      setImageLoaded(false);
      setCropBox({ x: 10, y: 10, width: 80, height: 80 });
    }
  }, [isOpen, imageSrc]);

  // Adjust crop box according to aspect ratio preset
  const applyPreset = useCallback(
    (preset: AspectPreset) => {
      setAspectPreset(preset);
      playTickSound();

      let targetRatio: number | null = null;
      if (preset === '1:1' || preset === '1x1' || preset === '2:2') {
        targetRatio = 1.0;
      } else if (preset === 'passport') {
        targetRatio = 35 / 45; // ~0.777
      } else if (preset === '4:6') {
        targetRatio = 4 / 6; // ~0.666
      } else if (preset === '3.5:5') {
        targetRatio = 3.5 / 5; // 0.7
      } else if (preset === '16:9') {
        targetRatio = 16 / 9;
      }

      if (targetRatio !== null && containerRef.current) {
        const containerW = containerRef.current.clientWidth;
        const containerH = containerRef.current.clientHeight;
        const containerAspect = containerW / containerH;

        let newW = 70;
        let newH = 70;

        if (targetRatio > 1) {
          newW = 80;
          newH = (newW / targetRatio) * containerAspect;
        } else {
          newH = 80;
          newW = newH * targetRatio * (1 / containerAspect);
        }

        newW = Math.min(90, Math.max(15, newW));
        newH = Math.min(90, Math.max(15, newH));

        const newX = Math.max(0, (100 - newW) / 2);
        const newY = Math.max(0, (100 - newH) / 2);

        setCropBox({
          x: newX,
          y: newY,
          width: newW,
          height: newH,
        });
      }
    },
    []
  );

  const handleImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
    const img = e.currentTarget;
    setNaturalSize({ w: img.naturalWidth, h: img.naturalHeight });
    setImageLoaded(true);
  };

  // Pointer / Touch down for moving crop box or handle
  const handlePointerDown = (e: React.PointerEvent, handle: string | null) => {
    e.stopPropagation();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);

    setIsDraggingBox(handle === null);
    setActiveHandle(handle);
    setDragStart({
      x: e.clientX,
      y: e.clientY,
      initialBox: { ...cropBox },
    });
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragStart || !containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const deltaXPct = ((e.clientX - dragStart.x) / rect.width) * 100;
    const deltaYPct = ((e.clientY - dragStart.y) / rect.height) * 100;

    const { initialBox } = dragStart;

    if (isDraggingBox) {
      // Move entire crop box
      const nextX = Math.max(0, Math.min(100 - initialBox.width, initialBox.x + deltaXPct));
      const nextY = Math.max(0, Math.min(100 - initialBox.height, initialBox.y + deltaYPct));
      setCropBox((prev) => ({ ...prev, x: nextX, y: nextY }));
    } else if (activeHandle) {
      // Resize with handle
      let nextX = initialBox.x;
      let nextY = initialBox.y;
      let nextW = initialBox.width;
      let nextH = initialBox.height;

      if (activeHandle.includes('e')) {
        nextW = Math.max(10, Math.min(100 - initialBox.x, initialBox.width + deltaXPct));
      }
      if (activeHandle.includes('s')) {
        nextH = Math.max(10, Math.min(100 - initialBox.y, initialBox.height + deltaYPct));
      }
      if (activeHandle.includes('w')) {
        const potentialW = initialBox.width - deltaXPct;
        if (potentialW >= 10 && initialBox.x + deltaXPct >= 0) {
          nextX = initialBox.x + deltaXPct;
          nextW = potentialW;
        }
      }
      if (activeHandle.includes('n')) {
        const potentialH = initialBox.height - deltaYPct;
        if (potentialH >= 10 && initialBox.y + deltaYPct >= 0) {
          nextY = initialBox.y + deltaYPct;
          nextH = potentialH;
        }
      }

      setCropBox({
        x: Math.max(0, nextX),
        y: Math.max(0, nextY),
        width: Math.min(100 - nextX, nextW),
        height: Math.min(100 - nextY, nextH),
      });
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
    setIsDraggingBox(false);
    setActiveHandle(null);
    setDragStart(null);
  };

  // Perform Final Crop on Canvas and generate high-res Data URL
  const handleExecuteCrop = () => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Handle orientation / rotation if any
      const srcW = img.naturalWidth;
      const srcH = img.naturalHeight;

      // Calculate pixel crop coordinates from percentages
      const cropPixelX = (cropBox.x / 100) * srcW;
      const cropPixelY = (cropBox.y / 100) * srcH;
      const cropPixelW = Math.max(10, (cropBox.width / 100) * srcW);
      const cropPixelH = Math.max(10, (cropBox.height / 100) * srcH);

      // Create intermediate canvas for rotated or cropped slice
      canvas.width = cropPixelW;
      canvas.height = cropPixelH;

      ctx.save();
      if (rotation !== 0) {
        // Rotate around center if rotation applied
        const rotRad = (rotation * Math.PI) / 180;
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = srcW;
        tempCanvas.height = srcH;
        const tempCtx = tempCanvas.getContext('2d');
        if (tempCtx) {
          tempCtx.translate(srcW / 2, srcH / 2);
          tempCtx.rotate(rotRad);
          tempCtx.drawImage(img, -srcW / 2, -srcH / 2);
          ctx.drawImage(
            tempCanvas,
            cropPixelX,
            cropPixelY,
            cropPixelW,
            cropPixelH,
            0,
            0,
            cropPixelW,
            cropPixelH
          );
        }
      } else {
        ctx.drawImage(
          img,
          cropPixelX,
          cropPixelY,
          cropPixelW,
          cropPixelH,
          0,
          0,
          cropPixelW,
          cropPixelH
        );
      }
      ctx.restore();

      const croppedUrl = canvas.toDataURL('image/png', 0.98);
      playSuccessChime();
      onApplyCrop(croppedUrl);
      onClose();
    };
    img.src = imageSrc;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 select-none animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-slate-900 border-2 border-cyan-500/40 rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center">
              <Scissors className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Crop at I-frame ang Litrato</span>
                <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-500/30">
                  {naturalSize.w} × {naturalSize.h} px
                </span>
              </h3>
              <p className="text-[11px] text-slate-400 truncate max-w-[280px] sm:max-w-md">
                {imageName || 'I-drag ang frame para pumili ng sukat'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Aspect Ratio Preset Bar */}
        <div className="px-4 py-2 bg-slate-950/70 border-b border-slate-800 flex items-center gap-1.5 overflow-x-auto text-xs">
          <span className="text-[11px] font-bold text-slate-400 whitespace-nowrap mr-1">Preset:</span>
          <button
            onClick={() => applyPreset('free')}
            className={`px-2.5 py-1 rounded-lg font-semibold whitespace-nowrap transition-all ${
              aspectPreset === 'free'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            🔓 Freeform
          </button>
          <button
            onClick={() => applyPreset('2:2')}
            className={`px-2.5 py-1 rounded-lg font-semibold whitespace-nowrap transition-all ${
              aspectPreset === '2:2'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            📸 2x2 in (Passport)
          </button>
          <button
            onClick={() => applyPreset('1x1')}
            className={`px-2.5 py-1 rounded-lg font-semibold whitespace-nowrap transition-all ${
              aspectPreset === '1x1'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            📸 1x1 in (ID)
          </button>
          <button
            onClick={() => applyPreset('passport')}
            className={`px-2.5 py-1 rounded-lg font-semibold whitespace-nowrap transition-all ${
              aspectPreset === 'passport'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            🛂 35×45mm
          </button>
          <button
            onClick={() => applyPreset('4:6')}
            className={`px-2.5 py-1 rounded-lg font-semibold whitespace-nowrap transition-all ${
              aspectPreset === '4:6'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            🖼️ 4R (4×6)
          </button>
          <button
            onClick={() => applyPreset('3.5:5')}
            className={`px-2.5 py-1 rounded-lg font-semibold whitespace-nowrap transition-all ${
              aspectPreset === '3.5:5'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            🖼️ 3R (3.5×5)
          </button>
          <button
            onClick={() => applyPreset('1:1')}
            className={`px-2.5 py-1 rounded-lg font-semibold whitespace-nowrap transition-all ${
              aspectPreset === '1:1'
                ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            ⬛ 1:1 Square
          </button>
        </div>

        {/* CROP WORKSPACE / IMAGE VIEWPORT */}
        <div className="flex-1 min-h-[280px] sm:min-h-[380px] p-4 bg-slate-950/90 flex items-center justify-center relative overflow-hidden">
          <div
            ref={containerRef}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            className="relative max-w-full max-h-[50vh] flex items-center justify-center touch-none select-none overflow-hidden rounded-xl border border-slate-800 shadow-2xl bg-black"
          >
            {/* The base image */}
            <img
              ref={imageRef}
              src={imageSrc || undefined}
              alt="To Crop"
              onLoad={handleImageLoad}
              className="max-h-[48vh] max-w-full object-contain pointer-events-none transition-transform"
              style={{
                transform: `rotate(${rotation}deg)`,
              }}
            />

            {/* Dark Mask overlay with cutout hole for the crop box */}
            {imageLoaded && (
              <div
                onPointerDown={(e) => handlePointerDown(e, null)}
                className="absolute border-2 border-cyan-400 shadow-[0_0_0_9999px_rgba(0,0,0,0.65)] cursor-move transition-shadow z-20"
                style={{
                  left: `${cropBox.x}%`,
                  top: `${cropBox.y}%`,
                  width: `${cropBox.width}%`,
                  height: `${cropBox.height}%`,
                }}
              >
                {/* 3x3 Rule of Thirds Grid Guidelines inside Crop Box */}
                <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none">
                  <div className="border-r border-b border-cyan-300/30" />
                  <div className="border-r border-b border-cyan-300/30" />
                  <div className="border-b border-cyan-300/30" />
                  <div className="border-r border-b border-cyan-300/30" />
                  <div className="border-r border-b border-cyan-300/30" />
                  <div className="border-b border-cyan-300/30" />
                  <div className="border-r border-cyan-300/30" />
                  <div className="border-r border-cyan-300/30" />
                  <div />
                </div>

                {/* 8 Drag & Resize Handles */}
                {/* Corners */}
                <div
                  onPointerDown={(e) => handlePointerDown(e, 'nw')}
                  className="absolute -top-2 -left-2 w-4 h-4 bg-cyan-400 border-2 border-white rounded-full cursor-nwse-resize shadow"
                />
                <div
                  onPointerDown={(e) => handlePointerDown(e, 'ne')}
                  className="absolute -top-2 -right-2 w-4 h-4 bg-cyan-400 border-2 border-white rounded-full cursor-nesw-resize shadow"
                />
                <div
                  onPointerDown={(e) => handlePointerDown(e, 'sw')}
                  className="absolute -bottom-2 -left-2 w-4 h-4 bg-cyan-400 border-2 border-white rounded-full cursor-nesw-resize shadow"
                />
                <div
                  onPointerDown={(e) => handlePointerDown(e, 'se')}
                  className="absolute -bottom-2 -right-2 w-4 h-4 bg-cyan-400 border-2 border-white rounded-full cursor-nwse-resize shadow"
                />

                {/* Edges */}
                <div
                  onPointerDown={(e) => handlePointerDown(e, 'n')}
                  className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-6 h-3 bg-cyan-400 border border-white rounded cursor-ns-resize shadow"
                />
                <div
                  onPointerDown={(e) => handlePointerDown(e, 's')}
                  className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-6 h-3 bg-cyan-400 border border-white rounded cursor-ns-resize shadow"
                />
                <div
                  onPointerDown={(e) => handlePointerDown(e, 'w')}
                  className="absolute -left-1.5 top-1/2 -translate-y-1/2 w-3 h-6 bg-cyan-400 border border-white rounded cursor-ew-resize shadow"
                />
                <div
                  onPointerDown={(e) => handlePointerDown(e, 'e')}
                  className="absolute -right-1.5 top-1/2 -translate-y-1/2 w-3 h-6 bg-cyan-400 border border-white rounded cursor-ew-resize shadow"
                />

                {/* Center Move Tag */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 px-2 py-0.5 rounded-full bg-cyan-950/90 border border-cyan-400 text-cyan-300 font-mono text-[9px] pointer-events-none shadow">
                  {Math.round((cropBox.width / 100) * naturalSize.w)} ×{' '}
                  {Math.round((cropBox.height / 100) * naturalSize.h)} px
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions: Rotate, Reset, Cancel & Apply */}
        <div className="px-5 py-3.5 bg-slate-950 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Quick Rotation Buttons */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                setRotation((prev) => (prev - 90 + 360) % 360);
                playTickSound();
              }}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-800 flex items-center gap-1 font-bold"
              title="Rotate 90° Kaliwa"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>-90°</span>
            </button>
            <button
              onClick={() => {
                setRotation((prev) => (prev + 90) % 360);
                playTickSound();
              }}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-800 flex items-center gap-1 font-bold"
              title="Rotate 90° Kanan"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>+90°</span>
            </button>
            <button
              onClick={() => {
                setCropBox({ x: 10, y: 10, width: 80, height: 80 });
                setRotation(0);
                setAspectPreset('free');
              }}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800"
              title="Reset Crop Area"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleExecuteCrop}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-black flex items-center gap-2 shadow-lg shadow-cyan-500/30 active:scale-95 transition-all"
            >
              <Check className="w-4 h-4" />
              <span>I-APPLY ANG CROP</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
