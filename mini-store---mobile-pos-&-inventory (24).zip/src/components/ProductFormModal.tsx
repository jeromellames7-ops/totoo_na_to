import React, { useState, useEffect, useRef } from 'react';
import { Product } from '../types';
import { saveProduct } from '../utils/storage';
import { getLanguage, t, LANG_CHANGE_EVENT } from '../utils/language';
import { X, Save, Barcode, Package, Upload, Camera, CameraOff, RefreshCw, CheckCircle2 } from 'lucide-react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { playScanBeep } from '../utils/sound';
import { compressImageForAi } from '../lib/imageCompressor';

interface ProductFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  productToEdit?: Product | null;
  initialBarcode?: string;
  onSaved: (savedProduct: Product) => void;
  targetAccountId?: string;
}

const PRESET_IMAGES = [
  { name: 'Noodles / Fast Food', url: 'https://images.unsplash.com/photo-1612927601601-6638404737ce?w=400&auto=format&fit=crop&q=80' },
  { name: 'Beverage / Drink', url: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=400&auto=format&fit=crop&q=80' },
  { name: 'Canned Goods', url: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=400&auto=format&fit=crop&q=80' },
  { name: 'Snacks & Chips', url: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=400&auto=format&fit=crop&q=80' },
  { name: 'Condiments / Cooking', url: 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=400&auto=format&fit=crop&q=80' },
  { name: 'Personal Care', url: 'https://images.unsplash.com/photo-1600857544200-b2f666a9a2ec?w=400&auto=format&fit=crop&q=80' },
  { name: 'General Grocery', url: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&auto=format&fit=crop&q=80' },
];

const CATEGORIES = [
  'Beverages',
  'Noodles & Instant Food',
  'Canned Goods',
  'Snacks & Chips',
  'Condiments & Cooking',
  'Personal Care',
  'Bakery & Snacks',
  'Frozen & Fresh',
  'General Grocery',
];

export const ProductFormModal: React.FC<ProductFormModalProps> = ({
  isOpen,
  onClose,
  productToEdit,
  initialBarcode = '',
  onSaved,
  targetAccountId,
}) => {
  const [name, setName] = useState('');
  const [barcode, setBarcode] = useState('');
  const [price, setPrice] = useState<string>('');
  const [costPrice, setCostPrice] = useState<string>('');
  const [stock, setStock] = useState<string>('10');
  const [lowStockThreshold, setLowStockThreshold] = useState<string>('5');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [imageUrl, setImageUrl] = useState(PRESET_IMAGES[0].url);
  const [details, setDetails] = useState('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [, setLangState] = useState(getLanguage());

  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanCameraError, setScanCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [justScannedSuccess, setJustScannedSuccess] = useState<boolean>(false);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const qrCodeRegionId = 'product-form-barcode-scanner';

  const stopScanner = async () => {
    if (scannerRef.current) {
      try {
        await scannerRef.current.stop();
        await scannerRef.current.clear();
      } catch (e) {
        // ignore error when already stopped
      }
      scannerRef.current = null;
    }
  };

  useEffect(() => {
    let isMounted = true;

    if (isScanning && isOpen) {
      setScanCameraError(null);

      const startCamera = async () => {
        await stopScanner();

        await new Promise((r) => setTimeout(r, 150));
        if (!isMounted) return;

        try {
          const html5Qrcode = new Html5Qrcode(qrCodeRegionId, {
            formatsToSupport: [
              Html5QrcodeSupportedFormats.QR_CODE,
              Html5QrcodeSupportedFormats.EAN_13,
              Html5QrcodeSupportedFormats.EAN_8,
              Html5QrcodeSupportedFormats.UPC_A,
              Html5QrcodeSupportedFormats.UPC_E,
              Html5QrcodeSupportedFormats.CODE_128,
              Html5QrcodeSupportedFormats.CODE_39,
              Html5QrcodeSupportedFormats.ITF,
              Html5QrcodeSupportedFormats.DATA_MATRIX,
            ],
            verbose: false,
          });

          scannerRef.current = html5Qrcode;

          const config = {
            fps: 25,
            qrbox: (viewfinderWidth: number, viewfinderHeight: number) => {
              const minEdge = Math.min(viewfinderWidth, viewfinderHeight);
              return {
                width: Math.floor(minEdge * 0.85),
                height: Math.floor(minEdge * 0.55),
              };
            },
          };

          await html5Qrcode.start(
            { facingMode: facingMode },
            config,
            (decodedText) => {
              if (!isMounted) return;
              const cleanCode = decodedText.trim();
              if (cleanCode) {
                playScanBeep();
                setBarcode(cleanCode);
                setJustScannedSuccess(true);
                setIsScanning(false);
                setTimeout(() => {
                  if (isMounted) setJustScannedSuccess(false);
                }, 3500);
              }
            },
            () => {
              // ignore frame errors
            }
          );
        } catch (err: any) {
          if (isMounted) {
            setScanCameraError(
              'Hindi mabuksan ang camera. Pakitingnan ang browser permissions o gamitin ang USB scanner.'
            );
          }
        }
      };

      startCamera();
    } else {
      stopScanner();
    }

    return () => {
      isMounted = false;
      stopScanner();
    };
  }, [isScanning, facingMode, isOpen]);

  useEffect(() => {
    const handleLangChange = () => setLangState(getLanguage());
    window.addEventListener(LANG_CHANGE_EVENT, handleLangChange);
    return () => window.removeEventListener(LANG_CHANGE_EVENT, handleLangChange);
  }, []);

  useEffect(() => {
    setIsScanning(false);
    setJustScannedSuccess(false);
    if (productToEdit) {
      setName(productToEdit.name);
      setBarcode(productToEdit.barcode);
      setPrice(productToEdit.price.toString());
      setCostPrice((productToEdit.costPrice || productToEdit.price * 0.8).toString());
      setStock(productToEdit.stock.toString());
      setLowStockThreshold(productToEdit.lowStockThreshold.toString());
      setCategory(productToEdit.category || CATEGORIES[0]);
      setImageUrl(productToEdit.imageUrl);
      setDetails(productToEdit.details || '');
    } else {
      setName('');
      setBarcode(initialBarcode || '');
      setPrice('');
      setCostPrice('');
      setStock('10');
      setLowStockThreshold('5');
      setCategory(CATEGORIES[0]);
      setImageUrl(PRESET_IMAGES[0].url);
      setDetails('');
    }
    setErrors({});
  }, [productToEdit, initialBarcode, isOpen]);

  if (!isOpen) return null;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const rawBase64 = reader.result as string;
        try {
          // Compress product image to lightweight 480px width to avoid localStorage bloat & memory lag
          const optimized = await compressImageForAi(rawBase64, 480, 0.85);
          setImageUrl(optimized);
        } catch {
          setImageUrl(rawBase64);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const validate = () => {
    const newErrors: { [key: string]: string } = {};

    if (!name.trim()) newErrors.name = 'Kailangan ang pangalan ng produkto!';
    if (!barcode.trim()) newErrors.barcode = 'Kailangan ang barcode!';
    if (!price || isNaN(Number(price)) || Number(price) <= 0) {
      newErrors.price = 'Valid na presyo ang kailangan!';
    }
    if (!stock || isNaN(Number(stock)) || Number(stock) < 0) {
      newErrors.stock = 'Valid na stock number ang kailangan!';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const numPrice = parseFloat(price);
    const numCost = costPrice ? parseFloat(costPrice) : numPrice * 0.8;
    const numStock = parseInt(stock, 10);
    const numThreshold = parseInt(lowStockThreshold, 10) || 5;

    const saved = saveProduct(
      {
        id: productToEdit ? productToEdit.id : undefined,
        name: name.trim(),
        barcode: barcode.trim(),
        price: numPrice,
        costPrice: numCost,
        stock: numStock,
        lowStockThreshold: numThreshold,
        category,
        imageUrl,
        details: details.trim(),
      },
      targetAccountId
    );

    onSaved(saved);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-lg bg-white border border-slate-200/80 rounded-3xl shadow-2xl overflow-hidden my-auto animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-slate-50 px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <Package className="w-5 h-5 text-indigo-600" />
              <span>{productToEdit ? t('formEditTitle') : t('formAddTitle')}</span>
            </h3>
            <p className="text-xs text-slate-500">{t('formSub')}</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Barcode / Product Code */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                <Barcode className="w-3.5 h-3.5 text-indigo-600" /> Barcode Number (Guhit-Guhit sa Plastic / Packaging) *
              </label>
              {justScannedSuccess && (
                <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center gap-1 animate-in fade-in zoom-in-95">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Nakopya ang Barcode!
                </span>
              )}
            </div>

            <div className="flex gap-2 items-center">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={barcode}
                  onChange={(e) => setBarcode(e.target.value)}
                  placeholder="e.g. 4800016022018 (Ilagay ang tunay na barcode mula sa produkto)"
                  className={`w-full bg-slate-50 border ${
                    errors.barcode ? 'border-rose-500' : 'border-slate-200'
                  } rounded-xl px-3.5 py-2.5 text-xs font-mono text-indigo-700 font-bold focus:outline-none focus:border-indigo-600 focus:bg-white transition-colors`}
                />
              </div>

              <button
                type="button"
                onClick={() => setIsScanning((prev) => !prev)}
                className={`py-2.5 px-3 rounded-xl font-bold text-xs flex items-center gap-1.5 shrink-0 transition-all shadow-xs active:scale-95 ${
                  isScanning
                    ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-200'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-200'
                }`}
                title="I-scan ang barcode ng produkto gamit ang camera para automatic na makopya"
              >
                {isScanning ? (
                  <>
                    <CameraOff className="w-4 h-4 shrink-0" />
                    <span className="whitespace-nowrap">Isara Scanner</span>
                  </>
                ) : (
                  <>
                    <Camera className="w-4 h-4 shrink-0" />
                    <span className="whitespace-nowrap">I-scan Barcode</span>
                  </>
                )}
              </button>
            </div>

            {/* Embedded Live Scanner Camera View */}
            {isScanning && (
              <div className="mt-3 p-3 bg-slate-900 rounded-2xl border border-slate-700 text-white shadow-xl animate-in fade-in slide-in-from-top-2 duration-200">
                <div className="flex justify-between items-center mb-2 px-1">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
                    <span className="text-xs font-bold text-slate-200">
                      I-tapat ang Barcode ng Produkto sa Camera
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'))
                    }
                    className="text-[11px] font-semibold bg-slate-800 hover:bg-slate-700 text-indigo-300 px-2.5 py-1 rounded-lg border border-slate-600 flex items-center gap-1 transition-all active:scale-95"
                    title="Palitan ang Camera (Front/Back)"
                  >
                    <RefreshCw className="w-3 h-3" /> Palitan Camera
                  </button>
                </div>

                {/* Video Region */}
                <div className="relative w-full overflow-hidden rounded-xl bg-black border border-slate-700/80 aspect-[4/3] max-h-[260px] flex items-center justify-center">
                  <div id={qrCodeRegionId} className="w-full h-full" />
                  <div className="absolute inset-x-6 top-1/2 -translate-y-1/2 z-10 pointer-events-none flex flex-col items-center">
                    <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-rose-500 to-transparent shadow-[0_0_12px_#f43f5e] animate-pulse" />
                    <span className="text-[10px] font-bold text-rose-300 bg-slate-900/80 px-2.5 py-0.5 rounded-full border border-rose-500/30 mt-2 tracking-wide uppercase shadow-lg">
                      I-tapat ang Guhit-Guhit na Barcode dito
                    </span>
                  </div>
                </div>

                {scanCameraError && (
                  <p className="text-xs text-rose-400 mt-2 bg-rose-950/50 p-2 rounded-lg border border-rose-800 text-center">
                    {scanCameraError}
                  </p>
                )}

                <p className="text-[11px] text-slate-400 text-center mt-2">
                  Kapag nabasa na ng camera ang barcode, automatic na makokopya ito at mailalagay sa textfield sa taas!
                </p>
              </div>
            )}

            <p className="text-[11px] text-slate-500 mt-1">
              Kapag iniscan ito sa Scanner Camera ng POS, automatic na magpo-pop up ang Quick Checkout Confirmation!
            </p>
            {errors.barcode && <p className="text-[11px] text-rose-500 mt-1">{errors.barcode}</p>}
          </div>

          {/* Product Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">{t('productNameLabel')}</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Lucky Me Pancit Canton 60g..."
              className={`w-full bg-slate-50 border ${
                errors.name ? 'border-rose-500' : 'border-slate-200'
              } rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 focus:bg-white`}
            />
            {errors.name && <p className="text-[11px] text-rose-500 mt-1">{errors.name}</p>}
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">{t('categoryLabel')}</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 focus:bg-white"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Price & Cost Price */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t('priceLabel')}</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="0.00"
                className={`w-full bg-slate-50 border ${
                  errors.price ? 'border-rose-500' : 'border-slate-200'
                } rounded-xl px-3.5 py-2.5 text-xs text-indigo-600 font-bold focus:outline-none focus:border-indigo-600 focus:bg-white`}
              />
              {errors.price && <p className="text-[11px] text-rose-500 mt-1">{errors.price}</p>}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t('costLabel')}</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={costPrice}
                onChange={(e) => setCostPrice(e.target.value)}
                placeholder="0.00"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-600 focus:bg-white"
              />
            </div>
          </div>

          {/* Stock & Low Stock Threshold */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t('stockLabel')}</label>
              <input
                type="number"
                min="0"
                value={stock}
                onChange={(e) => setStock(e.target.value)}
                placeholder="10"
                className={`w-full bg-slate-50 border ${
                  errors.stock ? 'border-rose-500' : 'border-slate-200'
                } rounded-xl px-3.5 py-2.5 text-xs text-slate-900 font-bold focus:outline-none focus:border-indigo-600 focus:bg-white`}
              />
              {errors.stock && <p className="text-[11px] text-rose-500 mt-1">{errors.stock}</p>}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t('lowStockLimitLabel')}</label>
              <input
                type="number"
                min="1"
                value={lowStockThreshold}
                onChange={(e) => setLowStockThreshold(e.target.value)}
                placeholder="5"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-orange-600 font-bold focus:outline-none focus:border-indigo-600 focus:bg-white"
              />
            </div>
          </div>

          {/* Notice about real Barcode scanning */}
          <div className="p-3 bg-indigo-50 rounded-2xl border border-indigo-200 text-indigo-900 text-xs flex items-center gap-2">
            <Barcode className="w-4 h-4 text-indigo-600 flex-shrink-0" />
            <span>
              <strong>Tip:</strong> Ang nakalagay na Barcode Number ay magagamit sa POS Scanner Camera o USB Barcode Scanner para sa mabilisang 1-Tap / Quick Checkout!
            </span>
          </div>

          {/* Product Picture Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">{t('imageLabel')}</label>
            <div className="flex gap-3 items-center mb-3">
              <img
                src={imageUrl || undefined}
                alt="Preview"
                className="w-14 h-14 rounded-xl object-cover bg-slate-100 border border-slate-200 flex-shrink-0"
              />
              <div className="flex-1 space-y-1">
                <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg border border-slate-200 transition-colors">
                  <Upload className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Upload Image File</span>
                  <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                </label>
              </div>
            </div>

            {/* Presets Grid */}
            <div className="grid grid-cols-7 gap-1.5">
              {PRESET_IMAGES.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setImageUrl(preset.url)}
                  className={`relative rounded-lg overflow-hidden border transition-all h-10 ${
                    imageUrl === preset.url
                      ? 'border-indigo-600 ring-2 ring-indigo-600/30 scale-105'
                      : 'border-slate-200 opacity-60 hover:opacity-100'
                  }`}
                >
                  <img src={preset.url || undefined} alt={preset.name} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Details / Description */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">{t('detailsLabel')}</label>
            <textarea
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              rows={2}
              placeholder="Size, flavor, packaging notes..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 focus:bg-white"
            />
          </div>

          {/* Footer Submit Button */}
          <div className="pt-2 flex justify-end gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs border border-slate-200"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-100 flex items-center gap-1.5 active:scale-95 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>{t('saveProductBtn')}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
