import React, { useState } from 'react';
import { Shield, X, Edit, Trash2, ExternalLink, CheckCircle2, AlertCircle, Database, UserCheck, Key, Mail, Lock, Store, RefreshCw } from 'lucide-react';
import { UserAccount, UserRole } from '../types';
import {
  getAccounts,
  adminUpdateUserCredentials,
  deleteUserAccount,
  getAdminTargetAccountId,
  setAdminTargetAccountId,
  getActiveUser,
} from '../utils/storage';
import { playSuccessChime } from '../utils/sound';

interface AdminManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAccountChanged: () => void;
}

export const AdminManagerModal: React.FC<AdminManagerModalProps> = ({
  isOpen,
  onClose,
  onAccountChanged,
}) => {
  const activeUser = getActiveUser();
  const accounts = getAccounts();
  const targetDatabaseId = getAdminTargetAccountId();

  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [editPin, setEditPin] = useState('');
  const [editStoreName, setEditStoreName] = useState('');
  const [editRole, setEditRole] = useState<UserRole>('Cashier');
  
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  if (!isOpen) return null;

  // Verify Admin Access
  if (activeUser.email?.toLowerCase() !== 'jeromellames7@gmail.com' && activeUser.role !== 'Admin') {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
        <div className="bg-slate-900 border border-rose-500/50 rounded-3xl p-6 text-center text-white max-w-md">
          <Shield className="w-12 h-12 text-rose-500 mx-auto mb-3" />
          <h3 className="text-lg font-bold">Access Denied</h3>
          <p className="text-xs text-slate-400 mt-1">
            Ang Admin Manager ay eksklusibo lamang para sa account na <strong>jeromellames7@gmail.com</strong>.
          </p>
          <button
            onClick={onClose}
            className="mt-4 px-4 py-2 rounded-xl bg-slate-800 text-white text-xs font-bold"
          >
            Isara
          </button>
        </div>
      </div>
    );
  }

  const handleOpenEdit = (user: UserAccount) => {
    setEditingUser(user);
    setEditName(user.name);
    setEditEmail(user.email || '');
    setEditPassword(user.password || '');
    setEditPin(user.pin || '1234');
    setEditStoreName(user.storeName || '');
    setEditRole(user.role);
    setMsg(null);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    setLoading(true);
    setMsg(null);

    try {
      await adminUpdateUserCredentials(editingUser.id, {
        name: editName,
        email: editEmail,
        password: editPassword,
        pin: editPin,
        storeName: editStoreName,
        role: editRole,
      });

      playSuccessChime();
      setMsg({ type: 'success', text: `Matagumpay na nabago ang credentials ni ${editName}` });
      setEditingUser(null);
      onAccountChanged();
    } catch (err: any) {
      setMsg({ type: 'error', text: err.message || 'Nabigo sa pag-update ng account.' });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (user: UserAccount) => {
    if (user.id === 'user-admin' || user.email?.toLowerCase() === 'jeromellames7@gmail.com') {
      alert('Hindi maaaring burahin ang Primary Admin Account.');
      return;
    }

    if (confirm(`Sigurado ka bang nais mong burahin ang account ni "${user.name}" (${user.email})?`)) {
      try {
        await deleteUserAccount(user.id);
        playSuccessChime();
        setMsg({ type: 'success', text: `Nabura ang account ni ${user.name}` });
        onAccountChanged();
      } catch (err: any) {
        setMsg({ type: 'error', text: err.message });
      }
    }
  };

  const handleSwitchDatabase = (user: UserAccount) => {
    setAdminTargetAccountId(user.id);
    playSuccessChime();
    setMsg({ type: 'success', text: `Pinagana ang live view/edit sa database ni: ${user.name} (${user.storeName})` });
    onAccountChanged();
  };

  const handleResetDatabaseView = () => {
    setAdminTargetAccountId(null);
    playSuccessChime();
    setMsg({ type: 'success', text: 'Bumalik sa iyong sariling Main Admin Database.' });
    onAccountChanged();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto select-none animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-slate-900 border border-amber-500/40 rounded-3xl shadow-[0_20px_60px_rgba(0,0,0,0.9)] overflow-hidden text-white relative my-6 animate-in zoom-in-95 duration-200 flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-700 p-0.5 shadow-lg shadow-amber-500/20 flex items-center justify-center">
              <Shield className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                <span>PRIMARY ADMIN SYSTEM & DATABASE HUB</span>
                <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase">
                  Jerome Control
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Pangasiwaan ang lahat ng Gmail, Passwords, PINs, at Database ng mga User
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-full hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Target Database Banner */}
        <div className="px-6 py-2.5 bg-slate-950/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>
              Aktibong Kinokontrol na Database:{' '}
              <strong className="text-cyan-300 font-mono">
                {targetDatabaseId
                  ? accounts.find((a) => a.id === targetDatabaseId)?.storeName || targetDatabaseId
                  : "Main Admin Database (Jerome's Mini Store)"}
              </strong>
            </span>
          </div>

          {targetDatabaseId && (
            <button
              onClick={handleResetDatabaseView}
              className="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-slate-950 border border-amber-500/40 text-[11px] font-bold flex items-center gap-1 transition-all"
            >
              <RefreshCw className="w-3 h-3" />
              <span>I-reset sa Admin DB</span>
            </button>
          )}
        </div>

        {/* Feedback Message Banner */}
        {msg && (
          <div
            className={`mx-6 mt-4 p-3 rounded-2xl border text-xs flex items-center gap-2 ${
              msg.type === 'success'
                ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300'
                : 'bg-rose-950/80 border-rose-500/40 text-rose-300'
            }`}
          >
            {msg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{msg.text}</span>
          </div>
        )}

        {/* Scrollable Content Area */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          {/* EDIT FORM DRAWER */}
          {editingUser && (
            <div className="p-4 rounded-2xl bg-slate-800/90 border-2 border-amber-500/80 shadow-2xl space-y-3 animate-in fade-in duration-200">
              <div className="flex items-center justify-between pb-2 border-b border-slate-700">
                <h4 className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                  <Edit className="w-4 h-4 text-amber-400" />
                  <span>Palitan ang Credentials & Database Settings ni: {editingUser.name}</span>
                </h4>
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-700"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveEdit} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1 flex items-center gap-1">
                      <Mail className="w-3 h-3 text-cyan-400" />
                      <span>Gmail / Email Address *</span>
                    </label>
                    <input
                      type="email"
                      required
                      value={editEmail}
                      onChange={(e) => setEditEmail(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs focus:border-amber-400 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1 flex items-center gap-1">
                      <Lock className="w-3 h-3 text-amber-400" />
                      <span>Password *</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={editPassword}
                      onChange={(e) => setEditPassword(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-amber-300 font-mono font-bold text-xs focus:border-amber-400 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">Pangalan</label>
                    <input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">Store / Business Name</label>
                    <input
                      type="text"
                      value={editStoreName}
                      onChange={(e) => setEditStoreName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">4-Digit Security PIN</label>
                    <input
                      type="text"
                      maxLength={4}
                      value={editPin}
                      onChange={(e) => setEditPin(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-cyan-300 font-mono font-bold text-xs"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditingUser(null)}
                    className="flex-1 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold transition-all"
                  >
                    Kanselahin
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-extrabold shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
                  >
                    {loading ? 'Sine-save...' : 'I-save ang Pagbabago'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* ACCOUNTS LIST */}
          <div className="space-y-3">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>Lahat ng Nakarehistrong Account sa Firebase ({accounts.length})</span>
              <span className="text-[10px] text-amber-400 font-mono font-normal">
                Full Admin Control Active
              </span>
            </p>

            <div className="space-y-2.5">
              {accounts.map((acc) => {
                const isCurrentDatabase = targetDatabaseId === acc.id || (!targetDatabaseId && acc.id === 'user-admin');
                return (
                  <div
                    key={acc.id}
                    className={`p-3.5 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all ${
                      isCurrentDatabase
                        ? 'bg-slate-800/90 border-cyan-500/60 shadow-lg shadow-cyan-500/10'
                        : 'bg-slate-800/50 border-slate-700/80 hover:bg-slate-800/80'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={acc.avatar || undefined}
                        alt={acc.name}
                        className="w-10 h-10 rounded-full object-cover ring-2 ring-slate-600 shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <p className="text-xs font-bold text-white truncate">{acc.name}</p>
                          <span
                            className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                              acc.role === 'Admin'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                : 'bg-slate-700 text-slate-300'
                            }`}
                          >
                            {acc.role}
                          </span>
                          {acc.email?.toLowerCase() === 'jeromellames7@gmail.com' && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold">
                              Primary Admin
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-cyan-300 font-mono truncate mt-0.5">
                          {acc.email || 'Walang Gmail'}
                        </p>
                        <div className="flex items-center gap-3 text-[10px] text-slate-400 mt-1 font-mono">
                          <span>
                            Password: <strong className="text-amber-300 font-bold">{acc.password || '123456'}</strong>
                          </span>
                          <span>
                            PIN: <strong className="text-cyan-300 font-bold">{acc.pin || '1234'}</strong>
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Controls */}
                    <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0 flex-wrap">
                      <button
                        type="button"
                        onClick={() => handleOpenEdit(acc)}
                        className="px-2.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-slate-950 text-xs font-bold border border-amber-500/30 flex items-center gap-1 transition-all"
                        title="Baguhin ang Gmail, Password, at PIN"
                      >
                        <Edit className="w-3 h-3" />
                        <span>Edit Credentials</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSwitchDatabase(acc)}
                        className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border flex items-center gap-1 transition-all ${
                          targetDatabaseId === acc.id
                            ? 'bg-cyan-500 text-slate-950 border-cyan-400'
                            : 'bg-slate-700/80 hover:bg-slate-700 text-cyan-300 border-slate-600'
                        }`}
                        title="Buksan at baguhin ang kanyang database"
                      >
                        <Database className="w-3 h-3" />
                        <span>{targetDatabaseId === acc.id ? 'Aktibong DB' : 'Access DB'}</span>
                      </button>

                      {acc.id !== 'user-admin' && acc.email?.toLowerCase() !== 'jeromellames7@gmail.com' && (
                        <button
                          type="button"
                          onClick={() => handleDelete(acc)}
                          className="p-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 transition-colors"
                          title="Burahin ang account"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
