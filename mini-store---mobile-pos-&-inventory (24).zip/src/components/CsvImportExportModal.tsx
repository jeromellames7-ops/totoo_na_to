import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { Product } from '../types';
import { getProducts, saveProduct, getEffectiveAccountId } from '../utils/storage';
import { saveToFirestore } from '../utils/firebaseSync';
import { X, FileSpreadsheet, Download, Upload, CheckCircle, FileText, Sparkles, RefreshCw, Database } from 'lucide-react';

interface CsvImportExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CsvImportExportModal: React.FC<CsvImportExportModalProps> = ({ isOpen, onClose }) => {
  const [excelFile, setExcelFile] = useState<File | null>(null);
  const [previewRows, setPreviewRows] = useState<Partial<Product>[]>([]);
  const [importStatus, setImportStatus] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  if (!isOpen) return null;

  // EXPORT INVENTORY TO EXCEL (.XLSX)
  const handleExportExcel = () => {
    const products = getProducts();
    if (products.length === 0) {
      alert('Walang paninda na mai-export sa kasalukuyan.');
      return;
    }

    const data = products.map((p) => ({
      'Barcode': p.barcode || '',
      'Pangalan (Name)': p.name || '',
      'Presyo (Price)': p.price || 0,
      'Puhunan (Cost Price)': p.costPrice || 0,
      'Stock': p.stock || 0,
      'Low Stock Warning': p.lowStockThreshold || 5,
      'Kategorya (Category)': p.category || 'General',
      'Detalye (Details)': p.details || '',
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);

    // Auto-fit column widths
    const max_width = data.reduce((w, r) => Math.max(w, (r['Pangalan (Name)'] || '').toString().length), 10);
    worksheet['!cols'] = [
      { wch: 18 }, // Barcode
      { wch: Math.max(max_width, 25) }, // Name
      { wch: 14 }, // Price
      { wch: 18 }, // Cost Price
      { wch: 10 }, // Stock
      { wch: 18 }, // Low Stock
      { wch: 20 }, // Category
      { wch: 30 }, // Details
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Mga Paninda');
    const dateStr = new Date().toISOString().split('T')[0];
    XLSX.writeFile(workbook, `TindahanPOS_Inventory_${dateStr}.xlsx`);
  };

  // DOWNLOAD EXCEL SAMPLE TEMPLATE (.XLSX)
  const handleDownloadExcelTemplate = () => {
    const sampleData = [
      {
        'Barcode': '4800016001001',
        'Pangalan (Name)': 'Lucky Me Pancit Canton Sweet & Spicy',
        'Presyo (Price)': 18,
        'Puhunan (Cost Price)': 15,
        'Stock': 50,
        'Low Stock Warning': 10,
        'Kategorya (Category)': 'Canned & Instant',
        'Detalye (Details)': 'Sweet & Spicy Flavor',
      },
      {
        'Barcode': '4800092002002',
        'Pangalan (Name)': 'Coca-Cola 1.5L',
        'Presyo (Price)': 75,
        'Puhunan (Cost Price)': 62,
        'Stock': 20,
        'Low Stock Warning': 5,
        'Kategorya (Category)': 'Beverages',
        'Detalye (Details)': 'Malamig na Softdrink',
      },
      {
        'Barcode': '4800123003003',
        'Pangalan (Name)': 'Bear Brand Powdered Milk 33g',
        'Presyo (Price)': 16,
        'Puhunan (Cost Price)': 13.5,
        'Stock': 40,
        'Low Stock Warning': 8,
        'Kategorya (Category)': 'Dairy & Snacks',
        'Detalye (Details)': 'Fortified milk powder',
      },
    ];

    const worksheet = XLSX.utils.json_to_sheet(sampleData);
    worksheet['!cols'] = [
      { wch: 18 },
      { wch: 35 },
      { wch: 14 },
      { wch: 18 },
      { wch: 10 },
      { wch: 18 },
      { wch: 20 },
      { wch: 25 },
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sample Template');
    XLSX.writeFile(workbook, `TindahanPOS_Product_Import_Template.xlsx`);
  };

  // PARSE UPLOADED FILE (.XLSX, .XLS, .CSV)
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setExcelFile(file);
    setIsProcessing(true);
    setImportStatus('Binabasa at ina-analyze ang Excel/CSV file...');

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const rawData = XLSX.utils.sheet_to_json<Record<string, any>>(ws, { defval: '' });

        if (rawData.length === 0) {
          setImportStatus('Walang nahanap na data sa in-upload na file.');
          setIsProcessing(false);
          return;
        }

        const parsed: Partial<Product>[] = rawData
          .map((row, index) => {
            const barcode =
              String(row['Barcode'] || row['barcode'] || row['BARCODE'] || '').trim() ||
              `EXCEL-${Date.now()}-${index + 1}`;
            const name =
              String(
                row['Pangalan (Name)'] ||
                  row['Name'] ||
                  row['Pangalan'] ||
                  row['name'] ||
                  row['Product Name'] ||
                  ''
              ).trim();
            const price =
              parseFloat(row['Presyo (Price)'] || row['Price'] || row['Presyo'] || row['price'] || 0) || 0;
            const costPrice =
              parseFloat(
                row['Puhunan (Cost Price)'] ||
                  row['CostPrice'] ||
                  row['Cost Price'] ||
                  row['Puhunan'] ||
                  row['costPrice'] ||
                  0
              ) || 0;
            const stock =
              parseInt(row['Stock'] || row['stock'] || row['STOCK'] || 0, 10) || 0;
            const lowStockThreshold =
              parseInt(
                row['Low Stock Warning'] ||
                  row['LowStockThreshold'] ||
                  row['Low Stock'] ||
                  row['lowStockThreshold'] ||
                  5,
                10
              ) || 5;
            const category =
              String(
                row['Kategorya (Category)'] ||
                  row['Category'] ||
                  row['Kategorya'] ||
                  row['category'] ||
                  'General'
              ).trim() || 'General';
            const details =
              String(row['Detalye (Details)'] || row['Details'] || row['Detalye'] || row['details'] || '').trim();

            return {
              barcode,
              name,
              price,
              costPrice,
              stock,
              lowStockThreshold,
              category,
              details,
            };
          })
          .filter((p) => Boolean(p.name && p.price > 0));

        if (parsed.length === 0) {
          setImportStatus('Walang valid na paninda (na may Pangalan at Presyo) ang nahanap sa file.');
        } else {
          setPreviewRows(parsed);
          setImportStatus(`✔ Nabasa ang ${parsed.length} na mga paninda mula sa ${file.name}. I-click ang button sa ibaba upang i-save sa System at Firebase!`);
        }
      } catch (err) {
        console.error('Error parsing file:', err);
        setImportStatus('Nagka-error sa pagbasa ng file. Pakisiguradong .xlsx, .xls o .csv ang format.');
      } finally {
        setIsProcessing(false);
      }
    };

    reader.readAsBinaryString(file);
  };

  // SAVE IMPORTED PRODUCTS TO SYSTEM INVENTORY AND FIREBASE FIRESTORE
  const handleConfirmImport = async () => {
    if (previewRows.length === 0) return;

    setIsProcessing(true);
    setImportStatus('Ina-upload at isina-save ang mga paninda sa System Inventory at Firebase Database...');

    const accountId = getEffectiveAccountId();
    let addedCount = 0;

    for (let i = 0; i < previewRows.length; i++) {
      const row = previewRows[i];
      if (row.name && row.price) {
        const prodId = `prod-xl-${Date.now()}-${i}-${Math.floor(Math.random() * 1000)}`;
        const newProduct: Product = {
          id: prodId,
          barcode: row.barcode || `XL-${Date.now()}-${i}`,
          name: row.name,
          price: row.price,
          costPrice: row.costPrice || 0,
          stock: row.stock || 0,
          lowStockThreshold: row.lowStockThreshold || 5,
          category: row.category || 'General',
          imageUrl: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400',
          details: row.details || '',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

        // Save to local storage & notify system listeners
        saveProduct(newProduct, accountId);

        // Direct save to Firebase Firestore database
        try {
          await saveToFirestore('products', prodId, { ...newProduct, accountId });
        } catch (err) {
          console.warn('Firebase direct save notice:', err);
        }

        addedCount++;
      }
    }

    setIsProcessing(false);
    setImportStatus(`🎉 MATAGUMPAY! Na-upload at na-save ang ${addedCount} na paninda sa System Inventory at Firebase Database!`);
    setPreviewRows([]);
    setExcelFile(null);

    setTimeout(() => {
      onClose();
    }, 2200);
  };

  return (
    <div className="fixed inset-0 z-70 bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-slate-900 text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-lg shadow-emerald-600/30">
              <FileSpreadsheet className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight flex items-center gap-2">
                <span>Excel Spreadsheet Bulk Import / Export</span>
              </h3>
              <p className="text-xs text-slate-300">
                I-download bilang Excel Table o mag-upload ng Excel (.xlsx / .csv) file papuntang Firebase Database.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 flex-1 overflow-y-auto space-y-5 bg-slate-50/50">
          {/* Export Section */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase text-slate-500 tracking-wider flex items-center gap-2">
                <Download className="w-4 h-4 text-emerald-600" />
                <span>1. Download Current Products to Excel Spreadsheet</span>
              </h4>
              <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-extrabold text-[10px] rounded-full border border-emerald-200">
                .XLSX Format
              </span>
            </div>
            <p className="text-xs text-slate-600">
              Awtomatikong i-export ang lahat ng paninda at barcode sa isang magandang formatted <strong>Excel Table (.xlsx)</strong> na pwedeng buksan sa Microsoft Excel o Google Sheets.
            </p>
            <button
              onClick={handleExportExcel}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-xl shadow-md shadow-emerald-600/20 flex items-center gap-2 transition-all active:scale-95"
            >
              <Download className="w-4 h-4 stroke-[3px]" />
              <span>DOWNLOAD EXCEL SPREADSHEET (.XLSX)</span>
            </button>
          </div>

          {/* Import Section */}
          <div className="bg-white border border-slate-200/90 rounded-2xl p-4 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black uppercase text-slate-500 tracking-wider flex items-center gap-2">
                <Upload className="w-4 h-4 text-indigo-600" />
                <span>2. Upload Excel / CSV Data to Inventory & Firebase</span>
              </h4>
              <button
                onClick={handleDownloadExcelTemplate}
                className="text-[11px] text-indigo-600 font-extrabold hover:underline flex items-center gap-1"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Download Sample Excel Template</span>
              </button>
            </div>

            {/* Upload File Input / Drop Area */}
            <div className="border-2 border-dashed border-indigo-200 hover:border-indigo-400 rounded-2xl p-6 text-center bg-indigo-50/20 transition-all">
              <input
                type="file"
                accept=".xlsx, .xls, .csv"
                onChange={handleFileChange}
                className="hidden"
                id="excel-file-input"
              />
              <label htmlFor="excel-file-input" className="cursor-pointer space-y-2 block">
                <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mx-auto border border-indigo-200">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xs font-black text-slate-900 block">
                    {excelFile ? excelFile.name : 'I-click para pumili at mag-upload ng Excel (.xlsx / .csv) File'}
                  </span>
                  <span className="text-[11px] text-slate-500 block mt-0.5">
                    Tumatanggap ng Microsoft Excel (.xlsx, .xls) o CSV files
                  </span>
                </div>
              </label>
            </div>

            {/* Status Message */}
            {importStatus && (
              <div className="text-xs font-bold text-indigo-900 bg-indigo-50 p-3 rounded-xl border border-indigo-200 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>{importStatus}</span>
              </div>
            )}

            {/* Preview Parsed Table */}
            {previewRows.length > 0 && (
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <h5 className="text-xs font-extrabold text-slate-800">
                    Preview ng mga Paninda ({previewRows.length} items):
                  </h5>
                  <span className="text-[11px] text-slate-500">I-verify bago i-save</span>
                </div>

                <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-xl bg-white text-[11px] shadow-xs">
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-slate-100 font-black text-slate-700 border-b border-slate-200 uppercase text-[10px]">
                      <tr>
                        <th className="p-2.5">Barcode</th>
                        <th className="p-2.5">Pangalan</th>
                        <th className="p-2.5">Presyo</th>
                        <th className="p-2.5">Puhunan</th>
                        <th className="p-2.5">Stock</th>
                        <th className="p-2.5">Kategorya</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {previewRows.map((r, i) => (
                        <tr key={i} className="hover:bg-slate-50">
                          <td className="p-2.5 font-mono text-slate-500">{r.barcode}</td>
                          <td className="p-2.5 font-bold text-slate-900">{r.name}</td>
                          <td className="p-2.5 font-black text-indigo-600">₱{r.price}</td>
                          <td className="p-2.5 text-slate-600">₱{r.costPrice || 0}</td>
                          <td className="p-2.5 font-bold text-slate-800">{r.stock}</td>
                          <td className="p-2.5 text-slate-500">{r.category}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Confirm Upload Button */}
                <button
                  onClick={handleConfirmImport}
                  disabled={isProcessing}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-300 text-white font-black text-xs rounded-xl shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 active:scale-95 transition-all"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>INA-UPLOAD AT ISINA-SAVE SA FIREBASE...</span>
                    </>
                  ) : (
                    <>
                      <Database className="w-4 h-4" />
                      <span>I-UPLOAD AT I-SAVE ANG {previewRows.length} NA PANINDA SA SYSTEM & FIREBASE</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-100 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl transition-colors hover:bg-slate-800"
          >
            Isara
          </button>
        </div>
      </div>
    </div>
  );
};

