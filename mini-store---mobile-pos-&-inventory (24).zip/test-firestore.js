import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore';
import fs from 'fs';

const config = JSON.parse(fs.readFileSync('./firebase-applet-config.json', 'utf8'));

const app = initializeApp(config);
const db = config.firestoreDatabaseId ? getFirestore(app, config.firestoreDatabaseId) : getFirestore(app);

async function test() {
  console.log("Checking Firestore database:", config.firestoreDatabaseId);
  try {
    const snap = await getDocs(collection(db, 'extracted_documents'));
    console.log("Found extracted_documents count:", snap.size);
    snap.forEach(d => {
      const data = d.data();
      const rows = data.sections?.reduce((a, s) => a + (s.rows?.length || 0), 0) || 0;
      console.log("Doc ID:", d.id, "Title:", data.title, "Total Rows:", rows, "Person:", data.detectedPersonName);
    });

    const pdsSnap = await getDocs(collection(db, 'pds_pictures'));
    console.log("Found pds_pictures count:", pdsSnap.size);
  } catch (err) {
    console.error("Firestore test error:", err);
  }
  process.exit(0);
}

test();
