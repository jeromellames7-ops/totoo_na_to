const fs = require('fs');
let code = fs.readFileSync('src/components/DocExtractor.tsx', 'utf8');

const targetBlock = `              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {filteredDbDocs.map((docItem, idx) => {
                    const personName = getDocumentPersonName(docItem);
                    const totalRows = (docItem.sections || []).reduce(
                      (acc, s) => acc + (s.rows ? s.rows.length : 0),
                      0
                    );
                    const isCurrentlyActive = result && result.id === docItem.id;

                    return (
                      <div
                        key={docItem.id || idx}
                        className={\`p-4 rounded-2xl bg-white border transition-all space-y-3 shadow-xs flex flex-col justify-between \${
                          isCurrentlyActive
                            ? 'border-emerald-600 ring-2 ring-emerald-500/20 bg-emerald-50/10'
                            : 'border-slate-300 hover:border-emerald-500 hover:shadow-md'
                        }\`}
                      >
                        <div className="space-y-2">
                          {/* Top Tag & Delete */}
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-emerald-100 text-emerald-950 border border-emerald-300 text-xs font-extrabold">
                                <User className="w-3.5 h-3.5 text-emerald-700" />
                                <span>{personName}</span>
                              </span>
                              {isCurrentlyActive && (
                                <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white font-mono text-[9px] font-extrabold uppercase">
                                  Aktibo
                                </span>
                              )}
                            </div>

                            <button
                              onClick={() => {
                                if (
                                  window.confirm(
                                    \`PERMANENTENG PAGBURA: Sigurado ka bang nais mong burahin si "\${personName}" mula sa Firebase Database? Hindi na ito maibabalik.\`
                                  )
                                ) {
                                  deleteDocumentFromFirestore(docItem.id);
                                }
                              }}
                              className="px-2 py-1 rounded-lg text-rose-600 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-xs font-bold flex items-center gap-1 transition-all"
                              title="Permanenteng burahin sa Firebase Database"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Burahin</span>
                            </button>
                          </div>

                          {/* Title & Document Type */}
                          <div>
                            <h4 className="text-xs font-bold text-slate-900 leading-snug">
                              {docItem.title || docItem.documentType}
                            </h4>
                            <p className="text-[10px] text-slate-500 font-mono mt-0.5">
                              ID: {docItem.id}
                            </p>
                          </div>

                          {/* Metadata Badges */}
                          <div className="flex items-center gap-2 text-[11px] font-mono text-slate-600 flex-wrap">
                            <span className="px-2 py-0.5 rounded bg-slate-100 border border-slate-200">
                              {docItem.sections ? docItem.sections.length : 0} Seksyon
                            </span>
                            <span className="px-2 py-0.5 rounded bg-slate-100 border border-slate-200">
                              {totalRows} Rows
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {new Date(docItem.scannedAt || Date.now()).toLocaleDateString()}
                            </span>
                          </div>
                        </div>

                        {/* Action Buttons Toolbar */}
                        <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between gap-2">
                          <div className="flex items-center gap-1">
                            {/* Export Excel from DB */}
                            <button
                              onClick={() => {
                                const wb = XLSX.utils.book_new();
                                (docItem.sections || []).forEach((sec, sIdx) => {
                                  const sheetData: any[] = [];
                                  (sec.rows || []).forEach((r) => sheetData.push(r));
                                  const ws = XLSX.utils.json_to_sheet(sheetData);
                                  const sheetName =
                                    sec.sectionTitle.replace(/[\/\\\?\*\[\]]/g, '').slice(0, 25) ||
                                    \`Section \${sIdx + 1}\`;
                                  XLSX.utils.book_append_sheet(wb, ws, sheetName);
                                });
                                XLSX.writeFile(
                                  wb,
                                  \`\${(docItem.detectedPersonName || docItem.title).replace(/\\s+/g, '_')}.xlsx\`
                                );
                              }}
                              className="p-1.5 rounded-lg text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 transition-colors"
                              title="I-export bilang Excel (.xlsx)"
                            >
                              <Download className="w-4 h-4" />
                            </button>

                            {/* Copy Markdown */}
                            <button
                              onClick={() => {
                                if (docItem.consolidatedMarkdownTable) {
                                  navigator.clipboard.writeText(docItem.consolidatedMarkdownTable);
                                  triggerAutoSaveToast('Na-copy ang Markdown table!');
                                }
                              }}
                              className="p-1.5 rounded-lg text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 transition-colors"
                              title="Kopyahin ang Markdown table code"
                            >
                              <Copy className="w-4 h-4" />
                            </button>
                          </div>

                          {/* Open / Load in Table */}
                          <button
                            onClick={() => {
                              setResult(docItem);
                              if (docItem.imagesBase64 && docItem.imagesBase64.length > 0) {
                                setSelectedImages(docItem.imagesBase64);
                              }
                              setIsDatabaseModalOpen(false);
                              triggerAutoSaveToast(\`Na-load ang "\${personName}" sa table!\`);
                            }}
                            className="px-3.5 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-sm transition-all active:scale-95"
                          >
                            <FileCheck className="w-3.5 h-3.5" />
                            <span>Buksan sa Table</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}`;

const replacement = `              ) : (
                <div className="overflow-x-auto rounded-xl border border-slate-200">
                  <table className="w-full text-left text-xs whitespace-nowrap bg-white">
                    <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                      <tr>
                        <th className="px-4 py-3 font-extrabold">#</th>
                        <th className="px-4 py-3 font-extrabold">Pangalan (Name)</th>
                        <th className="px-4 py-3 font-extrabold">Petsa ng Kapanganakan</th>
                        <th className="px-4 py-3 font-extrabold">Form Tag</th>
                        <th className="px-4 py-3 font-extrabold">Aksyon</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(() => {
                        const allRows: any[] = [];
                        let absoluteIndex = 1;
                        filteredDbDocs.forEach((docItem) => {
                          (docItem.sections || []).forEach((sec, sIdx) => {
                            (sec.rows || []).forEach((r, rIdx) => {
                              allRows.push({
                                docItem,
                                section: sec,
                                row: r,
                                rIdx,
                                sIdx,
                                absoluteIndex: absoluteIndex++
                              });
                            });
                          });
                        });
                        
                        return allRows.map((item) => {
                          const { docItem, row, absoluteIndex, sIdx, rIdx } = item;
                          const rawName = row['NAME (SURNAME, FIRST NAME, MIDDLE NAME)']?.trim() || docItem.detectedPersonName || 'HINDI MATUKOY';
                          const rawDOB = row['DATE OF BIRTH (MM, DD, YYYY)']?.trim() || row['DATE OF BIRTH']?.trim() || '-';
                          const isCurrentlyActive = result && result.id === docItem.id;
                          
                          return (
                            <tr key={\`db-row-\${docItem.id}-\${sIdx}-\${rIdx}\`} className={\`hover:bg-emerald-50/50 transition-colors \${isCurrentlyActive ? 'bg-emerald-50/20' : ''}\`}>
                              <td className="px-4 py-3 font-mono text-slate-400">{absoluteIndex}</td>
                              <td className="px-4 py-3 font-bold text-emerald-900">
                                {rawName}
                                {isCurrentlyActive && (
                                  <span className="ml-2 px-1.5 py-0.5 rounded text-[9px] bg-emerald-100 text-emerald-700 font-bold uppercase tracking-wide">
                                    Aktibo
                                  </span>
                                )}
                              </td>
                              <td className="px-4 py-3 text-slate-600">{rawDOB}</td>
                              <td className="px-4 py-3 text-slate-500 font-mono text-[10px] truncate max-w-[150px]" title={docItem.title || docItem.documentType}>
                                {docItem.title || docItem.documentType}
                              </td>
                              <td className="px-4 py-3">
                                <div className="flex items-center gap-2">
                                  <button
                                    onClick={() => {
                                      setResult(docItem);
                                      if (docItem.imagesBase64 && docItem.imagesBase64.length > 0) {
                                        setSelectedImages(docItem.imagesBase64);
                                      }
                                      setIsDatabaseModalOpen(false);
                                      triggerAutoSaveToast(\`Na-load ang rekord ni "\${rawName}" sa table!\`);
                                    }}
                                    className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-[10px] hover:bg-emerald-700 flex items-center gap-1 shadow-sm"
                                  >
                                    <FileCheck className="w-3 h-3" />
                                    Load Document
                                  </button>
                                  
                                  <button
                                    onClick={async () => {
                                      if (window.confirm(\`Sigurado ka bang nais mong burahin ang row ni "\${rawName}"?\`)) {
                                        // Clone doc
                                        const updatedDoc = JSON.parse(JSON.stringify(docItem));
                                        if (updatedDoc.sections && updatedDoc.sections[sIdx] && updatedDoc.sections[sIdx].rows) {
                                          updatedDoc.sections[sIdx].rows.splice(rIdx, 1);
                                        }
                                        
                                        const totalRowsRemaining = updatedDoc.sections.reduce((acc: number, sec: any) => acc + (sec.rows?.length || 0), 0);
                                        if (totalRowsRemaining === 0) {
                                          await deleteDocumentFromFirestore(docItem.id);
                                        } else {
                                          await saveDocumentToFirestore(updatedDoc);
                                          const updatedDocs = firestoreDocs.map(d => d.id === docItem.id ? updatedDoc : d);
                                          setFirestoreDocs(updatedDocs);
                                          if (result?.id === docItem.id) {
                                            setResult(updatedDoc);
                                          }
                                        }
                                        triggerAutoSaveToast(\`Nabura ang rekord ni "\${rawName}".\`);
                                      }
                                    }}
                                    className="p-1.5 rounded-lg text-rose-500 bg-rose-50 hover:bg-rose-100 hover:text-rose-700 border border-rose-100"
                                    title="Burahin ang Row"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        });
                      })()}
                    </tbody>
                  </table>
                </div>
              )}`;

if (code.includes(targetBlock)) {
  code = code.replace(targetBlock, replacement);
  fs.writeFileSync('src/components/DocExtractor.tsx', code);
  console.log('Success');
} else {
  console.log('Target block not found');
}
