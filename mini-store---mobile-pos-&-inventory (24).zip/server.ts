import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import { db } from './src/db/index.ts';
import { docExtractorState, extractedDocuments, pdsPictures, users } from './src/db/schema.ts';
import { eq } from 'drizzle-orm';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));

// Server-side Gemini AI Client with flexible key fallback
const getGeminiClient = (customKey?: string) => {
  const apiKey = customKey || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured.');
  }
  return new GoogleGenAI({
    apiKey: apiKey.trim(),
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// Persistent cloud database file for multi-device sync
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'cloud-sync-db.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface AccountSyncData {
  products: any[];
  sales: any[];
  utang: any[];
  shifts: any[];
  updatedAt: string;
}

interface ServerSyncStore {
  accounts: Record<string, AccountSyncData>;
  lastServerUpdate: string;
}

function loadCloudDb(): ServerSyncStore {
  try {
    if (fs.existsSync(DB_FILE)) {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(content);
    }
  } catch (err) {
    console.error('Error reading cloud DB file:', err);
  }
  return { accounts: {}, lastServerUpdate: new Date().toISOString() };
}

function saveCloudDb(data: ServerSyncStore) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing cloud DB file:', err);
  }
}

// SSE Clients connected across devices
let sseClients: express.Response[] = [];

function broadcastDataUpdate(accountId: string, updatedByDevice?: string) {
  const payload = JSON.stringify({
    type: 'CLOUD_DATA_MUTATED',
    accountId,
    updatedByDevice,
    timestamp: new Date().toISOString(),
  });

  sseClients.forEach((client) => {
    client.write(`data: ${payload}\n\n`);
  });
}

// 1. Health check endpoint for network status checks
app.get('/api/sync/health', (req, res) => {
  res.json({ status: 'ok', online: true, serverTime: new Date().toISOString() });
});

const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function executeGeminiWithRetry(
  ai: any,
  params: any,
  modelsToTry: string[] = ['gemini-3.1-flash-lite', 'gemini-flash-latest', 'gemini-3.7-flash']
) {
  let response: any = null;
  let lastError: any = null;

  for (let i = 0; i < modelsToTry.length; i++) {
    const m = modelsToTry[i];
    try {
      response = await ai.models.generateContent({
        ...params,
        model: m,
      });
      const responseText =
        response?.text ||
        response?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join('') ||
        '';
      if (response && (responseText || response.candidates)) {
        return response;
      }
    } catch (err: any) {
      lastError = err;
      const msg = String(err?.message || err);
      const isRateOrQuota =
        msg.includes('429') ||
        msg.includes('RESOURCE_EXHAUSTED') ||
        msg.includes('quota') ||
        msg.includes('rate');

      // Brief backoff before trying fallback model (slightly longer if rate-limited)
      const waitTime = isRateOrQuota ? 400 + i * 200 : 150;
      await delay(waitTime);
      continue;
    }
  }

  if (!response || (!response.text && !response.candidates)) {
    const lastMsg = String(lastError?.message || lastError || '');
    if (
      lastMsg.includes('429') ||
      lastMsg.includes('RESOURCE_EXHAUSTED') ||
      lastMsg.includes('Quota limit exceeded') ||
      lastMsg.includes('quota')
    ) {
      throw new Error(
        'Pansamantalang naabot ang rate limit sa Gemini API. Maghintay ng ilang segundo o maglagay ng sariling API Key sa Settings.'
      );
    }
    throw lastError || new Error('Kasalukuyang mataas ang demand sa AI models (503). Awtomatikong magre-retry.');
  }

  return response;
}

// AI Business Assistant chat endpoint
app.post('/api/business-chat', async (req, res) => {
  try {
    const { prompt, customApiKey } = req.body;
    if (!prompt) {
      return res.status(400).json({ success: false, error: 'Prompt is required' });
    }

    const ai = getGeminiClient(customApiKey);
    const response = await executeGeminiWithRetry(ai, { contents: prompt });
    const text = response?.text || '';

    if (!text) {
      throw new Error('No response from AI');
    }

    res.json({ success: true, text });
  } catch (err: any) {
    console.error('Error in /api/business-chat:', err);
    res.status(500).json({ success: false, error: err.message || 'Error generating business advice' });
  }
});

// AI Form & Document Table Extractor Endpoint
app.post('/api/extract-document', async (req, res) => {
  try {
    const { images, titleHint, customApiKey, customHeaders } = req.body;
    if (!images || !Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ success: false, error: 'Nag-aabang ng kamakailang larawan ng dokumento o form.' });
    }

    const ai = getGeminiClient(customApiKey);

    // Prepare multimodal image parts
    const parts: any[] = [];
    images.forEach((imgStr: string) => {
      let mimeType = 'image/png';
      let base64Data = imgStr;

      if (imgStr.startsWith('data:')) {
        const matches = imgStr.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
        if (matches) {
          mimeType = matches[1];
          base64Data = matches[2];
        } else {
          base64Data = imgStr.split(',')[1] || imgStr;
        }
      }

      parts.push({
        inlineData: {
          mimeType,
          data: base64Data,
        },
      });
    });

    const defaultHeaders = [
      'NAME (SURNAME, FIRST NAME, MIDDLE NAME)',
      'SUFFIX',
      'DATE OF BIRTH (MM, DD, YYYY)',
      'SEX',
      'CIVIL STATUS',
      'ADDRESS (PUROK, BRGY, MUNICIPALITY, PROVINCE)',
      'HEIGHT (Kg)',
      'WEIGHT (Kg)',
      'BLOOD TYPE',
      'RELIGION',
      'PHILHEALTH NO.',
      'SSS NO.',
      'PAG IBIG NO.',
      'TIN NO.',
      'PhilSys Number (PSN)',
      "Voter's Identification Number :",
      'CP NO.',
      'EMAIL ADDRESS',
      'EMPLOYMENT STATUS',
      'HOW LONG HAVE YOU BEEN LOOKING FOR WORK (MONTHS)',
      'PREFERRED OCCUPATION',
      'EDUCATIONAL BACKROUND (SCHOOL, COURSE, YEAR GRAD.)',
      'CERTIFICATION/VOCATIONAL TRAINING',
      'ELIGIBILITY/LICENSE (DATE TAKEN, VALID UNTIL)',
      'WORK EXPERIENCE (EMPLOYER NAME, ADDRESS, POSITION HELD, INCLUSIVE DATES, STATUS)',
      'OTHER SKILLS',
    ];

    const activeHeaders: string[] =
      Array.isArray(customHeaders) && customHeaders.length > 0
        ? customHeaders.map((h: any) => String(h || '').trim()).filter((h: string) => h.length > 0)
        : defaultHeaders;

    const headersListText = activeHeaders.map((h, idx) => `${idx + 1}. ${h}`).join('\n');

    const sampleRowObj: Record<string, string> = {};
    activeHeaders.forEach((h) => {
      sampleRowObj[h] = '';
    });

    const extractionInstruction = `
Ikaw ay isang ultra-fast AI Document Data Extractor para sa mga form (PDS, NSRP, Resume, Bio-data).
BUMASA NG HANDWRITTEN (sulat-kamay) at COMPUTER-PRINTED text.

MAHIGPIT NA PATAKARAN SA ZERO HALLUCINATION:
- HINDI KA PWEDENG MAGSINUNGALING: Kung hindi mo TOTOONG NAKITA o NABASA nang malinaw sa larawan ang isang datos para sa header, IWANANG BLANKO O EMPTY STRING ("") ITO!
- BAWAL maglagay ng placeholder ("N/A", "Unknown", "Juan Dela Cruz", atbp.). Tanging TOTOONG nakasulat lamang.
- Awtomatikong unawain ang papel kahit baligtad (180 deg) o nakatagilid.

${titleHint ? `TALA MULA SA GUMAGAMIT: ${titleHint}\n` : ''}
KUNIN ANG MGA DATOS PARA SA SUMUSUNOD NA MGA HEADERS:
${headersListText}

Format your output STRICTLY as valid JSON:
{
  "detectedPersonName": "BUONG PANGALAN NG APLIKANTE",
  "rows": [
    {
      "NAME (SURNAME, FIRST NAME, MIDDLE NAME)": "",
      "DATE OF BIRTH (MM, DD, YYYY)": "",
      "SEX": "",
      "CIVIL STATUS": "",
      "ADDRESS (PUROK, BRGY, MUNICIPALITY, PROVINCE)": "",
      "TIN NO.": "",
      "CP NO.": ""
    }
  ]
}
Kung walang nakitang datos sa isang header, ibalik ang "".
Return ONLY valid JSON.
`;

    parts.push({ text: extractionInstruction });

    const response = await executeGeminiWithRetry(
      ai,
      {
        contents: { parts },
        config: {
          temperature: 0.1,
          responseMimeType: 'application/json',
          thinkingConfig: {
            thinkingBudget: 0,
          },
        },
      },
      ['gemini-3.1-flash-lite', 'gemini-flash-latest', 'gemini-3.7-flash']
    );

    const rawText =
      response?.text ||
      response?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join('') ||
      '';

    if (!rawText) {
      throw new Error('Kasalukuyang mataas ang demand sa AI model (503). Pakisubukan muli pagkalipas ng ilang sandali.');
    }

    let parsedJson: any = null;

    try {
      parsedJson = JSON.parse(rawText);
    } catch (parseErr) {
      // Fallback clean regex match if model surrounds with ```json
      const jsonMatch = rawText.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
      if (jsonMatch) {
        parsedJson = JSON.parse(jsonMatch[1]);
      } else {
        throw new Error('Hindi ma-parse ang JSON output ng AI.');
      }
    }

    const TARGET_19_HEADERS = [
      'NAME (SURNAME, FIRST NAME, MIDDLE NAME)',
      'SUFFIX',
      'DATE OF BIRTH (MM, DD, YYYY)',
      'SEX',
      'CIVIL STATUS',
      'ADDRESS (PUROK, BRGY, MUNICIPALITY, PROVINCE)',
      'HEIGHT (CM)',
      'RELIGION',
      'TIN NO.',
      'CP NO.',
      'EMAIL ADDRESS',
      'EMPLOYMENT STATUS',
      'HOW LONG HAVE YOU BEEN LOOKING FOR WORK (MONTHS)',
      'PREFERRED OCCUPATION',
      'EDUCATIONAL BACKROUND (SCHOOL, COURSE, YEAR GRAD.)',
      'CERTIFICATION/VOCATIONAL TRAINING',
      'ELIGIBILITY/LICENSE (DATE TAKEN, VALID UNTIL)',
      'WORK EXPERIENCE (EMPLOYER NAME, ADDRESS, POSITION HELD, INCLUSIVE DATES, STATUS)',
      'OTHER SKILLS',
    ];

    // Build unified normalized rows
    let extractedRows: any[] = [];
    if (parsedJson?.rows && Array.isArray(parsedJson.rows) && parsedJson.rows.length > 0) {
      extractedRows = parsedJson.rows;
    } else if (parsedJson?.sections && Array.isArray(parsedJson.sections)) {
      parsedJson.sections.forEach((sec: any) => {
        if (sec.rows && Array.isArray(sec.rows)) {
          extractedRows.push(...sec.rows);
        }
      });
    }

    if (extractedRows.length === 0) {
      extractedRows = [sampleRowObj];
    }

    const normalizedRows = extractedRows.map((r: any) => {
      const rowObj: Record<string, string> = {};
      activeHeaders.forEach((hdr) => {
        if (r[hdr] !== undefined) {
          rowObj[hdr] = String(r[hdr] || '');
        } else {
          // Flexible fuzzy match for similar keys
          const cleanHdr = hdr.toLowerCase().replace(/[^a-z0-9]/g, '');
          const foundKey = Object.keys(r).find((k) => {
            const cleanK = k.toLowerCase().replace(/[^a-z0-9]/g, '');
            return cleanHdr.includes(cleanK) || cleanK.includes(cleanHdr);
          });
          rowObj[hdr] = foundKey ? String(r[foundKey] || '') : (r[hdr] || '');
        }
      });
      return rowObj;
    });

    const detectedDocName =
      parsedJson?.detectedPersonName ||
      normalizedRows[0]?.[activeHeaders[0]] ||
      normalizedRows[0]?.['NAME (SURNAME, FIRST NAME, MIDDLE NAME)'] ||
      'Aplikante PDS';

    // Build fast local Markdown table in 0ms (no LLM token generation needed)
    const mdHeaders = activeHeaders.join(' | ');
    const mdDividers = activeHeaders.map(() => '---').join(' | ');
    const mdRows = normalizedRows
      .map((row) => activeHeaders.map((h) => row[h] || '-').join(' | '))
      .join('\n');

    const formattedData = {
      detectedPersonName: detectedDocName,
      documentType: titleHint || 'PDS / Document Form',
      totalPages: images.length,
      detectedPageNumbers: [`Page 1 of ${images.length}`],
      sections: [
        {
          sectionTitle: 'RECORD NG DOKUMENTO / TABLE',
          headers: activeHeaders,
          rows: normalizedRows,
          checkboxes: [],
          notes: 'Target headers extracted',
        },
      ],
      signaturesAndDates: [],
      consolidatedMarkdownTable: `| ${mdHeaders} |\n| ${mdDividers} |\n${mdRows}`,
      unreadableSummary: '',
    };

    return res.json({
      success: true,
      data: formattedData,
      scannedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('Error in /api/extract-document:', err);
    return res.status(500).json({
      success: false,
      error: err.message || 'Nagkaroon ng error sa pag-scan ng dokumento.',
    });
  }
});

// Dedicated fast endpoint: Extract Applicant Name directly from PDS Picture Image with Candidate Table Matching
app.post('/api/extract-pds-name', async (req, res) => {
  try {
    const { image, candidateNames, customApiKey } = req.body;
    if (!image) {
      return res.status(400).json({ success: false, error: 'Nag-aabang ng larawan ng PDS.' });
    }

    const ai = getGeminiClient(customApiKey);

    let mimeType = 'image/jpeg';
    let base64Data = image;

    if (image.startsWith('data:')) {
      const matches = image.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
      if (matches) {
        mimeType = matches[1];
        base64Data = matches[2];
      } else {
        base64Data = image.split(',')[1] || image;
      }
    }

    const candidateListStr = Array.isArray(candidateNames) && candidateNames.length > 0
      ? candidateNames.slice(0, 500).map((n: string, idx: number) => `${idx + 1}. ${String(n).trim()}`).join('\n')
      : '';

    const prompt = `IKAW AY ISANG DALUBHASANG OCR AI EXPERT PARA SA CIVIL SERVICE PERSONAL DATA SHEET (CS FORM NO. 212 REVISED 2017 / 2025, BIO-DATA, RESUME, O APPLICATION FORM).
TIGNAN NG MABUTI AT BASAHIN NANG EKSAKTO KUNG ANO ANG NAKASULAT SA MISMONG LARAWAN NG PDS.

MAHALAGANG TAGUBILIN:
Basahin ang Block I. PERSONAL INFORMATION sa mga kahon:
1. SURNAME (Apelyido)
2. FIRST NAME (Pangalan)
3. MIDDLE NAME (Gitnang Pangalan)
4. NAME EXTENSION (JR., SR., III, IV - kung N/A o blangko, iwanang blangko)

PAALALA:
- Basahin nang mabuti kung ano ang nakasulat sa loob ng mga kahon ng PDS picture (maaaring computerized all-caps o sulat-kamay).
- Halimbawa kung ang nakasulat sa larawan ay:
  SURNAME: PERMANES
  FIRST NAME: MARCELINA
  MIDDLE NAME: QUINEZ
  NAME EXTENSION: N/A
  Ang buong pangalan ay: "PERMANES, MARCELINA QUINEZ"
- KUNG ANO ANG NAKASULAT SA LARAWAN, IYON LAMANG ANG KUNIN. HUWAG MANGHULA NG IBANG TAO O APELYIDO.
${candidateListStr ? `
Mga kilalang pangalan sa database:
${candidateListStr}
Kung ang nabasa sa larawan ay may eksaktong katugma sa listahan (parehong apelyido at unang pangalan), ilagay ito sa "matchedCandidate". Kung hindi tugma, ilagay ang null.` : ''}

Magbalik LAMANG ng valid JSON object:
{
  "surname": "APELYIDO MULA SA LARAWAN",
  "firstName": "UNANG PANGALAN MULA SA LARAWAN",
  "middleName": "GITNANG PANGALAN KUNG MAYROON",
  "nameExtension": "EXTENSION KUNG MAYROON O BLANGKO",
  "applicantName": "SURNAME, FIRST NAME MIDDLE NAME",
  "matchedCandidate": null
}`;

    const response = await executeGeminiWithRetry(
      ai,
      {
        contents: [
          {
            role: 'user',
            parts: [
              { inlineData: { mimeType, data: base64Data } },
              { text: prompt },
            ],
          },
        ],
        config: {
          responseMimeType: 'application/json',
          maxOutputTokens: 400,
          temperature: 0.1,
        },
      },
      ['gemini-3.1-flash-lite', 'gemini-flash-latest', 'gemini-3.7-flash']
    );

    const rawText =
      response?.text ||
      response?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join('') ||
      '';

    let applicantName = '';
    let matchedCandidate: string | null = null;
    try {
      const parsed = JSON.parse(rawText);
      const sName = (parsed.surname || '').trim().replace(/^N\/A$/i, '');
      const fName = (parsed.firstName || '').trim().replace(/^N\/A$/i, '');
      const mName = (parsed.middleName || '').trim().replace(/^N\/A$/i, '');
      const ext = (parsed.nameExtension || '').trim().replace(/^(N\/A|NONE)$/i, '');

      if (sName && fName) {
        applicantName = `${sName}, ${fName}${mName ? ' ' + mName : ''}${ext ? ' ' + ext : ''}`.toUpperCase();
      } else {
        applicantName = (parsed.applicantName || '').trim().toUpperCase();
      }

      if (
        parsed.matchedCandidate &&
        typeof parsed.matchedCandidate === 'string' &&
        parsed.matchedCandidate.trim().length > 0 &&
        parsed.matchedCandidate.toLowerCase() !== 'null'
      ) {
        matchedCandidate = parsed.matchedCandidate.trim();
      }
    } catch (e) {
      const jsonMatch = rawText.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
      if (jsonMatch) {
        try {
          const parsed = JSON.parse(jsonMatch[1]);
          const sName = (parsed.surname || '').trim().replace(/^N\/A$/i, '');
          const fName = (parsed.firstName || '').trim().replace(/^N\/A$/i, '');
          const mName = (parsed.middleName || '').trim().replace(/^N\/A$/i, '');
          const ext = (parsed.nameExtension || '').trim().replace(/^(N\/A|NONE)$/i, '');

          if (sName && fName) {
            applicantName = `${sName}, ${fName}${mName ? ' ' + mName : ''}${ext ? ' ' + ext : ''}`.toUpperCase();
          } else {
            applicantName = (parsed.applicantName || '').trim().toUpperCase();
          }

          if (
            parsed.matchedCandidate &&
            typeof parsed.matchedCandidate === 'string' &&
            parsed.matchedCandidate.trim().length > 0 &&
            parsed.matchedCandidate.toLowerCase() !== 'null'
          ) {
            matchedCandidate = parsed.matchedCandidate.trim();
          }
        } catch (_) {}
      }

      if (!applicantName) {
        const match = rawText.match(/"applicantName"\s*:\s*"([^"]+)"/);
        if (match) {
          applicantName = match[1].trim().toUpperCase();
        }
      }
      if (!matchedCandidate) {
        const matchCand = rawText.match(/"matchedCandidate"\s*:\s*"([^"]+)"/);
        if (matchCand && matchCand[1].toLowerCase() !== 'null') {
          matchedCandidate = matchCand[1].trim();
        }
      }
    }

    return res.json({ success: true, applicantName, matchedCandidate });
  } catch (err: any) {
    console.error('Error in /api/extract-pds-name:', err);
    return res.status(500).json({ success: false, error: err.message || 'Error sa pag-extract ng PDS name.' });
  }
});

// 2. SSE Stream for Real-time Multi-Device Sync
app.get('/api/sync/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  sseClients.push(res);

  req.on('close', () => {
    sseClients = sseClients.filter((c) => c !== res);
  });
});

// 3. Pull cloud data for an account or all data
app.get('/api/sync/pull', (req, res) => {
  const accountId = (req.query.accountId as string) || 'all';
  const db = loadCloudDb();

  if (accountId === 'all') {
    return res.json({ success: true, data: db.accounts, serverTime: db.lastServerUpdate });
  }

  const accountData = db.accounts[accountId] || {
    products: [],
    sales: [],
    utang: [],
    shifts: [],
    updatedAt: new Date().toISOString(),
  };

  res.json({ success: true, data: accountData, serverTime: db.lastServerUpdate });
});

// 4. Push / Sync endpoint: merges client data or queued offline items into Cloud DB
app.post('/api/sync/push', (req, res) => {
  try {
    const { accountId, products, sales, utang, shifts, deviceId } = req.body;
    if (!accountId) {
      return res.status(400).json({ success: false, error: 'Missing accountId' });
    }

    const db = loadCloudDb();
    const existing = db.accounts[accountId] || {
      products: [],
      sales: [],
      utang: [],
      shifts: [],
      updatedAt: new Date().toISOString(),
    };

    const nowIso = new Date().toISOString();

    // Smart merge products by id
    const productMap = new Map<string, any>();
    (existing.products || []).forEach((p: any) => productMap.set(p.id, p));
    if (Array.isArray(products)) {
      products.forEach((p: any) => {
        if (!p.id) return;
        const current = productMap.get(p.id);
        if (!current || new Date(p.updatedAt || 0) >= new Date(current.updatedAt || 0)) {
          productMap.set(p.id, p);
        }
      });
    }

    // Smart merge sales by id
    const salesMap = new Map<string, any>();
    (existing.sales || []).forEach((s: any) => salesMap.set(s.id, s));
    if (Array.isArray(sales)) {
      sales.forEach((s: any) => {
        if (!s.id) return;
        salesMap.set(s.id, s);
      });
    }

    // Smart merge utang records by id
    const utangMap = new Map<string, any>();
    (existing.utang || []).forEach((u: any) => utangMap.set(u.id, u));
    if (Array.isArray(utang)) {
      utang.forEach((u: any) => {
        if (!u.id) return;
        utangMap.set(u.id, u);
      });
    }

    // Smart merge shifts by id or timestamp
    const shiftMap = new Map<string, any>();
    (existing.shifts || []).forEach((sf: any) => shiftMap.set(sf.id || sf.timestamp, sf));
    if (Array.isArray(shifts)) {
      shifts.forEach((sf: any) => {
        const key = sf.id || sf.timestamp;
        if (key) shiftMap.set(key, sf);
      });
    }

    const updatedAccountData: AccountSyncData = {
      products: Array.from(productMap.values()),
      sales: Array.from(salesMap.values()).sort(
        (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      ),
      utang: Array.from(utangMap.values()).sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      ),
      shifts: Array.from(shiftMap.values()),
      updatedAt: nowIso,
    };

    db.accounts[accountId] = updatedAccountData;
    db.lastServerUpdate = nowIso;
    saveCloudDb(db);

    // Notify all connected devices via SSE
    broadcastDataUpdate(accountId, deviceId);

    return res.json({
      success: true,
      mergedData: updatedAccountData,
      serverTime: nowIso,
    });
  } catch (err: any) {
    console.error('Error processing push sync:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// 🚀 ONLINE CLOUD DATABASE FOR AI DOC EXTRACTOR
// (Account-isolated: Admin 1, Admin 2 & users have separate Cloud SQL & persistent databases)
// ==========================================
const DOC_EXTRACTOR_DB_FILE = path.join(DATA_DIR, 'doc-extractor-cloud-db.json');
let docExtractorSseClients: express.Response[] = [];

interface AccountDocExtractorState {
  activeTable: any;
  documents: any[];
  pdsPictures: any[];
  customHeaders: any[];
  updatedAt: string;
}

function loadDocExtractorCloudDb(): { accounts: Record<string, AccountDocExtractorState> } {
  try {
    if (fs.existsSync(DOC_EXTRACTOR_DB_FILE)) {
      const content = fs.readFileSync(DOC_EXTRACTOR_DB_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      if (parsed.accounts) {
        return parsed;
      }
      // Migrate legacy single store into 'user-admin1'
      return {
        accounts: {
          'user-admin1': {
            activeTable: parsed.activeTable || null,
            documents: parsed.documents || [],
            pdsPictures: parsed.pdsPictures || [],
            customHeaders: parsed.customHeaders || [],
            updatedAt: parsed.updatedAt || new Date().toISOString(),
          },
        },
      };
    }
  } catch (err) {
    console.error('Error reading doc extractor cloud DB file:', err);
  }
  return { accounts: {} };
}

function saveDocExtractorCloudDb(data: { accounts: Record<string, AccountDocExtractorState> }) {
  try {
    fs.writeFileSync(DOC_EXTRACTOR_DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving doc extractor cloud DB file:', err);
  }
}

// Store latest release data signals per account
const latestDesktopReleaseSignals: Record<string, any> = {};
const latestMobileReleaseSignals: Record<string, any> = {};

function broadcastDeviceReleaseSignal(accountId: string, signalData: any) {
  const target = signalData.targetDevice || 'desktop';
  if (target === 'desktop') {
    latestDesktopReleaseSignals[accountId] = signalData;
  } else {
    latestMobileReleaseSignals[accountId] = signalData;
  }

  const payload = JSON.stringify({
    type: target === 'mobile' ? 'MOBILE_RELEASE_SIGNAL' : 'DESKTOP_RELEASE_SIGNAL',
    accountId,
    targetDevice: target,
    signal: signalData,
    timestamp: new Date().toISOString(),
  });
  docExtractorSseClients.forEach((client) => {
    try {
      client.write(`data: ${payload}\n\n`);
    } catch (e) {}
  });
}

function broadcastDesktopReleaseSignal(accountId: string, signalData: any) {
  broadcastDeviceReleaseSignal(accountId, { ...signalData, targetDevice: 'desktop' });
}

function broadcastMobileReleaseSignal(accountId: string, signalData: any) {
  broadcastDeviceReleaseSignal(accountId, { ...signalData, targetDevice: 'mobile' });
}

function broadcastDocExtractorUpdate(accountId: string, updatedByDevice?: string) {
  const payload = JSON.stringify({
    type: 'DOC_EXTRACTOR_DATA_MUTATED',
    accountId,
    updatedByDevice,
    timestamp: new Date().toISOString(),
  });
  docExtractorSseClients.forEach((client) => {
    try {
      client.write(`data: ${payload}\n\n`);
    } catch (e) {}
  });
}

// Global System Sync Release endpoint
app.post('/api/sync/release-to-desktop', async (req, res) => {
  try {
    const rawAccountId = String(req.body.accountId || 'user-admin1').trim();
    const accountId = rawAccountId === 'user-admin' ? 'user-admin1' : rawAccountId;
    const { deviceId, deviceName, summary, dataBundle } = req.body;

    const signalData = {
      accountId,
      deviceId: deviceId || 'mobile_device',
      deviceName: deviceName || 'Mobile Phone / Handheld Device',
      timestamp: new Date().toISOString(),
      summary: summary || {
        productsCount: 0,
        salesCount: 0,
        tablesCount: 0,
        docsCount: 0,
      },
    };

    // If data bundle contains doc extractor data, save to docExtractorState
    if (dataBundle?.docExtractor) {
      const { activeTable, documents, pdsPictures, customHeaders } = dataBundle.docExtractor;
      const store = loadDocExtractorCloudDb();
      store.accounts[accountId] = {
        activeTable: activeTable || null,
        documents: Array.isArray(documents) ? documents : [],
        pdsPictures: Array.isArray(pdsPictures) ? pdsPictures : [],
        customHeaders: Array.isArray(customHeaders) ? customHeaders : [],
        updatedAt: new Date().toISOString(),
      };
      saveDocExtractorCloudDb(store);

      try {
        if (process.env.SQL_HOST) {
          const sqlId = `doc_extractor_${accountId}`;
          await db
            .insert(docExtractorState)
            .values({
              id: sqlId,
              activeTable: store.accounts[accountId].activeTable,
              pdsPictures: store.accounts[accountId].pdsPictures,
              documents: store.accounts[accountId].documents,
              customHeaders: store.accounts[accountId].customHeaders,
              updatedAt: new Date(),
            })
            .onConflictDoUpdate({
              target: docExtractorState.id,
              set: {
                activeTable: store.accounts[accountId].activeTable,
                pdsPictures: store.accounts[accountId].pdsPictures,
                documents: store.accounts[accountId].documents,
                customHeaders: store.accounts[accountId].customHeaders,
                updatedAt: new Date(),
              },
            });
        }
      } catch (sqlErr) {
        console.warn('[Cloud SQL] SQL update warning during desktop release:', sqlErr);
      }
    }

    broadcastDesktopReleaseSignal(accountId, signalData);
    broadcastDocExtractorUpdate(accountId, deviceId);

    return res.json({
      success: true,
      message: 'Data successfully released to desktop computer signal bus.',
      signal: signalData,
    });
  } catch (err: any) {
    console.error('Error in /api/sync/release-to-desktop:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Global System Sync Release endpoint for Mobile Device (PC -> Mobile)
app.post('/api/sync/release-to-mobile', async (req, res) => {
  try {
    const rawAccountId = String(req.body.accountId || 'user-admin1').trim();
    const accountId = rawAccountId === 'user-admin' ? 'user-admin1' : rawAccountId;
    const { deviceId, deviceName, summary, dataBundle } = req.body;

    const signalData = {
      accountId,
      targetDevice: 'mobile',
      deviceId: deviceId || 'desktop_computer',
      deviceName: deviceName || 'Desktop Computer / Laptop PC',
      timestamp: new Date().toISOString(),
      summary: summary || {
        productsCount: 0,
        salesCount: 0,
        tablesCount: 0,
        docsCount: 0,
      },
    };

    // If data bundle contains doc extractor data, save to docExtractorState
    if (dataBundle?.docExtractor) {
      const { activeTable, documents, pdsPictures, customHeaders } = dataBundle.docExtractor;
      const store = loadDocExtractorCloudDb();
      store.accounts[accountId] = {
        activeTable: activeTable || null,
        documents: Array.isArray(documents) ? documents : [],
        pdsPictures: Array.isArray(pdsPictures) ? pdsPictures : [],
        customHeaders: Array.isArray(customHeaders) ? customHeaders : [],
        updatedAt: new Date().toISOString(),
      };
      saveDocExtractorCloudDb(store);

      try {
        if (process.env.SQL_HOST) {
          const sqlId = `doc_extractor_${accountId}`;
          await db
            .insert(docExtractorState)
            .values({
              id: sqlId,
              activeTable: store.accounts[accountId].activeTable,
              pdsPictures: store.accounts[accountId].pdsPictures,
              documents: store.accounts[accountId].documents,
              customHeaders: store.accounts[accountId].customHeaders,
              updatedAt: new Date(),
            })
            .onConflictDoUpdate({
              target: docExtractorState.id,
              set: {
                activeTable: store.accounts[accountId].activeTable,
                pdsPictures: store.accounts[accountId].pdsPictures,
                documents: store.accounts[accountId].documents,
                customHeaders: store.accounts[accountId].customHeaders,
                updatedAt: new Date(),
              },
            });
        }
      } catch (sqlErr) {
        console.warn('[Cloud SQL] SQL update warning during mobile release:', sqlErr);
      }
    }

    broadcastMobileReleaseSignal(accountId, signalData);
    broadcastDocExtractorUpdate(accountId, deviceId);

    return res.json({
      success: true,
      message: 'Data successfully released to mobile device signal bus.',
      signal: signalData,
    });
  } catch (err: any) {
    console.error('Error in /api/sync/release-to-mobile:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/sync/desktop-release-status', (req, res) => {
  const rawAccountId = String(req.query.accountId || 'user-admin1').trim();
  const accountId = rawAccountId === 'user-admin' ? 'user-admin1' : rawAccountId;
  const signal = latestDesktopReleaseSignals[accountId] || null;
  return res.json({ success: true, accountId, signal });
});

app.get('/api/sync/mobile-release-status', (req, res) => {
  const rawAccountId = String(req.query.accountId || 'user-admin1').trim();
  const accountId = rawAccountId === 'user-admin' ? 'user-admin1' : rawAccountId;
  const signal = latestMobileReleaseSignals[accountId] || null;
  return res.json({ success: true, accountId, signal });
});

// 1. Doc Extractor SSE Live Stream
app.get('/api/doc-extractor/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  docExtractorSseClients.push(res);

  req.on('close', () => {
    docExtractorSseClients = docExtractorSseClients.filter((c) => c !== res);
  });
});

// 2. Doc Extractor Pull (Instant fetch from PostgreSQL Cloud SQL / disk cache per account)
app.get('/api/doc-extractor/pull', async (req, res) => {
  const rawAccountId = String(req.query.accountId || 'user-admin1').trim();
  const accountId = rawAccountId === 'user-admin' ? 'user-admin1' : rawAccountId;
  const sqlId = `doc_extractor_${accountId}`;

  try {
    if (process.env.SQL_HOST) {
      let rows = await db
        .select()
        .from(docExtractorState)
        .where(eq(docExtractorState.id, sqlId));

      if ((!rows || rows.length === 0) && (accountId === 'user-admin1' || accountId === 'user-admin')) {
        rows = await db
          .select()
          .from(docExtractorState)
          .where(eq(docExtractorState.id, 'global_master'));
      }

      if (rows && rows.length > 0 && rows[0]) {
        const state = rows[0];
        return res.json({
          success: true,
          accountId,
          source: 'cloudsql_postgresql',
          data: {
            activeTable: state.activeTable,
            pdsPictures: state.pdsPictures || [],
            documents: state.documents || [],
            customHeaders: state.customHeaders || [],
            updatedAt: state.updatedAt ? state.updatedAt.toISOString() : new Date().toISOString(),
          },
          serverTime: new Date().toISOString(),
        });
      }
    }
  } catch (sqlErr) {
    console.warn('[Cloud SQL] Pull notice, using cached storage:', sqlErr);
  }

  const dbData = loadDocExtractorCloudDb();
  const accountState = dbData.accounts[accountId] || {
    activeTable: null,
    documents: [],
    pdsPictures: [],
    customHeaders: [],
    updatedAt: new Date().toISOString(),
  };

  return res.json({
    success: true,
    accountId,
    source: 'cloud_cache',
    data: accountState,
    serverTime: new Date().toISOString(),
  });
});

// 3. Doc Extractor Push (Save to PostgreSQL Cloud SQL & broadcast for isolated account)
app.post('/api/doc-extractor/push', async (req, res) => {
  try {
    const { activeTable, documents, pdsPictures, customHeaders, deviceId } = req.body;
    const rawAccountId = String(req.body.accountId || 'user-admin1').trim();
    const accountId = rawAccountId === 'user-admin' ? 'user-admin1' : rawAccountId;
    const sqlId = `doc_extractor_${accountId}`;

    const store = loadDocExtractorCloudDb();
    const current = store.accounts[accountId] || {
      activeTable: null,
      documents: [],
      pdsPictures: [],
      customHeaders: [],
      updatedAt: new Date().toISOString(),
    };
    const nowIso = new Date().toISOString();

    const updatedAccountState: AccountDocExtractorState = {
      activeTable: activeTable !== undefined ? activeTable : current.activeTable,
      documents: Array.isArray(documents) ? documents : current.documents || [],
      pdsPictures: Array.isArray(pdsPictures) ? pdsPictures : current.pdsPictures || [],
      customHeaders: Array.isArray(customHeaders) ? customHeaders : current.customHeaders || [],
      updatedAt: nowIso,
    };

    store.accounts[accountId] = updatedAccountState;
    saveDocExtractorCloudDb(store);

    // Save to Cloud SQL PostgreSQL
    try {
      if (process.env.SQL_HOST) {
        await db
          .insert(docExtractorState)
          .values({
            id: sqlId,
            activeTable: updatedAccountState.activeTable,
            pdsPictures: updatedAccountState.pdsPictures,
            documents: updatedAccountState.documents,
            customHeaders: updatedAccountState.customHeaders,
            updatedAt: new Date(),
          })
          .onConflictDoUpdate({
            target: docExtractorState.id,
            set: {
              activeTable: updatedAccountState.activeTable,
              pdsPictures: updatedAccountState.pdsPictures,
              documents: updatedAccountState.documents,
              customHeaders: updatedAccountState.customHeaders,
              updatedAt: new Date(),
            },
          });
      }
    } catch (sqlErr) {
      console.error('[Cloud SQL] Push error:', sqlErr);
    }

    broadcastDocExtractorUpdate(accountId, deviceId);

    return res.json({
      success: true,
      accountId,
      source: 'cloudsql_postgresql',
      data: updatedAccountState,
      serverTime: nowIso,
    });
  } catch (err: any) {
    console.error('Error in /api/doc-extractor/push:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Doc Extractor Clear
app.post('/api/doc-extractor/clear', async (req, res) => {
  try {
    const rawAccountId = String(req.body.accountId || 'user-admin1').trim();
    const accountId = rawAccountId === 'user-admin' ? 'user-admin1' : rawAccountId;
    const sqlId = `doc_extractor_${accountId}`;
    const { deviceId } = req.body;

    const store = loadDocExtractorCloudDb();
    const cleared: AccountDocExtractorState = {
      activeTable: null,
      documents: [],
      pdsPictures: [],
      customHeaders: [],
      updatedAt: new Date().toISOString(),
    };
    store.accounts[accountId] = cleared;
    saveDocExtractorCloudDb(store);

    try {
      if (process.env.SQL_HOST) {
        await db
          .insert(docExtractorState)
          .values({
            id: sqlId,
            activeTable: null,
            pdsPictures: [],
            documents: [],
            customHeaders: [],
            updatedAt: new Date(),
          })
          .onConflictDoUpdate({
            target: docExtractorState.id,
            set: {
              activeTable: null,
              pdsPictures: [],
              documents: [],
              customHeaders: [],
              updatedAt: new Date(),
            },
          });
      }
    } catch (sqlErr) {}

    broadcastDocExtractorUpdate(accountId, deviceId);
    return res.json({ success: true, accountId });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

async function startServer() {
  // Vite middleware setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[TindahanPOS Cloud Sync Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
